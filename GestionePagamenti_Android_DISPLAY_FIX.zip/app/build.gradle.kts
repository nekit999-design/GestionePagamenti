plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.gestionescadenze"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.gestionescadenze.v20"
        minSdk = 26
        targetSdk = 34
        versionCode = 20
        versionName = "2.0.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlin {
        jvmToolchain(17)
    }
}
