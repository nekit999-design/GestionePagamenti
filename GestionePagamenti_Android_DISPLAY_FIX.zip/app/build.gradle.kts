plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.gestionescadenze"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.gestionescadenze"
        minSdk = 26
        targetSdk = 34

    buildFeatures {
        buildConfig = true
    }
        versionCode = 152
        versionName = "1.5.2"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlin {
        jvmToolchain(17)
    }
}
