plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.gestionescadenze"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.gestionescadenze"
        minSdk = 26
        targetSdk = 34
        versionCode = 177
        versionName = "1.5.55"
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlin {
        jvmToolchain(17)
    }
}
