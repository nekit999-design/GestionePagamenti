package com.example.gestionescadenze

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable

/**
 * Visual layer dedicated exclusively to the Calendar.
 *
 * This class intentionally does not know anything about packages, payments,
 * dialogs or session counting. It only translates the currently selected
 * visual profile into Calendar surfaces.
 */
object CalendarGlassStyle {
    private fun dp(context: Context, value: Int): Int =
        (value * context.resources.displayMetrics.density + 0.5f).toInt()

    fun surface(
        context: Context,
        effect: String,
        color: Int,
        radius: Int = 16,
        strokeColor: Int = Color.TRANSPARENT,
        strokeWidth: Int = 1
    ): GradientDrawable {
        if (effect == "NONE") {
            return GradientDrawable().apply {
                setColor(color)
                cornerRadius = dp(context, radius).toFloat()
                if (strokeWidth > 0) setStroke(dp(context, strokeWidth), strokeColor)
            }
        }
        val a = when (effect) {
            "SATIN" -> 226
            "VETRO_SOFT" -> 190
            "LIQUID" -> 148
            else -> 220
        }
        val edge = when (effect) {
            "SATIN" -> if (strokeColor == Color.TRANSPARENT) Color.rgb(218,228,239) else strokeColor
            "VETRO_SOFT", "LIQUID" -> Color.argb(155,175,215,248)
            else -> strokeColor
        }
        return GradientDrawable().apply {
            cornerRadius = dp(context, radius).toFloat()
            when (effect) {
                "LIQUID" -> setColors(intArrayOf(
                    Color.argb(a, Color.red(color), Color.green(color), Color.blue(color)),
                    Color.argb((a * 0.78f).toInt(), minOf(255, Color.red(color)+12), minOf(255, Color.green(color)+16), minOf(255, Color.blue(color)+20)),
                    Color.argb((a * 0.90f).toInt(), Color.red(color), Color.green(color), Color.blue(color))
                ))
                "VETRO_SOFT" -> setColors(intArrayOf(
                    Color.argb(a, Color.red(color), Color.green(color), Color.blue(color)),
                    Color.argb((a * 0.90f).toInt(), minOf(255, Color.red(color)+8), minOf(255, Color.green(color)+10), minOf(255, Color.blue(color)+14))
                ))
                else -> setColor(Color.argb(a, Color.red(color), Color.green(color), Color.blue(color)))
            }
            if (strokeWidth > 0) setStroke(dp(context, strokeWidth), edge)
        }
    }

    fun background(context: Context, effect: String): Drawable = when (effect) {
        "SATIN" -> GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
            Color.rgb(244,247,251), Color.rgb(232,239,247), Color.rgb(244,247,251)
        ))
        "VETRO_SOFT" -> GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
            Color.rgb(232,241,250), Color.rgb(211,226,241), Color.rgb(238,245,251)
        ))
        "LIQUID" -> GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
            Color.rgb(217,232,246), Color.rgb(231,226,246), Color.rgb(211,239,245), Color.rgb(237,229,239)
        ))
        else -> ColorDrawable(Color.rgb(247,248,250))
    }
}
