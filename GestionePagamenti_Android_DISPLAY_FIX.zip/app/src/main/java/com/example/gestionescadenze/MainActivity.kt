package com.example.gestionescadenze

import android.app.*
import android.content.Intent
import android.content.Context
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Color
import android.graphics.RectF
import android.graphics.LinearGradient
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Path
import android.net.Uri
import android.provider.MediaStore
import android.content.ContentValues
import android.provider.Settings
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.Paint
import android.graphics.Canvas
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import android.text.Editable
import android.text.TextWatcher
import java.io.BufferedReader
import java.io.InputStreamReader
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters
import kotlin.math.roundToInt

private data class Pack(var name: String, val start: LocalDate, val total: Int, var paid: Int = 0, var customRates: MutableList<Int>? = null, var packageType: String = "PERSONALIZZATO", var sessionTotal: Int = 12, var active: Boolean = true, var missedSessions: Int = 0)
private data class SessionPack(
    val id: Long,
    var name: String,
    val start: LocalDate,
    val totalSessions: Int,
    val cost: Int,
    var paid: Int = 0,
    var active: Boolean = true,
    var customRates: MutableList<Int>? = null
)
private data class TrashItem(val id:Long, val kind:String, val deletedAt:LocalDateTime, val payload:String)
private data class AppointmentType(var id:String, var name:String, var color:Int, var duration:Int = 45)
private data class CalendarRoutine(var name:String, var maxTotal:Int, var maxByType:MutableList<Int>)

private data class Appointment(
    val id: Long,
    var name: String,
    var date: LocalDate,
    var time: String,
    var type: String,
    var seriesId: Long = 0L,
    var sessionPackId: Long = 0L,
    var recovery: Boolean = false
) {
    val duration: Int get() = if (type == "TYPE2") 30 else 45
}

class MainActivity : Activity() {
    private val fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy")
    private val timeFmt = DateTimeFormatter.ofPattern("HH:mm")
    private val packs = mutableListOf<Pack>()
    private val sessionPacks = mutableListOf<SessionPack>()
    private val appointments = mutableListOf<Appointment>()
    private val trashItems = mutableListOf<TrashItem>()
    private var ferieStart: LocalDate? = null
    private var ferieEnd: LocalDate? = null
    private lateinit var list: LinearLayout
    private var dashboardEnabled = false
    private var homeSortMode = 0
    private lateinit var searchInput: EditText
    private lateinit var searchList: LinearLayout
    private var calendarWeekStart: LocalDate = LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    private var nextAppointmentId = 1L
    private var nextSessionPackId = 1L
    private var nextTrashId = 1L
    private var calendarZoom = 1.0f
    private var calendarVisibleDays = booleanArrayOf(true,true,true,true,true,false,false)
    private var calendarAutoFocusOnOpen = true
    private var calendarScrollX = 0
    private var calendarScrollY = 0
    private var calendarSwipeArmed = 0
    private var calendarWeekAnimationDirection = 0
    private var calendarNavPosition = 1 // legacy: 0 = sotto il titolo, 1 = in basso
    private var calendarNavOrder = mutableListOf("PREV", "SEARCH", "TODAY", "NEXT") // legacy
    private var calendarTopButtons = mutableListOf("APPT")
    private var calendarBottomButtons = mutableListOf("SEARCH", "TODAY", "PREV", "NEXT")
    private val appointmentTypes = mutableListOf(
        AppointmentType("TYPE1","ALLENAMENTO",Color.rgb(45,135,210),45),
        AppointmentType("TYPE2","MEZZ'ORA",Color.rgb(215,55,55),30)
    )
    private val calendarRoutines = mutableListOf(
        CalendarRoutine("Standard",3,mutableListOf(2,3)),
        CalendarRoutine("Light",2,mutableListOf(1,2)),
        CalendarRoutine("Full",4,mutableListOf(3,4))
    )
    private var activeRoutineIndex = 0
    private var surnameFirstDisplay = true
    private var pendingSummaryText = ""
    private val expandedClients = mutableSetOf<String>()
    private var activePackageDialog: AlertDialog? = null
    private var settingsTransitionPending = false
    private var settingsOverlay: FrameLayout? = null
    private var settingsOverlayContent: View? = null
    private var settingsSubpageOverlay: FrameLayout? = null
    private var trashReturnToSettings = false
    // Effetti visivi popup.
    // effect: NONE, SATIN, VETRO_SOFT, LIQUID; mode: CONTOUR (finestra nitida) o IMMERSIVE.
    private var popupBackdropEffect = "NONE"
    private var popupBackdropMode = "CONTOUR"
    private var popupBackdropIntensity = 65
    // Personalizzazione calendario: completamente separata dagli effetti delle finestre pop-up.
    // Il set attivo decide quale configurazione geometrica/cromatica usare per il calendario.
    // Ogni set possiede i propri parametri: modificare Liquid Glass non modifica Base o gli altri set.
    private var calendarStyleSet = "LIQUID_GLASS"
    // Parametri esclusivi del set LIQUID_GLASS per gli slot grandi.
    // Il default segue il nuovo riferimento visivo Liquid Glass; Base e Stile 3
    // avranno in seguito i propri parametri senza riutilizzare questi valori.
    private var liquidGlassSlotShape = "ARROTONDATO"
    private var liquidGlassSlotColor = Color.rgb(224,228,232)

    // Materiale dell'appuntamento: resta indipendente dalla geometria dello slot grande.
    // WATER = gel/acqua; SIDE_LIGHT = vetro con luce laterale guidata dal colore del tipo.
    private var calendarMaterialEffect = "WATER"
    private var calendarMaterialIntensity = 82
    private var popupBackdropOverlay: View? = null
    private var popupBackdropTarget: View? = null
    private var popupBackdropCurrentDialog: Dialog? = null
    private val popupBackdropDialogs = mutableListOf<Dialog>()
    private var popupDialogGlassOverlay: View? = null
    private val popupDialogOriginalBackgrounds = mutableMapOf<View, Drawable?>()
    private val popupDialogOriginalWindowBackgrounds = mutableMapOf<Dialog, Drawable?>()
    private var currentScreen = "HOME"

    private inner class CalendarHorizontalScrollView(context: Context) : HorizontalScrollView(context) {
        var onEdgeWeekChange: ((Int) -> Unit)? = null
        private var downX = 0f
        private var lastX = 0f
        private var edgeOverscroll = 0f
        private var edgeDirection = 0
        private var transitionSent = false
        private var edgeGesture = false
        private var touchChild: View? = null
        // Soglia ridotta: il cambio settimana deve scattare con uno swipe breve,
        // così non è necessario arrivare vicino al bordo fisico dello schermo.
        private val weekSwipeTriggerDp = 36

        private fun edgeState(): Int {
            val maxX = (getChildAt(0)?.width?.minus(width) ?: 0).coerceAtLeast(0)
            return when {
                scrollX <= dp(2) -> -1   // left edge: right swipe = previous week
                scrollX >= maxX - dp(2) -> 1 // right edge: left swipe = next week
                else -> 0
            }
        }

        private fun resetEdgeStretch(animate: Boolean) {
            val child = touchChild ?: getChildAt(0)
            if (animate) child?.animate()?.translationX(0f)?.setDuration(140)?.start()
            else child?.translationX = 0f
            edgeOverscroll = 0f
            edgeDirection = 0
            edgeGesture = false
        }

        override fun onInterceptTouchEvent(event: android.view.MotionEvent): Boolean {
            when (event.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    downX = event.x
                    lastX = event.x
                    edgeGesture = false
                    transitionSent = false
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    val dx = event.x - downX
                    val slop = android.view.ViewConfiguration.get(context).scaledTouchSlop
                    if (!edgeGesture && kotlin.math.abs(dx) > slop) {
                        val edge = edgeState()
                        val outward = (edge == -1 && dx > 0f) || (edge == 1 && dx < 0f)
                        if (outward) {
                            // Take ownership of the gesture as soon as an outward
                            // drag starts at an edge. This prevents child views from
                            // swallowing the gesture and makes the gesture work from
                            // the whole calendar surface, not only near the screen edge.
                            edgeGesture = true
                            lastX = event.x
                            touchChild = getChildAt(0)
                            touchChild?.animate()?.cancel()
                            touchChild?.translationX = 0f
                            return true
                        }
                    }
                }
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                    edgeGesture = false
                }
            }
            return if (edgeGesture) true else super.onInterceptTouchEvent(event)
        }

        override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
            val child = getChildAt(0)
            when (event.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    downX = event.x
                    lastX = event.x
                    edgeOverscroll = 0f
                    edgeDirection = 0
                    transitionSent = false
                    edgeGesture = false
                    touchChild = child
                    child?.animate()?.cancel()
                    child?.translationX = 0f
                }

                android.view.MotionEvent.ACTION_MOVE -> {
                    val dx = event.x - lastX
                    val edge = edgeState()

                    if (edgeGesture) {
                        val outward = (edge == -1 && dx > 0f) || (edge == 1 && dx < 0f)
                        if (outward && !transitionSent) {
                            val sign = if (dx > 0f) 1 else -1
                            if (edgeDirection == 0 || edgeDirection == sign) {
                                edgeDirection = sign
                                edgeOverscroll += kotlin.math.abs(dx)
                            } else {
                                edgeOverscroll = 0f
                                edgeDirection = sign
                            }

                            val resistance = 0.32f
                            val stretch = (edgeOverscroll * resistance).coerceAtMost(dp(54).toFloat())
                            child?.translationX = if (edge == -1) stretch else -stretch

                            if (edgeOverscroll >= dp(weekSwipeTriggerDp)) {
                                transitionSent = true
                                child?.animate()?.translationX(0f)?.setDuration(90)?.start()
                                // Physical direction is authoritative:
                                // right swipe at left edge -> previous week (-1)
                                // left swipe at right edge -> next week (+1)
                                onEdgeWeekChange?.invoke(if (edge == -1) -1 else 1)
                                edgeOverscroll = 0f
                                edgeDirection = 0
                            }
                        } else if (!transitionSent) {
                            edgeOverscroll = (edgeOverscroll - kotlin.math.abs(dx) * 1.5f).coerceAtLeast(0f)
                            val resistance = 0.32f
                            val stretch = (edgeOverscroll * resistance).coerceAtMost(dp(54).toFloat())
                            child?.translationX = if (edge == -1) stretch else -stretch
                        }
                        lastX = event.x
                        return true
                    }

                    lastX = event.x
                }

                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                    if (edgeGesture) {
                        if (!transitionSent) resetEdgeStretch(true) else resetEdgeStretch(false)
                        transitionSent = false
                        touchChild = null
                        return true
                    }
                }
            }
            return super.onTouchEvent(event)
        }
    }

    companion object {
        private const val REQ_EXPORT = 1001
        private const val REQ_IMPORT = 1002
        private const val REQ_SUMMARY = 1003
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        // CoachFlow usa una superficie edge-to-edge: lo sfondo dell'app continua
        // dietro status bar e barra di navigazione, mentre i contenuti ricevono
        // gli inset necessari per non finire sotto le barre di sistema.
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (android.os.Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(false)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        loadData()
        purgeExpiredTrash()
        saveData()
        maybeAutoBackup()
        build()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (settingsSubpageOverlay != null) {
            closeSettingsSubpage()
            return
        }
        if (trashReturnToSettings) {
            trashReturnToSettings = false
            settings()
            return
        }
        if (settingsOverlay != null) {
            settingsOverlay?.animate()?.cancel()
            settingsOverlayContent?.animate()?.cancel()
            detachSettingsOverlay()
            restoreHomeSystemBars()
            build()
            return
        }
        if (currentScreen == "CALENDAR") {
            build()
            return
        }
        super.onBackPressed()
    }

    private fun prepareEdgeToEdgeRoot(root: View) {
        val baseLeft = root.paddingLeft
        val baseTop = root.paddingTop
        val baseRight = root.paddingRight
        val baseBottom = root.paddingBottom
        root.setOnApplyWindowInsetsListener { v, insets ->
            val bars = if (android.os.Build.VERSION.SDK_INT >= 30) {
                insets.getInsets(android.view.WindowInsets.Type.systemBars())
            } else {
                android.graphics.Insets.of(
                    insets.systemWindowInsetLeft,
                    insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight,
                    insets.systemWindowInsetBottom
                )
            }
            v.setPadding(baseLeft, baseTop + bars.top, baseRight, baseBottom + bars.bottom)
            insets
        }
        root.requestApplyInsets()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()
    private fun dpf(value: Float): Float = value * resources.displayMetrics.density

    /**
     * Crea un vero livello "vetro" dietro la finestra popup.
     * La finestra/dialog rimane una Window separata e quindi resta perfettamente nitida.
     * Su Android 12+ il contenuto dell'Activity viene sfocato con RenderEffect;
     * sotto Android 12 manteniamo il fallback al solo dim nativo.
     */
    private fun popupBlurRadiusDp(): Int {
        val intensity = popupBackdropIntensity.coerceIn(0, 100) / 100f
        val base = when (popupBackdropEffect) {
            // Resa precedente, mantenuta invariata: ora si chiama Satinato.
            "SATIN" -> 24
            // Resa dell'attuale Liquid Glass, conservata e rinominata Vetro Soft.
            "VETRO_SOFT" -> 10
            // Nuovo Liquid Glass ultra-trasparente: vetro leggero, poca distorsione e massima leggibilità del fondo.
            "LIQUID" -> 4
            else -> 0
        }
        return (base * intensity).roundToInt().coerceIn(0, base)
    }

    private fun savePopupVisualPreferences() {
        getSharedPreferences("gestione_pagamenti", MODE_PRIVATE).edit()
            .putString("popupBackdropEffect", popupBackdropEffect)
            .putString("popupBackdropMode", popupBackdropMode)
            .putInt("popupBackdropIntensity", popupBackdropIntensity)
            .apply()
    }

    /** Applica la trasparenza immersiva alle superfici bianche interne, comprese quelle
     * contenute dentro ScrollView/NestedScrollView. I controlli interattivi restano invariati. */
    private fun applyImmersiveSurfaces(view: View) {
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) applyImmersiveSurfaces(view.getChildAt(i))
        }
        if (view is Button || view is EditText || view is Spinner || view is SeekBar ||
            view is RadioButton || view is CheckBox || view is AutoCompleteTextView) return
        val bg = view.background ?: return
        if (bg is android.graphics.drawable.GradientDrawable) {
            val c = bg.color?.defaultColor
            if (c != null && android.graphics.Color.red(c) >= 235 &&
                android.graphics.Color.green(c) >= 235 && android.graphics.Color.blue(c) >= 235) {
                // Solo la superficie: niente modifica ai bordi o ai colori dei controlli.
                bg.alpha = 150
            }
        } else if (bg is android.graphics.drawable.ColorDrawable) {
            val c = bg.color
            if (android.graphics.Color.red(c) >= 235 && android.graphics.Color.green(c) >= 235 &&
                android.graphics.Color.blue(c) >= 235) {
                bg.alpha = 150
            }
        }
    }

    private fun applyPopupBackdropEffect(currentDialog: Dialog? = popupBackdropCurrentDialog) {
        if (currentDialog != null && !popupBackdropDialogs.contains(currentDialog)) popupBackdropDialogs.add(currentDialog)
        popupBackdropCurrentDialog = currentDialog ?: popupBackdropDialogs.lastOrNull()
        val activeDialog = popupBackdropCurrentDialog
        if (popupBackdropEffect == "NONE") { clearPopupBackdropEffect(); return }

        val stackIndex = activeDialog?.let { popupBackdropDialogs.indexOf(it) } ?: -1
        val underlyingDialog = if (stackIndex > 0) popupBackdropDialogs[stackIndex - 1] else null
        val underlyingDecor = underlyingDialog?.window?.decorView as? ViewGroup
        val root: ViewGroup = underlyingDecor?.findViewById<ViewGroup>(android.R.id.content)
            ?: underlyingDecor
            ?: findViewById<ViewGroup>(android.R.id.content)
            ?: return

        clearPopupBackdropEffect()
        val target: View = root.getChildAt(0) ?: root
        popupBackdropTarget = target
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            val radius = popupBlurRadiusDp()
            if (radius > 0) target.setRenderEffect(android.graphics.RenderEffect.createBlurEffect(dp(radius).toFloat(), dp(radius).toFloat(), android.graphics.Shader.TileMode.CLAMP))
        }

        val intensity = popupBackdropIntensity.coerceIn(0,100) / 100f
        val satin = popupBackdropEffect == "SATIN"
        val softGlass = popupBackdropEffect == "VETRO_SOFT"
        val liquid = popupBackdropEffect == "LIQUID"
        val alpha = when {
            satin -> (52 * intensity).roundToInt().coerceIn(0,70)
            softGlass -> (28 * intensity).roundToInt().coerceIn(0,48)
            liquid -> (7 * intensity).roundToInt().coerceIn(0,16)
            else -> 0
        }
        val overlay = View(this).apply {
            background = when {
                satin -> android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(alpha,248,251,255))
                softGlass -> {
                    val softA = alpha.coerceAtLeast(8)
                    android.graphics.drawable.GradientDrawable(
                        android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                        intArrayOf(
                            android.graphics.Color.argb(softA + 8, 190, 222, 255),
                            android.graphics.Color.argb(softA, 235, 247, 255),
                            android.graphics.Color.argb((softA * 0.45f).roundToInt(), 255, 255, 255)
                        )
                    )
                }
                liquid -> android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                    intArrayOf(
                        android.graphics.Color.argb(alpha + 4, 150, 205, 255),
                        android.graphics.Color.argb(alpha + 2, 230, 244, 255),
                        android.graphics.Color.argb((alpha * 0.12f).roundToInt(), 255, 255, 255),
                        android.graphics.Color.argb(alpha + 2, 190, 225, 255)
                    )
                )
                else -> null
            }
            isClickable=false; isFocusable=false
        }
        root.addView(overlay, 0, ViewGroup.LayoutParams(-1,-1))
        popupBackdropOverlay = overlay

        // Immersivo: la finestra stessa diventa una superficie vetro traslucida.
        // Il contenuto resta nitido, ma lo sfondo della popup lascia filtrare
        // il livello sottostante: in questo modo la differenza con Contorno è reale.
        if (popupBackdropMode == "IMMERSIVE" && activeDialog?.window != null) {
            val window = activeDialog.window!!
            val content = window.findViewById<ViewGroup>(android.R.id.content)
            val panel = content?.getChildAt(0)
            if (panel != null) {
                if (!popupDialogOriginalBackgrounds.containsKey(panel)) {
                    popupDialogOriginalBackgrounds[panel] = panel.background?.constantState?.newDrawable()?.mutate() ?: panel.background
                }
                if (!popupDialogOriginalWindowBackgrounds.containsKey(activeDialog)) {
                    popupDialogOriginalWindowBackgrounds[activeDialog] = window.decorView.background?.constantState?.newDrawable()?.mutate() ?: window.decorView.background
                }
                val glass = android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                    when {
                        liquid -> intArrayOf(
                            android.graphics.Color.argb((92 + 62 * intensity).roundToInt().coerceIn(92,154), 178, 218, 250),
                            android.graphics.Color.argb((72 + 52 * intensity).roundToInt().coerceIn(72,124), 245, 250, 255),
                            android.graphics.Color.argb((86 + 58 * intensity).roundToInt().coerceIn(86,144), 188, 225, 250)
                        )
                        softGlass -> intArrayOf(
                            android.graphics.Color.argb((150 + 55 * intensity).roundToInt().coerceIn(150,205), 222, 239, 253),
                            android.graphics.Color.argb((132 + 48 * intensity).roundToInt().coerceIn(132,180), 252, 253, 255),
                            android.graphics.Color.argb((145 + 52 * intensity).roundToInt().coerceIn(145,197), 218, 235, 251)
                        )
                        else -> intArrayOf(
                            android.graphics.Color.argb((178 + 45 * intensity).roundToInt().coerceIn(178,223), 238, 245, 252),
                            android.graphics.Color.argb((160 + 42 * intensity).roundToInt().coerceIn(160,202), 255, 255, 255),
                            android.graphics.Color.argb((174 + 44 * intensity).roundToInt().coerceIn(174,218), 230, 240, 250)
                        )
                    }
                )
                glass.cornerRadius = dp(28).toFloat()
                val edgeAlpha = (55 + 60 * intensity).roundToInt().coerceIn(55,115)
                glass.setStroke(dp(1), android.graphics.Color.argb(edgeAlpha, 170, 215, 255))
                panel.background = glass
                window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))
                // Importante: la pagina può contenere ScrollView con card create separatamente.
                // Rendiamo trasparenti anche quelle superfici, così lo scrolling non scopre zone bianche.
                applyImmersiveSurfaces(panel)
                popupDialogGlassOverlay = panel
            }
        }
    }
    private fun clearPopupBackdropEffect() {
        popupBackdropOverlay?.let { (it.parent as? ViewGroup)?.removeView(it) }
        popupBackdropOverlay = null
        popupDialogGlassOverlay?.let { panel ->
            popupDialogOriginalBackgrounds.remove(panel)?.let { original -> panel.background = original }
        }
        popupDialogGlassOverlay = null
        popupDialogOriginalWindowBackgrounds.forEach { (dialog, original) ->
            if (dialog.isShowing) dialog.window?.setBackgroundDrawable(original)
        }
        popupDialogOriginalWindowBackgrounds.clear()
        popupBackdropTarget?.setRenderEffect(null)
        popupBackdropTarget = null
    }

    private fun removePopupBackdropDialog(dialog: Dialog) {
        popupBackdropDialogs.remove(dialog)
        if (popupBackdropCurrentDialog === dialog) popupBackdropCurrentDialog = popupBackdropDialogs.lastOrNull()
        clearPopupBackdropEffect()
        if (popupBackdropEffect != "NONE" && popupBackdropCurrentDialog != null) applyPopupBackdropEffect(popupBackdropCurrentDialog)
    }

    private fun preparePopupBackdrop(dialog: Dialog) {
        dialog.setOnDismissListener { removePopupBackdropDialog(dialog) }
    }

    private fun clientNameAutoCompleteAdapter(items: List<String>): ArrayAdapter<String> =
        object : ArrayAdapter<String>(this, 0, items) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = (convertView as? TextView) ?: TextView(this@MainActivity)
                v.text = getItem(position) ?: ""
                v.textSize = 16f
                v.setTextColor(Color.rgb(24,31,40))
                v.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                v.gravity = Gravity.CENTER_VERTICAL
                v.setPadding(dp(16), 0, dp(16), 0)
                v.background = ColorDrawable(Color.TRANSPARENT)
                v.layoutParams = AbsListView.LayoutParams(-1, dp(48))
                return v
            }
        }

    private fun styleClientNameSuggestions(field: AutoCompleteTextView) {
        field.setDropDownBackgroundDrawable(
            liquidInteractiveSurface(Color.rgb(248,249,251), 20, Color.rgb(220,226,234), 1)
        )
        field.dropDownVerticalOffset = dp(4)
        field.dropDownHorizontalOffset = 0
        field.dropDownWidth = ViewGroup.LayoutParams.MATCH_PARENT
        field.elevation = dp(2).toFloat()
    }

    private fun centeredSpinnerAdapter(items: List<String>): ArrayAdapter<String> =
        object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            init { setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent)
                (v as? TextView)?.apply { gravity = Gravity.CENTER; setTextColor(Color.rgb(24,31,40)); typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL) }
                return v
            }
            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getDropDownView(position, convertView, parent)
                (v as? TextView)?.apply { gravity = Gravity.CENTER; setTextColor(Color.rgb(24,31,40)); typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL) }
                return v
            }
        }
    // Selettore orario Niki UI: un unico pannello arrotondato, senza righe/pillole separate.
    private fun installNikiTimeDropdown(spinner: Spinner, centerOverAnchor: Boolean = false) {
        spinner.setOnTouchListener { v, event ->
            if (event.action != android.view.MotionEvent.ACTION_UP) return@setOnTouchListener true
            val adapter = spinner.adapter ?: return@setOnTouchListener true
            if (adapter.count == 0) return@setOnTouchListener true

            val content = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(6), dp(6), dp(6), dp(6))
                setBackgroundColor(Color.TRANSPARENT)
            }
            val scroll = ScrollView(this).apply {
                isFillViewport = false
                overScrollMode = View.OVER_SCROLL_NEVER
                setBackgroundColor(Color.TRANSPARENT)
            }
            scroll.addView(content, ViewGroup.LayoutParams(-1, -2))

            var popup: PopupWindow? = null
            for (i in 0 until adapter.count) {
                val label = adapter.getItem(i)?.toString() ?: continue
                val row = TextView(this).apply {
                    text = label
                    textSize = 16.5f
                    setTextColor(Color.rgb(24, 31, 40))
                    typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(14), 0, dp(14), 0)
                    background = liquidInteractiveSurface(
                        if (i == spinner.selectedItemPosition) Color.rgb(232, 243, 255) else Color.rgb(248,249,251),
                        16, Color.rgb(210,226,242), 1
                    )
                    applyLiquidControlDepth(this)
                    isClickable = true
                    setOnClickListener {
                        spinner.setSelection(i)
                        popup?.dismiss()
                    }
                }
                content.addView(row, LinearLayout.LayoutParams(-1, dp(44)).apply {
                    if (i > 0) setMargins(0, dp(1), 0, 0)
                })
            }

            val maxHeight = dp(360)
            val popupW = if (centerOverAnchor) v.width.coerceAtLeast(dp(84)) else dp(220)
            content.measure(
                View.MeasureSpec.makeMeasureSpec(popupW - dp(12), View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(maxHeight - dp(12), View.MeasureSpec.AT_MOST)
            )
            val popupH = content.measuredHeight.coerceIn(dp(52), maxHeight)
            popup = PopupWindow(scroll, popupW, popupH, true).apply {
                setBackgroundDrawable(liquidInteractiveSurface(Color.WHITE, 24, Color.rgb(190,220,246), 1))
                elevation = dp(12).toFloat()
                isOutsideTouchable = true
                isFocusable = true
                setOnDismissListener { spinner.clearFocus() }
            }

            val location = IntArray(2)
            v.getLocationOnScreen(location)
            val screenH = resources.displayMetrics.heightPixels
            if (centerOverAnchor) {
                // Il pannello orari ha la stessa larghezza dello slot e il suo centro
                // coincide esattamente con il centro dello slot da cui viene aperto.
                val x = location[0] + (v.width - popupW) / 2
                val y = location[1] + (v.height - popupH) / 2
                val clampedX = x.coerceIn(dp(8), resources.displayMetrics.widthPixels - popupW - dp(8))
                val clampedY = y.coerceIn(dp(12), screenH - popupH - dp(12))
                popup.showAtLocation(v, Gravity.TOP or Gravity.START, clampedX, clampedY)
            } else {
                val gapPx = dp(4)
                val belowY = location[1] + v.height + gapPx
                val fitsBelow = belowY + popupH <= screenH - dp(12)
                val xOffset = ((v.width - popupW) / 2).coerceIn(-dp(24), dp(24))
                if (fitsBelow) popup.showAsDropDown(v, xOffset, gapPx)
                else popup.showAsDropDown(v, xOffset, -(v.height + popupH + gapPx))
            }
            true
        }
    }
    // Selettore tipo appuntamento Niki UI: stesso pannello flottante del selettore orari.
    private fun installNikiTypeDropdown(spinner: Spinner, centerOnSpinner: Boolean = false) {
        spinner.setOnTouchListener { v, event ->
            if (event.action != android.view.MotionEvent.ACTION_UP) return@setOnTouchListener true
            val adapter = spinner.adapter ?: return@setOnTouchListener true
            if (adapter.count == 0) return@setOnTouchListener true

            val content = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(6), dp(6), dp(6), dp(6))
                setBackgroundColor(Color.TRANSPARENT)
            }
            val scroll = ScrollView(this).apply {
                overScrollMode = View.OVER_SCROLL_NEVER
                setBackgroundColor(Color.TRANSPARENT)
            }
            scroll.addView(content, ViewGroup.LayoutParams(-1, -2))
            var popup: PopupWindow? = null
            for (i in 0 until adapter.count) {
                val label = adapter.getItem(i)?.toString() ?: continue
                val row = TextView(this).apply {
                    text = label
                    textSize = 16f
                    setTextColor(Color.rgb(35,42,52))
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(14),0,dp(14),0)
                    isClickable = true
                    background = liquidInteractiveSurface(
                        if (i == spinner.selectedItemPosition) Color.rgb(232,243,255) else Color.rgb(248,249,251),
                        16, Color.rgb(210,226,242), 1
                    )
                    applyLiquidControlDepth(this)
                    setOnClickListener { spinner.setSelection(i); popup?.dismiss() }
                }
                content.addView(row, LinearLayout.LayoutParams(-1, dp(48)).apply {
                    if (i > 0) setMargins(0, dp(1), 0, 0)
                })
            }
            val popupW = dp(260)
            val maxHeight = dp(360)
            val popupH = (dp(12) + adapter.count * dp(48)).coerceAtMost(maxHeight)
            popup = PopupWindow(scroll, popupW, popupH, true).apply {
                setBackgroundDrawable(liquidInteractiveSurface(Color.WHITE,24,Color.rgb(190,220,246),1))
                elevation = dp(12).toFloat()
                isOutsideTouchable = true
                isFocusable = true
                setOnDismissListener { spinner.clearFocus() }
            }

            val location = IntArray(2)
            v.getLocationOnScreen(location)
            val screenH = resources.displayMetrics.heightPixels
            val gapPx = dp(4)
            val belowY = location[1] + v.height + gapPx
            val fitsBelow = belowY + popupH <= screenH - dp(12)
            val xOffset = if (centerOnSpinner) ((v.width - popupW) / 2).coerceAtLeast(-dp(24)) else (v.width - popupW)

            if (fitsBelow) {
                // Il popup resta direttamente sotto al selettore, anche dopo lo scroll della pagina.
                popup.showAsDropDown(v, xOffset, gapPx)
            } else {
                // Se non c'e spazio, si apre sopra mantenendo la stessa distanza dal campo.
                popup.showAsDropDown(v, xOffset, -(v.height + popupH + gapPx))
            }
            true
        }
    }
    private fun typeBgForColor(c:Int):Int = Color.rgb((Color.red(c)+255)/2,(Color.green(c)+255)/2,(Color.blue(c)+255)/2)
    private fun ensureAppointmentTypes(){
        if(appointmentTypes.isEmpty()){
            appointmentTypes.add(AppointmentType("TYPE1","ALLENAMENTO",Color.rgb(45,135,210),45))
            appointmentTypes.add(AppointmentType("TYPE2","MEZZ'ORA",Color.rgb(215,55,55),30))
        }else if(appointmentTypes.none{it.id=="TYPE1"}){
            appointmentTypes.add(0,AppointmentType("TYPE1","ALLENAMENTO",Color.rgb(45,135,210),45))
        }
    }
    private fun normalizedType(type:String):String = when(type){"ALLENAMENTO"->"TYPE1";"MEZZ'ORA"->"TYPE2";else->type}
    private fun typeIndex(type:String):Int {
        ensureAppointmentTypes()
        val id=normalizedType(type)
        val found=appointmentTypes.indexOfFirst{it.id==id}
        if(found>=0)return found
        val legacy=when(id){"TYPE1"->0;"TYPE2"->1;else->-1}
        return if(legacy>=0&&legacy<appointmentTypes.size)legacy else 0
    }
    private fun typeLabel(type:String):String { ensureAppointmentTypes(); return appointmentTypes.getOrNull(typeIndex(type))?.name ?: appointmentTypes.first().name }
    private fun typeColor(type:String):Int { ensureAppointmentTypes(); return appointmentTypes.getOrNull(typeIndex(type))?.color ?: appointmentTypes.first().color }
    private fun typeDuration(type:String):Int { ensureAppointmentTypes(); return appointmentTypes.getOrNull(typeIndex(type))?.duration ?: 45 }
    private fun typeIdAt(index:Int):String { ensureAppointmentTypes(); return appointmentTypes.getOrNull(index)?.id ?: appointmentTypes.first().id }

    private fun roundedSurface(color:Int, radius:Int=16, strokeColor:Int=Color.TRANSPARENT, strokeWidth:Int=0): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius=dp(radius).toFloat(); if(strokeWidth>0) setStroke(dp(strokeWidth),strokeColor) }

    /**
     * Controllo Liquid Glass: superficie leggermente gonfia/3D, traslucida e
     * lucida, pensata per campi e pulsanti. Il contenuto rimane sempre nitido.
     * Fuori dal profilo LIQUID restituisce volutamente lo stile precedente.
     */
    private fun liquidInteractiveSurface(color:Int, radius:Int=18, strokeColor:Int=Color.TRANSPARENT, strokeWidth:Int=1): GradientDrawable {
        if (popupBackdropEffect != "LIQUID") return roundedSurface(color, radius, strokeColor, strokeWidth)
        val r=Color.red(color); val g=Color.green(color); val b=Color.blue(color)
        // I controlli Liquid Glass seguono ora l'intensità scelta: a intensità bassa
        // la superficie lascia filtrare maggiormente lo sfondo, mentre al 100%
        // mantiene esattamente la resa attuale della 1.2.
        val t = popupBackdropIntensity.coerceIn(0,100) / 100f
        val factor = 0.20f + 0.80f * t
        fun a(base:Int) = (base * factor).roundToInt().coerceIn(0,255)
        val strokeA = (210 * factor).roundToInt().coerceIn(0,255)
        return GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
            Color.argb(a(178), minOf(255,r+22), minOf(255,g+24), minOf(255,b+28)),
            Color.argb(a(128), minOf(255,r+8), minOf(255,g+12), minOf(255,b+16)),
            Color.argb(a(162), r, g, b),
            Color.argb(a(188), minOf(255,r+18), minOf(255,g+22), minOf(255,b+26))
        )).apply {
            cornerRadius=dp(radius).toFloat()
            if(strokeWidth>0) setStroke(dp(strokeWidth), Color.argb(strokeA, 190, 225, 255))
        }
    }

    private fun applyLiquidControlDepth(view: View) {
        if (popupBackdropEffect == "LIQUID") {
            view.elevation=dp(3).toFloat()
            view.translationZ=dp(0.5f.roundToInt()).toFloat()
        } else {
            view.elevation=0f
            view.translationZ=0f
        }
    }

    /** Superfici dell'interfaccia principale: la scelta del vetro influenza anche
     * schede, pulsanti e blocchi, non solo le finestre popup. Il contenuto resta
     * sempre nitido; qui lavoriamo esclusivamente sulla superficie. */
    private fun appGlassSurface(color:Int, radius:Int=16, strokeColor:Int=Color.TRANSPARENT, strokeWidth:Int=1): GradientDrawable {
        if (popupBackdropEffect == "NONE") return roundedSurface(color, radius, strokeColor, strokeWidth)
        val a = when (popupBackdropEffect) {
            "SATIN" -> 226
            "VETRO_SOFT" -> 190
            "LIQUID" -> 148
            else -> 220
        }
        val edge = when (popupBackdropEffect) {
            "SATIN" -> if (strokeColor == Color.TRANSPARENT) Color.rgb(218,228,239) else strokeColor
            "VETRO_SOFT", "LIQUID" -> Color.argb(155, 175, 215, 248)
            else -> strokeColor
        }
        return GradientDrawable().apply {
            cornerRadius = dp(radius).toFloat()
            when (popupBackdropEffect) {
                "LIQUID" -> setColors(intArrayOf(
                    Color.argb(a, Color.red(color), Color.green(color), Color.blue(color)),
                    Color.argb((a * 0.78f).toInt(), minOf(255, Color.red(color)+12), minOf(255, Color.green(color)+16), minOf(255, Color.blue(color)+20)),
                    Color.argb((a * 0.90f).toInt(), Color.red(color), Color.green(color), Color.blue(color))
                ))
                "VETRO_SOFT" -> setColors(intArrayOf(
                    Color.argb(a, Color.red(color), Color.green(color), Color.blue(color)),
                    Color.argb((a * 0.90f).toInt(), minOf(255, Color.red(color)+8), minOf(255, Color.green(color)+10), minOf(255, Color.blue(color)+14))
                ))
                else -> setColor(Color.argb(a, Color.red(color), Color.green(color), Color.blue(color)))
            }
            if (strokeWidth > 0) setStroke(dp(strokeWidth), edge)
        }
    }

    /**
     * Superficie Liquid Glass "a goccia" per il calendario.
     * Il volume è costruito solo con luce, gradiente e bordi sfalsati:
     * nessun ovale o disegno interno.
     */
    private inner class LiquidDepthDrawable(
        private val radiusPx:Float,
        private val intensity:Float,
        private val accent:Int
    ) : Drawable() {
        private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val highlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val r = RectF()
        private val inner = RectF()

        override fun draw(canvas: Canvas) {
            val b = bounds
            if (b.width() <= 0 || b.height() <= 0) return
            val t = intensity.coerceIn(0f, 1f)
            val small = radiusPx <= dp(12)
            val inset = (0.9f + 0.7f * t).dp()
            r.set(b.left + inset, b.top + inset, b.right - inset, b.bottom - inset)

            // L'appuntamento è il livello "acqua" sopra la lastra: il colore del tipo
            // viene usato solo come riflesso, non come riempimento pieno.
            val ar = Color.red(accent)
            val ag = Color.green(accent)
            val ab = Color.blue(accent)
            val softR = ((ar * 0.20f) + 255f * 0.80f).roundToInt().coerceAtMost(255)
            val softG = ((ag * 0.20f) + 255f * 0.80f).roundToInt().coerceAtMost(255)
            val softB = ((ab * 0.20f) + 255f * 0.80f).roundToInt().coerceAtMost(255)

            // Corpo traslucido: più luminoso in alto e leggermente più denso in basso,
            // come una piccola lente d'acqua appoggiata sulla lastra.
            val topA = if (small) 38 + (12 * t).roundToInt() else 44 + (14 * t).roundToInt()
            val midA = if (small) 9 + (4 * t).roundToInt() else 11 + (5 * t).roundToInt()
            val bottomA = if (small) 27 + (10 * t).roundToInt() else 31 + (12 * t).roundToInt()
            fillPaint.shader = LinearGradient(
                r.left, r.top, r.left, r.bottom,
                intArrayOf(
                    Color.argb(topA, 255,255,255),
                    Color.argb(midA, softR,softG,softB),
                    Color.argb(bottomA, softR,softG,softB),
                    Color.argb((bottomA + 3).coerceAtMost(120), 246,251,255)
                ),
                floatArrayOf(0f,0.32f,0.78f,1f), Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(r, radiusPx, radiusPx, fillPaint)

            // Volume ottico centrale: una lente d'acqua non è uniforme come una card.
            // Una luce morbida attraversa il centro e si concentra verso la parte alta,
            // mentre il bordo inferiore rimane appena più denso. Le dimensioni restano
            // identiche: aumentiamo solo la percezione della curvatura.
            val bulge = RectF(r.left + 1.2f.dp(), r.top + 1.4f.dp(), r.right - 1.2f.dp(), r.bottom - 1.2f.dp())
            glowPaint.shader = RadialGradient(
                bulge.left + bulge.width()*0.50f, bulge.top + bulge.height()*0.34f,
                bulge.width()*0.62f,
                intArrayOf(
                    Color.argb((24 + 14*t).roundToInt(),255,255,255),
                    Color.argb((9 + 7*t).roundToInt(),255,255,255),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f,0.48f,1f), Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(bulge, radiusPx*0.92f, radiusPx*0.92f, glowPaint)

            // Riflesso diffuso superiore: la superficie sembra leggermente bombata.
            glowPaint.shader = RadialGradient(
                r.left + r.width()*0.34f, r.top + r.height()*0.12f,
                r.width()*0.72f,
                intArrayOf(
                    Color.argb((42 + 20*t).roundToInt(),255,255,255),
                    Color.argb((13 + 9*t).roundToInt(),255,255,255),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f,0.42f,1f), Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(r, radiusPx, radiusPx, glowPaint)

            // Rifrazione interna: una fascia chiarissima e molto trasparente appena
            // sotto il bordo superiore, come la luce che attraversa una superficie
            // d'acqua. Non aumenta lo spessore della card.
            val refraction = RectF(r.left + 2.4f.dp(), r.top + 4.0f.dp(), r.right - 2.4f.dp(), r.top + r.height()*0.46f)
            glowPaint.shader = LinearGradient(
                refraction.left, refraction.top, refraction.left, refraction.bottom,
                Color.argb((24 + 12*t).roundToInt(),255,255,255),
                Color.TRANSPARENT,
                Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(refraction, radiusPx*0.72f, radiusPx*0.72f, glowPaint)

            // Effetto lente/acqua più evidente: una luce concentrata attraversa il centro
            // e sfuma verso i bordi. Non cambia la geometria della card: simula la
            // rifrazione ottica dello strato liquido sopra nome e indicatore rosso.
            val lens = RectF(
                r.left + 3.0f.dp(), r.top + 2.2f.dp(),
                r.right - 3.0f.dp(), r.bottom - 2.0f.dp()
            )
            glowPaint.shader = RadialGradient(
                lens.left + lens.width()*0.50f,
                lens.top + lens.height()*0.50f,
                lens.width()*0.58f,
                intArrayOf(
                    Color.argb((30 + 24*t).roundToInt(),255,255,255),
                    Color.argb((12 + 12*t).roundToInt(),255,255,255),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f,0.48f,1f), Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(lens, radiusPx*0.86f, radiusPx*0.86f, glowPaint)

            // Due micro-caustiche superiori: fanno leggere la superficie come acqua
            // lucida senza trasformarla in una card gonfia.
            val caustic = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeCap = Paint.Cap.ROUND
                strokeWidth = (0.48f + 0.10f*t).dp()
                color = Color.argb((16 + 10*t).roundToInt(),255,255,255)
            }
            val c1 = Path()
            c1.moveTo(r.left + r.width()*0.20f, r.top + r.height()*0.30f)
            c1.quadTo(r.left + r.width()*0.38f, r.top + r.height()*0.22f,
                      r.left + r.width()*0.53f, r.top + r.height()*0.29f)
            canvas.drawPath(c1, caustic)
            val c2 = Path()
            c2.moveTo(r.left + r.width()*0.55f, r.top + r.height()*0.30f)
            c2.quadTo(r.left + r.width()*0.70f, r.top + r.height()*0.22f,
                      r.right - r.width()*0.18f, r.top + r.height()*0.30f)
            canvas.drawPath(c2, caustic)

            // Piccolo riflesso laterale, volutamente bianco/fumé: niente bordo blu pieno.
            edgePaint.shader = null
            edgePaint.strokeWidth = (if (small) 1.20f else 1.50f + 0.20f*t).dp()
            edgePaint.color = Color.argb((102 + 28*t).roundToInt(), 205, 226, 239)
            canvas.drawRoundRect(r, radiusPx, radiusPx, edgePaint)

            inner.set(r.left + 1.5f.dp(), r.top + 1.5f.dp(), r.right - 1.5f.dp(), r.bottom - 1.5f.dp())

            // Highlight superiore continuo: è il punto che deve far leggere "acqua".
            val hi = if (small) 82 + (24*t).roundToInt() else 92 + (28*t).roundToInt()
            highlightPaint.strokeWidth = (if (small) 1.45f else 1.8f).dp()
            highlightPaint.color = Color.argb(hi,255,255,255)
            val topPath = Path()
            topPath.moveTo(inner.left + inner.width()*0.13f, inner.top + 1f.dp())
            topPath.quadTo(inner.left + inner.width()*0.50f, inner.top - 0.9f.dp(), inner.right - inner.width()*0.13f, inner.top + 1f.dp())
            canvas.drawPath(topPath, highlightPaint)

            // Riflesso corto sul lato sinistro.
            val sidePath = Path()
            sidePath.moveTo(inner.left + 0.7f.dp(), inner.top + inner.height()*0.20f)
            sidePath.quadTo(inner.left - 0.1f.dp(), inner.top + inner.height()*0.38f, inner.left + 0.7f.dp(), inner.top + inner.height()*0.55f)
            highlightPaint.strokeWidth = (if (small) 1.15f else 1.35f).dp()
            highlightPaint.color = Color.argb((48 + 35*t).roundToInt(),255,255,255)
            canvas.drawPath(sidePath, highlightPaint)

            // Riflesso inferiore molto sottile: leggermente cromatico, ma attenuato.
            val low = Path()
            low.moveTo(inner.left + inner.width()*0.16f, inner.bottom - 0.7f.dp())
            low.quadTo(inner.left + inner.width()*0.50f, inner.bottom + 0.45f.dp(), inner.right - inner.width()*0.16f, inner.bottom - 0.7f.dp())
            highlightPaint.strokeWidth = (if (small) 1.45f else 1.75f).dp()
            highlightPaint.color = Color.argb((50 + 34*t).roundToInt(), softR, softG, softB)
            canvas.drawPath(low, highlightPaint)
        }

        private fun Float.dp():Float = this * resources.displayMetrics.density
        override fun setAlpha(alpha:Int) {}
        override fun setColorFilter(colorFilter:android.graphics.ColorFilter?) {}
        override fun getOpacity():Int = android.graphics.PixelFormat.TRANSLUCENT
    }

    /**
     * Strato superficiale dell'acqua: viene disegnato SOPRA il contenuto della card.
     * Non altera il testo/riga rossa, ma crea il tipico riflesso che fa percepire
     * il contenuto come immerso sotto una sottile pellicola d'acqua.
     */
    /**
     * Pellicola d'acqua più evidente sopra il contenuto dell'appuntamento.
     * Il contenuto resta sotto la superficie: luce, riflessi e caustiche vengono
     * disegnati in foreground senza modificare la riga rossa.
     */
    /** Transparent water film over the appointment content. */
    /**
     * Pellicola di gel/acqua trasparente sopra il contenuto dell'appuntamento.
     * È volutamente quasi invisibile al centro: la percezione viene dai menischi,
     * dal bordo e da riflessi sottili, così nome e riga restano leggibili.
     */
    /**
     * Pellicola di gel/acqua sopra l'appuntamento.
     * La superficie è quasi trasparente: il contenuto resta leggibile, mentre
     * menisco, riflessi e micro-rifrazione fanno percepire uno strato fisico sopra
     * nome e indicatore rosso, senza il precedente effetto "onda".
     */
    /** Transparent gel/water film drawn above appointment content. */
    /**
     * Ultima rifinitura della pellicola gel/acqua sugli appuntamenti.
     * La superficie resta molto trasparente: il volume viene percepito dai bordi,
     * dal menisco e da una rifrazione estremamente tenue che attraversa il contenuto.
     * Niente onde grafiche evidenti e niente copertura del nome/riga rossa.
     */
    /**
     * Pellicola gel/acqua: superficie ottica trasparente sopra il contenuto.
     * L'obiettivo è far percepire uno strato fisico senza coprire nome e indicatore.
     * La rifrazione viene suggerita da un menisco continuo e da una lieve lente
     * periferica; il centro resta volutamente limpido.
     */
    private inner class WaterSurfaceOverlayDrawable(
        private val radiusPx:Float,
        private val intensity:Float
    ) : Drawable() {
        private val p=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeCap=Paint.Cap.ROUND}
        private val fill=Paint(Paint.ANTI_ALIAS_FLAG)
        private val rr=RectF()
        override fun draw(canvas:Canvas){
            val b=bounds;if(b.width()<=0||b.height()<=0)return
            val d=resources.displayMetrics.density
            val t=intensity.coerceIn(.35f,1f)
            rr.set(b.left+.35f*d,b.top+.35f*d,b.right-.35f*d,b.bottom-.35f*d)
            val r=radiusPx.coerceAtLeast(9f*d)
            fill.shader=RadialGradient(rr.centerX(),rr.centerY(),rr.width()*.76f,
                intArrayOf(Color.argb(0,255,255,255),Color.argb(0,255,255,255),Color.argb((18*t).roundToInt(),205,232,242)),
                floatArrayOf(0f,.72f,1f),Shader.TileMode.CLAMP)
            canvas.drawRoundRect(rr,r,r,fill)
            p.strokeWidth=.55f*d;p.color=Color.argb((105*t).roundToInt(),255,255,255)
            val top=Path();top.moveTo(rr.left+rr.width()*.09f,rr.top+1.45f*d)
            top.cubicTo(rr.left+rr.width()*.30f,rr.top+.55f*d,rr.left+rr.width()*.70f,rr.top+.55f*d,rr.right-rr.width()*.09f,rr.top+1.45f*d)
            canvas.drawPath(top,p)
            p.strokeWidth=.34f*d;p.color=Color.argb((38*t).roundToInt(),215,240,247)
            val sideL=Path();sideL.moveTo(rr.left+.65f*d,rr.top+rr.height()*.25f)
            sideL.cubicTo(rr.left+.20f*d,rr.top+rr.height()*.50f,rr.left+.20f*d,rr.top+rr.height()*.50f,rr.left+.65f*d,rr.top+rr.height()*.75f);canvas.drawPath(sideL,p)
            val sideR=Path();sideR.moveTo(rr.right-.65f*d,rr.top+rr.height()*.25f)
            sideR.cubicTo(rr.right-.20f*d,rr.top+rr.height()*.50f,rr.right-.20f*d,rr.top+rr.height()*.50f,rr.right-.65f*d,rr.top+rr.height()*.75f);canvas.drawPath(sideR,p)
            p.strokeWidth=.30f*d;p.color=Color.argb((34*t).roundToInt(),255,255,255)
            canvas.drawLine(rr.left+rr.width()*.27f,rr.top+rr.height()*.16f,rr.right-rr.width()*.27f,rr.top+rr.height()*.16f,p)
            p.strokeWidth=.28f*d;p.color=Color.argb((42*t).roundToInt(),190,222,235)
            canvas.drawRoundRect(rr,r,r,p)
            fill.shader=null
        }
        override fun setAlpha(alpha:Int){}
        override fun setColorFilter(colorFilter:android.graphics.ColorFilter?){}
        override fun getOpacity():Int=android.graphics.PixelFormat.TRANSLUCENT
    }

    /**
     * Card appuntamento: rettangolare, trasparente e con un piccolo bordo LED
     * cromatico. Il colore arriva direttamente dal tipo di appuntamento impostato
     * nelle Impostazioni (blu, verde, rosso, ecc.). La riga rossa di scadenza resta
     * indipendente e quindi continua a significare esclusivamente "pacchetto scaduto".
     */
    private inner class AppointmentGelBaseDrawable(private val radiusPx:Float,private val accent:Int,private val material:String = calendarMaterialEffect,private val materialIntensity:Int = calendarMaterialIntensity):Drawable(){
        private val fill=Paint(Paint.ANTI_ALIAS_FLAG)
        private val edge=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE}
        private val led=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeCap=Paint.Cap.ROUND}
        private val rr=RectF()
        private val ledRect=RectF()
        override fun draw(canvas:Canvas){
            val b=bounds;if(b.width()<=0||b.height()<=0)return
            val d=resources.displayMetrics.density;val inset=.65f*d
            rr.set(b.left+inset,b.top+inset,b.right-inset,b.bottom-inset)
            val ar=Color.red(accent);val ag=Color.green(accent);val ab=Color.blue(accent)
            val tr=((ar*.08f)+255f*.92f).roundToInt().coerceAtMost(255)
            val tg=((ag*.08f)+255f*.92f).roundToInt().coerceAtMost(255)
            val tb=((ab*.08f)+255f*.92f).roundToInt().coerceAtMost(255)

            // Corpo gel: quasi neutro, con una minima contaminazione del colore del tipo.
            fill.shader=LinearGradient(rr.left,rr.top,rr.left,rr.bottom,
                intArrayOf(
                    Color.argb(38,255,255,255),
                    Color.argb(15,tr,tg,tb),
                    Color.argb(12,tr,tg,tb),
                    Color.argb(30,218,235,244)
                ),floatArrayOf(0f,.28f,.72f,1f),Shader.TileMode.CLAMP)
            canvas.drawRoundRect(rr,radiusPx,radiusPx,fill)

            val lightT=(materialIntensity.coerceIn(0,100)/100f)
            if(material=="SIDE_LIGHT") {
                // Luce che entra lateralmente nella lastra: il centro resta trasparente,
                // mentre i bordi ricevono una diffusione cromatica più intensa.
                val sideAlpha=(42+70*lightT).roundToInt()
                val glow=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE}
                glow.strokeWidth=(5.8f+3.5f*lightT)*d
                glow.color=Color.argb((18+28*lightT).roundToInt(),ar,ag,ab)
                canvas.drawRoundRect(ledRect,radiusPx+1.7f*d,radiusPx+1.7f*d,glow)
                glow.strokeWidth=(2.4f+1.2f*lightT)*d
                glow.color=Color.argb((42+52*lightT).roundToInt(),ar,ag,ab)
                canvas.drawRoundRect(ledRect,radiusPx+1.1f*d,radiusPx+1.1f*d,glow)
                glow.strokeWidth=(.72f+.28f*lightT)*d
                glow.color=Color.argb(sideAlpha,ar,ag,ab)
                canvas.drawRoundRect(rr,radiusPx,radiusPx,glow)

                // Accumulo di luce sui due lati verticali, come un bordo spesso illuminato.
                val leftGrad=LinearGradient(rr.left,rr.top,rr.left+rr.width()*.28f,rr.top,
                    Color.argb((105*lightT).roundToInt(),ar,ag,ab),Color.argb(0,ar,ag,ab),Shader.TileMode.CLAMP)
                val rightGrad=LinearGradient(rr.right,rr.top,rr.right-rr.width()*.28f,rr.top,
                    Color.argb((105*lightT).roundToInt(),ar,ag,ab),Color.argb(0,ar,ag,ab),Shader.TileMode.CLAMP)
                val fillSide=Paint(Paint.ANTI_ALIAS_FLAG)
                fillSide.shader=leftGrad
                canvas.drawRect(rr.left,rr.top,rr.left+rr.width()*.28f,rr.bottom,fillSide)
                fillSide.shader=rightGrad
                canvas.drawRect(rr.right-rr.width()*.28f,rr.top,rr.right,rr.bottom,fillSide)
            } else {
                // Gel/acqua: alone LED molto morbido e continuo, senza trasformare la card in una pillola.
                ledRect.set(rr.left-.6f*d,rr.top-.6f*d,rr.right+.6f*d,rr.bottom+.6f*d)
                led.strokeWidth=4.2f*d
                led.color=Color.argb(18,ar,ag,ab)
                canvas.drawRoundRect(ledRect,radiusPx+1.2f*d,radiusPx+1.2f*d,led)
                led.strokeWidth=2.2f*d
                led.color=Color.argb(28,ar,ag,ab)
                canvas.drawRoundRect(ledRect,radiusPx+1.0f*d,radiusPx+1.0f*d,led)
                led.strokeWidth=.72f*d
                led.color=Color.argb(112,ar,ag,ab)
                canvas.drawRoundRect(rr,radiusPx,radiusPx,led)
            }

            // Punto luce superiore discreto, coerente con entrambe le modalità.
            val topY=rr.top+1.25f*d
            led.strokeWidth=if(material=="SIDE_LIGHT") 1.0f*d else 1.15f*d
            led.color=Color.argb(if(material=="SIDE_LIGHT") (135+35*lightT).roundToInt() else 168,ar,ag,ab)
            canvas.drawLine(rr.left+rr.width()*.14f,topY,rr.right-rr.width()*.14f,topY,led)
            led.strokeWidth=.52f*d
            led.color=Color.argb(205,255,255,255)
            canvas.drawLine(rr.left+rr.width()*.17f,topY-.15f*d,rr.right-rr.width()*.17f,topY-.15f*d,led)

            // Bordo interno neutro, per conservare il look Niki UI anche con colori forti.
            edge.strokeWidth=.42f*d
            edge.color=Color.argb(62,205,226,238)
            canvas.drawRoundRect(rr,radiusPx,radiusPx,edge)
            fill.shader=null
        }
        override fun setAlpha(alpha:Int){}
        override fun setColorFilter(colorFilter:android.graphics.ColorFilter?){ }
        override fun getOpacity():Int=android.graphics.PixelFormat.TRANSLUCENT
    }

    private fun liquidDepthSurface(color:Int, radius:Int=12, accent:Int=Color.rgb(160,211,247)):Drawable {
        if (popupBackdropEffect != "LIQUID") return roundedSurface(color, radius, accent, 2)
        return LiquidDepthDrawable(dp(radius).toFloat(), popupBackdropIntensity.coerceIn(0,100)/100f, accent)
    }

    private fun calendarGlassBackground(): Drawable {
        if (popupBackdropEffect != "LIQUID") return ColorDrawable(Color.rgb(238,241,244))
        // Base neutra fredda: il vetro deve emergere dal piano senza rendere
        // l'interfaccia azzurra.
        return GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
            Color.rgb(224,228,232),
            Color.rgb(216,220,224),
            Color.rgb(230,233,236),
            Color.rgb(212,217,221)
        ))
    }

    private inner class SatinSlotDrawable(private val z:Float, private val slot:Int): Drawable() {
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val edge = Paint(Paint.ANTI_ALIAS_FLAG)
        private val highlight = Paint(Paint.ANTI_ALIAS_FLAG)
        private val r = RectF()

        override fun draw(canvas: Canvas) {
            val b = bounds
            if (b.width() <= 0 || b.height() <= 0) return
            val d = resources.displayMetrics.density
            val inset = (0.45f * z * d).coerceAtLeast(0.5f)
            r.set(b.left + inset, b.top + inset, b.right - inset, b.bottom - inset)

            // Lastra 45': piatta, satinata e leggermente fumé. Nessuna bombatura.
            val top = if (slot % 2 == 0) Color.rgb(226,230,233) else Color.rgb(222,226,229)
            val bottom = if (slot % 2 == 0) Color.rgb(214,219,223) else Color.rgb(210,215,219)
            fill.shader = LinearGradient(
                r.left, r.top, r.left, r.bottom,
                intArrayOf(
                    Color.argb(74, Color.red(top), Color.green(top), Color.blue(top)),
                    Color.argb(62, Color.red(bottom), Color.green(bottom), Color.blue(bottom)),
                    Color.argb(70, 235,238,240)
                ),
                floatArrayOf(0f, 0.52f, 1f), Shader.TileMode.CLAMP
            )
            canvas.drawRect(r, fill)

            // Satinatura: riflesso largo e diffuso, non lucido.
            highlight.shader = LinearGradient(
                r.left, r.top, r.right, r.top,
                Color.argb(25,255,255,255), Color.argb(7,255,255,255), Shader.TileMode.CLAMP
            )
            canvas.drawRect(r.left, r.top, r.right, r.top + (0.9f*z*d).coerceAtLeast(0.7f), highlight)

            // Bordo netto da taglio laser: sottile, squadrato, senza stondatura.
            edge.style = Paint.Style.STROKE
            edge.strokeWidth = (0.72f * z * d).coerceIn(0.8f*d, 1.1f*d)
            edge.color = Color.argb(92, 143,153,162)
            canvas.drawRect(r, edge)

            // Micro-luce sul taglio superiore e traccia più scura sul taglio inferiore:
            // fanno percepire lo spessore senza trasformare la lastra in una card.
            edge.strokeWidth = (0.5f * z * d).coerceAtLeast(0.5f)
            edge.color = Color.argb(128, 250,252,253)
            canvas.drawLine(r.left + edge.strokeWidth, r.top + edge.strokeWidth*0.5f,
                r.right - edge.strokeWidth, r.top + edge.strokeWidth*0.5f, edge)
            edge.color = Color.argb(72, 105,114,121)
            canvas.drawLine(r.left + edge.strokeWidth, r.bottom - edge.strokeWidth*0.5f,
                r.right - edge.strokeWidth, r.bottom - edge.strokeWidth*0.5f, edge)
        }

        override fun setAlpha(alpha:Int) {}
        override fun setColorFilter(colorFilter:android.graphics.ColorFilter?) {}
        override fun getOpacity():Int = android.graphics.PixelFormat.TRANSLUCENT
    }

    private fun calendarSlotSurface(z:Float, slot:Int): Drawable {
        // IMPORTANT: la geometria e il colore degli slot grandi dipendono SOLO dal set
        // calendario. Non vengono più letti da popupBackdropEffect.
        return when (calendarStyleSet) {
            "LIQUID_GLASS" -> LiquidGlassSlotDrawable(
                z = z,
                slot = slot,
                baseColor = liquidGlassSlotColor,
                shape = liquidGlassSlotShape
            )
            else -> LiquidGlassSlotDrawable(
                z = z,
                slot = slot,
                baseColor = liquidGlassSlotColor,
                shape = liquidGlassSlotShape
            )
        }
    }

    private fun applyCalendarSlotDepth(view: View) {
        // La lastra è sul piano: nessuna dipendenza dagli effetti delle finestre popup.
        view.elevation=0f
        view.translationZ=0f
    }

    /** Slot grande del set LIQUID GLASS.
     * Questa classe contiene esclusivamente superficie/geometria dello slot 45'.
     * Non gestisce gli appuntamenti, il gel/acqua, la riga rossa o i popup.
     */
    private inner class LiquidGlassSlotDrawable(
        private val z:Float,
        private val slot:Int,
        private val baseColor:Int,
        private val shape:String
    ): Drawable() {
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val outerGlow = Paint(Paint.ANTI_ALIAS_FLAG)
        private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val innerEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val r = RectF()
        private val inner = RectF()

        override fun draw(canvas:Canvas){
            val b=bounds
            if(b.width()<=0 || b.height()<=0)return
            val d=resources.displayMetrics.density
            val inset=(0.8f*z*d).coerceAtLeast(0.7f)
            r.set(b.left+inset,b.top+inset,b.right-inset,b.bottom-inset)

            // Liquid Glass: la lastra resta quasi trasparente al centro.
            // La profondità viene costruita soprattutto attraverso bordi, riflessi e
            // una luce morbida che si raccoglie sugli spigoli.
            val radius=(dp(15f)*z).coerceAtMost(r.height()*0.22f)
            val rr = if(shape=="ARROTONDATO") radius else 0f

            val br=Color.red(baseColor)
            val bg=Color.green(baseColor)
            val bb=Color.blue(baseColor)

            fill.shader=LinearGradient(
                r.left,r.top,r.right,r.bottom,
                intArrayOf(
                    Color.argb(42,250,253,255),
                    Color.argb(30,br,bg,bb),
                    Color.argb(24,255,255,255),
                    Color.argb(38,br,bg,bb)
                ),
                floatArrayOf(0f,0.28f,0.62f,1f),
                Shader.TileMode.CLAMP
            )
            if(rr>0f) canvas.drawRoundRect(r,rr,rr,fill) else canvas.drawRect(r,fill)

            // Bagliore esterno minimo: simula luce che entra nel taglio del vetro,
            // senza usare elevation o ombre pesanti.
            outerGlow.style=Paint.Style.STROKE
            outerGlow.strokeWidth=(2.2f*z*d).coerceAtLeast(1.6f*d)
            outerGlow.shader=LinearGradient(
                r.left,r.top,r.right,r.bottom,
                intArrayOf(
                    Color.argb(105,225,242,255),
                    Color.argb(35,255,255,255),
                    Color.argb(72,185,220,248),
                    Color.argb(105,235,247,255)
                ),
                floatArrayOf(0f,0.35f,0.7f,1f),
                Shader.TileMode.CLAMP
            )
            if(rr>0f) canvas.drawRoundRect(r,rr,rr,outerGlow) else canvas.drawRect(r,outerGlow)

            // Taglio principale: molto sottile, quasi bianco, con variazione d'intensità.
            edge.strokeWidth=(0.85f*z*d).coerceIn(0.75f*d,1.25f*d)
            edge.shader=LinearGradient(
                r.left,r.top,r.right,r.bottom,
                intArrayOf(
                    Color.argb(185,255,255,255),
                    Color.argb(100,196,224,244),
                    Color.argb(125,255,255,255),
                    Color.argb(165,207,234,250)
                ),
                floatArrayOf(0f,0.28f,0.62f,1f),
                Shader.TileMode.CLAMP
            )
            if(rr>0f) canvas.drawRoundRect(r,rr,rr,edge) else canvas.drawRect(r,edge)

            // Secondo bordo interno: è quello che dà la sensazione di spessore reale.
            val innerInset=(1.8f*z*d).coerceAtLeast(1.2f*d)
            inner.set(r.left+innerInset,r.top+innerInset,r.right-innerInset,r.bottom-innerInset)
            innerEdge.strokeWidth=(0.55f*z*d).coerceAtLeast(0.55f*d)
            innerEdge.color=Color.argb(72,255,255,255)
            if(rr>0f){
                val ir=(rr-innerInset*0.45f).coerceAtLeast(2f)
                canvas.drawRoundRect(inner,ir,ir,innerEdge)
            }else canvas.drawRect(inner,innerEdge)

            // Riflesso superiore continuo: sottile e non uniforme, come una superficie
            // fisica che intercetta la luce.
            val shine=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeCap=Paint.Cap.ROUND}
            shine.strokeWidth=(0.65f*z*d).coerceAtLeast(0.55f*d)
            shine.shader=LinearGradient(
                r.left,r.top,r.right,r.top,
                intArrayOf(Color.argb(30,255,255,255),Color.argb(145,255,255,255),Color.argb(55,255,255,255)),
                floatArrayOf(0f,0.5f,1f),Shader.TileMode.CLAMP
            )
            val y=r.top+(2.6f*z*d)
            canvas.drawLine(r.left+radius*0.75f,y,r.right-radius*0.75f,y,shine)

            // Piccola luce inferiore: rafforza lo spessore senza rendere la lastra pesante.
            val lower=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeWidth=(0.6f*z*d).coerceAtLeast(0.55f*d);color=Color.argb(65,120,158,190);strokeCap=Paint.Cap.ROUND}
            val ly=r.bottom-(2.2f*z*d)
            canvas.drawLine(r.left+radius*0.9f,ly,r.right-radius*0.9f,ly,lower)

            // Una piccola diffusione di luce verticale sui lati rende la lastra più
            // "spessa" senza riempire il centro di colore.
            val side=Paint(Paint.ANTI_ALIAS_FLAG)
            side.shader=LinearGradient(r.left,r.top,r.left+r.width()*0.18f,r.top,Color.argb(72,220,242,255),Color.argb(0,220,242,255),Shader.TileMode.CLAMP)
            if(rr>0f) canvas.drawRoundRect(r,rr,rr,side) else canvas.drawRect(r,side)
            side.shader=LinearGradient(r.right,r.top,r.right-r.width()*0.18f,r.top,Color.argb(62,185,220,248),Color.argb(0,185,220,248),Shader.TileMode.CLAMP)
            if(rr>0f) canvas.drawRoundRect(r,rr,rr,side) else canvas.drawRect(r,side)
        }

        override fun setAlpha(alpha:Int) {}
        override fun setColorFilter(colorFilter:android.graphics.ColorFilter?) {}
        override fun getOpacity():Int = android.graphics.PixelFormat.TRANSLUCENT
    }

    private fun calendarSearchScreen(){
        currentScreen = "CALENDAR"
        detachSettingsOverlay()
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(14),dp(16),dp(10));background=appGlassBackground()}
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        top.addView(TextView(this).apply{text="🔎 Ricerca appuntamenti";textSize=22f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,dp(52),1f))
        top.addView(buttonStyle("Chiudi").apply{setOnClickListener{calendarScreen()}},LinearLayout.LayoutParams(dp(82),dp(44)))
        root.addView(top)
        searchInput=modernEditText().apply{
            hint="Cerca per nome cliente";textSize=16f;setSingleLine(true);setPadding(dp(14),0,dp(14),0);background=roundedSurface(Color.WHITE,20,Color.rgb(226,229,234),1)
            addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){searchList.removeAllViews();if(s.toString().trim().isNotEmpty())renderSearchResults(s.toString().trim().lowercase())};override fun afterTextChanged(s:Editable?){}})
        }
        root.addView(searchInput,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,dp(8),0,dp(8))})
        searchList=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,dp(4),0,0)}
        val scroll=ScrollView(this).apply{addView(searchList,ViewGroup.LayoutParams(-1,-2))}
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        root.addView(softBlueButtonStyle("← Torna al calendario").apply{setOnClickListener{calendarScreen()}},LinearLayout.LayoutParams(-1,dp(48)))
        prepareEdgeToEdgeRoot(root)
        setContentView(root)
        searchInput.requestFocus()
    }

    private fun dayHeader(day:LocalDate):View{
        val z=calendarZoom
        val today=day==LocalDate.now()
        val headerBg=GradientDrawable().apply{cornerRadius=(dp(12)*z);setColor(if(today)Color.argb(210,238,242,246)else Color.argb(195,255,255,255));setStroke((dp(1)*z).toInt(),if(today)Color.rgb(184,198,210)else Color.rgb(205,220,235))}
        return TextView(this).apply{text="${dayShort(day.dayOfWeek.value-1)}\n${day.dayOfMonth.toString().padStart(2,'0')}/${day.monthValue.toString().padStart(2,'0')}";textSize=15f*z;gravity=Gravity.CENTER;setTextColor(Color.rgb(45,50,56));background=headerBg;setPadding(0,(dp(6)*z).toInt(),0,(dp(6)*z).toInt())}.apply{layoutParams=LinearLayout.LayoutParams(-1,(dp(58)*z).toInt()).apply{setMargins(0,0,0,(dp(4)*z).toInt())}}
    }

    private fun dayColumn(day:LocalDate, includeHeader:Boolean=true):View{
        val z=calendarZoom
        val col=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding((dp(4)*z).toInt(),0,(dp(4)*z).toInt(),(dp(4)*z).toInt())}
        if(includeHeader) col.addView(dayHeader(day))
        for(slot in 0 until 20){val mins=7*60+slot*45;val hour=mins/60;val minute=mins%60;val time=String.format("%02d:%02d",hour,minute);val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding((dp(5)*z).toInt(),(dp(4)*z).toInt(),(dp(5)*z).toInt(),(dp(4)*z).toInt());background=calendarSlotSurface(z,slot);isClickable=true}.also{applyCalendarSlotDepth(it)}
            val items=appointments.filter{it.date==day&&it.time==time}.sortedBy{it.type}
            val maxTotal=calendarRoutines.getOrNull(activeRoutineIndex)?.maxTotal?:3;val countColor=when{items.size>=maxTotal->Color.rgb(205,55,55);items.size==maxTotal-1->Color.rgb(210,145,25);else->Color.GRAY}
            val timeRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            timeRow.addView(TextView(this).apply{text=time;textSize=11f*z;setTextColor(Color.rgb(105,110,118));setTypeface(null,android.graphics.Typeface.BOLD)},LinearLayout.LayoutParams(0,(dp(22)*z).toInt(),1f))
            timeRow.addView(TextView(this).apply{text="${items.size}/${calendarRoutines.getOrNull(activeRoutineIndex)?.maxTotal?:3}";textSize=9f*z;setTextColor(countColor);gravity=Gravity.CENTER},LinearLayout.LayoutParams((dp(30)*z).toInt(),(dp(22)*z).toInt()))
            box.addView(timeRow)
            if(items.isEmpty()){box.addView(TextView(this).apply{text="＋";textSize=18f*z;gravity=Gravity.CENTER;setTextColor(Color.LTGRAY)},LinearLayout.LayoutParams(-1,(dp(42)*z).toInt()));box.setOnClickListener{appointmentDialogForSlot(day,time)}}
            else{val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                items.forEachIndexed{index,a->row.addView(appointmentChip(a),LinearLayout.LayoutParams(0,(dp(46)*z).toInt(),1f).apply{if(index>0)setMargins((dp(3)*z).toInt(),0,0,0)})}
                box.addView(row,LinearLayout.LayoutParams(-1,(dp(46)*z).toInt()))
                box.addView(TextView(this).apply{text="${items.size}/${calendarRoutines.getOrNull(activeRoutineIndex)?.maxTotal?:3} appuntamenti";textSize=8.5f*z;setTextColor(Color.GRAY);gravity=Gravity.CENTER_VERTICAL;setPadding(0,(dp(2)*z).toInt(),0,0)},LinearLayout.LayoutParams(-1,(dp(16)*z).toInt()))
                box.setOnClickListener{appointmentDialogForSlot(day,time)}
            }
            col.addView(box,LinearLayout.LayoutParams(-1,(dp(86)*z).toInt()).apply{setMargins(0,(dp(2)*z).toInt(),0,0)})
        }
        return col
    }

    private fun calendarPackageExpired(name:String):Boolean{
        val key=identityKey(name)
        val regularExpired=packs.any{it.active&&identityKey(it.name)==key&&statusFor(it,ratesFor(it),dueDates(it)).label=="SCADUTA"}
        val sessionExpired=sessionPacks.any{it.active&&identityKey(it.name)==key&&sessionStatus(it).label in setOf("SCADUTA","DA PAGARE")}
        return regularExpired||sessionExpired
    }

    private inner class SiliconeStripeDrawable(private val z:Float) : Drawable() {
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val highlight = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val edgeGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val rr = RectF()

        override fun draw(canvas: Canvas) {
            if (bounds.width() <= 0 || bounds.height() <= 0) return
            val inset = 0.55f.dp()
            rr.set(bounds.left + inset, bounds.top + inset, bounds.right - inset, bounds.bottom - inset)
            val radius = rr.height() * 0.50f

            // Corpo rosso: pieno, morbido e leggermente più luminoso nella parte alta.
            fill.shader = LinearGradient(
                rr.left, rr.top, rr.left, rr.bottom,
                intArrayOf(
                    Color.rgb(255,106,114),
                    Color.rgb(247,64,74),
                    Color.rgb(220,43,54),
                    Color.rgb(198,35,47)
                ),
                floatArrayOf(0f,0.24f,0.68f,1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(rr, radius, radius, fill)

            // Un bordo morbido chiude la forma senza creare una linea separata.
            edgeGlow.strokeWidth = (0.70f * z).dp().coerceAtLeast(0.7f)
            edgeGlow.color = Color.argb(110,255,142,148)
            canvas.drawRoundRect(rr, radius, radius, edgeGlow)

            // Riflesso principale: una sola luce continua, perfettamente orizzontale.
            // Parte dentro la curva sinistra e arriva dentro la curva destra, senza
            // interrompersi prima delle estremità.
            val y = rr.top + rr.height() * 0.28f
            val left = rr.left + rr.height() * 0.34f
            val right = rr.right - rr.height() * 0.34f
            highlight.strokeWidth = (0.82f * z).dp().coerceAtLeast(0.8f)
            highlight.shader = LinearGradient(
                left, y, right, y,
                intArrayOf(
                    Color.argb(105,255,238,239),
                    Color.argb(195,255,246,247),
                    Color.argb(195,255,246,247),
                    Color.argb(105,255,238,239)
                ),
                floatArrayOf(0f,0.13f,0.87f,1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawLine(left, y, right, y, highlight)

            // Micro-riflesso inferiore: molto tenue, segue la stessa geometria e
            // completa la sensazione di silicone senza aumentare lo spessore percepito.
            val low = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeCap = Paint.Cap.ROUND
                strokeWidth = (0.45f * z).dp().coerceAtLeast(0.5f)
                color = Color.argb(78,142,18,30)
            }
            val lowY = rr.bottom - rr.height() * 0.22f
            canvas.drawLine(left + rr.height()*0.10f, lowY, right - rr.height()*0.10f, lowY, low)
        }

        private fun Float.dp():Float = this * resources.displayMetrics.density
        override fun setAlpha(alpha:Int) {}
        override fun setColorFilter(colorFilter:android.graphics.ColorFilter?) {}
        override fun getOpacity():Int = android.graphics.PixelFormat.TRANSLUCENT
    }

    private fun appointmentChip(a:Appointment):View{
        val accent=typeColor(a.type)
        val bg=typeBgForColor(accent)
        val chip=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding((dp(3)*calendarZoom).toInt(),(dp(2)*calendarZoom).toInt(),(dp(3)*calendarZoom).toInt(),(dp(2)*calendarZoom).toInt());background=AppointmentGelBaseDrawable(dp(12).toFloat(),accent,calendarMaterialEffect,calendarMaterialIntensity);foreground=if(calendarMaterialEffect=="WATER") WaterSurfaceOverlayDrawable(dp(12).toFloat(),calendarMaterialIntensity/100f) else null;foregroundGravity=Gravity.FILL;isClickable=true}
        if(calendarPackageExpired(a.name)){
            // Indicatore scadenza: resta perfettamente orizzontale, più corto del chip,
            // con estremità arrotondate e una sfumatura luminosa per ricordare una
            // piccola striscia di materiale liquido spremuto sulla superficie.
            val stripe=SiliconeStripeDrawable(calendarZoom)
            chip.addView(TextView(this).apply{
                background=stripe
                elevation=dpf(1.6f)
            },LinearLayout.LayoutParams(-1,(dp(6)*calendarZoom).toInt()).apply{
                // Abbassiamo appena la striscia: ora non tocca più il bordo superiore
                // della card e può leggere meglio come piccolo cordoncino di silicone.
                setMargins((dp(10)*calendarZoom).toInt(),(dp(2)*calendarZoom).toInt(),(dp(10)*calendarZoom).toInt(),(dp(1)*calendarZoom).toInt())
            })
        }
        chip.addView(TextView(this).apply{text=displaySurnameFirst(a.name);textSize=9.5f*calendarZoom;setTextColor(Color.rgb(25,30,35));gravity=Gravity.CENTER;maxLines=2;ellipsize=android.text.TextUtils.TruncateAt.END;setTypeface(null,android.graphics.Typeface.BOLD);scaleX=1.004f;scaleY=0.998f;setShadowLayer(dpf(0.55f),0f,dpf(0.12f),Color.argb(30,255,255,255))},LinearLayout.LayoutParams(-1,(dp(if(calendarPackageExpired(a.name)) 33 else 42)*calendarZoom).toInt()))
        chip.setOnClickListener{appointmentActions(a)}
        return chip}

    private fun registerDeletedRegularAppointment(a:Appointment){
        if(!a.recovery){regularPackFor(a.name,a.date)?.let{it.missedSessions++}}
    }

    private fun appointmentActions(a:Appointment){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(6),dp(18),dp(10))}
        box.addView(TextView(this).apply{text=displaySurnameFirst(a.name);textSize=23f;setTextColor(Color.rgb(24,27,31));setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setPadding(0,dp(4),0,dp(2))},LinearLayout.LayoutParams(-1,dp(42)))
        box.addView(TextView(this).apply{text="${a.date.format(fmt)} • ${a.time} • ${typeDuration(a.type)} min";textSize=13.5f;setTextColor(Color.rgb(92,96,102));gravity=Gravity.CENTER;setPadding(0,0,0,dp(14))},LinearLayout.LayoutParams(-1,dp(30)))
        val edit=TextView(this).apply{text="Modifica / sposta";textSize=15f;gravity=Gravity.CENTER;setTextColor(Color.rgb(35,91,145));setTypeface(null,android.graphics.Typeface.BOLD);background=liquidInteractiveSurface(Color.rgb(232,243,255),20,Color.rgb(188,211,238),1);isClickable=true;applyLiquidControlDepth(this)}
        val del=TextView(this).apply{text="Elimina appuntamento";textSize=15f;gravity=Gravity.CENTER;setTextColor(Color.rgb(195,55,55));setTypeface(null,android.graphics.Typeface.BOLD);background=roundedSurface(Color.rgb(255,244,244),18,Color.rgb(244,215,215),1);isClickable=true}
        val cancel=TextView(this).apply{text="Annulla";textSize=14f;setTextColor(Color.rgb(0,125,110));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);background=roundedSurface(Color.rgb(248,250,253),18,Color.rgb(218,225,232),1);isClickable=true}
        box.addView(edit,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,0,0,dp(7))})
        box.addView(del,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,0,0,dp(7))})
        box.addView(cancel,LinearLayout.LayoutParams(-1,dp(46)))
        val dialog=AlertDialog.Builder(this).setView(box).create();styleModernCoachDialog(dialog)
        preparePopupBackdrop(dialog)
        dialog.setOnShowListener{popupBackdropCurrentDialog=dialog;dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28));applyPopupBackdropEffect(dialog);dialog.window?.setDimAmount(0.40f);dialog.window?.let{w->w.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT)};animateCalendarDialog(dialog,box);edit.setOnClickListener{dialog.dismiss();appointmentDialog(a)};del.setOnClickListener{
            dialog.dismiss()
            if(a.seriesId!=0L){
                val series=appointments.filter{it.seriesId==a.seriesId}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
                val seriesCount=series.size
                val selectedIndex=series.indexOfFirst{it.id==a.id}
                val laterCount=if(selectedIndex>=0) series.size-selectedIndex else 0
                val (seqDialog,outer,body)=packActionDialogBase("Elimina appuntamento","🗑",Color.rgb(205,45,55),Color.rgb(255,225,228),Color.WHITE)
                body.addView(dialogBodyText("Questo appuntamento fa parte di una programmazione di $seriesCount appuntamenti.\n\nScegli cosa vuoi eliminare."))
                fun seqButton(label:String, sub:String?=null, bg:Int=Color.rgb(246,248,250), fg:Int=Color.rgb(25,28,32)):Button=dialogButton(if(sub.isNullOrBlank())label else "$label\n$sub",fg,bg,if(bg==Color.rgb(246,248,250)) Color.rgb(220,225,232) else bg){}
                val one=seqButton("Solo questo appuntamento")
                val subsequent=seqButton("Questo e tutti i successivi","Elimina $laterCount appuntamenti da questo in poi")
                val all=seqButton("Tutta la sequenza","Elimina tutti i $seriesCount appuntamenti",Color.rgb(255,244,244),Color.rgb(195,55,55))
                body.addView(one,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(7))})
                body.addView(subsequent,LinearLayout.LayoutParams(-1,dp(58)).apply{setMargins(0,0,0,dp(7))})
                body.addView(all,LinearLayout.LayoutParams(-1,dp(58)).apply{setMargins(0,0,0,dp(5))})
                body.addView(dialogButton("Annulla",Color.rgb(0,125,110),Color.rgb(248,250,253),Color.rgb(218,225,232)){seqDialog.dismiss()},LinearLayout.LayoutParams(-1,dp(44)))
                one.setOnClickListener{registerDeletedRegularAppointment(a);addTrashItem("APPOINTMENT",appointmentTrashPayload(a));appointments.remove(a);saveData();seqDialog.dismiss();calendarScreen()}
                subsequent.setOnClickListener{
                    if(selectedIndex>=0){val toRemove=appointments.filter{it.seriesId==a.seriesId && (it.date.isAfter(a.date) || (it.date==a.date && it.time>=a.time))};toRemove.forEach{registerDeletedRegularAppointment(it);addTrashItem("APPOINTMENT",appointmentTrashPayload(it))};appointments.removeAll{it.id in toRemove.map{r->r.id}.toSet()}}
                    saveData();seqDialog.dismiss();calendarScreen()
                }
                all.setOnClickListener{val toRemove=appointments.filter{it.seriesId==a.seriesId};toRemove.forEach{registerDeletedRegularAppointment(it);addTrashItem("APPOINTMENT",appointmentTrashPayload(it))};appointments.removeAll{it.id in toRemove.map{r->r.id}.toSet()};saveData();seqDialog.dismiss();calendarScreen()}
                seqDialog.show()
            }else{
                val (confirmDialog,outer,body)=packActionDialogBase("Elimina appuntamento?","🗑",Color.rgb(205,45,55),Color.rgb(255,225,228),Color.WHITE)
                body.addView(dialogBodyText("Vuoi eliminare l'appuntamento di ${displaySurnameFirst(a.name)} del ${a.date.format(fmt)} alle ${a.time}?"))
                val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                buttons.addView(dialogButton("Annulla",Color.rgb(65,80,100),Color.WHITE,Color.rgb(215,223,232)){confirmDialog.dismiss()},LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(0,0,dp(4),0)})
                buttons.addView(dialogButton("🗑  Elimina",Color.WHITE,Color.rgb(205,45,55),Color.rgb(205,45,55)){registerDeletedRegularAppointment(a);addTrashItem("APPOINTMENT",appointmentTrashPayload(a));appointments.remove(a);saveData();confirmDialog.dismiss();calendarScreen()},LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(dp(4),0,0,0)})
                body.addView(buttons)
                confirmDialog.show()
            }
        };cancel.setOnClickListener{dialog.dismiss()}}
        dialog.show()
    }

    private fun animateCalendarDialog(dialog: AlertDialog, content: View){
        dialog.window?.apply{
            // Disattiva l'animazione di finestra Android: evitiamo di sommare due
            // animazioni (sistema + Niki UI) mentre il calendario continua a essere renderizzato sotto.
            attributes = attributes.apply{windowAnimations = 0}
        }
        content.alpha = 0f
        content.scaleX = 0.985f
        content.scaleY = 0.985f
        content.translationY = dp(8).toFloat()
        content.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .translationY(0f)
            .setDuration(170)
            .setInterpolator(android.view.animation.DecelerateInterpolator())
            .start()
    }

    private fun animateSettingsPageIn(dialog: AlertDialog, content: View){
        val shouldAnimate=settingsTransitionPending
        settingsTransitionPending=false
        dialog.window?.apply{
            attributes=attributes.apply{windowAnimations=0}
        }
        if(!shouldAnimate)return
        content.animate().cancel()
        content.alpha=0f
        content.translationX=dp(34).toFloat()
        content.scaleX=0.985f
        content.scaleY=0.985f
        content.animate().alpha(1f).translationX(0f).scaleX(1f).scaleY(1f)
            .setDuration(210)
            .setInterpolator(android.view.animation.DecelerateInterpolator(1.15f))
            .withLayer().start()
    }

    private fun styleFullPageCoachDialog(dialog:AlertDialog){
        preparePopupBackdrop(dialog)
        dialog.setOnShowListener{
            popupBackdropCurrentDialog=dialog
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28))
            applyPopupBackdropEffect(dialog)
            dialog.window?.setDimAmount(0.40f)
            dialog.window?.let{w->
                val metrics=resources.displayMetrics
                w.setLayout((metrics.widthPixels*0.92f).toInt(),(metrics.heightPixels*0.82f).toInt())
                w.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
                // La finestra resta ferma, mentre la pagina interna è realmente scrollabile
                // anche quando il contenuto, a tastiera chiusa, sarebbe più corto del viewport.
                fun prepareScroll(v:View){
                    if(v is ScrollView){
                        v.isFillViewport=true
                        v.clipToPadding=false
                        v.setPadding(0,dp(76),0,dp(76))
                        val child=v.getChildAt(0)
                        if(child!=null){
                            v.post{
                                val extra=dp(152)
                                child.minimumHeight=maxOf(child.measuredHeight,v.height+extra)
                            }
                        }
                    }
                    if(v is ViewGroup){
                        for(i in 0 until v.childCount) prepareScroll(v.getChildAt(i))
                    }
                }
                w.decorView.post{prepareScroll(w.decorView)}
            }
        }
    }

    private fun styleModernCoachDialog(dialog:AlertDialog){
        preparePopupBackdrop(dialog)
        dialog.setOnShowListener{
            popupBackdropCurrentDialog=dialog
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28))
            applyPopupBackdropEffect(dialog)
            dialog.window?.setDimAmount(0.40f)
            dialog.window?.let{w->
                val metrics=resources.displayMetrics
                w.setLayout((metrics.widthPixels*0.92f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT)
                w.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
            }
            dialog.findViewById<TextView>(resources.getIdentifier("alertTitle","id","android"))?.apply{
                textSize=22f
                gravity=Gravity.CENTER
                textAlignment=View.TEXT_ALIGNMENT_CENTER
                setTextColor(Color.rgb(28,30,33))
                setTypeface(null,android.graphics.Typeface.NORMAL)
                layoutParams = (layoutParams ?: ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT)).apply {
                    width = ViewGroup.LayoutParams.MATCH_PARENT
                    gravity = Gravity.CENTER
                }
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.apply{setTextColor(Color.rgb(0,125,110));setAllCaps(false);stateListAnimator=null}
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.apply{setTextColor(Color.rgb(0,125,110));setAllCaps(false);stateListAnimator=null}
        }
    }

    private fun styleSettingsPageWindow(dialog:AlertDialog){
        dialog.window?.apply{
            // Settings uses a full-screen window, but NOT edge-to-edge into
            // the status bar. The status bar stays opaque white with dark
            // icons so Android/Samsung system icons never collide with the
            // Settings title or become unreadable on the light background.
            setBackgroundDrawable(roundedSurface(Color.WHITE,0))
            setDimAmount(0f)
            if(android.os.Build.VERSION.SDK_INT >= 30){
                setDecorFitsSystemWindows(true)
            }
            clearFlags(android.view.WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            if(android.os.Build.VERSION.SDK_INT >= 21){
                clearFlags(android.view.WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION)
            }
            addFlags(android.view.WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            statusBarColor=Color.WHITE
            navigationBarColor=Color.WHITE
            if(android.os.Build.VERSION.SDK_INT >= 28){
                navigationBarDividerColor=Color.WHITE
            }
            val metrics=resources.displayMetrics
            setLayout(metrics.widthPixels,metrics.heightPixels)
        }
    }

    private fun styleSettingsPageDialog(dialog:AlertDialog, returnToSettings:Boolean){
        var backHandled=false
        dialog.setOnKeyListener{_,keyCode,event->
            if(keyCode==android.view.KeyEvent.KEYCODE_BACK && event.action==android.view.KeyEvent.ACTION_UP){
                if(backHandled)return@setOnKeyListener true
                backHandled=true
                val content=dialog.window?.decorView
                if(content!=null){
                    content.animate().cancel()
                    content.animate().translationX(dp(34).toFloat()).alpha(0f)
                        .setDuration(170)
                        .setInterpolator(android.view.animation.DecelerateInterpolator(1.15f))
                        .withLayer()
                        .withEndAction{dialog.dismiss();if(returnToSettings)window.decorView.post{settings()}}
                        .start()
                }else{
                    dialog.dismiss()
                    if(returnToSettings)window.decorView.post{settings()}
                }
                true
            }else false
        }
        dialog.setOnCancelListener{
            removePopupBackdropDialog(dialog)
            if(!backHandled && returnToSettings){
                backHandled=true
                window.decorView.post{settings()}
            }
        }
    }

    private fun styleOneUiDialog(dialog:AlertDialog){
        preparePopupBackdrop(dialog)
        dialog.setOnShowListener{
            popupBackdropCurrentDialog=dialog
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28))
            applyPopupBackdropEffect(dialog)
            dialog.window?.setDimAmount(0.38f)
            dialog.findViewById<TextView>(resources.getIdentifier("alertTitle","id","android"))?.apply{
                textSize=22f
                gravity=Gravity.CENTER
                textAlignment=View.TEXT_ALIGNMENT_CENTER
                setTextColor(Color.rgb(28,30,33))
                setTypeface(null,android.graphics.Typeface.NORMAL)
                setPadding(0,dp(2),0,dp(2))
                layoutParams = (layoutParams ?: ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT)).apply {
                    width = ViewGroup.LayoutParams.MATCH_PARENT
                    gravity = Gravity.CENTER
                }
            }
            dialog.findViewById<TextView>(android.R.id.message)?.apply{
                textSize=16f
                setTextColor(Color.rgb(55,58,63))
                setLineSpacing(0f,1.05f)
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.apply{setTextColor(Color.rgb(0,125,110));setAllCaps(false);stateListAnimator=null;minHeight=0;minimumHeight=0}
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.apply{setTextColor(Color.rgb(0,125,110));setAllCaps(false);stateListAnimator=null;minHeight=0;minimumHeight=0}
        }
    }

    private fun appointmentDialog(existing:Appointment?, forcedDay:LocalDate?=null, forcedTime:String?=null){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(4),dp(14),0)}
        val name=AutoCompleteTextView(this).apply{hint="Cognome e Nome";setText(existing?.name?:"");setSingleLine(true);setAdapter(clientNameAutoCompleteAdapter((packs.map{it.name}+sessionPacks.map{it.name}).distinct()))}
        val date=modernEditText().apply{hint="Data (gg/mm/aaaa)";inputType=2;setText((existing?.date?:forcedDay?:calendarWeekStart).format(fmt))};setupDateInput(date)
        val time=Spinner(this).also{installNikiTimeDropdown(it, true)}
        val type=Spinner(this);type.adapter=centeredSpinnerAdapter(appointmentTypes.map{it.name});type.setSelection(existing?.let{typeIndex(it.type)}?:0)
        var seriesEdit: Button? = null
        if(existing!=null && existing.seriesId!=0L){
            seriesEdit=Button(this).apply{
                text="↻  Modifica ripetizione";setAllCaps(false);textSize=15f;gravity=Gravity.CENTER_VERTICAL;setTextColor(Color.rgb(25,92,170))
                setTypeface(null,android.graphics.Typeface.BOLD)
                background=liquidInteractiveSurface(Color.rgb(232,242,255),20,Color.rgb(168,207,247),1);applyLiquidControlDepth(this);stateListAnimator=null
                setPadding(dp(14),0,dp(10),0)
            }
        }
        var recovery: CheckBox? = null

        // Mantieni aggiornata la fascia oraria disponibile anche nella nuova UI compatta.
        fun refreshTimeSlots(){
            val selectedType=typeIdAt(type.selectedItemPosition)
            val selectedDate=runCatching{parseDate(date.text.toString())}.getOrNull()?: (existing?.date?:forcedDay?:calendarWeekStart)
            val slots=availableTimeSlots(selectedDate,selectedType,existing)
            val values=if(slots.isEmpty()) listOf("NESSUNA FASCIA DISPONIBILE") else slots
            time.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,values)
            val wanted=existing?.time?:forcedTime
            if(wanted!=null){val idx=values.indexOf(wanted);if(idx>=0)time.setSelection(idx)}
        }

        fun refreshRecoveryOption(){
            if(existing!=null || recovery==null) return
            val selectedDate=runCatching{parseDate(date.text.toString())}.getOrNull() ?: LocalDate.now()
            val possiblePack=regularPackFor(name.text.toString(),selectedDate)
            val pending=possiblePack?.let{recoveriesForPack(it)} ?: 0
            recovery!!.isChecked=false
            recovery!!.isEnabled=pending>0
            recovery!!.visibility=if(pending>0)View.VISIBLE else View.GONE
            if(pending>0) recovery!!.text="↩ Recupero seduta persa ($pending disponibile/i)"
        }

        if(existing==null){
            // Creazione appuntamento: UI compatta e moderna. La logica di calendario/ripetizione resta invariata.
            val page=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(14),dp(18),dp(12))}
            val scroll=ScrollView(this).apply{isFillViewport=true;clipToPadding=false;setPadding(0,0,0,dp(24))}
            scroll.addView(page,ViewGroup.LayoutParams(-1,-2))

            val header=LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
                setPadding(dp(14),dp(10),dp(14),dp(10))
                background=roundedSurface(Color.rgb(238,246,255),22,Color.rgb(200,222,246),1)
            }
            val icon=TextView(this).apply{
                text="📅";textSize=23f;gravity=Gravity.CENTER
                background=roundedSurface(Color.WHITE,18)
                setPadding(dp(8),dp(7),dp(8),dp(7))
            }
            header.addView(icon,LinearLayout.LayoutParams(dp(50),dp(50)))
            val headerText=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),0,0,0)}
            headerText.addView(TextView(this).apply{
                text="Nuovo appuntamento";textSize=18f;setTextColor(Color.rgb(25,55,85));setTypeface(null,android.graphics.Typeface.BOLD)
            })
            headerText.addView(TextView(this).apply{
                text="Aggiungi un nuovo appuntamento al calendario";textSize=12.5f;setTextColor(Color.rgb(82,104,125));setPadding(0,dp(3),0,0)
            })
            header.addView(headerText,LinearLayout.LayoutParams(0,-2,1f))
            page.addView(header,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})

            fun modernSpinner(spinner:Spinner){
                spinner.background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(220,226,234),1)
                applyLiquidControlDepth(spinner)
                spinner.setPadding(dp(14),0,dp(10),0)
            }
            name.background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(220,226,234),1)
            applyLiquidControlDepth(name)
            name.setPadding(dp(14),0,dp(14),0)
            name.textSize=16f
            name.setTextColor(Color.rgb(35,38,42))
            name.setHintTextColor(Color.rgb(135,140,147))
            styleClientNameSuggestions(name)
            name.isFocusable=true;name.isFocusableInTouchMode=true
            modernSpinner(time);modernSpinner(type);installNikiTypeDropdown(type)
            val fields=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
            fields.addView(TextView(this).apply{text="Cognome e Nome";textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,74,80));setPadding(dp(2),0,0,dp(5))})
            fields.addView(name,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(10))})
            fields.addView(TextView(this).apply{text="Data";textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,74,80));setPadding(dp(2),0,0,dp(5))})
            fields.addView(date,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(10))})
            fields.addView(TextView(this).apply{text="Fascia oraria disponibile";textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,74,80));setPadding(dp(2),0,0,dp(5))})
            fields.addView(time,LinearLayout.LayoutParams(dp(110),dp(50)).apply{gravity=Gravity.CENTER;setMargins(0,0,0,dp(10))})
            fields.addView(TextView(this).apply{text="Tipo appuntamento";textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,74,80));setPadding(dp(2),0,0,dp(5))})
            fields.addView(type,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(10))})
            page.addView(fields)
            recovery=CheckBox(this).apply{
                text="↩ Recupero seduta persa";textSize=13.5f;setTextColor(Color.rgb(55,58,63));setPadding(0,0,0,0);visibility=View.GONE
            }
            page.addView(recovery,LinearLayout.LayoutParams(-1,dp(44)).apply{setMargins(dp(2),0,0,dp(2))})

            val repeat=CheckBox(this).apply{
                text="Ripeti ogni settimana";textSize=14f;setTextColor(Color.rgb(35,38,42));setPadding(0,0,0,0)
            }
            val repeatRow=LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
                setPadding(dp(12),dp(7),dp(10),dp(7))
                background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(220,226,234),1)
                applyLiquidControlDepth(this)
                addView(repeat,LinearLayout.LayoutParams(0,dp(48),1f))
            }
            page.addView(repeatRow,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})

            val repeatPanel=LinearLayout(this).apply{
                orientation=LinearLayout.VERTICAL;visibility=View.GONE
                setPadding(dp(12),dp(10),dp(12),dp(10))
                background=roundedSurface(Color.rgb(238,246,255),20,Color.rgb(205,225,247),1)
            }
            repeatPanel.addView(TextView(this).apply{
                text="Seleziona giorni e orari";textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,75,125));setPadding(0,0,0,dp(7))
            })
            val days=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
            val checks=(0..6).map{i->CheckBox(this).apply{text=dayShort(i);isChecked=i==((forcedDay?:calendarWeekStart).dayOfWeek.value-1);setPadding(0,0,0,0)}}
            val dayTimes=mutableMapOf<Int,Spinner>()
            val dayRows=mutableMapOf<Int,LinearLayout>()
            fun datesForWeekday(dayIndex:Int,start:LocalDate,end:LocalDate):List<LocalDate>{
                val out=mutableListOf<LocalDate>();var d=start
                while(!d.isAfter(end)){if(d.dayOfWeek.value-1==dayIndex)out.add(d);d=d.plusDays(1)}
                return out
            }
            fun slotsForWeekday(dayIndex:Int,start:LocalDate,end:LocalDate,selectedType:String):List<String>{
                val dates=datesForWeekday(dayIndex,start,end);if(dates.isEmpty())return emptyList()
                val first=availableTimeSlots(dates.first(),selectedType,existing)
                return first.filter{slot->dates.all{d->canAdd(d,slot,selectedType,if(existing?.date==d)existing else null)}}
            }
            val end=modernEditText().apply{hint="Fine ripetizione (gg/mm/aaaa)";inputType=2;setText(calendarWeekStart.plusWeeks(12).format(fmt));visibility=View.GONE};setupDateInput(end)
            repeatPanel.addView(days)
            repeatPanel.addView(end,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(8),0,0)})
            page.addView(repeatPanel,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})
            checks.forEachIndexed{idx,c->
                val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                row.addView(c,LinearLayout.LayoutParams(0,dp(48),1f))
                val spinner=Spinner(this).also{installNikiTimeDropdown(it, true)};modernSpinner(spinner);dayTimes[idx]=spinner
                row.addView(spinner,LinearLayout.LayoutParams(dp(110),dp(46)).apply{gravity=Gravity.CENTER_VERTICAL})
                dayRows[idx]=row;days.addView(row)
            }
            fun refreshDayTimeRows(){
                val startDate=runCatching{parseDate(date.text.toString())}.getOrNull()?:calendarWeekStart
                val endDate=runCatching{parseDate(end.text.toString())}.getOrNull()?:startDate
                val selectedType=typeIdAt(type.selectedItemPosition)
                checks.forEachIndexed{idx,c->
                    val row=dayRows[idx]?:return@forEachIndexed;val spinner=dayTimes[idx]?:return@forEachIndexed
                    // I sette giorni restano sempre visibili: solo l'orario viene mostrato
                    // quando il relativo giorno è selezionato.
                    row.visibility=View.VISIBLE
                    spinner.visibility=if(c.isChecked)View.VISIBLE else View.INVISIBLE
                    spinner.isEnabled=c.isChecked
                    if(!c.isChecked)return@forEachIndexed
                    val values=slotsForWeekday(idx,startDate,endDate,selectedType);val shown=if(values.isEmpty())listOf("NESSUNA FASCIA DISPONIBILE") else values
                    spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,shown)
                    val preferred=if(idx==((forcedDay?:calendarWeekStart).dayOfWeek.value-1))time.selectedItem?.toString()else null
                    if(preferred!=null){val pi=shown.indexOf(preferred);if(pi>=0)spinner.setSelection(pi)}
                    spinner.isEnabled=values.isNotEmpty()
                }
            }
            // Listener collegati dopo la dichiarazione della funzione locale: evita riferimenti non risolti in Kotlin.
            checks.forEach{c->c.setOnCheckedChangeListener{_,_->refreshDayTimeRows()}}
            type.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{
                override fun onNothingSelected(parent:AdapterView<*>?){ }
                override fun onItemSelected(parent:AdapterView<*>?,view:View?,position:Int,id:Long){
                    refreshTimeSlots()
                    if(repeat.isChecked) refreshDayTimeRows()
                }
            }
            var dialogRef:AlertDialog?=null
            repeat.setOnCheckedChangeListener{_,checked->
                repeatPanel.visibility=if(checked)View.VISIBLE else View.GONE
                end.visibility=if(checked)View.VISIBLE else View.GONE
                time.visibility=if(checked)View.GONE else View.VISIBLE
                recovery?.visibility=if(checked)View.GONE else if(recovery?.isEnabled==true)View.VISIBLE else View.GONE
                refreshDayTimeRows()
                dialogRef?.window?.let{w->
                    val target=if(checked)ViewGroup.LayoutParams.WRAP_CONTENT else ViewGroup.LayoutParams.WRAP_CONTENT
                    w.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),target)
                }
                if(checked){
                    repeatPanel.alpha=0f
                    repeatPanel.translationY=-dp(10).toFloat()
                    repeatPanel.animate().alpha(1f).translationY(0f).setDuration(180).start()
                    // Dopo l'espansione porta automaticamente la nuova sezione in vista,
                    // lasciando comunque lo ScrollView libero di muoversi in entrambe le direzioni.
                    scroll.postDelayed({
                        val target=(repeatPanel.top-dp(12)).coerceAtLeast(0)
                        scroll.smoothScrollTo(0,target)
                    },220)
                } else {
                    scroll.post{scroll.smoothScrollTo(0,0)}
                }
            }
            date.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){refreshTimeSlots();if(repeat.isChecked)refreshDayTimeRows();refreshRecoveryOption()};override fun afterTextChanged(s:Editable?){}})
            name.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){refreshRecoveryOption()};override fun afterTextChanged(s:Editable?){}})
            end.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){if(repeat.isChecked)refreshDayTimeRows()};override fun afterTextChanged(s:Editable?){}})

            val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            val cancel=TextView(this).apply{text="Annulla";textSize=14f;setTextColor(Color.rgb(20,91,165));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(220,226,234),1);isClickable=true;applyLiquidControlDepth(this)}
            val save=TextView(this).apply{text="✓ Salva";textSize=14f;setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);background=liquidInteractiveSurface(Color.rgb(232,243,255),20,Color.rgb(188,211,238),1);isClickable=true;applyLiquidControlDepth(this)}
            actions.addView(cancel,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(6),0)})
            actions.addView(save,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(6),0,0,0)})
            page.addView(actions,LinearLayout.LayoutParams(-1,dp(48)))
            page.setPadding(dp(18),dp(14),dp(18),dp(24))

            listOf<View>(name,date,end).forEach{field->field.setOnFocusChangeListener{_,hasFocus->if(hasFocus)scroll.post{scroll.smoothScrollTo(0,(field.top-dp(24)).coerceAtLeast(0))}}}
            val dialog=AlertDialog.Builder(this).setView(scroll).create()
            preparePopupBackdrop(dialog)
            dialog.setOnShowListener{
                popupBackdropCurrentDialog=dialog
                dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28))
                applyPopupBackdropEffect(dialog);dialog.window?.setDimAmount(0.40f)
                dialog.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
                dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT)
                animateCalendarDialog(dialog,scroll)
                name.clearFocus();date.clearFocus();end.clearFocus()
            }
            cancel.setOnClickListener{dialog.dismiss()}
            save.setOnClickListener{
                val selectedDayTimes=dayTimes.filterKeys{checks[it].isChecked}.mapValues{it.value.selectedItem?.toString() ?: ""}
                createAppointments(name.text.toString().trim(),date.text.toString(),time.selectedItem?.toString() ?: "",typeIdAt(type.selectedItemPosition),repeat.isChecked,checks,end.text.toString(),recovery?.isChecked==true,dayTimes=selectedDayTimes)
                dialog.dismiss()
            }
            dialogRef=dialog
            dialog.show()
            refreshTimeSlots()
            refreshRecoveryOption()
            refreshDayTimeRows()
        }else{
            val page=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(14),dp(18),dp(18))}
            val scroll=ScrollView(this).apply{isFillViewport=true;clipToPadding=false;setPadding(0,0,0,dp(8));addView(page,ViewGroup.LayoutParams(-1,-2))}

            val top=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_HORIZONTAL}
            val icon=TextView(this).apply{
                text="✎";textSize=24f;gravity=Gravity.CENTER;setTextColor(Color.rgb(25,105,190))
                background=roundedSurface(Color.rgb(225,239,255),50);setPadding(dp(12),dp(10),dp(12),dp(10))
            }
            top.addView(icon,LinearLayout.LayoutParams(dp(64),dp(64)).apply{gravity=Gravity.CENTER})
            top.addView(TextView(this).apply{text="Modifica appuntamento";textSize=22f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(24,35,50));gravity=Gravity.CENTER;setPadding(0,dp(10),0,dp(2))},LinearLayout.LayoutParams(-1,dp(38)))
            top.addView(TextView(this).apply{text="Modifica i dati dell'appuntamento";textSize=13.5f;setTextColor(Color.rgb(88,98,110));gravity=Gravity.CENTER;setPadding(0,0,0,dp(12))},LinearLayout.LayoutParams(-1,dp(30)))
            page.addView(top)

            fun label(t:String)=TextView(this).apply{text=t;textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,78,88));setPadding(dp(2),0,0,dp(5))}
            fun modernAuto(v:AutoCompleteTextView){v.background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(220,226,234),1);applyLiquidControlDepth(v);v.setPadding(dp(14),0,dp(14),0);v.textSize=16f;v.setTextColor(Color.rgb(35,38,42));v.setHintTextColor(Color.rgb(135,140,147))}
            fun modernSpinner(v:Spinner){v.background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(220,226,234),1);applyLiquidControlDepth(v);v.setPadding(dp(12),0,dp(10),0)}
            modernAuto(name)
            styleClientNameSuggestions(name)
            // date è un EditText: manteniamo il campo moderno separato.
            date.background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(220,226,234),1);applyLiquidControlDepth(date);date.setPadding(dp(14),0,dp(14),0);date.textSize=16f
            modernSpinner(time);modernSpinner(type);installNikiTypeDropdown(type)
            val fields=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(2),0,dp(2),0)}
            fields.addView(label("Cognome e Nome"));fields.addView(name,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(10))})
            fields.addView(label("Data"));fields.addView(date,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(10))})
            fields.addView(label("Fascia oraria"));fields.addView(time,LinearLayout.LayoutParams(dp(110),dp(50)).apply{gravity=Gravity.CENTER;setMargins(0,0,0,dp(10))})
            fields.addView(label("Tipo appuntamento"));fields.addView(type,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(8))})
            page.addView(fields)
            if(seriesEdit!=null){
                page.addView(seriesEdit,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(6),0,dp(8))})
            }
            val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            val cancel=TextView(this).apply{text="Annulla";textSize=14f;setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(218,225,234),1);isClickable=true;applyLiquidControlDepth(this)}
            val save=TextView(this).apply{text="✓ Salva";textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;background=liquidInteractiveSurface(Color.rgb(232,243,255),20,Color.rgb(188,211,238),1);isClickable=true;applyLiquidControlDepth(this)}
            actions.addView(cancel,LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(0,0,dp(5),0)});actions.addView(save,LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(dp(5),0,0,0)})
            page.addView(actions,LinearLayout.LayoutParams(-1,dp(50)))
            listOf<View>(name,date).forEach{field->field.setOnFocusChangeListener{_,hasFocus->if(hasFocus)scroll.post{scroll.smoothScrollTo(0,(field.top-dp(20)).coerceAtLeast(0))}}}
            // La schermata di modifica usa esattamente la stessa struttura Glass
            // della schermata "Nuovo appuntamento": una sola superficie sulla finestra,
            // senza un secondo pannello Glass interno che crea una doppia fascia in basso.
            val dialog=AlertDialog.Builder(this).setView(scroll).create()
            preparePopupBackdrop(dialog)
            dialog.setOnShowListener{
                popupBackdropCurrentDialog=dialog
                dialog.window?.apply{
                    setBackgroundDrawable(roundedSurface(Color.WHITE,28))
                    setDimAmount(0.40f)
                    setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT)
                    setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
                }
                applyPopupBackdropEffect(dialog)
                animateCalendarDialog(dialog,scroll)
            }
            cancel.setOnClickListener{dialog.dismiss()}
            save.setOnClickListener{updateAppointment(existing,name.text.toString().trim(),date.text.toString(),time.selectedItem?.toString() ?: "",typeIdAt(type.selectedItemPosition));dialog.dismiss()}
            dialog.show();refreshTimeSlots();seriesEdit?.setOnClickListener{dialog.dismiss();editSeriesProgramming(existing!!)}
        }
    }

    private fun editSeriesProgramming(anchor:Appointment){
        val seriesId=anchor.seriesId
        if(seriesId==0L)return
        val series=appointments.filter{it.seriesId==seriesId}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        if(series.isEmpty())return
        val future=series.filter{!it.date.isBefore(anchor.date)}
        if(future.isEmpty())return
        val endDate=series.maxOf{it.date}

        val page=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(18),dp(10),dp(18),dp(12))
        }
        val scroll=ScrollView(this).apply{
            isFillViewport=true
            clipToPadding=false
            setPadding(0,0,0,dp(18))
            addView(page,ViewGroup.LayoutParams(-1,-2))
        }

        // Header Niki UI: icona grafica + titolo + contesto, senza emoji.
        val header=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(12),dp(10),dp(12),dp(12))
            background=liquidInteractiveSurface(Color.rgb(238,246,255),22,Color.rgb(194,220,247),1)
        }
        val icon=TextView(this).apply{
            text="↻";textSize=30f;gravity=Gravity.CENTER
            setTextColor(Color.rgb(25,92,170))
            background=liquidInteractiveSurface(Color.rgb(222,237,255),20)
        }
        header.addView(icon,LinearLayout.LayoutParams(dp(56),dp(56)))
        val headerText=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
        headerText.addView(TextView(this).apply{
            text="Modifica ripetizione";textSize=19f;setTextColor(Color.rgb(24,38,58));setTypeface(null,android.graphics.Typeface.BOLD)
        })
        headerText.addView(TextView(this).apply{
            text="Modifica da ${anchor.date.format(fmt)} in poi";textSize=13f;setTextColor(Color.rgb(82,104,125));setPadding(0,dp(3),0,0)
        })
        header.addView(headerText,LinearLayout.LayoutParams(0,-2,1f))
        page.addView(header,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})

        page.addView(TextView(this).apply{
            text="Scegli i giorni e gli orari della nuova programmazione";textSize=14f;setTextColor(Color.rgb(55,64,76));setPadding(dp(2),0,dp(2),dp(10))
        })

        val type=Spinner(this).apply{adapter=centeredSpinnerAdapter(appointmentTypes.map{it.name});setSelection(typeIndex(anchor.type));installNikiTypeDropdown(this);background=liquidInteractiveSurface(Color.rgb(248,249,251),18,Color.rgb(220,226,234),1);setPadding(dp(14),0,dp(10),0)}
        page.addView(TextView(this).apply{text="Tipo appuntamento";textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,74,80));setPadding(dp(2),0,0,dp(5))})
        page.addView(type,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(12))})

        val days=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        page.addView(TextView(this).apply{text="Giorni";textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,74,80));setPadding(dp(2),0,0,dp(6))})

        val checks=(0..6).map{i->CheckBox(this).apply{
            text=dayShort(i);textSize=15f;setTextColor(Color.rgb(35,38,42));setPadding(0,0,0,0);isChecked=future.any{it.date.dayOfWeek.value-1==i}
        }}
        val dayTimes=mutableMapOf<Int,Spinner>()
        val rows=mutableMapOf<Int,LinearLayout>()

        fun datesForDay(dayIndex:Int):List<LocalDate>{
            val out=mutableListOf<LocalDate>();var d=anchor.date
            while(!d.isAfter(endDate)){if(d.dayOfWeek.value-1==dayIndex)out.add(d);d=d.plusDays(1)}
            return out
        }
        fun availableSeriesSlots(dayIndex:Int,selectedType:String):List<String>{
            val dates=datesForDay(dayIndex)
            if(dates.isEmpty())return emptyList()
            val first=availableTimeSlotsAfterSeriesRemoval(dates.first(),selectedType,seriesId)
            return first.filter{slot->dates.all{d->canAddAfterSeriesRemoval(d,slot,selectedType,seriesId)}}
        }
        fun refresh(){
            val selectedType=typeIdAt(type.selectedItemPosition)
            checks.forEachIndexed{idx,c->
                val spinner=dayTimes[idx] ?: return@forEachIndexed
                val row=rows[idx] ?: return@forEachIndexed
                row.alpha=if(c.isChecked)1f else 0.72f
                spinner.visibility=if(c.isChecked)View.VISIBLE else View.INVISIBLE
                if(!c.isChecked)return@forEachIndexed
                val values=availableSeriesSlots(idx,selectedType)
                val shown=if(values.isEmpty())listOf("NESSUNA FASCIA DISPONIBILE") else values
                spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,shown)
                val preferred=future.firstOrNull{it.date.dayOfWeek.value-1==idx}?.time
                if(preferred!=null){val pi=shown.indexOf(preferred);if(pi>=0)spinner.setSelection(pi)}
                spinner.isEnabled=values.isNotEmpty()
            }
        }

        checks.forEachIndexed{idx,c->
            val row=LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
                setPadding(dp(12),dp(2),dp(8),dp(2))
                background=liquidInteractiveSurface(Color.rgb(248,249,251),18,Color.rgb(220,226,234),1)
            }
            row.addView(c,LinearLayout.LayoutParams(0,dp(50),1f))
            val spinner=Spinner(this).also{
                installNikiTimeDropdown(it, true)
                it.background=liquidInteractiveSurface(Color.rgb(248,249,251),16,Color.rgb(220,226,234),1)
                it.setPadding(dp(10),0,dp(6),0)
            }
            dayTimes[idx]=spinner
            row.addView(spinner,LinearLayout.LayoutParams(dp(110),dp(46)).apply{gravity=Gravity.CENTER_VERTICAL})
            rows[idx]=row
            days.addView(row,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,0,0,dp(6))})
            c.setOnCheckedChangeListener{_,_->refresh()}
        }
        page.addView(days,LinearLayout.LayoutParams(-1,-2))

        val endCard=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(12),dp(10),dp(12),dp(10))
            background=liquidInteractiveSurface(Color.rgb(232,243,255),18,Color.rgb(192,220,248),1)
        }
        endCard.addView(TextView(this).apply{text="▣";textSize=22f;setTextColor(Color.rgb(25,92,170));gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(38),dp(38)))
        endCard.addView(TextView(this).apply{
            text="Fine programmazione: ${endDate.format(fmt)}\nVerranno aggiornati gli appuntamenti futuri selezionati.";textSize=13f;setTextColor(Color.rgb(55,74,96));setLineSpacing(0f,1.05f);setPadding(dp(8),0,0,0)
        },LinearLayout.LayoutParams(0,-2,1f))
        page.addView(endCard,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(8),0,dp(12))})

        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val cancel=TextView(this).apply{
            text="Annulla";textSize=14f;setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);isClickable=true
            background=liquidInteractiveSurface(Color.rgb(248,249,251),18,Color.rgb(188,211,238),1)
        }
        val save=TextView(this).apply{
            text="✓ Salva";textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;isClickable=true
            background=liquidInteractiveSurface(Color.rgb(232,243,255),18,Color.rgb(188,211,238),1);applyLiquidControlDepth(this)
        }
        actions.addView(cancel,LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(0,0,dp(5),0)})
        actions.addView(save,LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(dp(5),0,0,0)})
        page.addView(actions,LinearLayout.LayoutParams(-1,dp(50)))

        type.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent:AdapterView<*>?){ }
            override fun onItemSelected(parent:AdapterView<*>?,view:View?,position:Int,id:Long){refresh()}
        }
        val dialog=AlertDialog.Builder(this).setView(scroll).create()
        styleFullPageCoachDialog(dialog)
        cancel.setOnClickListener{dialog.dismiss()}
        save.setOnClickListener{
            val selected=checks.mapIndexedNotNull{idx,c->if(c.isChecked)idx else null}
            if(selected.isEmpty()){Toast.makeText(this,"Seleziona almeno un giorno.",Toast.LENGTH_LONG).show();return@setOnClickListener}
            val selectedType=typeIdAt(type.selectedItemPosition)
            val times=selected.associateWith{idx->dayTimes[idx]?.selectedItem?.toString()?.takeUnless{it=="NESSUNA FASCIA DISPONIBILE"}}
            if(times.values.any{it==null}){Toast.makeText(this,"Scegli un orario disponibile per ogni giorno selezionato.",Toast.LENGTH_LONG).show();return@setOnClickListener}
            applySeriesProgrammingFrom(anchor,selected,times.mapValues{it.value!!},selectedType,endDate)
            dialog.dismiss()
        }
        dialog.show()
        animateSeriesProgrammingIn(dialog,scroll)
        refresh()
    }

    private fun animateSeriesProgrammingIn(dialog: AlertDialog, content: View){
        dialog.window?.attributes = dialog.window?.attributes?.apply{windowAnimations=0}
        content.animate().cancel()
        content.alpha=0f
        content.translationX=dp(34).toFloat()
        content.scaleX=0.985f
        content.scaleY=0.985f
        content.animate().alpha(1f).translationX(0f).scaleX(1f).scaleY(1f)
            .setDuration(210)
            .setInterpolator(android.view.animation.DecelerateInterpolator(1.15f))
            .withLayer().start()
    }

    private fun availableTimeSlotsAfterSeriesRemoval(date:LocalDate,type:String,seriesId:Long):List<String>{
        return (0 until 20).map{slot -> val mins=7*60+slot*45; String.format("%02d:%02d",mins/60,mins%60)}.filter{slot->canAddAfterSeriesRemoval(date,slot,type,seriesId)}
    }

    private fun canAddAfterSeriesRemoval(date:LocalDate,time:String,type:String,seriesId:Long):Boolean{
        val r=calendarRoutines.getOrNull(activeRoutineIndex)?:CalendarRoutine("Personalizzata",3,MutableList(appointmentTypes.size){3})
        val items=appointments.filter{it.date==date&&it.time==time&&it.seriesId!=seriesId}
        if(items.size>=r.maxTotal)return false
        val idx=typeIndex(type);if(items.count{typeIndex(it.type)==idx}>=(r.maxByType.getOrNull(idx)?:r.maxTotal))return false
        return true
    }

    private fun applySeriesProgrammingFrom(anchor:Appointment,selectedDays:List<Int>,dayTimes:Map<Int,String>,type:String,endDate:LocalDate){
        val seriesId=anchor.seriesId
        val future=appointments.filter{it.seriesId==seriesId&&!it.date.isBefore(anchor.date)}
        if(future.isEmpty())return
        val sessionPackId=future.firstOrNull{it.sessionPackId!=0L}?.sessionPackId ?: anchor.sessionPackId
        val futureIds=future.map{it.id}.toSet()
        appointments.removeAll{it.id in futureIds}
        var d=anchor.date;var created=0;var skipped=0
        val linked=sessionPackId.takeIf{it!=0L}?.let{id->sessionPacks.firstOrNull{it.id==id}}
        val usedBefore=linked?.let{s->sessionBooked(s)}?:0
        while(!d.isAfter(endDate)){
            val idx=d.dayOfWeek.value-1
            if(idx in selectedDays){
                val t=dayTimes[idx]!!
                val capacityOk=canAdd(d,t,type)
                val packageOk=linked==null||usedBefore+created<linked.totalSessions
                if(capacityOk&&packageOk){appointments.add(Appointment(nextAppointmentId++,anchor.name,d,t,type,seriesId,sessionPackId,anchor.recovery));created++}else skipped++
            }
            d=d.plusDays(1)
        }
        saveData();calendarScreen()
        if(skipped>0)Toast.makeText(this,"$skipped appuntamenti non inseriti perché la fascia o il pacchetto non erano disponibili.",Toast.LENGTH_LONG).show()
    }

    private fun nikiConfirmDialog(title:String,message:String,positiveText:String,positiveColor:Int=Color.rgb(30,112,230),icon:String="⚠️",onPositive:()->Unit){
        val (dialog,outer,body)=packActionDialogBase(title,icon,positiveColor,if(positiveColor==Color.rgb(205,55,55))Color.rgb(255,235,235) else Color.rgb(232,242,255),Color.WHITE)
        body.addView(dialogBodyText(message))
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        row.addView(dialogButton("Annulla",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(218,225,232)){dialog.dismiss()},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(4),0)})
        row.addView(dialogButton(positiveText,Color.WHITE,positiveColor,positiveColor){dialog.dismiss();onPositive()},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(4),0,0,0)})
        body.addView(row)
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun dayShort(i:Int)=arrayOf("Lunedì","Martedì","Mercoledì","Giovedì","Venerdì","Sabato","Domenica")[i]
    private fun createAppointments(name:String,dateText:String,timeText:String,type:String,repeat:Boolean,checks:List<CheckBox>,endText:String,recovery:Boolean=false,allowWarnings:Boolean=false,dayTimes:Map<Int,String>?=null){
        try{
            val cleanName=normalizeDisplayName(name);require(cleanName.isNotEmpty());val start=parseDate(dateText);val time=normalizeTime(timeText);val linked=if(recovery)null else activeSessionPackFor(cleanName)
            if(recovery){
                val rp=regularPackFor(cleanName,start) ?: throw IllegalArgumentException("Nessun recupero disponibile")
                if(repeat || recoveriesForPack(rp)<=0) throw IllegalArgumentException("Nessun recupero disponibile")
            }
            if(!allowWarnings){
                val duplicateDates=if(repeat){
                    val end=runCatching{parseDate(endText)}.getOrNull()?:start
                    val selected=checks.mapIndexedNotNull{idx,c->if(c.isChecked)idx+1 else null}.toSet()
                    appointments.filter{identityKey(it.name)==identityKey(cleanName)&&selected.contains(it.date.dayOfWeek.value)&&!it.date.isBefore(start)&&!it.date.isAfter(end)}.map{it.date}.distinct().sorted()
                }else appointments.filter{identityKey(it.name)==identityKey(cleanName)&&it.date==start}.map{it.date}
                if(duplicateDates.isNotEmpty()){
                    val first=appointments.filter{identityKey(it.name)==identityKey(cleanName)&&duplicateDates.contains(it.date)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time}).first()
                    nikiConfirmDialog("Appuntamento già presente",if(repeat)"$cleanName ha già appuntamenti in ${duplicateDates.size} giorno/i della ripetizione. Primo trovato: ${first.date.format(fmt)} alle ${first.time}. Vuoi comunque crearli?" else "$cleanName ha già un appuntamento il ${first.date.format(fmt)} alle ${first.time}. Vuoi comunque creare un altro appuntamento oggi?","Crea comunque"){createAppointments(cleanName,dateText,timeText,type,repeat,checks,endText,recovery,true,dayTimes)}
                    return
                }
                if(linked!=null){
                    val remaining=linked.totalSessions-sessionBooked(linked)
                    val potential=if(!repeat)1 else run {
                        val end=runCatching{parseDate(endText)}.getOrNull()?:start
                        val selected=checks.mapIndexedNotNull{idx,c->if(c.isChecked)idx+1 else null}.toSet()
                        var d=start;var count=0
                        while(!d.isAfter(end)){
                            if(selected.contains(d.dayOfWeek.value)){
                                val dayTime=dayTimes?.get(d.dayOfWeek.value-1)?.let{normalizeTime(it)} ?: time
                                if(canAdd(d,dayTime,type))count++
                            }
                            d=d.plusDays(1)
                        }
                        count
                    }
                    if(remaining>0&&potential>=remaining){
                        nikiConfirmDialog("Ultima seduta del pacchetto","Questa prenotazione utilizzerà l'ultima seduta disponibile di $cleanName. Dopo questa prenotazione il pacchetto risulterà scaduto. Vuoi continuare?","Continua"){createAppointments(cleanName,dateText,timeText,type,repeat,checks,endText,recovery,true,dayTimes)}
                        return
                    }
                }
            }
            if(!repeat){
                if(!canAdd(start,time,type))throw IllegalArgumentException("Fascia piena")
                if(linked!=null&&sessionBooked(linked)>=linked.totalSessions)throw IllegalArgumentException("Pacchetto sedute pieno")
                appointments.add(Appointment(nextAppointmentId++,cleanName,start,time,type,0L,linked?.id?:0L,recovery));saveData();calendarScreen();return
            }
            val end=parseDate(endText);require(!end.isBefore(start));val selected=checks.mapIndexedNotNull{idx,c->if(c.isChecked)idx+1 else null};require(selected.isNotEmpty())
            val series=nextAppointmentId;var d=start;var count=0;var sessionAdded=0
            while(!d.isAfter(end)){
                if(selected.contains(d.dayOfWeek.value)){
                    val dayTime=dayTimes?.get(d.dayOfWeek.value-1)?.let{normalizeTime(it)} ?: time
                    if(canAdd(d,dayTime,type)){appointments.add(Appointment(nextAppointmentId++,cleanName,d,dayTime,type,series,linked?.id?:0L,recovery));sessionAdded++}else count++
                }
                d=d.plusDays(1)
            }
            saveData();calendarScreen();if(count>0)Toast.makeText(this,"$count ripetizioni non inserite perché la fascia o il pacchetto sedute non erano disponibili.",Toast.LENGTH_LONG).show()
        }catch(e:Exception){Toast.makeText(this,if(e.message=="Fascia piena")"Fascia non disponibile: massimo 3 persone e massimo 2 allenamenti." else "Controlla cliente, data, ora e ripetizione.",Toast.LENGTH_LONG).show()}
    }

    private fun normalizeTime(value:String):String{val clean=value.trim();val parts=clean.split(":");require(parts.size==2);val h=parts[0].toInt();val m=parts[1].toInt();require(h in 7..21&&m in 0..59);require((h*60+m-7*60)%45==0);return String.format("%02d:%02d",h,m)}
    private fun updateAppointment(a:Appointment,name:String,dateText:String,timeText:String,type:String){
        try{
            val cleanName=normalizeDisplayName(name);require(cleanName.isNotEmpty());val date=parseDate(dateText);val time=normalizeTime(timeText)
            val duplicate=appointments.firstOrNull{it!==a&&it.date==date&&identityKey(it.name)==identityKey(cleanName)}
            if(duplicate!=null){
                nikiConfirmDialog("Appuntamento già presente","$cleanName ha già un appuntamento il ${date.format(fmt)} alle ${duplicate.time}. Vuoi comunque spostare/modificare questo appuntamento?","Continua"){updateAppointmentConfirmed(a,cleanName,date,time,type)};return
            }
            updateAppointmentConfirmed(a,cleanName,date,time,type)
        }catch(_:Exception){Toast.makeText(this,"Controlla i dati dell'appuntamento.",Toast.LENGTH_LONG).show()}
    }

    private fun updateAppointmentConfirmed(a:Appointment,name:String,date:LocalDate,time:String,type:String){
        if(!canAdd(date,time,type,a)){Toast.makeText(this,"Questa fascia non è disponibile.",Toast.LENGTH_LONG).show();return}
        var linked=if(a.sessionPackId!=0L)sessionPacks.firstOrNull{it.id==a.sessionPackId} else null
        if(linked==null)linked=activeSessionPackFor(name)
        if(linked!=null&&a.sessionPackId!=linked.id){
            val bookedWithoutThis=sessionBooked(linked)-if(a.sessionPackId==linked.id) 1 else 0
            if(bookedWithoutThis>=linked.totalSessions){Toast.makeText(this,"Il pacchetto sedute è già completo.",Toast.LENGTH_LONG).show();return}
            a.sessionPackId=linked.id
        }
        a.name=name;a.date=date;a.time=time;a.type=type;saveData();calendarScreen()
    }

    private fun appointmentDialogForSlot(day:LocalDate,time:String){appointmentDialog(null,day,time)}

    private fun availableTimeSlots(date:LocalDate,type:String,ignore:Appointment?=null):List<String>{
        return (0 until 20).map{slot->
            val mins=7*60+slot*45
            String.format("%02d:%02d",mins/60,mins%60)
        }.filter{slot->canAdd(date,slot,type,ignore)}
    }

    private fun canAdd(date:LocalDate,time:String,type:String,ignore:Appointment?=null):Boolean{
        val r=calendarRoutines.getOrNull(activeRoutineIndex)?:CalendarRoutine("Personalizzata",3,MutableList(appointmentTypes.size){3})
        val items=appointments.filter{it.date==date&&it.time==time&&it!==ignore}
        if(items.size>=r.maxTotal)return false
        val idx=typeIndex(type);if(items.count{typeIndex(it.type)==idx}>=(r.maxByType.getOrNull(idx)?:r.maxTotal))return false
        return true
    }

}
