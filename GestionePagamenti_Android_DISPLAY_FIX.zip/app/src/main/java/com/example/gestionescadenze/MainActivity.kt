package com.example.gestionescadenze

import android.app.*
import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Color
import android.net.Uri
import android.provider.MediaStore
import android.content.ContentValues
import android.provider.Settings
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.graphics.drawable.GradientDrawable
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import android.text.Editable
import android.text.TextWatcher
import java.io.BufferedReader
import java.io.InputStreamReader
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters

private data class Pack(var name: String, val start: LocalDate, val total: Int, var paid: Int = 0, var customRates: MutableList<Int>? = null, var packageType: String = "PERSONALIZZATO", var sessionTotal: Int = 12, var active: Boolean = true, var missedSessions: Int = 0)
private data class SessionPack(
    val id: Long,
    var name: String,
    val start: LocalDate,
    val totalSessions: Int,
    val cost: Int,
    var active: Boolean = true
)
private data class AppointmentType(var id:String, var name:String, var color:Int, var duration:Int = 45)
private data class CalendarRoutine(var name:String, var maxTotal:Int, var maxByType:MutableList<Int>)

private data class Appointment(
    val id: Long,
    var name: String,
    var date: LocalDate,
    var time: String,
    var type: String,
    var seriesId: Long = 0L,
    var sessionPackId: Long = 0L,
    var recovery: Boolean = false
) {
    val duration: Int get() = if (type == "TYPE2") 30 else 45
}

class MainActivity : Activity() {
    private val fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy")
    private val timeFmt = DateTimeFormatter.ofPattern("HH:mm")
    private val packs = mutableListOf<Pack>()
    private val sessionPacks = mutableListOf<SessionPack>()
    private val appointments = mutableListOf<Appointment>()
    private var ferieStart: LocalDate? = null
    private var ferieEnd: LocalDate? = null
    private lateinit var list: LinearLayout
    private var dashboardEnabled = false
    private lateinit var searchInput: EditText
    private lateinit var searchList: LinearLayout
    private var calendarWeekStart: LocalDate = LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    private var nextAppointmentId = 1L
    private var nextSessionPackId = 1L
    private var calendarZoom = 1.0f
    private var calendarVisibleDays = booleanArrayOf(true,true,true,true,true,false,false)
    private val appointmentTypes = mutableListOf(
        AppointmentType("TYPE1","ALLENAMENTO",Color.rgb(45,135,210),45),
        AppointmentType("TYPE2","MEZZ'ORA",Color.rgb(215,55,55),30)
    )
    private val calendarRoutines = mutableListOf(
        CalendarRoutine("Standard",3,mutableListOf(2,3)),
        CalendarRoutine("Light",2,mutableListOf(1,2)),
        CalendarRoutine("Full",4,mutableListOf(3,4))
    )
    private var activeRoutineIndex = 0
    private var pendingSummaryText = ""
    private val expandedClients = mutableSetOf<String>()
    private var activePackageDialog: AlertDialog? = null

    companion object {
        private const val REQ_EXPORT = 1001
        private const val REQ_IMPORT = 1002
        private const val REQ_SUMMARY = 1003
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        if (android.os.Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(true)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        loadData()
        maybeAutoBackup()
        build()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()
    private fun typeBgForColor(c:Int):Int = Color.rgb((Color.red(c)+255)/2,(Color.green(c)+255)/2,(Color.blue(c)+255)/2)
    private fun normalizedType(type:String):String = when(type){"ALLENAMENTO"->"TYPE1";"MEZZ'ORA"->"TYPE2";else->type}
    private fun typeIndex(type:String):Int = appointmentTypes.indexOfFirst{it.id==normalizedType(type)}.let{if(it>=0)it else 0}
    private fun typeLabel(type:String):String = appointmentTypes.getOrNull(typeIndex(type))?.name ?: appointmentTypes.first().name
    private fun typeColor(type:String):Int = appointmentTypes.getOrNull(typeIndex(type))?.color ?: appointmentTypes.first().color
    private fun typeDuration(type:String):Int = appointmentTypes.getOrNull(typeIndex(type))?.duration ?: 45
    private fun typeIdAt(index:Int):String = appointmentTypes.getOrNull(index)?.id ?: appointmentTypes.first().id

    private fun roundedSurface(color:Int, radius:Int=16, strokeColor:Int=Color.TRANSPARENT, strokeWidth:Int=0): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius=dp(radius).toFloat(); if(strokeWidth>0) setStroke(dp(strokeWidth),strokeColor) }

    private fun buttonStyle(textValue: String): Button = Button(this).apply {
        text = textValue; textSize = 13.5f; setTextColor(Color.rgb(35,38,42)); gravity = Gravity.CENTER
        minHeight = 0; minimumHeight = 0; setAllCaps(false); stateListAnimator = null
        background = roundedSurface(Color.rgb(241,243,246),16,Color.rgb(226,229,234),1)
    }

    private fun primaryButtonStyle(textValue: String): Button = Button(this).apply {
        text = textValue; textSize = 13.5f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        minHeight = 0; minimumHeight = 0; setAllCaps(false); stateListAnimator = null
        background = roundedSurface(Color.rgb(20,112,232),16,Color.rgb(20,112,232),1)
    }

    private fun softBlueButtonStyle(textValue: String): Button = Button(this).apply {
        text = textValue; textSize = 13.5f; setTextColor(Color.rgb(30,83,145)); gravity = Gravity.CENTER
        minHeight = 0; minimumHeight = 0; setAllCaps(false); stateListAnimator = null
        background = roundedSurface(Color.rgb(235,244,255),16,Color.rgb(205,224,248),1)
    }

    private fun build() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(14),dp(16),dp(10)); setBackgroundColor(Color.rgb(247,248,250)) }
        val titleRow = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        titleRow.addView(TextView(this).apply { text="CoachFlow"; textSize=30f; setTextColor(Color.rgb(20,20,22)); gravity=Gravity.CENTER_VERTICAL }, LinearLayout.LayoutParams(0,dp(56),1f))
        val dashButton = Button(this).apply {
            text=if(dashboardEnabled) "DASH  ●" else "DASH  ○"; textSize=12.5f; setTextColor(Color.rgb(70,74,80)); gravity=Gravity.CENTER; minHeight=0; minimumHeight=0; setPadding(dp(8),0,dp(8),0); setAllCaps(false); stateListAnimator=null
            background=roundedSurface(if(dashboardEnabled) Color.rgb(235,241,248) else Color.rgb(248,249,250),18,Color.rgb(220,223,227),1)
            setOnClickListener { dashboardEnabled=!dashboardEnabled; saveData(); updateDashboardButton(this); render() }
        }
        titleRow.addView(dashButton,LinearLayout.LayoutParams(dp(78),dp(42)).apply{setMargins(dp(6),0,dp(4),0)})
        val moreButton=Button(this).apply{
            text="⋯"; textSize=22f; setTextColor(Color.rgb(55,58,63)); gravity=Gravity.CENTER
            minHeight=0; minimumHeight=0; setPadding(0,0,0,dp(4)); setAllCaps(false); stateListAnimator=null
            background=roundedSurface(Color.rgb(248,249,251),18,Color.rgb(220,223,227),1)
            setOnClickListener{mainMoreMenu()}
        }
        titleRow.addView(moreButton,LinearLayout.LayoutParams(dp(48),dp(42)))
        root.addView(titleRow,LinearLayout.LayoutParams(-1,dp(56)))
        root.addView(TextView(this).apply { text="Clienti  •  Pacchetti  •  Calendario  •  Pagamenti"; textSize=15f; setTextColor(Color.rgb(92,95,101)); setPadding(dp(2),0,0,dp(5)) },LinearLayout.LayoutParams(-1,dp(34)))
        val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val add=primaryButtonStyle("＋ Nuovo").apply{setOnClickListener{newPackageMenu()}}
        val ferie=buttonStyle("Chiusura ferie").apply{setOnClickListener{settings()}}
        val cal=primaryButtonStyle("📅 Calendario").apply{setOnClickListener{calendarScreen()}}
        buttons.addView(add,LinearLayout.LayoutParams(0,dp(58),1f).apply{setMargins(0,0,dp(4),0)}); buttons.addView(ferie,LinearLayout.LayoutParams(0,dp(58),1f).apply{setMargins(dp(2),0,dp(2),0)}); buttons.addView(cal,LinearLayout.LayoutParams(0,dp(58),1f).apply{setMargins(dp(4),0,0,0)}); root.addView(buttons,LinearLayout.LayoutParams(-1,dp(60)))
        root.addView(TextView(this).apply{textSize=13f;setTextColor(Color.DKGRAY);setPadding(0,dp(4),0,dp(4));gravity=Gravity.CENTER_VERTICAL;text=closureText()},LinearLayout.LayoutParams(-1,dp(34)))
        list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,dp(12),0,0)}
        val scroll=ScrollView(this).apply{addView(list,ViewGroup.LayoutParams(-1,-2))}; root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root); render()
    }

    private fun updateDashboardButton(button:Button){button.text=if(dashboardEnabled)"DASH  ●" else "DASH  ○";button.background=roundedSurface(if(dashboardEnabled)Color.rgb(235,241,248)else Color.rgb(248,249,250),18,Color.rgb(220,223,227),1)}

    private fun mainMoreMenu(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(4),dp(18),dp(8))}
        fun option(title:String,subtitle:String,icon:String,action:()->Unit){
            val row=LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL
                gravity=Gravity.CENTER_VERTICAL
                setPadding(dp(14),dp(12),dp(12),dp(12))
                background=roundedSurface(Color.rgb(246,248,250),20,Color.rgb(228,231,235),1)
                isClickable=true
                isFocusable=true
            }
            row.addView(TextView(this).apply{
                text=icon;textSize=22f;gravity=Gravity.CENTER
                setBackground(roundedSurface(Color.WHITE,16))
                setPadding(dp(8),dp(6),dp(8),dp(6))
            },LinearLayout.LayoutParams(dp(50),dp(50)))
            val texts=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
            texts.addView(TextView(this@MainActivity).apply{
                text=title;textSize=16f;setTextColor(Color.rgb(25,28,32))
                setTypeface(null,android.graphics.Typeface.BOLD)
            })
            texts.addView(TextView(this@MainActivity).apply{
                text=subtitle;textSize=12.5f;setTextColor(Color.rgb(100,104,110))
                setPadding(0,dp(3),0,0)
            })
            row.addView(texts,LinearLayout.LayoutParams(0,-2,1f))
            row.addView(TextView(this@MainActivity).apply{
                text="›";textSize=28f;setTextColor(Color.rgb(120,124,130));gravity=Gravity.CENTER
            },LinearLayout.LayoutParams(dp(28),dp(50)))
            row.setOnClickListener{action()}
            box.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))})
        }
        option("Backup e dati","Automatico • Esporta • Importa","☁"){backupMenu()}
        option("Impostazioni","Preferenze e gestione dell'app","⚙"){settings()}
        val close=Button(this).apply{
            text="Chiudi";setAllCaps(false);textSize=14f;setTextColor(Color.rgb(0,125,110))
            setBackgroundColor(Color.TRANSPARENT);stateListAnimator=null
        }
        box.addView(close,LinearLayout.LayoutParams(-1,dp(46)).apply{setMargins(0,dp(4),0,0)})
        val dialog=AlertDialog.Builder(this).setTitle("Altre opzioni").setView(box).create()
        dialog.setOnShowListener{
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28))
            dialog.window?.setDimAmount(0.42f)
            close.setOnClickListener{dialog.dismiss()}
        }
        dialog.show()
    }

    private fun newPackageMenu(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(4),dp(18),dp(8))}
        fun option(title:String,subtitle:String,icon:String,action:()->Unit){
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(12),dp(12),dp(12));background=roundedSurface(Color.rgb(246,248,250),20,Color.rgb(228,231,235),1);isClickable=true;isFocusable=true}
            val ico=TextView(this).apply{text=icon;textSize=23f;gravity=Gravity.CENTER;setBackground(roundedSurface(Color.WHITE,16));setPadding(dp(8),dp(6),dp(8),dp(6))}
            row.addView(ico,LinearLayout.LayoutParams(dp(50),dp(50)))
            val texts=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
            texts.addView(TextView(this).apply{text=title;textSize=16f;setTextColor(Color.rgb(25,28,32));setTypeface(null,android.graphics.Typeface.BOLD)})
            texts.addView(TextView(this).apply{text=subtitle;textSize=12.5f;setTextColor(Color.rgb(100,104,110));setPadding(0,dp(3),0,0)})
            row.addView(texts,LinearLayout.LayoutParams(0,-2,1f))
            row.addView(TextView(this).apply{text="›";textSize=28f;setTextColor(Color.rgb(120,124,130));gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(28),dp(50)))
            row.setOnClickListener{action()}
            box.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))})
        }
        option("Pacchetto 12 settimane","3 rate • Bronze / Silver / Gold","📦"){newPack()}
        option("Pacchetto sedute","Numero sedute e costo personalizzabili","🏋️"){newSessionPack()}
        val close=Button(this).apply{text="Chiudi";setAllCaps(false);textSize=14f;setTextColor(Color.rgb(0,125,110));setBackgroundColor(Color.TRANSPARENT);stateListAnimator=null}
        box.addView(close,LinearLayout.LayoutParams(-1,dp(46)).apply{setMargins(0,dp(4),0,0)})
        val dialog=AlertDialog.Builder(this).setView(box).create()
        styleOneUiDialog(dialog)
        dialog.setOnShowListener{ 
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28))
            dialog.window?.setDimAmount(0.42f)
            box.getChildAt(0)?.setOnClickListener{dialog.dismiss();newPack()}
            box.getChildAt(1)?.setOnClickListener{dialog.dismiss();newSessionPack()}
            close.setOnClickListener{dialog.dismiss()}
        }
        dialog.show()
    }

    private fun newSessionPack(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(8),dp(16),0)}
        val name=EditText(this).apply{hint="Nome e Cognome"}
        val sessions=EditText(this).apply{hint="Numero sedute";inputType=2;setSingleLine(true)}
        val cost=EditText(this).apply{hint="Costo totale (€)";inputType=2;setSingleLine(true)}
        box.addView(name);box.addView(sessions);box.addView(cost)
        AlertDialog.Builder(this).setTitle("Nuovo pacchetto sedute").setMessage("Il pacchetto viene saldato per intero e le sedute vengono conteggiate automaticamente dagli appuntamenti del calendario.").setView(box).setNegativeButton("Annulla",null).setPositiveButton("CREA"){_,_->
            try{
                val n=normalizeDisplayName(name.text.toString());val total=sessions.text.toString().trim().toInt();val c=cost.text.toString().trim().toInt()
                require(n.isNotEmpty()&&total>0&&c>0)
                sessionPacks.add(SessionPack(nextSessionPackId++,n,LocalDate.now(),total,c));saveData();render()
            }catch(_:Exception){Toast.makeText(this,"Controlla nome, numero sedute e costo.",Toast.LENGTH_LONG).show()}
        }.create().also{styleOneUiDialog(it);it.show()}
    }

    private fun normalizeDisplayName(value:String):String{
        return value.trim().split(Regex("\\s+")).filter{it.isNotBlank()}.joinToString(" "){word->
            word.lowercase().replaceFirstChar{if(it.isLowerCase())it.titlecase() else it.toString()}
        }
    }

    private fun identityKey(value:String):String{
        return value.trim().lowercase().split(Regex("\\s+")).filter{it.isNotBlank()}.sorted().joinToString(" ")
    }

    private fun newPack(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(8),dp(16),0)}
        val name=EditText(this).apply{hint="Nome e Cognome"}
        val date=EditText(this).apply{hint="Data inizio (gg/mm/aaaa)";inputType=2}
        setupDateInput(date)
        val type=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("BRONZE • 12 sedute","SILVER • 24 sedute","GOLD • 36 sedute"))}
        val cost=EditText(this).apply{hint="Costo totale (€)";inputType=2}
        box.addView(name);box.addView(date)
        box.addView(TextView(this).apply{text="Tipo pacchetto";textSize=13f;setTextColor(Color.DKGRAY);setPadding(0,dp(8),0,dp(3))})
        box.addView(type);box.addView(cost)
        AlertDialog.Builder(this).setTitle("Nuovo pacchetto 12 settimane").setView(box).setNegativeButton("Annulla",null).setPositiveButton("Crea"){_,_->
            try{
                val n=normalizeDisplayName(name.text.toString());val d=parseDate(date.text.toString());val c=cost.text.toString().trim().toInt()
                require(n.isNotEmpty()&&c>0)
                val kind=when(type.selectedItemPosition){0->"BRONZE";1->"SILVER";else->"GOLD"}
                packs.add(Pack(n,d,c,0,null,kind,when(kind){"BRONZE"->12;"SILVER"->24;else->36},true));saveData();render()
            }catch(_:Exception){Toast.makeText(this,"Controlla nome, data, tipo e costo.",Toast.LENGTH_LONG).show()}
        }.create().also{styleOneUiDialog(it);it.show()}
    }

    private fun setupDateInput(edit:EditText){edit.addTextChangedListener(object:TextWatcher{private var editing=false;override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){};override fun afterTextChanged(s:Editable?){if(editing||s==null)return;val digits=s.toString().filter{it.isDigit()}.take(8);val formatted=buildString{digits.forEachIndexed{i,c->if(i==2||i==4)append('/');append(c)}};if(formatted!=s.toString()){editing=true;edit.setText(formatted);edit.setSelection(formatted.length);editing=false}}})}
    private fun parseDate(value:String):LocalDate=LocalDate.parse(value.trim(),fmt)

    private fun settings(){
        val scroll=ScrollView(this).apply{isFillViewport=true}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(4),dp(18),dp(8))}
        fun section(title:String,subtitle:String){
            box.addView(TextView(this).apply{text=title;textSize=19f;setTextColor(Color.rgb(24,27,31));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(0,dp(10),0,dp(3))})
            box.addView(TextView(this).apply{text=subtitle;textSize=13.5f;setTextColor(Color.rgb(92,96,102));setPadding(0,0,0,dp(8))})
        }
        section("Chiusura ferie","Le scadenze che cadono nella chiusura vengono spostate al giorno successivo alla riapertura.")
        val s=EditText(this).apply{hint="Data inizio • gg/mm/aaaa";inputType=2;setSingleLine(true);setText(ferieStart?.format(fmt) ?: "")};setupDateInput(s)
        val e=EditText(this).apply{hint="Data fine • gg/mm/aaaa";inputType=2;setSingleLine(true);setText(ferieEnd?.format(fmt) ?: "")};setupDateInput(e)
        box.addView(s,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,0,0,dp(6))})
        box.addView(e,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,0,0,dp(14))})

        section("Giorni visualizzati nel calendario","Scegli quali giorni della settimana mostrare. La scelta viene salvata.")
        val dayChecks=(0..6).map{i->CheckBox(this).apply{text=dayShort(i);textSize=15f;isChecked=calendarVisibleDays[i];setPadding(0,0,0,0)}}
        dayChecks.forEach{cb->box.addView(cb,LinearLayout.LayoutParams(-1,dp(42)))}

        section("Tipi di appuntamento","Personalizza il nome e il colore. I primi 2 tipi sono già configurati.")
        val typeRows=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val typeNameFields=mutableListOf<EditText>()
        val workingTypes=appointmentTypes.map{it.copy()}.toMutableList()
        fun colorHex(c:Int)=String.format("#%06X",0xFFFFFF and c)
        fun renderTypeRows(){
            typeRows.removeAllViews();typeNameFields.clear()
            workingTypes.forEachIndexed{idx,t->
                val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                val name=EditText(this).apply{setSingleLine(true);setText(t.name);hint="Nome appuntamento ${idx+1}";gravity=Gravity.CENTER};typeNameFields.add(name)
                row.addView(name,LinearLayout.LayoutParams(0,dp(54),1f))
                val colorBtn=Button(this).apply{setAllCaps(false);text="✏️ Colore";textSize=12f;gravity=Gravity.CENTER;setTextColor(t.color);background=roundedSurface(typeBgForColor(t.color),14);stateListAnimator=null}
                colorBtn.setOnClickListener{
                    val palette=listOf("Blu" to Color.rgb(45,135,210),"Rosso" to Color.rgb(215,55,55),"Verde" to Color.rgb(40,160,90),"Arancione" to Color.rgb(235,140,35),"Viola" to Color.rgb(125,80,190),"Giallo" to Color.rgb(220,180,35),"Azzurro" to Color.rgb(55,170,205),"Grigio" to Color.rgb(100,105,112))
                    val labels=palette.map{"● ${it.first}"}.toMutableList();labels.add("＋ Personalizzato…")
                    AlertDialog.Builder(this).setTitle("Colore appuntamento").setItems(labels.toTypedArray()){_,which->
                        if(which<palette.size){val c=palette[which].second;t.color=c;colorBtn.setTextColor(c);colorBtn.background=roundedSurface(typeBgForColor(c),14)}else{
                            val input=EditText(this).apply{setSingleLine(true);setText(colorHex(t.color));gravity=Gravity.CENTER;hint="#RRGGBB"}
                            AlertDialog.Builder(this).setTitle("Colore personalizzato").setView(input).setNegativeButton("Annulla",null).setPositiveButton("OK"){_,_->runCatching{Color.parseColor(input.text.toString().trim())}.onSuccess{c->t.color=c;colorBtn.setTextColor(c);colorBtn.background=roundedSurface(typeBgForColor(c),14)}.onFailure{Toast.makeText(this,"Colore non valido. Usa #RRGGBB.",Toast.LENGTH_SHORT).show()}}.create().also{styleOneUiDialog(it);it.show()}
                        }
                    }.create().also{styleOneUiDialog(it);it.show()}
                }
                row.addView(colorBtn,LinearLayout.LayoutParams(dp(142),dp(48)).apply{setMargins(dp(6),0,0,0)})
                typeRows.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(3),0,dp(3))})
            }
        }
        renderTypeRows();box.addView(typeRows)
        val addType=softBlueButtonStyle("＋ Nome appuntamento")
        box.addView(addType,LinearLayout.LayoutParams(-1,dp(46)).apply{setMargins(0,dp(7),0,dp(8))})
        addType.setOnClickListener{val n=workingTypes.size+1;workingTypes.add(AppointmentType("TYPE$n","Nuovo appuntamento",Color.rgb(90,105,120),45));renderTypeRows()}

        section("Routine calendario","Imposta la capienza massima della fascia e il limite massimo per ogni tipo.")
        val routineSpinner=Spinner(this).apply{adapter=centeredSpinnerAdapter(calendarRoutines.map{it.name});setSelection(activeRoutineIndex)}
        val routineName=EditText(this).apply{hint="Nome routine";gravity=Gravity.CENTER;setSingleLine(true);setText(calendarRoutines[activeRoutineIndex].name)}
        val maxTotal=EditText(this).apply{hint="Appuntamenti massimi per fascia";inputType=2;gravity=Gravity.CENTER;setSingleLine(true);setText(calendarRoutines[activeRoutineIndex].maxTotal.toString())}
        val limitsBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val limitFields=mutableListOf<EditText>()
        fun renderLimits(){
            limitsBox.removeAllViews();limitFields.clear();val r=calendarRoutines[activeRoutineIndex]
            while(r.maxByType.size<workingTypes.size)r.maxByType.add(r.maxTotal)
            workingTypes.forEachIndexed{idx,t->
                val f=EditText(this).apply{hint="Massimo ${t.name}";inputType=2;gravity=Gravity.CENTER;setSingleLine(true);setText((r.maxByType.getOrNull(idx)?:r.maxTotal).toString())}
                limitFields.add(f);limitsBox.addView(f,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,dp(4),0,0)})
            }
        }
        box.addView(routineSpinner,LinearLayout.LayoutParams(-1,dp(52)))
        box.addView(routineName,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,dp(6),0,0)})
        box.addView(maxTotal,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,dp(4),0,0)})
        box.addView(limitsBox);renderLimits()
        val routineActions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER}
        val saveRoutine=buttonStyle("Salva routine");val newRoutine=softBlueButtonStyle("＋ Nuova routine");val deleteRoutine=buttonStyle("Elimina")
        routineActions.addView(saveRoutine,LinearLayout.LayoutParams(0,dp(46),1f).apply{setMargins(0,dp(6),dp(4),0)})
        routineActions.addView(newRoutine,LinearLayout.LayoutParams(0,dp(46),1f).apply{setMargins(dp(4),dp(6),dp(4),0)})
        routineActions.addView(deleteRoutine,LinearLayout.LayoutParams(0,dp(46),0.72f).apply{setMargins(dp(4),dp(6),0,0)})
        box.addView(routineActions)
        routineSpinner.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent:AdapterView<*>?){ }
            override fun onItemSelected(parent:AdapterView<*>?,view:View?,position:Int,id:Long){activeRoutineIndex=position;val r=calendarRoutines[position];routineName.setText(r.name);maxTotal.setText(r.maxTotal.toString());renderLimits()}
        }
        saveRoutine.setOnClickListener{try{
            val idx=routineSpinner.selectedItemPosition;val n=routineName.text.toString().trim();val total=maxTotal.text.toString().toInt();val limits=limitFields.map{it.text.toString().trim().toInt()}
            require(n.isNotEmpty()&&total>0&&limits.all{it>=0&&it<=total})
            calendarRoutines[idx]=CalendarRoutine(n,total,limits.toMutableList());activeRoutineIndex=idx
            saveData();routineSpinner.adapter=centeredSpinnerAdapter(calendarRoutines.map{it.name});routineSpinner.setSelection(idx)
            Toast.makeText(this,"Routine salvata.",Toast.LENGTH_SHORT).show()
        }catch(_:Exception){Toast.makeText(this,"Controlla i valori della routine.",Toast.LENGTH_LONG).show()}}
        newRoutine.setOnClickListener{
            calendarRoutines.add(CalendarRoutine("Nuova routine",3,MutableList(workingTypes.size){if(it==0)2 else 3}));activeRoutineIndex=calendarRoutines.lastIndex
            routineSpinner.adapter=centeredSpinnerAdapter(calendarRoutines.map{it.name});routineSpinner.setSelection(activeRoutineIndex);routineName.setText(calendarRoutines.last().name);maxTotal.setText("3");renderLimits()
        }
        deleteRoutine.setOnClickListener{if(calendarRoutines.size<=1){Toast.makeText(this,"Deve rimanere almeno una routine.",Toast.LENGTH_SHORT).show()}else{calendarRoutines.removeAt(routineSpinner.selectedItemPosition);activeRoutineIndex=0;routineSpinner.adapter=centeredSpinnerAdapter(calendarRoutines.map{it.name});routineSpinner.setSelection(0)}}

        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(10),0,0)}
        val clear=Button(this).apply{text="Cancella ferie";setAllCaps(false);textSize=13.5f;setTextColor(Color.rgb(205,55,55));setBackgroundColor(Color.TRANSPARENT);stateListAnimator=null}
        val cancel=Button(this).apply{text="Annulla";setAllCaps(false);textSize=13.5f;setTextColor(Color.rgb(0,125,110));setBackgroundColor(Color.TRANSPARENT);stateListAnimator=null}
        val save=Button(this).apply{text="Salva";setAllCaps(false);textSize=13.5f;setTextColor(Color.WHITE);background=roundedSurface(Color.rgb(0,125,110),18);stateListAnimator=null}
        actions.addView(clear,LinearLayout.LayoutParams(0,dp(46),1f));actions.addView(cancel,LinearLayout.LayoutParams(0,dp(46),1f));actions.addView(save,LinearLayout.LayoutParams(dp(86),dp(44)));box.addView(actions)
        scroll.addView(box,ViewGroup.LayoutParams(-1,-2))
        val dialog=AlertDialog.Builder(this).setView(scroll).create();styleOneUiDialog(dialog)
        dialog.setOnShowListener{
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28));dialog.window?.setDimAmount(0.42f)
            cancel.setOnClickListener{dialog.dismiss()}
            clear.setOnClickListener{ferieStart=null;ferieEnd=null;saveData();dialog.dismiss();build()}
            save.setOnClickListener{try{
                val st=s.text.toString().trim();val et=e.text.toString().trim()
                if(st.isEmpty()&&et.isEmpty()){ferieStart=null;ferieEnd=null}else{val sd=parseDate(st);val ed=parseDate(et);require(!ed.isBefore(sd));ferieStart=sd;ferieEnd=ed}
                require(dayChecks.any{it.isChecked})
                dayChecks.forEachIndexed{i,cb->calendarVisibleDays[i]=cb.isChecked}
                appointmentTypes.clear();workingTypes.forEachIndexed{i,t->{val nn=typeNameFields.getOrNull(i)?.text?.toString()?.trim().orEmpty();appointmentTypes.add(t.copy(name=nn.ifEmpty{t.name}))}}
                calendarRoutines.forEach{while(it.maxByType.size<appointmentTypes.size)it.maxByType.add(it.maxTotal)}
                saveData();dialog.dismiss();build();Toast.makeText(this,"Impostazioni salvate.",Toast.LENGTH_SHORT).show()
            }catch(_:Exception){Toast.makeText(this,"Inserisci dati validi e seleziona almeno un giorno del calendario.",Toast.LENGTH_LONG).show()}}
        }
        dialog.show()
    }
    private fun backupMenu(){
        val last=getSharedPreferences("gestione_pagamenti",MODE_PRIVATE).getString("autoBackupDate","")
        val lastText=if(last.isNullOrBlank())"Nessun backup automatico ancora"else"Ultimo backup automatico: $last"
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(4),dp(18),dp(8))}
        fun option(title:String,subtitle:String,icon:String,action:()->Unit){
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(12),dp(12),dp(12));background=roundedSurface(Color.rgb(246,248,250),20,Color.rgb(228,231,235),1);isClickable=true;isFocusable=true}
            row.addView(TextView(this).apply{text=icon;textSize=22f;gravity=Gravity.CENTER;setBackground(roundedSurface(Color.WHITE,16));setPadding(dp(8),dp(6),dp(8),dp(6))},LinearLayout.LayoutParams(dp(50),dp(50)))
            val texts=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
            texts.addView(TextView(this@MainActivity).apply{text=title;textSize=16f;setTextColor(Color.rgb(25,28,32));setTypeface(null,android.graphics.Typeface.BOLD)})
            texts.addView(TextView(this@MainActivity).apply{text=subtitle;textSize=12.5f;setTextColor(Color.rgb(100,104,110));setPadding(0,dp(3),0,0)})
            row.addView(texts,LinearLayout.LayoutParams(0,-2,1f))
            row.addView(TextView(this@MainActivity).apply{text="›";textSize=28f;setTextColor(Color.rgb(120,124,130));gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(28),dp(50)))
            row.setOnClickListener{action()}
            box.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))})
        }
        option("Backup automatico","Attivo • 1 copia automatica al giorno, separata dal manuale","☁"){maybeAutoBackup();Toast.makeText(this,"$lastText",Toast.LENGTH_LONG).show()}
        option("Esporta backup manuale","Salva una copia completa dove preferisci","↑"){exportData()}
        option("Importa backup manuale","Ripristina una copia precedentemente salvata","↓"){importData()}
        option("Ripristina backup automatico",lastText,"↺"){restoreAutoBackup()}
        val close=Button(this).apply{text="Chiudi";setAllCaps(false);textSize=14f;setTextColor(Color.rgb(0,125,110));setBackgroundColor(Color.TRANSPARENT);stateListAnimator=null}
        box.addView(close,LinearLayout.LayoutParams(-1,dp(46)).apply{setMargins(0,dp(4),0,0)})
        val dialog=AlertDialog.Builder(this).setTitle("Backup e dati").setView(box).create()
        dialog.setOnShowListener{dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28));dialog.window?.setDimAmount(0.42f);close.setOnClickListener{dialog.dismiss()}}
        dialog.show()
    }
    private fun exportData(){startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/json";putExtra(Intent.EXTRA_TITLE,"GestionePagamenti_backup.json")},REQ_EXPORT)}
    private fun importData(){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/json"},REQ_IMPORT)}
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK)return;val uri=data?.data?:return;if(requestCode==REQ_EXPORT)writeBackup(uri)else if(requestCode==REQ_IMPORT)readBackup(uri)else if(requestCode==REQ_SUMMARY)writeSummary(uri)}

    private fun backupJson():JSONObject{
        val root=JSONObject();root.put("format","GestionePagamenti");root.put("version",5);root.put("exportedAt",LocalDateTime.now().toString());root.put("ferieStart",ferieStart?.toString()?:JSONObject.NULL);root.put("ferieEnd",ferieEnd?.toString()?:JSONObject.NULL);root.put("dashboardEnabled",dashboardEnabled);root.put("calendarVisibleDays",JSONArray().apply{calendarVisibleDays.forEach{put(it)}});root.put("appointmentTypes",JSONArray().apply{appointmentTypes.forEach{t->put(JSONObject().apply{put("id",t.id);put("name",t.name);put("color",t.color);put("duration",t.duration)})}});root.put("activeRoutineIndex",activeRoutineIndex);root.put("calendarRoutines",JSONArray().apply{calendarRoutines.forEach{r->put(JSONObject().apply{put("name",r.name);put("maxTotal",r.maxTotal);put("maxByType",JSONArray().apply{r.maxByType.forEach{put(it)}})})}})
        val array=JSONArray();packs.forEach{p->val rates=ratesFor(p);val dates=dueDates(p);array.put(JSONObject().apply{put("name",p.name);put("start",p.start.toString());put("total",p.total);put("paid",p.paid);put("dueDates",JSONArray().apply{dates.forEach{put(it.toString())}});put("rateAmounts",JSONArray().apply{rates.forEach{put(it)}});put("packageType",p.packageType);put("sessionTotal",p.sessionTotal);put("active",p.active);put("missedSessions",p.missedSessions)})};root.put("packs",array)
        root.put("sessionPacks",JSONArray().apply{sessionPacks.forEach{s->put(JSONObject().apply{put("id",s.id);put("name",s.name);put("start",s.start.toString());put("totalSessions",s.totalSessions);put("cost",s.cost);put("active",s.active)})}})
        root.put("appointments",JSONArray().apply{appointments.forEach{a->put(JSONObject().apply{put("id",a.id);put("name",a.name);put("date",a.date.toString());put("time",a.time);put("type",a.type);put("seriesId",a.seriesId);put("sessionPackId",a.sessionPackId);put("recovery",a.recovery)})}});return root
    }

    private fun loadCalendarConfig(root:JSONObject){
        appointmentTypes.clear();root.optJSONArray("appointmentTypes")?.let{ta->for(i in 0 until ta.length()){val t=ta.getJSONObject(i);appointmentTypes.add(AppointmentType(t.optString("id","TYPE${i+1}"),t.optString("name",if(i==0)"ALLENAMENTO" else if(i==1)"MEZZ'ORA" else "Tipo ${i+1}"),t.optInt("color",if(i==0)Color.rgb(45,135,210) else Color.rgb(215,55,55)),t.optInt("duration",if(i==1)30 else 45)))}};if(appointmentTypes.isEmpty()){appointmentTypes.add(AppointmentType("TYPE1","ALLENAMENTO",Color.rgb(45,135,210),45));appointmentTypes.add(AppointmentType("TYPE2","MEZZ'ORA",Color.rgb(215,55,55),30))}
        calendarRoutines.clear();root.optJSONArray("calendarRoutines")?.let{ra->for(i in 0 until ra.length()){val r=ra.getJSONObject(i);val limits=mutableListOf<Int>();r.optJSONArray("maxByType")?.let{ja->for(j in 0 until ja.length())limits.add(ja.optInt(j,3))};if(limits.isEmpty()){limits.add(2);limits.add(3)};while(limits.size<appointmentTypes.size)limits.add(r.optInt("maxTotal",3));calendarRoutines.add(CalendarRoutine(r.optString("name","Routine ${i+1}"),r.optInt("maxTotal",3),limits))}};if(calendarRoutines.isEmpty())calendarRoutines.add(CalendarRoutine("Standard",3,MutableList(appointmentTypes.size){if(it==0)2 else 3}));activeRoutineIndex=root.optInt("activeRoutineIndex",0).coerceIn(0,calendarRoutines.lastIndex)
    }
    private fun writeSummary(uri:Uri){try{contentResolver.openOutputStream(uri)?.use{it.write(pendingSummaryText.toByteArray(Charsets.UTF_8))};Toast.makeText(this,"Riepilogo esportato.",Toast.LENGTH_LONG).show()}catch(_:Exception){Toast.makeText(this,"Impossibile esportare il riepilogo.",Toast.LENGTH_LONG).show()}}

    private fun regularPackFor(name:String, date:LocalDate):Pack? = packs.filter {
        it.active && identityKey(it.name)==identityKey(name) && !date.isBefore(it.start) && !date.isAfter(it.start.plusWeeks(12).minusDays(1))
    }.maxByOrNull { it.start }

    private fun recoveryUsedForPack(p:Pack):Int = appointments.count {
        it.recovery && identityKey(it.name)==identityKey(p.name) && !it.date.isBefore(p.start) && !it.date.isAfter(p.start.plusWeeks(12).minusDays(1))
    }

    private fun recoveriesForPack(p:Pack):Int = (p.missedSessions - recoveryUsedForPack(p)).coerceAtLeast(0)

    private fun sessionsForPack(p:Pack,until:LocalDate=LocalDate.now()):List<Appointment>{
        val end=p.start.plusWeeks(12).minusDays(1)
        return appointments.filter{identityKey(it.name)==identityKey(p.name)&&!it.date.isBefore(p.start)&&!it.date.isAfter(until)&&!it.date.isAfter(end)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
    }

    private fun sessionsForSessionPack(s:SessionPack,until:LocalDate=LocalDate.now()):List<Appointment>{
        return appointments.filter{it.sessionPackId==s.id&&!it.date.isAfter(until)&&!it.date.isBefore(s.start)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
    }

    private fun summaryForPack(p: Pack): String {
        val today = LocalDate.now()
        val packageEnd = p.start.plusWeeks(12).minusDays(1)
        val done = sessionsForPack(p, today)
        val expected = p.sessionTotal
        val recoveryDue = recoveriesForPack(p)
        val remaining = (expected - done.size).coerceAtLeast(0)
        val futurePackage = appointments.filter {
            identityKey(it.name) == identityKey(p.name) &&
                it.date.isAfter(today) && !it.date.isAfter(packageEnd) && !it.date.isBefore(p.start)
        }.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        return buildString {
            appendLine("📊 RIEPILOGO SEDUTE")
            appendLine()
            appendLine("Cliente: ${displaySurnameFirst(p.name)}")
            appendLine("Pacchetto: ${p.packageType} • $expected sedute")
            appendLine("Periodo: ${p.start.format(fmt)} → ${packageEnd.format(fmt)}")
            appendLine("Situazione al ${today.format(fmt)}")
            appendLine("Sedute effettuate: ${done.size}/$expected")
            appendLine("Sedute future prenotate: ${futurePackage.size}")
            appendLine("Sedute rimanenti: $remaining")
            if (!packageEnd.isAfter(today) || !p.active) appendLine("Sedute perse: $recoveryDue")
            appendLine()
            appendLine("SEDUTE EFFETTUATE")
            if (done.isEmpty()) appendLine("Nessuna seduta effettuata.")
            done.forEachIndexed { index, a ->
                val type = typeLabel(a.type)
                appendLine("${index + 1}. ${a.date.format(fmt)} • ${a.time} • $type")
            }
        }
    }

    private fun summaryForSessionPack(s: SessionPack): String {
        val today = LocalDate.now()
        val done = sessionsForSessionPack(s, today)
        val futurePackage = appointments.filter { it.sessionPackId == s.id && it.date.isAfter(today) }
            .sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        val annualFuture = appointments.filter {
            identityKey(it.name)==identityKey(s.name) && it.date.isAfter(today) && it.sessionPackId != s.id
        }.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        return buildString {
            appendLine("📋 PROGRAMMAZIONE ${displaySurnameFirst(s.name).uppercase()}")
            appendLine("Pacchetto • ${s.totalSessions} sedute")
            appendLine("Periodo pacchetto: ${s.start.format(fmt)} → aperto fino a esaurimento sedute")
            appendLine()
            appendLine("📊 SITUAZIONE")
            appendLine("• Sedute previste: ${s.totalSessions}")
            appendLine("• Sedute effettuate: ${done.size}")
            appendLine("• Sedute prenotate nel pacchetto: ${futurePackage.size}")
            appendLine("• Sedute rimanenti: ${(s.totalSessions-done.size).coerceAtLeast(0)}")
            appendLine()
            appendLine("🗓 PROGRAMMAZIONE DEL PACCHETTO")
            if(futurePackage.isEmpty()) appendLine("Nessun appuntamento futuro nel pacchetto.")
            futurePackage.forEachIndexed{index,a->
                val type=typeLabel(a.type)
                appendLine("${index+1}. ${a.date.format(fmt)} • ${a.time} • $type")
            }
            if(annualFuture.isNotEmpty()){
                appendLine()
                appendLine("📅 PROGRAMMAZIONE SUCCESSIVA")
                appendLine("Gli appuntamenti successivi restano nel calendario e verranno considerati per il prossimo pacchetto.")
                annualFuture.forEachIndexed{index,a->
                    val type=typeLabel(a.type)
                    appendLine("${index+1}. ${a.date.format(fmt)} • ${a.time} • $type")
                }
            }
        }
    }

    private fun copySummaryToClipboard(text:String,name:String){
        pendingSummaryText=text
        val clipboard=getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Riepilogo $name",text))
        val preview=TextView(this).apply{this.text=text;textSize=14f;setTextColor(Color.rgb(35,35,35));setPadding(dp(16),dp(8),dp(16),dp(8))}
        val dialog=AlertDialog.Builder(this).setTitle("📊 Riepilogo pronto per WhatsApp").setMessage("Il riepilogo è già stato copiato negli appunti. Puoi incollarlo direttamente su WhatsApp.").setView(ScrollView(this).apply{addView(preview)}).setPositiveButton("COPIA DI NUOVO"){_,_->
            clipboard.setPrimaryClip(ClipData.newPlainText("Riepilogo $name",text))
            Toast.makeText(this,"Riepilogo copiato negli appunti.",Toast.LENGTH_SHORT).show()
        }.setNegativeButton("CHIUDI",null).create()
        styleOneUiDialog(dialog)
        dialog.show()
    }

    private fun exportSummary(text:String,name:String){copySummaryToClipboard(text,name)}

    private fun maybeAutoBackup(){
        val prefs=getSharedPreferences("gestione_pagamenti",MODE_PRIVATE)
        val today=LocalDate.now().format(fmt)
        if(prefs.getString("autoBackupDate","")==today)return
        if(writeAutoBackup())prefs.edit().putString("autoBackupDate",today).apply()
    }

    private fun writeAutoBackup():Boolean{
        return try{
            val json=backupJson().toString(2).toByteArray(Charsets.UTF_8)
            val day=LocalDate.now().toString()
            val fileName="GestionePagamenti_auto_${day}.json"
            if(android.os.Build.VERSION.SDK_INT>=29){
                val resolver=contentResolver
                val projection=arrayOf(MediaStore.Downloads._ID)
                val selection="${MediaStore.Downloads.DISPLAY_NAME}=? AND ${MediaStore.Downloads.RELATIVE_PATH}=?"
                val args=arrayOf(fileName,"Download/GestionePagamenti/Backup automatici/")
                var uri:Uri?=null
                resolver.query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,projection,selection,args,null)?.use{c->if(c.moveToFirst())uri=Uri.withAppendedPath(MediaStore.Downloads.EXTERNAL_CONTENT_URI,c.getLong(0).toString())}
                val target=uri ?: resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,ContentValues().apply{
                    put(MediaStore.Downloads.DISPLAY_NAME,fileName)
                    put(MediaStore.Downloads.MIME_TYPE,"application/json")
                    put(MediaStore.Downloads.RELATIVE_PATH,"Download/GestionePagamenti/Backup automatici/")
                })
                target!=null && resolver.openOutputStream(target,"wt")?.use{it.write(json);true}==true
            }else{
                val dir=java.io.File(filesDir,"auto_backup");if(!dir.exists())dir.mkdirs()
                java.io.File(dir,fileName).writeBytes(json);true
            }
        }catch(_:Exception){false}
    }

    private fun restoreAutoBackup(){
        try{
            val text=if(android.os.Build.VERSION.SDK_INT>=29){
                val resolver=contentResolver
                val projection=arrayOf(MediaStore.Downloads._ID,MediaStore.Downloads.DISPLAY_NAME)
                val selection="${MediaStore.Downloads.DISPLAY_NAME} LIKE ? AND ${MediaStore.Downloads.RELATIVE_PATH}=?"
                val args=arrayOf("GestionePagamenti_auto_%.json","Download/GestionePagamenti/Backup automatici/")
                var uri:Uri?=null;var latestName=""
                resolver.query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,projection,selection,args,"${MediaStore.Downloads.DISPLAY_NAME} DESC")?.use{c->if(c.moveToFirst()){latestName=c.getString(1);uri=Uri.withAppendedPath(MediaStore.Downloads.EXTERNAL_CONTENT_URI,c.getLong(0).toString())}}
                uri?.let{resolver.openInputStream(it)?.use{ins->BufferedReader(InputStreamReader(ins,Charsets.UTF_8)).readText()}}
            }else{
                val dir=java.io.File(filesDir,"auto_backup")
                dir.listFiles()?.sortedByDescending{it.name}?.firstOrNull()?.takeIf{it.exists()}?.readText()
            } ?: throw Exception()
            val root=JSONObject(text);require(root.optString("format")=="GestionePagamenti")
            AlertDialog.Builder(this).setTitle("Ripristinare backup automatico?").setMessage("Il backup automatico sostituirà i dati attualmente presenti nell'app.\n\nBackup del: ${root.optString("exportedAt", "data non disponibile")}").setNegativeButton("ANNULLA",null).setPositiveButton("RIPRISTINA"){_,_->restoreFromJson(root)}.show()
        }catch(_:Exception){Toast.makeText(this,"Nessun backup automatico disponibile.",Toast.LENGTH_LONG).show()}
    }

    private fun restoreFromJson(root:JSONObject){
        try{
            val newPacks=mutableListOf<Pack>();val array=root.getJSONArray("packs");for(i in 0 until array.length()){val o=array.getJSONObject(i);newPacks.add(Pack(o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("total"),o.optInt("paid",0),o.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}},o.optString("packageType","PERSONALIZZATO"),o.optInt("sessionTotal",12),o.optBoolean("active",true),o.optInt("missedSessions",0)))}
            val newSessionPacks=mutableListOf<SessionPack>();val sp=root.optJSONArray("sessionPacks");if(sp!=null)for(i in 0 until sp.length()){val o=sp.getJSONObject(i);newSessionPacks.add(SessionPack(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("totalSessions"),o.getInt("cost"),o.optBoolean("active",true)))}
            val newAppointments=mutableListOf<Appointment>();val ap=root.optJSONArray("appointments");if(ap!=null)for(i in 0 until ap.length()){val o=ap.getJSONObject(i);newAppointments.add(Appointment(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("date")),o.getString("time"),normalizedType(o.optString("type","TYPE1")),o.optLong("seriesId",0L),o.optLong("sessionPackId",0L),o.optBoolean("recovery",false)))}
            packs.clear();packs.addAll(newPacks);sessionPacks.clear();sessionPacks.addAll(newSessionPacks);appointments.clear();appointments.addAll(newAppointments);nextAppointmentId=(appointments.maxOfOrNull{it.id}?:0L)+1;nextSessionPackId=(sessionPacks.maxOfOrNull{it.id}?:0L)+1
            ferieStart=if(root.isNull("ferieStart"))null else LocalDate.parse(root.getString("ferieStart"));ferieEnd=if(root.isNull("ferieEnd"))null else LocalDate.parse(root.getString("ferieEnd"));dashboardEnabled=root.optBoolean("dashboardEnabled",false);loadCalendarConfig(root);calendarVisibleDays=booleanArrayOf(true,true,true,true,true,false,false);root.optJSONArray("calendarVisibleDays")?.let{ja->if(ja.length()==7)calendarVisibleDays=BooleanArray(7){i->ja.optBoolean(i,i<5)}}
            saveData();build();Toast.makeText(this,"Backup automatico ripristinato.",Toast.LENGTH_LONG).show()
        }catch(_:Exception){Toast.makeText(this,"Backup automatico non valido.",Toast.LENGTH_LONG).show()}
    }

    private fun writeBackup(uri:Uri){try{contentResolver.openOutputStream(uri)?.use{it.write(backupJson().toString(2).toByteArray(Charsets.UTF_8))};Toast.makeText(this,"Backup esportato correttamente.",Toast.LENGTH_LONG).show()}catch(_:Exception){Toast.makeText(this,"Impossibile esportare il backup.",Toast.LENGTH_LONG).show()}}
    private fun readBackup(uri:Uri){try{val text=contentResolver.openInputStream(uri)?.use{BufferedReader(InputStreamReader(it,Charsets.UTF_8)).readText()}?:throw Exception();val root=JSONObject(text);require(root.optString("format")=="GestionePagamenti");val newPacks=mutableListOf<Pack>();val array=root.getJSONArray("packs");for(i in 0 until array.length()){val o=array.getJSONObject(i);newPacks.add(Pack(o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("total"),o.optInt("paid",0), o.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}}, o.optString("packageType","PERSONALIZZATO"), o.optInt("sessionTotal",when(o.optString("packageType","PERSONALIZZATO")){"BRONZE"->12;"SILVER"->24;"GOLD"->36;else->12}), o.optBoolean("active",true), o.optInt("missedSessions",0)))};ferieStart=if(root.isNull("ferieStart"))null else LocalDate.parse(root.getString("ferieStart"));ferieEnd=if(root.isNull("ferieEnd"))null else LocalDate.parse(root.getString("ferieEnd"));dashboardEnabled=root.optBoolean("dashboardEnabled",false);loadCalendarConfig(root);calendarVisibleDays=booleanArrayOf(true,true,true,true,true,false,false);root.optJSONArray("calendarVisibleDays")?.let{ja->if(ja.length()==7)calendarVisibleDays=BooleanArray(7){i->ja.optBoolean(i,i<5)}};val newSessionPacks=mutableListOf<SessionPack>();val sp=root.optJSONArray("sessionPacks");if(sp!=null)for(i in 0 until sp.length()){val o=sp.getJSONObject(i);newSessionPacks.add(SessionPack(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("totalSessions"),o.getInt("cost"),o.optBoolean("active",true)))};val newAppointments=mutableListOf<Appointment>();val ap=root.optJSONArray("appointments");if(ap!=null)for(i in 0 until ap.length()){val o=ap.getJSONObject(i);newAppointments.add(Appointment(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("date")),o.getString("time"),normalizedType(o.optString("type","TYPE1")),o.optLong("seriesId",0L),o.optLong("sessionPackId",0L),o.optBoolean("recovery",false)))};packs.clear();packs.addAll(newPacks);sessionPacks.clear();sessionPacks.addAll(newSessionPacks);appointments.clear();appointments.addAll(newAppointments);nextAppointmentId=(appointments.maxOfOrNull{it.id}?:0L)+1;nextSessionPackId=(sessionPacks.maxOfOrNull{it.id}?:0L)+1;saveData();build();Toast.makeText(this,"Backup importato: dati, ferie, pagamenti e appuntamenti ripristinati.",Toast.LENGTH_LONG).show()}catch(_:Exception){Toast.makeText(this,"Backup non valido o non leggibile.",Toast.LENGTH_LONG).show()}}

    private fun saveData(){
        val prefs=getSharedPreferences("gestione_pagamenti",MODE_PRIVATE);val array=JSONArray();packs.forEach{p->array.put(JSONObject().apply{put("name",p.name);put("start",p.start.toString());put("total",p.total);put("paid",p.paid);put("rateAmounts",JSONArray().apply{ratesFor(p).forEach{put(it)}});put("packageType",p.packageType);put("sessionTotal",p.sessionTotal);put("active",p.active);put("missedSessions",p.missedSessions)})};val sp=JSONArray();sessionPacks.forEach{s->sp.put(JSONObject().apply{put("id",s.id);put("name",s.name);put("start",s.start.toString());put("totalSessions",s.totalSessions);put("cost",s.cost);put("active",s.active)})};val ap=JSONArray();appointments.forEach{a->ap.put(JSONObject().apply{put("id",a.id);put("name",a.name);put("date",a.date.toString());put("time",a.time);put("type",a.type);put("seriesId",a.seriesId);put("sessionPackId",a.sessionPackId);put("recovery",a.recovery)})};prefs.edit().putString("packs",array.toString()).putString("sessionPacks",sp.toString()).putString("appointments",ap.toString()).putString("ferieStart",ferieStart?.toString()).putString("ferieEnd",ferieEnd?.toString()).putBoolean("dashboardEnabled",dashboardEnabled).putString("calendarVisibleDays",calendarVisibleDays.joinToString(","){if(it)"1" else "0"}).putString("appointmentTypes",JSONArray().apply{appointmentTypes.forEach{t->put(JSONObject().apply{put("id",t.id);put("name",t.name);put("color",t.color);put("duration",t.duration)})}}.toString()).putInt("activeRoutineIndex",activeRoutineIndex).putString("calendarRoutines",JSONArray().apply{calendarRoutines.forEach{r->put(JSONObject().apply{put("name",r.name);put("maxTotal",r.maxTotal);put("maxByType",JSONArray().apply{r.maxByType.forEach{put(it)}})})}}.toString()).putLong("nextAppointmentId",nextAppointmentId).putLong("nextSessionPackId",nextSessionPackId).apply();maybeAutoBackup()
    }
    private fun loadData(){
        val prefs=getSharedPreferences("gestione_pagamenti",MODE_PRIVATE);packs.clear();sessionPacks.clear();appointments.clear();val saved=prefs.getString("packs",null);if(!saved.isNullOrEmpty())try{val array=JSONArray(saved);for(i in 0 until array.length()){val o=array.getJSONObject(i);packs.add(Pack(o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("total"),o.optInt("paid",0), o.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}}, o.optString("packageType","PERSONALIZZATO"), o.optInt("sessionTotal",when(o.optString("packageType","PERSONALIZZATO")){"BRONZE"->12;"SILVER"->24;"GOLD"->36;else->12}), o.optBoolean("active",true), o.optInt("missedSessions",0)))}}catch(_:Exception){packs.clear()};val ap=prefs.getString("appointments",null);if(!ap.isNullOrEmpty())try{val array=JSONArray(ap);for(i in 0 until array.length()){val o=array.getJSONObject(i);appointments.add(Appointment(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("date")),o.getString("time"),normalizedType(o.optString("type","TYPE1")),o.optLong("seriesId",0L),o.optLong("sessionPackId",0L),o.optBoolean("recovery",false)))}}catch(_:Exception){appointments.clear()};val savedSp=prefs.getString("sessionPacks",null);if(!savedSp.isNullOrEmpty())try{val array=JSONArray(savedSp);for(i in 0 until array.length()){val o=array.getJSONObject(i);sessionPacks.add(SessionPack(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("totalSessions"),o.getInt("cost"),o.optBoolean("active",true)))}}catch(_:Exception){sessionPacks.clear()};nextAppointmentId=maxOf(prefs.getLong("nextAppointmentId",1L),(appointments.maxOfOrNull{it.id}?:0L)+1);nextSessionPackId=maxOf(prefs.getLong("nextSessionPackId",1L),(sessionPacks.maxOfOrNull{it.id}?:0L)+1)
        appointments.filter{it.sessionPackId==0L}.forEach{a->activeSessionPackFor(a.name)?.let{sp->a.sessionPackId=sp.id}}
        ferieStart=prefs.getString("ferieStart",null)?.let{runCatching{LocalDate.parse(it)}.getOrNull()};ferieEnd=prefs.getString("ferieEnd",null)?.let{runCatching{LocalDate.parse(it)}.getOrNull()};dashboardEnabled=prefs.getBoolean("dashboardEnabled",false);val savedDays=prefs.getString("calendarVisibleDays",null);calendarVisibleDays=if(!savedDays.isNullOrBlank()){val parts=savedDays.split(",");if(parts.size==7)BooleanArray(7){i->parts[i]=="1"}else booleanArrayOf(true,true,true,true,true,false,false)}else booleanArrayOf(true,true,true,true,true,false,false);appointmentTypes.clear();prefs.getString("appointmentTypes",null)?.let{runCatching{val a=JSONArray(it);for(i in 0 until a.length()){val t=a.getJSONObject(i);appointmentTypes.add(AppointmentType(t.optString("id","TYPE${i+1}"),t.optString("name",if(i==0)"ALLENAMENTO" else if(i==1)"MEZZ'ORA" else "Tipo ${i+1}"),t.optInt("color",if(i==0)Color.rgb(45,135,210) else Color.rgb(215,55,55)),t.optInt("duration",if(i==1)30 else 45)))}}};if(appointmentTypes.isEmpty()){appointmentTypes.add(AppointmentType("TYPE1","ALLENAMENTO",Color.rgb(45,135,210),45));appointmentTypes.add(AppointmentType("TYPE2","MEZZ'ORA",Color.rgb(215,55,55),30))};activeRoutineIndex=prefs.getInt("activeRoutineIndex",0);prefs.getString("calendarRoutines",null)?.let{runCatching{val a=JSONArray(it);calendarRoutines.clear();for(i in 0 until a.length()){val r=a.getJSONObject(i);val limits=mutableListOf<Int>();r.optJSONArray("maxByType")?.let{ja->for(j in 0 until ja.length())limits.add(ja.optInt(j,3))};if(limits.isEmpty()){limits.add(2);limits.add(3)};while(limits.size<appointmentTypes.size)limits.add(r.optInt("maxTotal",3));calendarRoutines.add(CalendarRoutine(r.optString("name","Routine ${i+1}"),r.optInt("maxTotal",3),limits))}}};if(calendarRoutines.isEmpty())calendarRoutines.add(CalendarRoutine("Standard",3,MutableList(appointmentTypes.size){if(it==0)2 else 3}));activeRoutineIndex=activeRoutineIndex.coerceIn(0,calendarRoutines.lastIndex)
    }

    private fun ratesFor(p:Pack):List<Int>{
        val c=p.customRates
        if(c!=null&&c.size==3&&c.all{it>=0}&&c.sum()==p.total)return c.toList()
        val r1=p.total/3;return listOf(r1,r1,p.total-r1*2)
    }

    private fun saveRates(p:Pack,rates:List<Int>){p.customRates=rates.toMutableList()}

    private fun registerPayment(p:Pack,index:Int,paidNow:Int){
        try{
            val rates=ratesFor(p)
            val due=rates[index]
            require(paidNow>0)
            require(p.paid+paidNow<=p.total)

            val paidBeforeCurrent=rates.take(index).sum()
            val alreadyPaidOnCurrent=(p.paid-paidBeforeCurrent).coerceAtLeast(0)
            val totalPaidOnCurrent=alreadyPaidOnCurrent+paidNow
            val newRates=rates.toMutableList()

            p.paid+=paidNow

            // Se il cliente paga più della rata prevista, la rata corrente
            // diventa pari a quanto effettivamente versato e il residuo viene
            // redistribuito sulle rate successive.
            if(totalPaidOnCurrent>due){
                newRates[index]=totalPaidOnCurrent
                val remainingCount=2-index
                if(remainingCount>0){
                    val remaining=p.total-rates.take(index).sum()-totalPaidOnCurrent
                    require(remaining>=0)
                    val base=remaining/remainingCount
                    val extra=remaining%remainingCount
                    for(j in index+1..2){
                        newRates[j]=base+if(j-index-1<extra)1 else 0
                    }
                } else require(totalPaidOnCurrent==p.total-rates.take(index).sum())
            }

            require(newRates.sum()==p.total)
            saveRates(p,newRates)
            expandedClients.add(identityKey(p.name))
            saveData()
            // Aggiorna immediatamente anche la scheda Gestione pacchetto già aperta.
            // Prima veniva aggiornata solo dopo averla chiusa e riaperta.
            activePackageDialog?.dismiss()
            activePackageDialog = null
            render()
            packageInfoDialog(p)
            if(totalPaidOnCurrent>due) Toast.makeText(this,"Pagamento registrato: rate successive ricalcolate automaticamente.",Toast.LENGTH_LONG).show()
            else Toast.makeText(this,"Pagamento di €$paidNow registrato.",Toast.LENGTH_SHORT).show()
        }catch(_:Exception){
            Toast.makeText(this,"Importo non valido o superiore al totale residuo.",Toast.LENGTH_LONG).show()
        }
    }

    private fun paymentAmountDialog(p:Pack,index:Int){
        val rates=ratesFor(p)
        val due=rates[index]
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(8),dp(16),0)}
        box.addView(TextView(this).apply{this.text="Rata ${index+1} • prevista €$due";textSize=15f;setTextColor(Color.DKGRAY);setPadding(0,0,0,dp(8))})
        val amount=EditText(this).apply{hint="Importo effettivamente pagato (€)";inputType=2;setSingleLine(true);setText(due.toString());selectAll()}
        box.addView(amount)
        AlertDialog.Builder(this)
            .setTitle("Modifica importo pagamento")
            .setView(box)
            .setNegativeButton("ANNULLA",null)
            .setPositiveButton("CONFERMA PAGAMENTO"){_,_->
                val value=amount.text.toString().trim().toIntOrNull()
                if(value==null||value<=0||p.paid+value>p.total){
                    Toast.makeText(this,"Importo non valido o superiore al totale residuo.",Toast.LENGTH_LONG).show()
                }else{
                    registerPayment(p,index,value)
                }
            }.create().also{styleOneUiDialog(it);it.show()}
    }

    private fun paymentOptionsDialog(p:Pack,index:Int){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(4),dp(18),dp(8))}
        box.addView(TextView(this).apply{text="Opzioni pagamento";textSize=24f;setTextColor(Color.rgb(24,27,31));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(0,0,0,dp(12))})
        val edit=Button(this).apply{text="Modifica importo da pagare";setAllCaps(false);textSize=15f;gravity=Gravity.CENTER_VERTICAL;setTextColor(Color.rgb(25,28,32));background=roundedSurface(Color.rgb(246,248,250),18,Color.rgb(228,231,235),1);stateListAnimator=null}
        val cancel=Button(this).apply{text="Annulla";setAllCaps(false);textSize=14f;setTextColor(Color.rgb(0,125,110));setBackgroundColor(Color.TRANSPARENT);stateListAnimator=null}
        box.addView(edit,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,0,0,dp(4))});box.addView(cancel,LinearLayout.LayoutParams(-1,dp(46)))
        val dialog=AlertDialog.Builder(this).setView(box).create();styleOneUiDialog(dialog)
        dialog.setOnShowListener{dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28));dialog.window?.setDimAmount(0.42f);edit.setOnClickListener{dialog.dismiss();paymentAmountDialog(p,index)};cancel.setOnClickListener{dialog.dismiss()}}
        dialog.show()
    }

    private fun editRateDialog(p:Pack,index:Int){
        val rates=ratesFor(p);val firstUnpaid=p.paidRateIndex(rates);if(index<firstUnpaid){Toast.makeText(this,"Questa rata è già pagata.",Toast.LENGTH_SHORT).show();return}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(8),dp(16),0)}
        val amount=EditText(this).apply{hint="Nuovo importo rata";inputType=2;setSingleLine(true);setText(rates[index].toString())};box.addView(amount)
        val laterCount=2-index
        AlertDialog.Builder(this).setTitle("Modifica rata ${index+1}").setMessage(if(laterCount>0)"Modifica questa rata: le rate successive verranno ricalcolate automaticamente per mantenere invariato il totale di €${p.total}." else "Essendo l'ultima rata, l'importo viene calcolato sul residuo del pacchetto.").setView(box).setNegativeButton("Annulla",null).setPositiveButton("SALVA"){_,_->
            try{
                val newAmount=amount.text.toString().trim().toInt();require(newAmount>0)
                val paidBefore=rates.take(index).sum();val alreadyOnRate=p.paid-paidBefore;require(newAmount>=alreadyOnRate)
                val remainingAfter=p.total-paidBefore-newAmount;require(remainingAfter>=0)
                val newRates=rates.toMutableList();newRates[index]=newAmount
                if(laterCount>0){val base=remainingAfter/laterCount;val extra=remainingAfter%laterCount;for(j in index+1..2)newRates[j]=base+if(j-index-1<extra)1 else 0}else require(remainingAfter==0)
                require(newRates.sum()==p.total);saveRates(p,newRates);saveData();render()
            }catch(_:Exception){Toast.makeText(this,"Importo non valido: controlla il residuo del pacchetto.",Toast.LENGTH_LONG).show()}
        }.create().also{styleOneUiDialog(it);it.show()}
    }
    private fun dueDates(p:Pack):List<LocalDate>{val out=mutableListOf<LocalDate>();var d=p.start;repeat(3){out.add(d);d=advance(d,28)};return out}
    private fun advance(d0:LocalDate,days:Int):LocalDate{var d=d0.plusDays(days.toLong());val fs=ferieStart;val fe=ferieEnd;if(fs!=null&&fe!=null&&!fe.isBefore(fs)&&!d.isBefore(fs)&&!d.isAfter(fe))d=fe.plusDays(1);return d}
    private fun closureText():String{val fs=ferieStart;val fe=ferieEnd;return if(fs!=null&&fe!=null)"🏖 Chiusura ferie: ${fs.format(fmt)} → ${fe.format(fmt)}" else "Nessuna chiusura ferie impostata"}

    private fun displaySurnameFirst(name:String):String{
        val parts=name.trim().split(Regex("\\s+")).filter{it.isNotBlank()}
        return when{parts.size<=1->name.trim();else->parts.last()+" "+parts.dropLast(1).joinToString(" ")}
    }


    private fun render(){
        list.removeAllViews()
        val query=if(::searchInput.isInitialized)searchInput.text.toString().trim().lowercase() else ""
        if(query.isNotEmpty()){
            renderSearchResults(query)
            return
        }
        val filtered=packs.filter{it.active}.sortedWith(compareBy<Pack>{statusRank(statusFor(it,ratesFor(it),dueDates(it)))}.thenBy{it.start}.thenBy{it.name.lowercase()})
        val filteredSessions=sessionPacks.filter{it.active&&(query.isEmpty()||it.name.lowercase().contains(query))}.sortedWith(compareBy<SessionPack>{statusRank(sessionStatus(it))}.thenBy{it.start}.thenBy{it.name.lowercase()})
        if(dashboardEnabled){renderDashboard(filtered,filteredSessions)}else{
            if(filtered.isEmpty()&&filteredSessions.isEmpty()){
                list.addView(TextView(this).apply{text=if(packs.isEmpty()&&sessionPacks.isEmpty())"Nessun pacchetto inserito." else "Nessun cliente trovato.";textSize=18f;setTextColor(Color.DKGRAY);setPadding(0,dp(12),0,dp(12))})
                return
            }
            val unified=mutableListOf<Pair<Int,Any>>()
            filtered.forEach{unified.add(statusRank(statusFor(it,ratesFor(it),dueDates(it))) to it)}
            filteredSessions.forEach{unified.add(statusRank(sessionStatus(it)) to it)}
            unified.sortedWith(compareBy<Pair<Int,Any>>{it.first}.thenBy{item->when(val value=item.second){is Pack->value.start;is SessionPack->value.start;else->LocalDate.MAX}}).forEach{item->when(val value=item.second){is Pack->card(value);is SessionPack->sessionCard(value)}}
        }
    }

    private fun renderSearchResults(query:String){
        val target=if(::searchList.isInitialized)searchList else list
        target.removeAllViews()
        val matchingNames=(packs.filter{it.name.lowercase().contains(query)}.map{it.name}+sessionPacks.filter{it.name.lowercase().contains(query)}.map{it.name}+appointments.filter{it.name.lowercase().contains(query)}.map{it.name}).distinctBy{identityKey(it)}.sortedBy{it.lowercase()}
        val matchingAppointments=appointments.filter{it.name.lowercase().contains(query)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        if(matchingNames.isEmpty()&&matchingAppointments.isEmpty()){
            target.addView(TextView(this).apply{text="Nessun risultato";textSize=17f;setTextColor(Color.DKGRAY);setPadding(dp(8),dp(16),dp(8),dp(16))})
            return
        }
        if(matchingNames.isNotEmpty()){
            target.addView(TextView(this).apply{text="CLIENTI";textSize=12f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(100,104,110));setPadding(dp(6),dp(4),dp(6),dp(6))})
            matchingNames.forEach{name->
                val key=identityKey(name)
                val regular=packs.firstOrNull{it.active&&identityKey(it.name)==key}
                val session=sessionPacks.firstOrNull{it.active&&identityKey(it.name)==key}
                val statusColor=when{regular!=null->statusFor(regular,ratesFor(regular),dueDates(regular)).color;session!=null->sessionStatus(session).color;else->Color.GRAY}
                val future=appointments.filter{identityKey(it.name)==key&&it.date.isAfter(LocalDate.now())}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
                val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;background=roundedSurface(Color.WHITE,18,Color.rgb(228,231,235),1);setPadding(dp(14),dp(10),dp(10),dp(10))}
                val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                top.addView(TextView(this).apply{text=displaySurnameFirst(name);textSize=17f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(24,27,31));gravity=Gravity.CENTER_VERTICAL;maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END},LinearLayout.LayoutParams(0,dp(44),1f))
                top.addView(TextView(this).apply{text=if(future.isNotEmpty())"${future.size} appuntamenti" else "Nessun futuro";textSize=12.5f;setTextColor(Color.rgb(90,94,100));gravity=Gravity.CENTER},LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,dp(44)))
                top.addView(TextView(this).apply{text="●";textSize=18f;setTextColor(statusColor);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(28),dp(44)))
                row.addView(top)
                val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(6),0,0)}
                val program=Button(this).apply{text="📋 Programmazione";setAllCaps(false);textSize=12.5f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(Color.rgb(20,95,150));background=roundedSurface(Color.rgb(240,247,253),15,Color.rgb(190,220,248),1);setOnClickListener{copyProgrammingToClipboard(name)}}
                actions.addView(program,LinearLayout.LayoutParams(0,dp(42),1f).apply{setMargins(0,0,dp(5),0)})
                val packageButton=Button(this).apply{text="📦 Pacchetto";setAllCaps(false);textSize=12.5f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(Color.rgb(65,70,185));background=roundedSurface(Color.rgb(246,246,255),15,Color.rgb(214,214,246),1);setOnClickListener{openPackageFromSearch(name)}}
                actions.addView(packageButton,LinearLayout.LayoutParams(0,dp(42),0.82f).apply{setMargins(0,0,dp(5),0)})
                val open=Button(this).apply{text="Apri";setAllCaps(false);textSize=12.5f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(Color.rgb(0,125,110));background=roundedSurface(Color.rgb(244,249,248),15,Color.rgb(190,225,216),1);setOnClickListener{showSearchClientAppointments(name)}}
                actions.addView(open,LinearLayout.LayoutParams(dp(72),dp(42)))
                row.addView(actions)
                row.setOnClickListener{showSearchClientAppointments(name)}
                target.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})
            }
        }
        if(matchingAppointments.isNotEmpty()){
            target.addView(TextView(this).apply{text="APPUNTAMENTI";textSize=12f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(100,104,110));setPadding(dp(6),dp(10),dp(6),dp(6))})
            matchingAppointments.forEach{a->
                val accent=typeColor(a.type)
                val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;background=roundedSurface(Color.WHITE,16,Color.rgb(228,231,235),1);setPadding(dp(12),dp(8),dp(12),dp(8))}
                row.addView(TextView(this).apply{text=displaySurnameFirst(a.name);textSize=15f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(30,32,36));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,dp(52),1f))
                row.addView(TextView(this).apply{text="${a.date.format(fmt)}\n${a.time} • ${typeLabel(a.type)}";textSize=11.5f;setTextColor(accent);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(118),dp(52)))
                row.setOnClickListener{appointmentActions(a)}
                target.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(6))})
            }
        }
    }

    private fun openPackageFromSearch(name:String){
        val key=identityKey(name)
        val regular=packs.firstOrNull{it.active&&identityKey(it.name)==key}
        val session=sessionPacks.firstOrNull{it.active&&identityKey(it.name)==key}
        when{
            regular!=null&&session==null -> packageInfoDialog(regular)
            session!=null&&regular==null -> sessionPaymentInfo(session)
            regular!=null&&session!=null -> {
                val choices=arrayOf("📦 ${regular.packageType} • 12 settimane","🎯 Pacchetto sedute • ${session.totalSessions} sedute")
                AlertDialog.Builder(this).setTitle(displaySurnameFirst(name)).setItems(choices){_,which->
                    if(which==0) packageInfoDialog(regular) else sessionPaymentInfo(session)
                }.setNegativeButton("ANNULLA",null).create().also{styleOneUiDialog(it);it.show()}
            }
            else -> Toast.makeText(this,"Nessun pacchetto attivo per ${displaySurnameFirst(name)}.",Toast.LENGTH_SHORT).show()
        }
    }

    private fun showSearchClientAppointments(name:String){
        val key=identityKey(name)
        val all=appointments.filter{identityKey(it.name)==key}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        val future=all.filter{it.date.isAfter(LocalDate.now())}
        if(future.isEmpty()){
            Toast.makeText(this,"Nessun appuntamento futuro per ${displaySurnameFirst(name)}.",Toast.LENGTH_SHORT).show()
            return
        }
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(4),dp(16),dp(6))}
        box.addView(TextView(this).apply{text="${future.size} appuntamenti futuri";textSize=13f;setTextColor(Color.rgb(100,104,110));setPadding(0,0,0,dp(8))})
        future.forEach{a->
            val accent=typeColor(a.type)
            box.addView(TextView(this).apply{text="${a.date.format(fmt)} • ${a.time} • ${typeLabel(a.type)}";textSize=14.5f;setTextColor(accent);setPadding(0,dp(5),0,dp(5))})
        }
        val dialog=AlertDialog.Builder(this).setTitle(displaySurnameFirst(name)).setView(box).setNegativeButton("CHIUDI",null).setPositiveButton("📋 COPIA PROGRAMMAZIONE"){_,_->copyProgrammingToClipboard(name)}.create()
        styleOneUiDialog(dialog);dialog.show()
    }

    private fun programmingAppointments(name:String, choice:Int):List<Appointment>{
        val today=LocalDate.now()
        val all=appointments.filter{identityKey(it.name)==identityKey(name)&&it.date.isAfter(today)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        return when(choice){
            0 -> all.take(10)
            1 -> all.take(30)
            2 -> {
                val pack=packs.filter{it.active&&identityKey(it.name)==identityKey(name)}.maxByOrNull{it.start}
                val session=sessionPacks.filter{it.active&&identityKey(it.name)==identityKey(name)}.maxByOrNull{it.start}
                when {
                    pack!=null -> all.filter{!it.date.isAfter(pack.start.plusWeeks(12).minusDays(1))&& !it.date.isBefore(pack.start)}
                    session!=null -> all.filter{it.sessionPackId==session.id}
                    else -> all
                }
            }
            else -> all
        }
    }

    private fun programmingText(name:String, choice:Int):String{
        val selected=programmingAppointments(name,choice)
        if(selected.isEmpty()) return "Nessun appuntamento futuro disponibile."
        val title=when(choice){0->"PROSSIMI 10 APPUNTAMENTI";1->"PROSSIMI 30 APPUNTAMENTI";2->"PROGRAMMAZIONE PACCHETTO";else->"PROGRAMMAZIONE ANNUALE"}
        return buildString{
            appendLine("📋 $title")
            appendLine("Cliente: ${displaySurnameFirst(name)}")
            appendLine()
            selected.forEachIndexed{index,a->
                val type=typeLabel(a.type)
                appendLine("${index+1}. ${a.date.format(fmt)} • ${a.time} • $type")
            }
        }
    }

    private fun programmingOptionsDialog(name:String){
        val options=arrayOf("Prossimi 10 appuntamenti","Prossimi 30 appuntamenti","Tutto il pacchetto","Tutta la programmazione annuale")
        val dialog=AlertDialog.Builder(this)
            .setTitle("📋 Copia programmazione")
            .setItems(options){_,which->
                val text=programmingText(name,which)
                if(text.startsWith("Nessun appuntamento")) Toast.makeText(this,text,Toast.LENGTH_SHORT).show()
                else copyProgrammingTextToClipboard(text,name)
            }
            .setNegativeButton("ANNULLA",null)
            .create()
        styleOneUiDialog(dialog);dialog.show()
    }

    private fun copyProgrammingTextToClipboard(text:String,name:String){
        val clipboard=getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Programmazione $name",text))
        val preview=TextView(this).apply{this.text=text;textSize=14f;setTextColor(Color.rgb(35,35,35));setPadding(dp(16),dp(8),dp(16),dp(8))}
        val dialog=AlertDialog.Builder(this).setTitle("📋 Programmazione pronta").setMessage("La programmazione è già stata copiata negli appunti. Puoi incollarla direttamente su WhatsApp.").setView(ScrollView(this).apply{addView(preview)}).setNegativeButton("CHIUDI",null).setPositiveButton("COPIA DI NUOVO"){_,_->clipboard.setPrimaryClip(ClipData.newPlainText("Programmazione $name",text));Toast.makeText(this,"Programmazione copiata.",Toast.LENGTH_SHORT).show()}.create()
        styleOneUiDialog(dialog);dialog.show()
    }

    private fun copyProgrammingToClipboard(name:String){ programmingOptionsDialog(name) }

    private fun renderDashboard(items:List<Pack>,sessionItems:List<SessionPack>){
        val today=LocalDate.now()
        val activeClients=(items.map{identityKey(it.name)}+sessionItems.map{identityKey(it.name)}).distinct().size
        val todayAppointments=appointments.count{it.date==today}
        val toCollect=packs.filter{it.active}.fold(0){acc,p -> acc + (p.total-p.paid).coerceAtLeast(0)}
        val stats=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(0,0,0,dp(10))}
        fun stat(value:String,label:String):View=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(6),dp(8),dp(6),dp(8));background=roundedSurface(Color.WHITE,16,Color.rgb(230,232,236),1)
            addView(TextView(this@MainActivity).apply{text=value;textSize=19f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(28,31,35));gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,dp(28)))
            addView(TextView(this@MainActivity).apply{text=label;textSize=10.5f;setTextColor(Color.rgb(105,108,114));gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,dp(22))) }
        stats.addView(stat(activeClients.toString(),"CLIENTI ATTIVI"),LinearLayout.LayoutParams(0,dp(58),1f).apply{setMargins(0,0,dp(4),0)})
        stats.addView(stat(todayAppointments.toString(),"SEDUTE OGGI"),LinearLayout.LayoutParams(0,dp(58),1f).apply{setMargins(dp(2),0,dp(2),0)})
        stats.addView(stat("€$toCollect","DA INCASSARE"),LinearLayout.LayoutParams(0,dp(58),1f).apply{setMargins(dp(4),0,0,0)})
        list.addView(stats)
        val groups=listOf(
            Triple("SCADUTI",Color.rgb(210,45,45),items.filter{statusFor(it,ratesFor(it),dueDates(it)).label=="SCADUTA"}),
            Triple("IN SCADENZA",Color.rgb(220,160,20),items.filter{statusFor(it,ratesFor(it),dueDates(it)).label=="IN SCADENZA"}),
            Triple("IN REGOLA",Color.rgb(35,150,70),items.filter{statusFor(it,ratesFor(it),dueDates(it)).label=="IN REGOLA"})
        )
        val sessionGroups=listOf(
            Triple("SCADUTI",Color.rgb(210,45,45),sessionItems.filter{sessionStatus(it).label=="SCADUTA"}),
            Triple("IN SCADENZA",Color.rgb(220,160,20),sessionItems.filter{sessionStatus(it).label=="IN SCADENZA"}),
            Triple("IN REGOLA",Color.rgb(35,150,70),sessionItems.filter{sessionStatus(it).label=="IN REGOLA"})
        )
        groups.indices.forEach{idx->
            val clients=groups[idx].third
            val sessions=sessionGroups[idx].third
            if(clients.isEmpty()&&sessions.isEmpty())return@forEach
            val label=groups[idx].first;val color=groups[idx].second
            val section=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;background=roundedSurface(Color.WHITE,18,Color.rgb(232,234,238),1)}
            val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;isClickable=true;isFocusable=true;setPadding(dp(12),dp(4),dp(12),dp(4))}
            header.addView(TextView(this).apply{text="●";textSize=18f;setTextColor(color);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(28),dp(48)))
            val totalCount=clients.size+sessions.size
            header.addView(TextView(this).apply{text="$label ($totalCount)";textSize=17f;setTextColor(Color.rgb(35,35,35));gravity=Gravity.CENTER_VERTICAL;setPadding(dp(8),0,0,0)},LinearLayout.LayoutParams(0,dp(48),1f))
            val arrow=TextView(this).apply{text="▾";textSize=20f;setTextColor(Color.DKGRAY);gravity=Gravity.CENTER}
            header.addView(arrow,LinearLayout.LayoutParams(dp(36),dp(48)));section.addView(header)
            val sectionHasExpandedClient = clients.any{expandedClients.contains(identityKey(it.name))} || sessions.any{expandedClients.contains(identityKey(it.name))}
            val clientsBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=if(sectionHasExpandedClient)View.VISIBLE else View.GONE;setPadding(dp(8),0,dp(8),dp(4))}
            clients.forEach{card(it,clientsBox)};sessions.forEach{sessionCard(it,clientsBox)}
            section.addView(clientsBox)
            arrow.text=if(sectionHasExpandedClient)"▴" else "▾"
            header.setOnClickListener{val open=clientsBox.visibility!=View.VISIBLE;clientsBox.visibility=if(open)View.VISIBLE else View.GONE;arrow.text=if(open)"▴" else "▾"}
            list.addView(section,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})
        }
    }

    private fun card(p:Pack,parent:ViewGroup=list){
        val rates=ratesFor(p);val dates=dueDates(p);val status=statusFor(p,rates,dates)
        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(4),dp(10),dp(4));background=roundedSurface(Color.WHITE,18,Color.rgb(231,233,237),1)}
        val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;isClickable=true;isFocusable=true;setPadding(dp(2),0,0,0)}
        val nameView=TextView(this).apply{text=displaySurnameFirst(p.name);textSize=17.5f;setTextColor(Color.rgb(20,20,20));gravity=Gravity.CENTER_VERTICAL;maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END}
        header.addView(nameView,LinearLayout.LayoutParams(0,dp(48),1f))
        val menu=Button(this).apply{text="⋮";textSize=19f;minWidth=0;minimumWidth=0;setPadding(0,0,0,0);stateListAnimator=null;background=roundedSurface(Color.rgb(242,244,247),12,Color.rgb(228,231,235),1);setOnClickListener{packageInfoDialog(p)}}
        header.addView(menu,LinearLayout.LayoutParams(dp(38),dp(40)).apply{setMargins(dp(6),0,dp(6),0)})
        header.addView(TextView(this).apply{text="●";textSize=18f;setTextColor(status.color);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(26),dp(44)))
        card.addView(header)

        val isExpanded=expandedClients.contains(identityKey(p.name))
        val details=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=if(isExpanded)View.VISIBLE else View.GONE;setPadding(dp(2),dp(4),dp(2),dp(2))}
        details.addView(TextView(this).apply{text="${p.packageType} • ${p.sessionTotal} sedute • Partenza: ${p.start.format(fmt)}    Totale: €${p.total}";textSize=14f;setTextColor(Color.DKGRAY);setPadding(0,dp(2),0,dp(8))})
        for(i in 0..2){
            val isPaid=p.paid>=rates.take(i+1).sum();val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
            val suffix = if(isPaid) " ✓ pagata" else if(i==p.paidRateIndex(rates)) " • parziale €${p.paid-rates.take(i).sum()}" else ""
            row.addView(TextView(this).apply{this.text="Rata ${i+1}: €${rates[i]} • ${dates[i].format(fmt)}$suffix";textSize=15f;setTextColor(Color.rgb(30,30,30));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,dp(48),1f))
            if(!isPaid){
                if(i==p.paidRateIndex(rates)) row.addView(Button(this).apply{this.text="PAGA";setOnClickListener{
                    val alreadyPaidOnCurrent=(p.paid-rates.take(i).sum()).coerceAtLeast(0)
                    val remainingToPay=(rates[i]-alreadyPaidOnCurrent).coerceAtLeast(0)
                    if(remainingToPay>0) registerPayment(p,i,remainingToPay)
                }})
                row.addView(Button(this).apply{this.text="⋮";textSize=17f;minWidth=0;minimumWidth=0;setPadding(0,0,0,0);setOnClickListener{paymentOptionsDialog(p,i)}},LinearLayout.LayoutParams(dp(36),dp(44)))
            }
            details.addView(row)
        }
        card.addView(details)
        header.setOnClickListener{val open=details.visibility!=View.VISIBLE;details.visibility=if(open)View.VISIBLE else View.GONE;if(open)expandedClients.add(identityKey(p.name)) else expandedClients.remove(identityKey(p.name))}
        parent.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})
    }

    private fun packageInfoDialog(p:Pack){
        val rates=ratesFor(p)
        val dates=dueDates(p)
        val status=statusFor(p,rates,dates)
        val expected=p.sessionTotal
        val done=sessionsForPack(p,LocalDate.now()).size
        val recoveries=recoveriesForPack(p)
        val remaining=(expected-done).coerceAtLeast(0)

        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),0,dp(14),dp(10))}
        val scroll=ScrollView(this).apply{isFillViewport=true;addView(root)}

        val client=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(10),dp(8),dp(10));background=roundedSurface(Color.rgb(247,249,252),20,Color.rgb(228,232,238),1)}
        val initials=displaySurnameFirst(p.name).split(" ").filter{it.isNotBlank()}.take(2).joinToString(""){it.first().uppercase()}
        client.addView(TextView(this).apply{text=initials;textSize=18f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(20,70,130));background=roundedSurface(Color.rgb(230,240,252),28);},LinearLayout.LayoutParams(dp(52),dp(52)))
        val clientText=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
        clientText.addView(TextView(this@MainActivity).apply{text=displaySurnameFirst(p.name);textSize=18f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32))})
        clientText.addView(TextView(this@MainActivity).apply{text="●  ${status.label}";textSize=13f;setTextColor(status.color);setPadding(0,dp(3),0,0)})
        client.addView(clientText,LinearLayout.LayoutParams(0,-2,1f))
        root.addView(client,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(8),0,dp(10))})

        val stats=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        fun stat(value:String,label:String):View=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(4),dp(7),dp(4),dp(7));background=roundedSurface(Color.WHITE,16,Color.rgb(230,233,238),1)
            addView(TextView(this@MainActivity).apply{text=value;textSize=17f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,30,38));gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,dp(27)))
            addView(TextView(this@MainActivity).apply{text=label;textSize=9.5f;setTextColor(Color.rgb(85,90,98));gravity=Gravity.CENTER;maxLines=2},LinearLayout.LayoutParams(-1,dp(30))) }
        stats.addView(stat("$expected","SEDUTE TOTALI"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(0,0,dp(4),0)})
        stats.addView(stat("$remaining","SEDUTE RIMASTE"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(dp(2),0,dp(2),0)})
        stats.addView(stat("$recoveries","RECUPERI"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(dp(2),0,dp(2),0)})
        stats.addView(stat("€${p.total}","TOTALE PACCHETTO"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(dp(4),0,0,0)})
        root.addView(stats)

        val info=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(8),dp(14),dp(8));background=roundedSurface(Color.WHITE,18,Color.rgb(230,233,238),1)}
        fun infoRow(label:String,value:String){val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(7),0,dp(7))};r.addView(TextView(this@MainActivity).apply{text=label;textSize=13f;setTextColor(Color.rgb(85,90,98))},LinearLayout.LayoutParams(0,dp(34),1f));r.addView(TextView(this@MainActivity).apply{text=value;textSize=13.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,40,48));gravity=Gravity.CENTER_VERTICAL});info.addView(r)}
        infoRow("Tipo pacchetto",p.packageType.replace("PERSONALIZZATO","Personalizzato"))
        infoRow("Data di inizio",p.start.format(fmt))
        infoRow("Importo totale","€${p.total}")
        infoRow("Pagato","€${p.paid}")
        infoRow("Stato","${status.label}")
        root.addView(info,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(10),0,dp(14))})

        val rateTitle=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        rateTitle.addView(TextView(this).apply{text="Rate di pagamento";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32))},LinearLayout.LayoutParams(0,dp(42),1f))
        rateTitle.addView(Button(this).apply{text="+ Aggiungi rata";setAllCaps(false);textSize=11.5f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(Color.rgb(15,95,180));background=roundedSurface(Color.rgb(235,244,255),16,Color.rgb(190,218,248),1);setOnClickListener{Toast.makeText(this@MainActivity,"Le 3 rate del pacchetto sono già configurate.",Toast.LENGTH_SHORT).show()}},LinearLayout.LayoutParams(dp(122),dp(38)))
        root.addView(rateTitle)
        for(i in 0..2){
            val isPaid=p.paid>=rates.take(i+1).sum()
            val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),dp(5),dp(6),dp(5));background=roundedSurface(Color.WHITE,16,Color.rgb(230,233,238),1)}
            r.addView(TextView(this).apply{text="${i+1}";textSize=13f;gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);background=roundedSurface(Color.rgb(242,245,249),22);setTextColor(Color.rgb(40,45,52))},LinearLayout.LayoutParams(dp(34),dp(40)))
            r.addView(TextView(this).apply{this.text="€${rates[i]}\n${dates[i].format(fmt)}${if(isPaid)" • ✓ Pagata" else ""}";textSize=13.5f;setTextColor(Color.rgb(35,40,48));setPadding(dp(10),0,0,0)},LinearLayout.LayoutParams(0,dp(52),1f))
            if(!isPaid&&i==p.paidRateIndex(rates)) r.addView(Button(this).apply{this.text="PAGA";setAllCaps(false);textSize=11f;minHeight=0;minimumHeight=0;stateListAnimator=null;setOnClickListener{val already=(p.paid-rates.take(i).sum()).coerceAtLeast(0);registerPayment(p,i,(rates[i]-already).coerceAtLeast(0))}},LinearLayout.LayoutParams(dp(72),dp(40)))
            r.addView(Button(this).apply{this.text="⋮";textSize=17f;minWidth=0;minimumWidth=0;setPadding(0,0,0,0);stateListAnimator=null;background=roundedSurface(Color.rgb(242,244,247),12,Color.rgb(228,231,235),1);setOnClickListener{paymentOptionsDialog(p,i)}},LinearLayout.LayoutParams(dp(38),dp(40)).apply{setMargins(dp(5),0,0,0)})
            root.addView(r,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(4),0,dp(4))})
        }

        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(12),0,dp(4))}
        fun actionButton(label:String,accent:Int,bg:Int,click:()->Unit)=Button(this).apply{text=label;setAllCaps(false);textSize=11.5f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(accent);background=roundedSurface(bg,16,Color.rgb(205,220,238),1);setOnClickListener{click()}}
        actions.addView(actionButton("✓ Segna tutto pagato",Color.rgb(15,95,180),Color.rgb(238,246,255)){p.paid=p.total;saveData();render()},LinearLayout.LayoutParams(0,dp(46),1f).apply{setMargins(0,0,dp(4),0)})
        actions.addView(actionButton("✎ Modifica",Color.rgb(15,95,180),Color.rgb(238,246,255)){editPackDialog(p)},LinearLayout.LayoutParams(0,dp(46),0.7f).apply{setMargins(dp(2),0,dp(2),0)})
        actions.addView(actionButton("⏹ Termina",Color.rgb(120,80,25),Color.rgb(255,248,232)){terminatePackDialog(p)},LinearLayout.LayoutParams(0,dp(46),0.7f).apply{setMargins(dp(2),0,dp(2),0)})
        actions.addView(actionButton("🗑 Elimina",Color.rgb(200,45,45),Color.rgb(255,244,244)){confirmDeletePack(p)},LinearLayout.LayoutParams(0,dp(46),0.7f).apply{setMargins(dp(4),0,0,0)})
        root.addView(actions)
        root.addView(Button(this).apply{text="🗂 Storico cliente";setAllCaps(false);textSize=13f;setTextColor(Color.rgb(65,70,78));background=roundedSurface(Color.rgb(246,248,250),16,Color.rgb(228,231,235),1);stateListAnimator=null;setOnClickListener{showClientHistory(p.name)}},LinearLayout.LayoutParams(-1,dp(44)).apply{setMargins(0,dp(4),0,dp(2))})
        root.addView(Button(this).apply{text="📋 Copia programmazione";setAllCaps(false);textSize=13f;setTextColor(Color.rgb(20,95,170));background=roundedSurface(Color.rgb(238,246,255),16,Color.rgb(190,218,248),1);stateListAnimator=null;setOnClickListener{programmingOptionsDialog(p.name)}},LinearLayout.LayoutParams(-1,dp(44)).apply{setMargins(0,dp(4),0,dp(2))})
        root.addView(Button(this).apply{text="📊 Riepilogo sedute • WhatsApp";setAllCaps(false);textSize=13f;setTextColor(Color.rgb(20,95,170));background=roundedSurface(Color.rgb(238,246,255),16,Color.rgb(190,218,248),1);stateListAnimator=null;setOnClickListener{copySummaryToClipboard(summaryForPack(p),p.name)}},LinearLayout.LayoutParams(-1,dp(44)).apply{setMargins(0,dp(4),0,dp(2))})

        activePackageDialog?.dismiss()
        val dialog=AlertDialog.Builder(this).setTitle("Gestione pacchetto").setView(scroll).setNegativeButton("CHIUDI",null).create()
        activePackageDialog=dialog
        dialog.setOnShowListener{dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28));dialog.window?.setDimAmount(0.42f)}
        dialog.setOnDismissListener{if(activePackageDialog===dialog) activePackageDialog=null}
        dialog.show()
    }

    private fun sessionUsed(s:SessionPack):Int=appointments.count{it.sessionPackId==s.id}
    private fun sessionStatus(s:SessionPack):PackStatus{val used=sessionUsed(s);return when{used>=s.totalSessions->PackStatus("SCADUTA",Color.rgb(210,45,45));s.totalSessions-used<=2->PackStatus("IN SCADENZA",Color.rgb(220,160,20));else->PackStatus("IN REGOLA",Color.rgb(35,150,70))}}
    private fun activeSessionPackFor(name:String):SessionPack?=sessionPacks.filter{it.active&&identityKey(it.name)==identityKey(name)&&sessionUsed(it)<it.totalSessions}.maxByOrNull{it.start}

    private fun sessionCard(s:SessionPack,parent:ViewGroup=list){
        val used=sessionUsed(s);val remaining=(s.totalSessions-used).coerceAtLeast(0);val status=sessionStatus(s)
        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(4),dp(10),dp(4));background=roundedSurface(Color.WHITE,18,Color.rgb(231,233,237),1)}
        val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;isClickable=true;isFocusable=true;setPadding(dp(2),0,0,0)}
        val name=TextView(this).apply{text=displaySurnameFirst(s.name);textSize=17.5f;setTextColor(Color.rgb(20,20,20));gravity=Gravity.CENTER_VERTICAL;maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END}
        header.addView(name,LinearLayout.LayoutParams(0,dp(48),1f))
        header.addView(TextView(this).apply{text="$remaining rimaste";textSize=13f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(status.color);gravity=Gravity.CENTER_VERTICAL;maxLines=1},LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,dp(44)))
        val menu=Button(this).apply{text="⋮";textSize=19f;minWidth=0;minimumWidth=0;setPadding(0,0,0,0);stateListAnimator=null;background=roundedSurface(Color.rgb(242,244,247),12,Color.rgb(228,231,235),1);setOnClickListener{sessionPaymentInfo(s)}}
        header.addView(menu,LinearLayout.LayoutParams(dp(38),dp(40)).apply{setMargins(dp(6),0,dp(6),0)})
        header.addView(TextView(this).apply{text="●";textSize=18f;setTextColor(status.color);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(26),dp(44)))
        card.addView(header)

        val details=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE;setPadding(dp(4),dp(4),0,dp(2))}
        details.addView(TextView(this).apply{text="Pacchetto sedute • €${s.cost} • $used/${s.totalSessions} registrate";textSize=14f;setTextColor(Color.rgb(75,78,84));setPadding(0,0,0,dp(4))})
        val dates=appointments.filter{it.sessionPackId==s.id}.sortedBy{it.date}.joinToString(" • " ){it.date.format(fmt)}
        if(dates.isNotEmpty())details.addView(TextView(this).apply{text="Date: $dates";textSize=12.5f;setTextColor(Color.DKGRAY);setPadding(0,0,0,dp(5))})
        details.addView(Button(this).apply{text="⋮ ALTRE INFORMAZIONI";textSize=12.5f;setAllCaps(false);stateListAnimator=null;setOnClickListener{sessionOptionsDialog(s)}} ,LinearLayout.LayoutParams(-1,dp(40)))
        card.addView(details)
        header.setOnClickListener{val open=details.visibility!=View.VISIBLE;details.visibility=if(open)View.VISIBLE else View.GONE;if(open)expandedClients.add(identityKey(s.name)) else expandedClients.remove(identityKey(s.name))}
        parent.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})
    }

    private fun sessionPaymentInfo(s:SessionPack){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(4),dp(18),dp(8))}
        fun option(title:String,subtitle:String,icon:String,action:()->Unit){
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(10),dp(12),dp(10));background=roundedSurface(Color.rgb(246,248,250),20,Color.rgb(228,231,235),1);isClickable=true;isFocusable=true}
            row.addView(TextView(this).apply{text=icon;textSize=21f;gravity=Gravity.CENTER;setBackground(roundedSurface(Color.WHITE,16));setPadding(dp(8),dp(6),dp(8),dp(6))},LinearLayout.LayoutParams(dp(50),dp(50)))
            val texts=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
            texts.addView(TextView(this@MainActivity).apply{text=title;textSize=15.5f;setTextColor(Color.rgb(25,28,32));setTypeface(null,android.graphics.Typeface.BOLD)})
            texts.addView(TextView(this@MainActivity).apply{text=subtitle;textSize=12.5f;setTextColor(Color.rgb(100,104,110));setPadding(0,dp(2),0,0)})
            row.addView(texts,LinearLayout.LayoutParams(0,-2,1f));row.addView(TextView(this@MainActivity).apply{text="›";textSize=27f;setTextColor(Color.rgb(120,124,130));gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(28),dp(50)))
            row.setOnClickListener{action()};box.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(4),0,dp(4))})
        }
        option("Riepilogo sedute","Visualizza e copia il riepilogo per WhatsApp","📊"){copySummaryToClipboard(summaryForSessionPack(s),s.name)}
        option("Storico cliente","Pacchetti terminati e informazioni precedenti","🗂"){showClientHistory(s.name)}
        option("Gestisci pacchetto","Rinomina, termina o elimina il pacchetto","⚙️"){sessionOptionsDialog(s)}
        val close=Button(this).apply{text="Chiudi";setAllCaps(false);textSize=14f;setTextColor(Color.rgb(0,125,110));setBackgroundColor(Color.TRANSPARENT);stateListAnimator=null}
        box.addView(close,LinearLayout.LayoutParams(-1,dp(46)).apply{setMargins(0,dp(4),0,0)})
        val dialog=AlertDialog.Builder(this).setTitle(displaySurnameFirst(s.name)).setView(box).create()
        dialog.setOnShowListener{dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28));dialog.window?.setDimAmount(0.42f);close.setOnClickListener{dialog.dismiss()}}
        dialog.show()
    }

    private fun terminatePackDialog(p:Pack){
        val future=appointments.filter{identityKey(it.name)==identityKey(p.name)&&it.date.isAfter(LocalDate.now())}
        val dialog=AlertDialog.Builder(this)
            .setTitle("Terminare il pacchetto?")
            .setMessage("Il pacchetto verrà spostato nello storico e non sarà più considerato attivo.\n\nSono presenti ${future.size} appuntamenti futuri nel calendario. Puoi mantenerli oppure eliminarli.")
            .setNegativeButton("ANNULLA",null)
            .setNeutralButton("MANTIENI APPUNTAMENTI"){_,_->p.active=false;saveData();render();Toast.makeText(this,"Pacchetto terminato. Appuntamenti mantenuti.",Toast.LENGTH_SHORT).show()}
            .setPositiveButton("ELIMINA FUTURI"){_,_->appointments.removeAll{identityKey(it.name)==identityKey(p.name)&&it.date.isAfter(LocalDate.now())};p.active=false;saveData();render();Toast.makeText(this,"Pacchetto terminato e appuntamenti futuri eliminati.",Toast.LENGTH_SHORT).show()}
            .create()
        styleOneUiDialog(dialog);dialog.show()
    }

    private fun confirmDeletePack(p:Pack){
        val dialog=AlertDialog.Builder(this)
            .setTitle("Eliminare pacchetto?")
            .setMessage("Stai per eliminare definitivamente il pacchetto di ${displaySurnameFirst(p.name)}.\n\nLe rate e i dati del pacchetto verranno rimossi. Gli appuntamenti del cliente resteranno nel calendario.")
            .setNegativeButton("ANNULLA",null)
            .setPositiveButton("ELIMINA"){_,_->packs.remove(p);saveData();render();Toast.makeText(this,"Pacchetto eliminato.",Toast.LENGTH_SHORT).show()}
            .create()
        styleOneUiDialog(dialog)
        dialog.show()
    }

    private fun editPackDialog(p:Pack){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(6),dp(18),0)}
        val name=EditText(this).apply{setSingleLine(true);setText(p.name);setSelection(text.length);textSize=16f;hint="Cognome Nome"}
        val type=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("BRONZE • 12 sedute","SILVER • 24 sedute","GOLD • 36 sedute","PERSONALIZZATO"));setSelection(when(p.packageType){"BRONZE"->0;"SILVER"->1;"GOLD"->2;else->3})}
        val sessions=EditText(this).apply{setSingleLine(true);inputType=2;setText(p.sessionTotal.toString());hint="Numero sedute"}
        box.addView(TextView(this).apply{text="Nome cliente";textSize=13f;setTextColor(Color.rgb(95,99,105))})
        box.addView(name,LinearLayout.LayoutParams(-1,dp(52)))
        box.addView(TextView(this).apply{text="Tipo pacchetto";textSize=13f;setTextColor(Color.rgb(95,99,105));setPadding(0,dp(10),0,dp(2))})
        box.addView(type,LinearLayout.LayoutParams(-1,dp(52)))
        box.addView(TextView(this).apply{text="Numero sedute";textSize=13f;setTextColor(Color.rgb(95,99,105));setPadding(0,dp(10),0,dp(2))})
        box.addView(sessions,LinearLayout.LayoutParams(-1,dp(52)))
        fun sync(){sessions.setText(when(type.selectedItemPosition){0->"12";1->"24";2->"36";else->p.sessionTotal.toString()})}
        type.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(parent:AdapterView<*>?){};override fun onItemSelected(parent:AdapterView<*>?,view:View?,position:Int,id:Long){if(position<3)sync()}}
        val dialog=AlertDialog.Builder(this).setTitle("Modifica pacchetto").setView(box).setNegativeButton("ANNULLA",null).setPositiveButton("SALVA",null).create()
        styleOneUiDialog(dialog)
        dialog.setOnShowListener{dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{
            val newName=normalizeDisplayName(name.text.toString())
            val newTotal=sessions.text.toString().trim().toIntOrNull()
            if(newName.isBlank()||newTotal==null||newTotal<=0){Toast.makeText(this,"Controlla nome e numero sedute.",Toast.LENGTH_LONG).show();return@setOnClickListener}
            val done=sessionsForPack(p,LocalDate.now()).size
            if(newTotal<done){Toast.makeText(this,"Non puoi impostare $newTotal sedute: ne risultano già effettuate $done.",Toast.LENGTH_LONG).show();return@setOnClickListener}
            val oldKey=identityKey(p.name)
            val kind=when(type.selectedItemPosition){0->"BRONZE";1->"SILVER";2->"GOLD";else->"PERSONALIZZATO"}
            p.name=newName;p.packageType=kind;p.sessionTotal=if(kind=="BRONZE")12 else if(kind=="SILVER")24 else if(kind=="GOLD")36 else newTotal
            appointments.filter{identityKey(it.name)==oldKey}.forEach{it.name=newName}
            saveData();render();dialog.dismiss();Toast.makeText(this,"Pacchetto aggiornato.",Toast.LENGTH_SHORT).show()
        }}
        dialog.show()
    }

    private fun renamePackDialog(p:Pack){
        val input=EditText(this).apply{
            setSingleLine(true)
            setText(p.name)
            setSelection(text.length)
            textSize=16f
            hint="Cognome Nome"
        }
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(22),dp(6),dp(22),0)}
        box.addView(TextView(this).apply{text="Nuovo nome del cliente/pacchetto";textSize=13f;setTextColor(Color.rgb(95,99,105));setPadding(0,0,0,dp(6))})
        box.addView(input,LinearLayout.LayoutParams(-1,dp(54)))
        val dialog=AlertDialog.Builder(this).setTitle("Rinomina pacchetto").setView(box).setPositiveButton("SALVA",null).setNegativeButton("ANNULLA",null).create()
        styleOneUiDialog(dialog)
        dialog.setOnShowListener{
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{
                val newName=normalizeDisplayName(input.text.toString())
                if(newName.isBlank()){input.error="Inserisci un nome";return@setOnClickListener}
                val oldKey=identityKey(p.name)
                p.name=newName
                appointments.filter{identityKey(it.name)==oldKey}.forEach{it.name=newName}
                saveData();render();dialog.dismiss();Toast.makeText(this,"Pacchetto rinominato.",Toast.LENGTH_SHORT).show()
            }
        }
        dialog.show()
    }

    private fun sessionOptionsDialog(s:SessionPack){
        val used=sessionUsed(s);val remaining=(s.totalSessions-used).coerceAtLeast(0)
        val actions=arrayOf("Rinomina pacchetto","Termina pacchetto","Elimina pacchetto")
        AlertDialog.Builder(this).setTitle(s.name).setMessage("Pacchetto da ${s.totalSessions} sedute • €${s.cost} saldato per intero\nSedute registrate: $used/${s.totalSessions}\nSedute rimanenti: $remaining").setItems(actions){_,which->when(which){
            0->{renameSessionPackDialog(s)}
            1->{s.active=false;saveData();render()}
            else->{sessionPacks.remove(s);appointments.filter{it.sessionPackId==s.id}.forEach{it.sessionPackId=0L};saveData();render()}
        }}.setNegativeButton("Chiudi",null).create().also{styleOneUiDialog(it);it.show()}
    }

    private fun renameSessionPackDialog(s:SessionPack){
        val input=EditText(this).apply{
            setSingleLine(true)
            setText(s.name)
            setSelection(text.length)
            textSize=16f
            hint="Cognome Nome"
        }
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(22),dp(6),dp(22),0)}
        box.addView(TextView(this).apply{text="Nuovo nome del cliente/pacchetto";textSize=13f;setTextColor(Color.rgb(95,99,105));setPadding(0,0,0,dp(6))})
        box.addView(input,LinearLayout.LayoutParams(-1,dp(54)))
        val dialog=AlertDialog.Builder(this).setTitle("Rinomina pacchetto").setView(box).setPositiveButton("SALVA",null).setNegativeButton("ANNULLA",null).create()
        dialog.setOnShowListener{
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{
                val newName=normalizeDisplayName(input.text.toString())
                if(newName.isBlank()){input.error="Inserisci un nome";return@setOnClickListener}
                val oldKey=identityKey(s.name)
                s.name=newName
                appointments.filter{it.sessionPackId==s.id}.forEach{it.name=newName}
                saveData();render();dialog.dismiss();Toast.makeText(this,"Pacchetto rinominato.",Toast.LENGTH_SHORT).show()
            }
        }
        styleOneUiDialog(dialog)
        dialog.show()
    }

    private fun showClientHistory(name:String){
        val oldPacks=packs.filter{!it.active&&identityKey(it.name)==identityKey(name)}
        val oldSessions=sessionPacks.filter{!it.active&&identityKey(it.name)==identityKey(name)}
        if(oldPacks.isEmpty()&&oldSessions.isEmpty()){Toast.makeText(this,"Nessun pacchetto terminato nello storico di $name.",Toast.LENGTH_SHORT).show();return}
        val items=mutableListOf<Pair<String,()->Unit>>()
        oldPacks.forEach{p->items.add("${p.packageType} • ${p.start.format(fmt)} • €${p.total}" to {exportSummary(summaryForPack(p),p.name)})}
        oldSessions.forEach{s->items.add("${s.totalSessions} sedute • ${s.start.format(fmt)} • €${s.cost}" to {exportSummary(summaryForSessionPack(s),s.name)})}
        AlertDialog.Builder(this).setTitle("🗂 Storico • $name").setItems(items.map{it.first}.toTypedArray()){_,which->items[which].second.invoke()}.setNegativeButton("Chiudi",null).show()
    }

    private fun Pack.paidRateIndex(rates:List<Int>):Int=(0..2).firstOrNull{paid<rates.take(it+1).sum()}?:3

    private data class PackStatus(val label:String,val color:Int)
    private fun statusRank(status:PackStatus):Int=when(status.label){"SCADUTA"->0;"IN SCADENZA"->1;else->2}
    private fun statusFor(p:Pack,rates:List<Int>,dates:List<LocalDate>):PackStatus{if(p.paid>=p.total)return PackStatus("IN REGOLA",Color.rgb(35,150,70));val nextIndex=(0..2).firstOrNull{p.paid<rates.take(it+1).sum()}?:2;val due=dates[nextIndex];val today=LocalDate.now();return when{due.isBefore(today)->PackStatus("SCADUTA",Color.rgb(210,45,45));!due.isAfter(today.plusDays(7))->PackStatus("IN SCADENZA",Color.rgb(220,160,20));else->PackStatus("IN REGOLA",Color.rgb(35,150,70))}}

    // ---------------- CALENDARIO ----------------
    private fun calendarScreen(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),dp(12),dp(10),dp(8));setBackgroundColor(Color.rgb(247,248,250))}
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        top.addView(buttonStyle("‹").apply{setOnClickListener{calendarWeekStart=calendarWeekStart.minusWeeks(1);calendarScreen()}},LinearLayout.LayoutParams(dp(52),dp(48)))
        top.addView(TextView(this).apply{text="Settimana ${calendarWeekStart.format(fmt)}";textSize=17f;gravity=Gravity.CENTER;setTextColor(Color.rgb(30,30,30))},LinearLayout.LayoutParams(0,dp(48),1f))
        top.addView(buttonStyle("›").apply{setOnClickListener{calendarWeekStart=calendarWeekStart.plusWeeks(1);calendarScreen()}},LinearLayout.LayoutParams(dp(52),dp(48)))
        root.addView(top)
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        actions.addView(primaryButtonStyle("＋ Appuntamento").apply{setOnClickListener{appointmentDialog(null)}},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(3),0)})
        actions.addView(buttonStyle("Oggi").apply{setOnClickListener{calendarWeekStart=LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));calendarScreen()}},LinearLayout.LayoutParams(0,dp(48),0.55f).apply{setMargins(dp(3),0,dp(3),0)})
        actions.addView(primaryButtonStyle("🔎 Cerca").apply{setOnClickListener{calendarSearchScreen()}},LinearLayout.LayoutParams(0,dp(48),0.72f).apply{setMargins(dp(3),0,0,0)})
        root.addView(actions,LinearLayout.LayoutParams(-1,dp(52)))
        val titleRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val visibleOffsets=mutableListOf<Int>();calendarVisibleDays.forEachIndexed{i,shown->if(shown)visibleOffsets.add(i)};val firstVisibleOffset=visibleOffsets.firstOrNull()?:0;val lastVisibleOffset=visibleOffsets.lastOrNull()?:4;titleRow.addView(TextView(this).apply{text="${calendarWeekStart.plusDays(firstVisibleOffset.toLong()).format(fmt)}  →  ${calendarWeekStart.plusDays(lastVisibleOffset.toLong()).format(fmt)}";textSize=14f;setTextColor(Color.DKGRAY);gravity=Gravity.CENTER;setPadding(0,dp(4),0,dp(8))},LinearLayout.LayoutParams(0,dp(34),1f))
        val zoomLabel=TextView(this).apply{text="${(calendarZoom*100).toInt()}%";textSize=12f;setTextColor(Color.GRAY);gravity=Gravity.CENTER}
        titleRow.addView(buttonStyle("−").apply{setOnClickListener{calendarZoom=(calendarZoom-0.25f).coerceAtLeast(0.75f);calendarScreen()}},LinearLayout.LayoutParams(dp(44),dp(34)))
        titleRow.addView(zoomLabel,LinearLayout.LayoutParams(dp(44),dp(34)))
        titleRow.addView(buttonStyle("+").apply{setOnClickListener{calendarZoom=(calendarZoom+0.25f).coerceAtMost(1.75f);calendarScreen()}},LinearLayout.LayoutParams(dp(44),dp(34)))
        root.addView(titleRow,LinearLayout.LayoutParams(-1,dp(38)))
        val verticalScroll=ScrollView(this).apply{isFillViewport=false}
        val horizontalScroll=HorizontalScrollView(this).apply{isFillViewport=false;isHorizontalScrollBarEnabled=true}
        val week=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        calendarVisibleDays.forEachIndexed{i,shown->if(shown)week.addView(dayColumn(calendarWeekStart.plusDays(i.toLong())),LinearLayout.LayoutParams((dp(178)*calendarZoom).toInt().coerceAtLeast(dp(132)),-2))}
        horizontalScroll.addView(week,ViewGroup.LayoutParams(-2,-2))
        verticalScroll.addView(horizontalScroll,ViewGroup.LayoutParams(-2,-2))
        root.addView(verticalScroll,LinearLayout.LayoutParams(-1,0,1f))
        root.addView(softBlueButtonStyle("← Torna ai clienti").apply{setOnClickListener{build()}},LinearLayout.LayoutParams(-1,dp(48)))
        setContentView(root)
    }

    private fun calendarSearchScreen(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(14),dp(16),dp(10));setBackgroundColor(Color.rgb(247,248,250))}
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        top.addView(TextView(this).apply{text="🔎 Ricerca appuntamenti";textSize=22f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,dp(52),1f))
        top.addView(buttonStyle("Chiudi").apply{setOnClickListener{calendarScreen()}},LinearLayout.LayoutParams(dp(82),dp(44)))
        root.addView(top)
        searchInput=EditText(this).apply{
            hint="Cerca per nome cliente";textSize=16f;setSingleLine(true);setPadding(dp(14),0,dp(14),0);background=roundedSurface(Color.WHITE,20,Color.rgb(226,229,234),1)
            addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){searchList.removeAllViews();if(s.toString().trim().isNotEmpty())renderSearchResults(s.toString().trim().lowercase())};override fun afterTextChanged(s:Editable?){}})
        }
        root.addView(searchInput,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,dp(8),0,dp(8))})
        searchList=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,dp(4),0,0)}
        val scroll=ScrollView(this).apply{addView(searchList,ViewGroup.LayoutParams(-1,-2))}
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        root.addView(softBlueButtonStyle("← Torna al calendario").apply{setOnClickListener{calendarScreen()}},LinearLayout.LayoutParams(-1,dp(48)))
        setContentView(root)
        searchInput.requestFocus()
    }

    private fun dayColumn(day:LocalDate):View{
        val z=calendarZoom
        val col=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding((dp(4)*z).toInt(),0,(dp(4)*z).toInt(),(dp(4)*z).toInt())}
        val today=day==LocalDate.now()
        val headerBg=GradientDrawable().apply{cornerRadius=(dp(12)*z);setColor(if(today)Color.rgb(232,242,255)else Color.WHITE);setStroke((dp(1)*z).toInt(),if(today)Color.rgb(145,190,232)else Color.rgb(226,229,234))}
        col.addView(TextView(this).apply{text="${dayShort(day.dayOfWeek.value-1)}\n${day.dayOfMonth.toString().padStart(2,'0')}/${day.monthValue.toString().padStart(2,'0')}";textSize=15f*z;gravity=Gravity.CENTER;setTextColor(if(today)Color.rgb(35,105,180)else Color.rgb(45,45,45));background=headerBg;setPadding(0,(dp(6)*z).toInt(),0,(dp(6)*z).toInt())},LinearLayout.LayoutParams(-1,(dp(58)*z).toInt()).apply{setMargins(0,0,0,(dp(4)*z).toInt())})
        for(slot in 0 until 20){val mins=7*60+slot*45;val hour=mins/60;val minute=mins%60;val time=String.format("%02d:%02d",hour,minute);val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding((dp(5)*z).toInt(),(dp(4)*z).toInt(),(dp(5)*z).toInt(),(dp(4)*z).toInt());background=GradientDrawable().apply{cornerRadius=(dp(9)*z);setColor(if(slot%2==0)Color.WHITE else Color.rgb(250,251,252));setStroke((dp(1)*z).toInt(),Color.rgb(232,234,238))};isClickable=true}
            val items=appointments.filter{it.date==day&&it.time==time}.sortedBy{it.type}
            val maxTotal=calendarRoutines.getOrNull(activeRoutineIndex)?.maxTotal?:3;val countColor=when{items.size>=maxTotal->Color.rgb(205,55,55);items.size==maxTotal-1->Color.rgb(210,145,25);else->Color.GRAY}
            val timeRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            timeRow.addView(TextView(this).apply{text=time;textSize=11f*z;setTextColor(Color.rgb(105,110,118));setTypeface(null,android.graphics.Typeface.BOLD)},LinearLayout.LayoutParams(0,(dp(22)*z).toInt(),1f))
            timeRow.addView(TextView(this).apply{text="${items.size}/3";textSize=9f*z;setTextColor(countColor);gravity=Gravity.CENTER},LinearLayout.LayoutParams((dp(30)*z).toInt(),(dp(22)*z).toInt()))
            box.addView(timeRow)
            if(items.isEmpty()){box.addView(TextView(this).apply{text="＋";textSize=18f*z;gravity=Gravity.CENTER;setTextColor(Color.LTGRAY)},LinearLayout.LayoutParams(-1,(dp(42)*z).toInt()));box.setOnClickListener{appointmentDialogForSlot(day,time)}}
            else{val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                items.forEachIndexed{index,a->row.addView(appointmentChip(a),LinearLayout.LayoutParams(0,(dp(46)*z).toInt(),1f).apply{if(index>0)setMargins((dp(3)*z).toInt(),0,0,0)})}
                box.addView(row,LinearLayout.LayoutParams(-1,(dp(46)*z).toInt()))
                box.addView(TextView(this).apply{text="${items.size}/${calendarRoutines.getOrNull(activeRoutineIndex)?.maxTotal?:3} appuntamenti";textSize=8.5f*z;setTextColor(Color.GRAY);gravity=Gravity.CENTER_VERTICAL;setPadding(0,(dp(2)*z).toInt(),0,0)},LinearLayout.LayoutParams(-1,(dp(16)*z).toInt()))
                box.setOnClickListener{appointmentDialogForSlot(day,time)}
            }
            col.addView(box,LinearLayout.LayoutParams(-1,(dp(84)*z).toInt()).apply{setMargins(0,(dp(2)*z).toInt(),0,0)})
        }
        return col
    }

    private fun calendarPackageExpired(name:String):Boolean{
        val key=identityKey(name)
        val regularExpired=packs.any{it.active&&identityKey(it.name)==key&&statusFor(it,ratesFor(it),dueDates(it)).label=="SCADUTA"}
        val sessionExpired=sessionPacks.any{it.active&&identityKey(it.name)==key&&sessionStatus(it).label=="SCADUTA"}
        return regularExpired||sessionExpired
    }

    private fun appointmentChip(a:Appointment):View{
        val isHalf=typeDuration(a.type)==30
        val accent=if(isHalf)Color.rgb(215,55,55)else Color.rgb(45,135,210)
        val bg=if(isHalf)Color.rgb(255,239,239)else Color.rgb(232,244,255)
        val chip=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding((dp(3)*calendarZoom).toInt(),(dp(2)*calendarZoom).toInt(),(dp(3)*calendarZoom).toInt(),(dp(2)*calendarZoom).toInt());background=GradientDrawable().apply{cornerRadius=(dp(11)*calendarZoom);setColor(bg);setStroke((dp(1)*calendarZoom).toInt(),accent)};isClickable=true}
        chip.addView(TextView(this).apply{text=a.name;textSize=9.5f*calendarZoom;setTextColor(Color.rgb(25,30,35));gravity=Gravity.CENTER;maxLines=2;ellipsize=android.text.TextUtils.TruncateAt.END;setTypeface(null,android.graphics.Typeface.BOLD)},LinearLayout.LayoutParams(-1,(dp(42)*calendarZoom).toInt()))
        chip.setOnClickListener{appointmentActions(a)}
        return chip}

    private fun registerDeletedRegularAppointment(a:Appointment){
        if(!a.recovery){regularPackFor(a.name,a.date)?.let{it.missedSessions++}}
    }

    private fun appointmentActions(a:Appointment){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(4),dp(18),dp(8))}
        box.addView(TextView(this).apply{text=a.name;textSize=23f;setTextColor(Color.rgb(24,27,31));setTypeface(null,android.graphics.Typeface.BOLD)})
        box.addView(TextView(this).apply{text="${a.date.format(fmt)} • ${a.time} • ${"${typeDuration(a.type)} min"}";textSize=13.5f;setTextColor(Color.rgb(92,96,102));setPadding(0,dp(3),0,dp(12))})
        val edit=Button(this).apply{text="Modifica / sposta";setAllCaps(false);textSize=15f;gravity=Gravity.CENTER_VERTICAL;setTextColor(Color.rgb(25,28,32));background=roundedSurface(Color.rgb(246,248,250),18,Color.rgb(228,231,235),1);stateListAnimator=null}
        val del=Button(this).apply{text="Elimina appuntamento";setAllCaps(false);textSize=15f;gravity=Gravity.CENTER_VERTICAL;setTextColor(Color.rgb(205,55,55));background=roundedSurface(Color.rgb(255,244,244),18,Color.rgb(244,215,215),1);stateListAnimator=null}
        val missedPack=regularPackFor(a.name,a.date)
        val markMissed=if(a.date.isBefore(LocalDate.now()) && missedPack!=null) Button(this).apply{this.text=if(a.recovery)"Segna recupero non effettuato" else "Segna seduta come persa";setAllCaps(false);textSize=14.5f;gravity=Gravity.CENTER_VERTICAL;setTextColor(Color.rgb(190,120,20));background=roundedSurface(Color.rgb(255,248,232),18,Color.rgb(244,224,190),1);stateListAnimator=null} else null
        val cancel=Button(this).apply{text="Annulla";setAllCaps(false);textSize=14f;setTextColor(Color.rgb(0,125,110));setBackgroundColor(Color.TRANSPARENT);stateListAnimator=null}
        box.addView(edit,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,0,0,dp(6))});
        if(markMissed!=null) box.addView(markMissed,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(5))})
        box.addView(del,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,0,0,dp(3))});box.addView(cancel,LinearLayout.LayoutParams(-1,dp(46)))
        val dialog=AlertDialog.Builder(this).setView(box).create();styleOneUiDialog(dialog)
        dialog.setOnShowListener{dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28));dialog.window?.setDimAmount(0.42f);edit.setOnClickListener{dialog.dismiss();appointmentDialog(a)};markMissed?.setOnClickListener{
            missedPack?.let{p->if(!a.recovery)p.missedSessions++}
            appointments.remove(a);saveData();dialog.dismiss();calendarScreen()
        };del.setOnClickListener{
            dialog.dismiss()
            if(a.seriesId!=0L){
                val series=appointments.filter{it.seriesId==a.seriesId}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
                val seriesCount=series.size
                val selectedIndex=series.indexOfFirst{it.id==a.id}
                val laterCount=if(selectedIndex>=0) series.size-selectedIndex else 0
                val boxSeq=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(8),dp(20),dp(10))}
                boxSeq.addView(TextView(this).apply{
                    text="Elimina appuntamento";textSize=23f;setTextColor(Color.rgb(24,27,31));setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setPadding(0,0,0,dp(8))
                },LinearLayout.LayoutParams(-1,dp(48)))
                boxSeq.addView(TextView(this).apply{
                    text="Questo appuntamento fa parte di una programmazione di $seriesCount appuntamenti.\n\nCosa vuoi eliminare?"
                    textSize=16f;setTextColor(Color.rgb(55,58,63));gravity=Gravity.CENTER;setPadding(0,0,0,dp(12))
                })
                fun seqButton(label:String, sub:String?=null, bg:Int=Color.rgb(246,248,250), fg:Int=Color.rgb(25,28,32)):Button{
                    return Button(this).apply{
                        text=if(sub.isNullOrBlank()) label else "$label\n$sub"
                        setAllCaps(false);textSize=15f;gravity=Gravity.CENTER;setTextColor(fg);setPadding(dp(10),0,dp(10),0)
                        background=roundedSurface(bg,18,Color.rgb(228,231,235),1);stateListAnimator=null
                    }
                }
                val one=seqButton("Solo questo appuntamento")
                val subsequent=seqButton("Questo e tutti i successivi","Elimina $laterCount appuntamenti da questo in poi")
                val all=seqButton("Tutta la sequenza","Elimina tutti i $seriesCount appuntamenti",Color.rgb(255,244,244),Color.rgb(195,55,55))
                val cancelSeq=Button(this).apply{text="Annulla";setAllCaps(false);textSize=14f;gravity=Gravity.CENTER;setTextColor(Color.rgb(0,125,110));setBackgroundColor(Color.TRANSPARENT);stateListAnimator=null}
                boxSeq.addView(one,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(7))})
                boxSeq.addView(subsequent,LinearLayout.LayoutParams(-1,dp(58)).apply{setMargins(0,0,0,dp(7))})
                boxSeq.addView(all,LinearLayout.LayoutParams(-1,dp(58)).apply{setMargins(0,0,0,dp(4))})
                boxSeq.addView(cancelSeq,LinearLayout.LayoutParams(-1,dp(44)))
                val seqDialog=AlertDialog.Builder(this).setView(boxSeq).create()
                styleOneUiDialog(seqDialog)
                seqDialog.setOnShowListener{
                    seqDialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28));seqDialog.window?.setDimAmount(0.42f)
                    one.setOnClickListener{registerDeletedRegularAppointment(a);appointments.remove(a);saveData();seqDialog.dismiss();calendarScreen()}
                    subsequent.setOnClickListener{
                        if(selectedIndex>=0){
                            val toRemove=appointments.filter{it.seriesId==a.seriesId && (it.date.isAfter(a.date) || (it.date==a.date && it.time>=a.time))}
                            toRemove.forEach{registerDeletedRegularAppointment(it)}
                            appointments.removeAll{it.id in toRemove.map{r->r.id}.toSet()}
                        }
                        saveData();seqDialog.dismiss();calendarScreen()
                    }
                    all.setOnClickListener{val toRemove=appointments.filter{it.seriesId==a.seriesId};toRemove.forEach{registerDeletedRegularAppointment(it)};appointments.removeAll{it.id in toRemove.map{r->r.id}.toSet()};saveData();seqDialog.dismiss();calendarScreen()}
                    cancelSeq.setOnClickListener{seqDialog.dismiss()}
                }
                seqDialog.show()
            }else{
                AlertDialog.Builder(this)
                    .setTitle("Elimina appuntamento?")
                    .setMessage("Vuoi eliminare questo appuntamento?")
                    .setNegativeButton("ANNULLA",null)
                    .setPositiveButton("ELIMINA"){_,_->registerDeletedRegularAppointment(a);appointments.remove(a);saveData();calendarScreen()}
                    .create().also{styleOneUiDialog(it);it.show()}
            }
        };cancel.setOnClickListener{dialog.dismiss()}}
        dialog.show()
    }

    private fun styleOneUiDialog(dialog:AlertDialog){
        dialog.setOnShowListener{
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28))
            dialog.window?.setDimAmount(0.38f)
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.apply{setTextColor(Color.rgb(0,125,110));setAllCaps(false);stateListAnimator=null}
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.apply{setTextColor(Color.rgb(0,125,110));setAllCaps(false);stateListAnimator=null}
        }
    }

    private fun appointmentDialog(existing:Appointment?, forcedDay:LocalDate?=null, forcedTime:String?=null){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(4),dp(14),0)}
        val name=AutoCompleteTextView(this).apply{hint="Cliente";setText(existing?.name?:"");setSingleLine(true);setAdapter(ArrayAdapter(this@MainActivity,android.R.layout.simple_dropdown_item_1line,(packs.map{it.name}+sessionPacks.map{it.name}).distinct().toTypedArray()))}
        val date=EditText(this).apply{hint="Data (gg/mm/aaaa)";inputType=2;setText((existing?.date?:forcedDay?:calendarWeekStart).format(fmt))};setupDateInput(date)
        val time=Spinner(this)
        val type=Spinner(this);type.adapter=centeredSpinnerAdapter(appointmentTypes.map{it.name});type.setSelection(existing?.let{typeIndex(it.type)}?:0)
        box.addView(name);box.addView(date)
        box.addView(TextView(this).apply{text="Fascia oraria disponibile";textSize=13f;setTextColor(Color.DKGRAY);setPadding(0,dp(8),0,dp(3))})
        box.addView(time)
        box.addView(type)
        var seriesEdit: Button? = null
        if(existing!=null && existing.seriesId!=0L){
            seriesEdit=Button(this).apply{
                text="🔄 Modifica programmazione";setAllCaps(false);textSize=15f;gravity=Gravity.CENTER_VERTICAL;setTextColor(Color.rgb(35,105,180))
                background=roundedSurface(Color.rgb(232,242,255),18,Color.rgb(185,210,238),1);stateListAnimator=null
            }
            box.addView(seriesEdit,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,dp(8),0,dp(4))})
        }
        var recovery: CheckBox? = null
        if(existing==null){
            recovery=CheckBox(this).apply{
                text="↩ Recupero seduta persa"
                setPadding(0,dp(8),0,dp(4))
                visibility=View.GONE
            }
            box.addView(recovery)
        }

        fun refreshTimeSlots(){
            val selectedType=typeIdAt(type.selectedItemPosition)
            val selectedDate=runCatching{parseDate(date.text.toString())}.getOrNull()?: (existing?.date?:forcedDay?:calendarWeekStart)
            val slots=availableTimeSlots(selectedDate,selectedType,existing)
            val values=if(slots.isEmpty()) listOf("NESSUNA FASCIA DISPONIBILE") else slots
            time.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,values)
            val wanted=existing?.time?:forcedTime
            if(wanted!=null){val idx=values.indexOf(wanted);if(idx>=0)time.setSelection(idx)}
        }
        fun refreshRecoveryOption(){
            if(existing!=null || recovery==null) return
            val selectedDate=runCatching{parseDate(date.text.toString())}.getOrNull() ?: LocalDate.now()
            val possiblePack=regularPackFor(name.text.toString(),selectedDate)
            val pending=possiblePack?.let{recoveriesForPack(it)} ?: 0
            recovery.isChecked=false
            recovery.isEnabled=pending>0
            recovery.visibility=if(pending>0)View.VISIBLE else View.GONE
            if(pending>0) recovery.text="↩ Recupero seduta persa ($pending disponibile/i)"
        }
        refreshTimeSlots()
        refreshRecoveryOption()
        type.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(parent:AdapterView<*>?){ } override fun onItemSelected(parent:AdapterView<*>?,view:View?,position:Int,id:Long){refreshTimeSlots()}}
        date.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){refreshTimeSlots();refreshRecoveryOption()};override fun afterTextChanged(s:Editable?){}})
        name.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){refreshRecoveryOption()};override fun afterTextChanged(s:Editable?){}})
        if(existing==null){
            box.addView(TextView(this).apply{text="Ripetizione (facoltativa)";textSize=14f;setTextColor(Color.DKGRAY);setPadding(0,dp(10),0,dp(4))})
            val repeat=CheckBox(this).apply{text="Ripeti ogni settimana"}
            val days=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE}
            val checks=(0..6).map{i->CheckBox(this).apply{text=dayShort(i);isChecked=i==((forcedDay?:calendarWeekStart).dayOfWeek.value-1);setPadding(0,0,0,0)}}
            val dayTimes=mutableMapOf<Int,Spinner>()
            val dayRows=mutableMapOf<Int,LinearLayout>()
            fun datesForWeekday(dayIndex:Int,start:LocalDate,end:LocalDate):List<LocalDate>{
                val out=mutableListOf<LocalDate>();var d=start
                while(!d.isAfter(end)){if(d.dayOfWeek.value-1==dayIndex)out.add(d);d=d.plusDays(1)}
                return out
            }
            fun slotsForWeekday(dayIndex:Int,start:LocalDate,end:LocalDate,selectedType:String):List<String>{
                val dates=datesForWeekday(dayIndex,start,end)
                if(dates.isEmpty()) return emptyList()
                val first=availableTimeSlots(dates.first(),selectedType,existing)
                return first.filter{slot->dates.all{d->canAdd(d,slot,selectedType,if(existing?.date==d)existing else null)}}
            }
            val end=EditText(this).apply{hint="Fine ripetizione (gg/mm/aaaa)";inputType=2;setText(calendarWeekStart.plusWeeks(12).format(fmt));visibility=View.GONE};setupDateInput(end)
            fun refreshDayTimeRows(){
                val startDate=runCatching{parseDate(date.text.toString())}.getOrNull()?:calendarWeekStart
                val endDate=runCatching{parseDate(end.text.toString())}.getOrNull()?:startDate
                val selectedType=typeIdAt(type.selectedItemPosition)
                checks.forEachIndexed{idx,c->
                    val row=dayRows[idx] ?: return@forEachIndexed
                    row.visibility=View.VISIBLE
                    val spinner=dayTimes[idx] ?: return@forEachIndexed
                    spinner.visibility=if(c.isChecked) View.VISIBLE else View.GONE
                    if(!c.isChecked) return@forEachIndexed
                    val values=slotsForWeekday(idx,startDate,endDate,selectedType)
                    val shown=if(values.isEmpty()) listOf("NESSUNA FASCIA DISPONIBILE") else values
                    spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,shown)
                    val preferred=if(idx==((forcedDay?:calendarWeekStart).dayOfWeek.value-1)) time.selectedItem?.toString() else null
                    if(preferred!=null){val pi=shown.indexOf(preferred);if(pi>=0)spinner.setSelection(pi)}
                    spinner.isEnabled=values.isNotEmpty()
                }
            }
            checks.forEachIndexed{idx,c->
                val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                row.addView(c,LinearLayout.LayoutParams(0,dp(50),1f))
                val spinner=Spinner(this)
                dayTimes[idx]=spinner
                row.addView(spinner,LinearLayout.LayoutParams(dp(155),dp(48)))
                dayRows[idx]=row
                days.addView(row)
                c.setOnCheckedChangeListener{_,_->refreshDayTimeRows()}
            }
            repeat.setOnCheckedChangeListener{_,checked->days.visibility=if(checked)View.VISIBLE else View.GONE;end.visibility=if(checked)View.VISIBLE else View.GONE;time.visibility=if(checked)View.GONE else View.VISIBLE;refreshDayTimeRows();recovery?.let{it.visibility=if(checked)View.GONE else if(it.isEnabled)View.VISIBLE else View.GONE}}
            date.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){if(repeat.isChecked)refreshDayTimeRows()};override fun afterTextChanged(s:Editable?){}})
            end.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){if(repeat.isChecked)refreshDayTimeRows()};override fun afterTextChanged(s:Editable?){}})
            box.addView(repeat);box.addView(days);box.addView(end)
            AlertDialog.Builder(this).setTitle("Nuovo appuntamento").setView(box).setNegativeButton("Annulla",null).setPositiveButton("SALVA"){_,_->
                val selectedDayTimes=dayTimes.filterKeys{checks[it].isChecked}.mapValues{it.value.selectedItem?.toString() ?: ""}
                createAppointments(name.text.toString().trim(),date.text.toString(),time.selectedItem?.toString() ?: "",typeIdAt(type.selectedItemPosition),repeat.isChecked,checks,end.text.toString(),recovery?.isChecked==true,dayTimes=selectedDayTimes)
            }.create().also{styleOneUiDialog(it);it.show();refreshDayTimeRows()}
        }else{
            AlertDialog.Builder(this).setTitle("Modifica appuntamento").setView(box).setNegativeButton("Annulla",null).setPositiveButton("SALVA"){_,_->updateAppointment(existing,name.text.toString().trim(),date.text.toString(),time.selectedItem?.toString() ?: "",typeIdAt(type.selectedItemPosition))}.create().also{dialog->
                styleOneUiDialog(dialog);dialog.show();seriesEdit?.setOnClickListener{dialog.dismiss();editSeriesProgramming(existing!!)}
            }
        }
    }

    private fun editSeriesProgramming(anchor:Appointment){
        val seriesId=anchor.seriesId
        if(seriesId==0L)return
        val series=appointments.filter{it.seriesId==seriesId}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        if(series.isEmpty())return
        val future=series.filter{!it.date.isBefore(anchor.date)}
        if(future.isEmpty())return
        val endDate=series.maxOf{it.date}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(2),dp(14),0)}
        box.addView(TextView(this).apply{text="Modifica da ${anchor.date.format(fmt)} in poi";textSize=13.5f;setTextColor(Color.rgb(92,96,102));setPadding(0,0,0,dp(10))})
        box.addView(TextView(this).apply{text="Scegli i giorni e gli orari della nuova programmazione";textSize=14f;setTextColor(Color.rgb(55,58,63));setPadding(0,0,0,dp(6))})
        val type=Spinner(this).apply{adapter=centeredSpinnerAdapter(appointmentTypes.map{it.name});setSelection(typeIndex(anchor.type))}
        box.addView(TextView(this).apply{text="Tipo allenamento";textSize=13f;setTextColor(Color.DKGRAY);setPadding(0,dp(6),0,dp(2))})
        box.addView(type)
        val days=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val checks=(0..6).map{i->CheckBox(this).apply{text=dayShort(i);setPadding(0,0,0,0);isChecked=future.any{it.date.dayOfWeek.value-1==i}}}
        val dayTimes=mutableMapOf<Int,Spinner>()
        val rows=mutableMapOf<Int,LinearLayout>()
        fun datesForDay(dayIndex:Int):List<LocalDate>{
            val out=mutableListOf<LocalDate>();var d=anchor.date
            while(!d.isAfter(endDate)){if(d.dayOfWeek.value-1==dayIndex)out.add(d);d=d.plusDays(1)}
            return out
        }
        fun availableSeriesSlots(dayIndex:Int,selectedType:String):List<String>{
            val dates=datesForDay(dayIndex)
            if(dates.isEmpty())return emptyList()
            val first=availableTimeSlotsAfterSeriesRemoval(dates.first(),selectedType,seriesId)
            return first.filter{slot->dates.all{d->canAddAfterSeriesRemoval(d,slot,selectedType,seriesId)}}
        }
        fun refresh(){
            val selectedType=typeIdAt(type.selectedItemPosition)
            checks.forEachIndexed{idx,c->
                val spinner=dayTimes[idx] ?: return@forEachIndexed
                spinner.visibility=if(c.isChecked)View.VISIBLE else View.GONE
                if(!c.isChecked)return@forEachIndexed
                val values=availableSeriesSlots(idx,selectedType)
                val shown=if(values.isEmpty())listOf("NESSUNA FASCIA DISPONIBILE") else values
                spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,shown)
                val preferred=future.firstOrNull{it.date.dayOfWeek.value-1==idx}?.time
                if(preferred!=null){val pi=shown.indexOf(preferred);if(pi>=0)spinner.setSelection(pi)}
                spinner.isEnabled=values.isNotEmpty()
            }
        }
        checks.forEachIndexed{idx,c->
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            row.addView(c,LinearLayout.LayoutParams(0,dp(50),1f))
            val spinner=Spinner(this);dayTimes[idx]=spinner
            row.addView(spinner,LinearLayout.LayoutParams(dp(155),dp(48)))
            rows[idx]=row;days.addView(row)
            c.setOnCheckedChangeListener{_,_->refresh()}
        }
        box.addView(TextView(this).apply{text="Giorni";textSize=13f;setTextColor(Color.DKGRAY);setPadding(0,dp(10),0,dp(2))})
        box.addView(days)
        box.addView(TextView(this).apply{text="Fine programmazione: ${endDate.format(fmt)}";textSize=13f;setTextColor(Color.rgb(92,96,102));setPadding(0,dp(8),0,dp(4))})
        type.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(parent:AdapterView<*>?){ } override fun onItemSelected(parent:AdapterView<*>?,view:View?,position:Int,id:Long){refresh()}}
        val dialog=AlertDialog.Builder(this).setTitle("Modifica programmazione").setView(box).setNegativeButton("Annulla",null).setPositiveButton("SALVA"){_,_->
            val selected=checks.mapIndexedNotNull{idx,c->if(c.isChecked)idx else null}
            if(selected.isEmpty()){Toast.makeText(this,"Seleziona almeno un giorno.",Toast.LENGTH_LONG).show();return@setPositiveButton}
            val selectedType=typeIdAt(type.selectedItemPosition)
            val times=selected.associateWith{idx->dayTimes[idx]?.selectedItem?.toString()?.takeUnless{it=="NESSUNA FASCIA DISPONIBILE"}}
            if(times.values.any{it==null}){Toast.makeText(this,"Scegli un orario disponibile per ogni giorno selezionato.",Toast.LENGTH_LONG).show();return@setPositiveButton}
            applySeriesProgrammingFrom(anchor,selected, times.mapValues{it.value!!}, selectedType, endDate)
        }.create()
        styleOneUiDialog(dialog);dialog.show();refresh()
    }

    private fun availableTimeSlotsAfterSeriesRemoval(date:LocalDate,type:String,seriesId:Long):List<String>{
        return (0 until 20).map{slot -> val mins=7*60+slot*45; String.format("%02d:%02d",mins/60,mins%60)}.filter{slot->canAddAfterSeriesRemoval(date,slot,type,seriesId)}
    }

    private fun canAddAfterSeriesRemoval(date:LocalDate,time:String,type:String,seriesId:Long):Boolean{
        val r=calendarRoutines.getOrNull(activeRoutineIndex)?:CalendarRoutine("Standard",3,MutableList(appointmentTypes.size){3})
        val items=appointments.filter{it.date==date&&it.time==time&&it.seriesId!=seriesId}
        if(items.size>=r.maxTotal)return false
        val idx=typeIndex(type);if(items.count{typeIndex(it.type)==idx}>=(r.maxByType.getOrNull(idx)?:r.maxTotal))return false
        return true
    }

    private fun applySeriesProgrammingFrom(anchor:Appointment,selectedDays:List<Int>,dayTimes:Map<Int,String>,type:String,endDate:LocalDate){
        val seriesId=anchor.seriesId
        val future=appointments.filter{it.seriesId==seriesId&&!it.date.isBefore(anchor.date)}
        if(future.isEmpty())return
        val sessionPackId=future.firstOrNull{it.sessionPackId!=0L}?.sessionPackId ?: anchor.sessionPackId
        val futureIds=future.map{it.id}.toSet()
        appointments.removeAll{it.id in futureIds}
        var d=anchor.date;var created=0;var skipped=0
        val linked=sessionPackId.takeIf{it!=0L}?.let{id->sessionPacks.firstOrNull{it.id==id}}
        val usedBefore=linked?.let{s->appointments.count{it.sessionPackId==s.id}}?:0
        while(!d.isAfter(endDate)){
            val idx=d.dayOfWeek.value-1
            if(idx in selectedDays){
                val t=dayTimes[idx]!!
                val capacityOk=canAdd(d,t,type)
                val packageOk=linked==null||usedBefore+created<linked.totalSessions
                if(capacityOk&&packageOk){appointments.add(Appointment(nextAppointmentId++,anchor.name,d,t,type,seriesId,sessionPackId,anchor.recovery));created++}else skipped++
            }
            d=d.plusDays(1)
        }
        saveData();calendarScreen()
        if(skipped>0)Toast.makeText(this,"$skipped appuntamenti non inseriti perché la fascia o il pacchetto non erano disponibili.",Toast.LENGTH_LONG).show()
    }

    private fun dayShort(i:Int)=arrayOf("Lunedì","Martedì","Mercoledì","Giovedì","Venerdì","Sabato","Domenica")[i]
    private fun createAppointments(name:String,dateText:String,timeText:String,type:String,repeat:Boolean,checks:List<CheckBox>,endText:String,recovery:Boolean=false,allowWarnings:Boolean=false,dayTimes:Map<Int,String>?=null){
        try{
            val cleanName=normalizeDisplayName(name);require(cleanName.isNotEmpty());val start=parseDate(dateText);val time=normalizeTime(timeText);val linked=if(recovery)null else activeSessionPackFor(cleanName)
            if(recovery){
                val rp=regularPackFor(cleanName,start) ?: throw IllegalArgumentException("Nessun recupero disponibile")
                if(repeat || recoveriesForPack(rp)<=0) throw IllegalArgumentException("Nessun recupero disponibile")
            }
            if(!allowWarnings){
                val duplicateDates=if(repeat){
                    val end=runCatching{parseDate(endText)}.getOrNull()?:start
                    val selected=checks.mapIndexedNotNull{idx,c->if(c.isChecked)idx+1 else null}.toSet()
                    appointments.filter{identityKey(it.name)==identityKey(cleanName)&&selected.contains(it.date.dayOfWeek.value)&&!it.date.isBefore(start)&&!it.date.isAfter(end)}.map{it.date}.distinct().sorted()
                }else appointments.filter{identityKey(it.name)==identityKey(cleanName)&&it.date==start}.map{it.date}
                if(duplicateDates.isNotEmpty()){
                    val first=appointments.filter{identityKey(it.name)==identityKey(cleanName)&&duplicateDates.contains(it.date)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time}).first()
                    AlertDialog.Builder(this).setTitle("⚠️ Appuntamento già presente").setMessage(if(repeat)"$cleanName ha già appuntamenti in ${duplicateDates.size} giorno/i della ripetizione. Primo trovato: ${first.date.format(fmt)} alle ${first.time}. Vuoi comunque crearli?" else "$cleanName ha già un appuntamento il ${first.date.format(fmt)} alle ${first.time}. Vuoi comunque creare un altro appuntamento oggi?").setNegativeButton("ANNULLA",null).setPositiveButton("CREA COMUNQUE"){_,_->createAppointments(cleanName,dateText,timeText,type,repeat,checks,endText,recovery,true,dayTimes)}.show()
                    return
                }
                if(linked!=null){
                    val remaining=linked.totalSessions-sessionUsed(linked)
                    val potential=if(!repeat)1 else run {
                        val end=runCatching{parseDate(endText)}.getOrNull()?:start
                        val selected=checks.mapIndexedNotNull{idx,c->if(c.isChecked)idx+1 else null}.toSet()
                        var d=start;var count=0
                        while(!d.isAfter(end)){
                            if(selected.contains(d.dayOfWeek.value)){
                                val dayTime=dayTimes?.get(d.dayOfWeek.value-1)?.let{normalizeTime(it)} ?: time
                                if(canAdd(d,dayTime,type))count++
                            }
                            d=d.plusDays(1)
                        }
                        count
                    }
                    if(remaining>0&&potential>=remaining){
                        AlertDialog.Builder(this).setTitle("⚠️ Ultima seduta del pacchetto").setMessage("Questa prenotazione utilizzerà l'ultima seduta disponibile di $cleanName. Dopo questa prenotazione il pacchetto risulterà scaduto. Vuoi continuare?").setNegativeButton("ANNULLA",null).setPositiveButton("CONTINUA"){_,_->createAppointments(cleanName,dateText,timeText,type,repeat,checks,endText,recovery,true,dayTimes)}.show()
                        return
                    }
                }
            }
            if(!repeat){
                if(!canAdd(start,time,type))throw IllegalArgumentException("Fascia piena")
                if(linked!=null&&sessionUsed(linked)>=linked.totalSessions)throw IllegalArgumentException("Pacchetto sedute pieno")
                appointments.add(Appointment(nextAppointmentId++,cleanName,start,time,type,0L,linked?.id?:0L,recovery));saveData();calendarScreen();return
            }
            val end=parseDate(endText);require(!end.isBefore(start));val selected=checks.mapIndexedNotNull{idx,c->if(c.isChecked)idx+1 else null};require(selected.isNotEmpty())
            val series=nextAppointmentId;var d=start;var count=0;var sessionAdded=0
            while(!d.isAfter(end)){
                if(selected.contains(d.dayOfWeek.value)){
                    val dayTime=dayTimes?.get(d.dayOfWeek.value-1)?.let{normalizeTime(it)} ?: time
                    if(linked!=null&&sessionUsed(linked)+sessionAdded>=linked.totalSessions){count++;d=d.plusDays(1);continue}
                    if(canAdd(d,dayTime,type)){appointments.add(Appointment(nextAppointmentId++,cleanName,d,dayTime,type,series,linked?.id?:0L,recovery));sessionAdded++}else count++
                }
                d=d.plusDays(1)
            }
            saveData();calendarScreen();if(count>0)Toast.makeText(this,"$count ripetizioni non inserite perché la fascia o il pacchetto sedute non erano disponibili.",Toast.LENGTH_LONG).show()
        }catch(e:Exception){Toast.makeText(this,if(e.message=="Fascia piena")"Fascia non disponibile: massimo 3 persone e massimo 2 allenamenti." else "Controlla cliente, data, ora e ripetizione.",Toast.LENGTH_LONG).show()}
    }

    private fun normalizeTime(value:String):String{val clean=value.trim();val parts=clean.split(":");require(parts.size==2);val h=parts[0].toInt();val m=parts[1].toInt();require(h in 7..21&&m in 0..59);require((h*60+m-7*60)%45==0);return String.format("%02d:%02d",h,m)}
    private fun updateAppointment(a:Appointment,name:String,dateText:String,timeText:String,type:String){
        try{
            val cleanName=normalizeDisplayName(name);require(cleanName.isNotEmpty());val date=parseDate(dateText);val time=normalizeTime(timeText)
            val duplicate=appointments.firstOrNull{it!==a&&it.date==date&&identityKey(it.name)==identityKey(cleanName)}
            if(duplicate!=null){
                AlertDialog.Builder(this).setTitle("⚠️ Appuntamento già presente").setMessage("$cleanName ha già un appuntamento il ${date.format(fmt)} alle ${duplicate.time}. Vuoi comunque spostare/modificare questo appuntamento?").setNegativeButton("ANNULLA",null).setPositiveButton("CONTINUA"){_,_->updateAppointmentConfirmed(a,cleanName,date,time,type)}.show();return
            }
            updateAppointmentConfirmed(a,cleanName,date,time,type)
        }catch(_:Exception){Toast.makeText(this,"Controlla i dati dell'appuntamento.",Toast.LENGTH_LONG).show()}
    }

    private fun updateAppointmentConfirmed(a:Appointment,name:String,date:LocalDate,time:String,type:String){
        if(!canAdd(date,time,type,a)){Toast.makeText(this,"Questa fascia non è disponibile.",Toast.LENGTH_LONG).show();return}
        var linked=if(a.sessionPackId!=0L)sessionPacks.firstOrNull{it.id==a.sessionPackId} else null
        if(linked==null)linked=activeSessionPackFor(name)
        if(linked!=null&&a.sessionPackId!=linked.id){
            val usedWithoutThis=sessionUsed(linked)
            if(usedWithoutThis>=linked.totalSessions){Toast.makeText(this,"Il pacchetto sedute è già completo.",Toast.LENGTH_LONG).show();return}
            a.sessionPackId=linked.id
        }
        a.name=name;a.date=date;a.time=time;a.type=type;saveData();calendarScreen()
    }

    private fun appointmentDialogForSlot(day:LocalDate,time:String){appointmentDialog(null,day,time)}

    private fun availableTimeSlots(date:LocalDate,type:String,ignore:Appointment?=null):List<String>{
        return (0 until 20).map{slot->
            val mins=7*60+slot*45
            String.format("%02d:%02d",mins/60,mins%60)
        }.filter{slot->canAdd(date,slot,type,ignore)}
    }

    private fun canAdd(date:LocalDate,time:String,type:String,ignore:Appointment?=null):Boolean{
        val r=calendarRoutines.getOrNull(activeRoutineIndex)?:CalendarRoutine("Standard",3,MutableList(appointmentTypes.size){3})
        val items=appointments.filter{it.date==date&&it.time==time&&it!==ignore}
        if(items.size>=r.maxTotal)return false
        val idx=typeIndex(type);if(items.count{typeIndex(it.type)==idx}>=(r.maxByType.getOrNull(idx)?:r.maxTotal))return false
        return true
    }

}
