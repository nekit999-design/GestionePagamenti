package com.example.gestionescadenze

import android.app.*
import android.content.Intent
import android.content.Context
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Color
import android.graphics.RectF
import android.graphics.LinearGradient
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Path
import android.net.Uri
import android.provider.MediaStore
import android.content.ContentValues
import android.provider.Settings
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.animation.ValueAnimator
import android.graphics.Paint
import android.graphics.Canvas
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import android.text.Editable
import android.text.TextWatcher
import java.io.BufferedReader
import java.io.InputStreamReader
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters
import kotlin.math.roundToInt

data class Pack(var name: String, val start: LocalDate, val total: Int, var paid: Int = 0, var customRates: MutableList<Int>? = null, var packageType: String = "PERSONALIZZATO", var sessionTotal: Int = 12, var active: Boolean = true, var missedSessions: Int = 0, var weeklyWeeks: Int = 12, var weeklyQuantities: MutableMap<String,Int> = mutableMapOf(), var includedAppointmentType: String? = null, var clientId:Long = 0L)
data class SessionPack(
    val id: Long,
    var name: String,
    val start: LocalDate,
    val totalSessions: Int,
    val cost: Int,
    var paid: Int = 0,
    var active: Boolean = true,
    var customRates: MutableList<Int>? = null,
    var customQuantities: MutableMap<String,Int> = mutableMapOf(),
    var clientId:Long = 0L
)
data class TrashItem(val id:Long, val kind:String, val deletedAt:LocalDateTime, val payload:String)
data class AppointmentType(var id:String, var name:String, var color:Int)
data class CalendarRoutine(var name:String, var maxTotal:Int, var maxByType:MutableList<Int>)
data class ClosurePeriod(var start: LocalDate, var end: LocalDate)
data class FreeEvent(val id: Long, var title: String, var date: LocalDate, var startTime: String, var endTime: String, var color: Int = Color.rgb(92,120,190))
data class ClientProfile(var id:Long,var firstName:String,var lastName:String,var birthDate:String,var taxCode:String,var phone:String,var email:String,var address:String,var city:String,var emergencyName:String,var emergencyRelation:String,var emergencyPhone:String,var sports:String,var pain:String,var injuries:String,var backNeck:String,var joints:String,var surgery:String,var medicalConditions:String,var medications:String,var other:String,var signedAt:String="")

data class Appointment(
    val id: Long,
    var name: String,
    var date: LocalDate,
    var time: String,
    var type: String,
    var seriesId: Long = 0L,
    var sessionPackId: Long = 0L,
    var recovery: Boolean = false
) {
}

class MainActivity : Activity() {
    private val fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy")
    private val timeFmt = DateTimeFormatter.ofPattern("HH:mm")
    private val packs = mutableListOf<Pack>()
    private val sessionPacks = mutableListOf<SessionPack>()
    private val appointments = mutableListOf<Appointment>()
    private val freeEvents = mutableListOf<FreeEvent>()
    private val clients = mutableListOf<ClientProfile>()
    private var nextClientId = 1L
    private val trashItems = mutableListOf<TrashItem>()
    // Chiusure dello studio: la prima conserva la compatibilità con i dati precedenti;
    // il motore usa sempre la lista completa dei periodi.
    private var closurePeriods = mutableListOf<ClosurePeriod>()
    private var ferieStart: LocalDate? = null
    private var ferieEnd: LocalDate? = null
    private lateinit var list: LinearLayout
    private var dashboardEnabled = false
    private var homeSortMode = 0
    private lateinit var searchInput: EditText
    private lateinit var searchList: LinearLayout
    private var calendarWeekStart: LocalDate = LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    private var nextAppointmentId = 1L
    private var nextFreeEventId = 1L
    private var nextSessionPackId = 1L
    // Silenzia temporaneamente solo l'avviso del vecchio pacchetto a sedute
    // (SessionPack senza tipologie personalizzate). Non viene salvato nel backup.
    private val sessionPackWarningSuppressedUntil = mutableMapOf<Long,Long>()
    private var nextTrashId = 1L
    private var calendarZoom = 1.0f
    private var calendarVisibleDays = booleanArrayOf(true,true,true,true,true,false,false)
    private var calendarAutoFocusOnOpen = true
    private var calendarScrollX = 0
    private var calendarScrollY = 0
    // Riferimenti al calendario già montato: gli eventi liberi vengono aggiornati
    // in-place quando possibile, senza ricostruire l'intera pagina sotto al dialog.
    private var calendarHeaderWeekView: LinearLayout? = null
    private var calendarBodyWeekView: LinearLayout? = null
    private var calendarHeaderScrollView: HorizontalScrollView? = null
    private var calendarBodyScrollView: HorizontalScrollView? = null
    private var calendarVerticalScrollView: ScrollView? = null
    // Stato del viewport da ripristinare quando l'editor Evento libero si chiude.
    // Serve a evitare che la ricomposizione del calendario cambi la coppia di giorni
    // visibile o faccia percepire uno spostamento del contenuto.
    private var freeEventReturnScrollX: Int? = null
    private var freeEventReturnScrollY: Int? = null
    private var freeEventReturnWeekStart: LocalDate? = null
    private var freeEventReturnExpansionDay: LocalDate? = null
    private var calendarSwipeArmed = 0
    private var calendarWeekAnimationDirection = 0
    // Micro-interazione Evento libero: la giornata selezionata si espande lateralmente
    // e porta con sé intestazione + slot, lasciando una piccola colonna di respiro tra i giorni.
    private var calendarEventExpansionDay: LocalDate? = null
    private var calendarEventExpansionAnimate = false
    private var calendarEventCollapseAnimate = false
    private var calendarEventRemovalId: Long? = null
    private var calendarEventRemovalSnapshot: FreeEvent? = null
    // Giorno da cui parte la transizione: il giorno stesso resta ancorato,
    // si muovono solo le giornate successive. Vale sia in creazione sia in eliminazione.
    private var calendarEventAnimationDay: LocalDate? = null
    private val calendarEventExpansionDp = 92
    private val calendarEventExpansionGapDp = 8
    // Evento libero: colore selezionabile e colore predefinito persistente.
    private var freeEventDefaultColor = Color.rgb(92,120,190)
    private var freeEventTimeStep = 15
    private var calendarNavPosition = 1 // legacy: 0 = sotto il titolo, 1 = in basso
    private var calendarNavOrder = mutableListOf("PREV", "SEARCH", "TODAY", "NEXT") // legacy
    private var calendarTopButtons = mutableListOf("APPT")
    private var calendarBottomButtons = mutableListOf("SEARCH", "TODAY", "PREV", "NEXT")
    private val appointmentTypes = mutableListOf(
        AppointmentType("TYPE1","ALLENAMENTO",Color.rgb(45,135,210)),
        AppointmentType("TYPE2","MEZZ'ORA",Color.rgb(215,55,55))
    )
    private val calendarRoutines = mutableListOf(
        CalendarRoutine("Standard",3,mutableListOf(2,3)),
        CalendarRoutine("Light",2,mutableListOf(1,2)),
        CalendarRoutine("Full",4,mutableListOf(3,4))
    )
    private var activeRoutineIndex = 0
    private var surnameFirstDisplay = true
    private var pendingSummaryText = ""
    private val expandedClients = mutableSetOf<String>()
    private var activePackageDialog: AlertDialog? = null
    private var settingsTransitionPending = false
    private var settingsOverlay: FrameLayout? = null
    private var settingsOverlayContent: View? = null
    private var settingsSubpageOverlay: FrameLayout? = null
    private var clientOverlay: FrameLayout? = null
    private var clientQuestionnaireOverlay: FrameLayout? = null
    private var trashReturnToSettings = false
    // Effetti visivi popup.
    // effect: NONE, SATIN, VETRO_SOFT, LIQUID; mode: CONTOUR (finestra nitida) o IMMERSIVE.
    private var popupBackdropEffect = "NONE"
    private var popupBackdropMode = "CONTOUR"
    private var popupBackdropIntensity = 65
    // Stile degli slot grandi del calendario: 10 = Liquid Glass attuale (predefinito).
    private var largeSlotStyle = 10
    // 10 stili indipendenti per gli slot appuntamento: 10 = Liquid Glass attuale (predefinito).
    private var appointmentSlotStyle = 10
    // CoachFlow 2.0: durata configurabile della griglia del calendario.
    private var calendarSlotDuration = 45
    private var popupBackdropOverlay: View? = null
    private var popupBackdropTarget: View? = null
    private var popupBackdropCurrentDialog: Dialog? = null
    private val popupBackdropDialogs = mutableListOf<Dialog>()
    private var popupDialogGlassOverlay: View? = null
    private val popupDialogOriginalBackgrounds = mutableMapOf<View, Drawable?>()
    private val popupDialogOriginalWindowBackgrounds = mutableMapOf<Dialog, Drawable?>()
    private var currentScreen = "HOME"
    // Il gesto Android "Indietro" non deve chiudere CoachFlow al primo tentativo.
    // Le finestre Dialog gestiscono autonomamente il loro Back; qui gestiamo
    // soltanto le pagine della Activity e le schede sovrapposte.
    private var lastHomeBackAt = 0L
    private var paymentsOverlay: View? = null
    private var questionnaireHasUnsavedChanges: (() -> Boolean)? = null
    // Al rientro dall'altra app ricostruiamo solo il calendario se era la schermata attiva.
    // Serve a ridisegnare le superfici Liquid Glass senza toccare dati o logica degli appuntamenti.
    private var calendarNeedsResumeRefresh = false

    private inner class CalendarHorizontalScrollView(context: Context) : HorizontalScrollView(context) {
        var onEdgeWeekChange: ((Int) -> Unit)? = null
        private var downX = 0f
        private var lastX = 0f
        private var edgeOverscroll = 0f
        private var edgeDirection = 0
        private var transitionSent = false
        private var edgeGesture = false
        private var touchChild: View? = null
        // Soglia ridotta: il cambio settimana deve scattare con uno swipe breve,
        // così non è necessario arrivare vicino al bordo fisico dello schermo.
        private val weekSwipeTriggerDp = 36

        private fun edgeState(): Int {
            val maxX = (getChildAt(0)?.width?.minus(width) ?: 0).coerceAtLeast(0)
            return when {
                scrollX <= dp(2) -> -1   // left edge: right swipe = previous week
                scrollX >= maxX - dp(2) -> 1 // right edge: left swipe = next week
                else -> 0
            }
        }

        private fun resetEdgeStretch(animate: Boolean) {
            val child = touchChild ?: getChildAt(0)
            if (animate) child?.animate()?.translationX(0f)?.setDuration(140)?.start()
            else child?.translationX = 0f
            edgeOverscroll = 0f
            edgeDirection = 0
            edgeGesture = false
        }

        override fun onInterceptTouchEvent(event: android.view.MotionEvent): Boolean {
            when (event.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    downX = event.x
                    lastX = event.x
                    edgeGesture = false
                    transitionSent = false
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    val dx = event.x - downX
                    val slop = android.view.ViewConfiguration.get(context).scaledTouchSlop
                    if (!edgeGesture && kotlin.math.abs(dx) > slop) {
                        val edge = edgeState()
                        val outward = (edge == -1 && dx > 0f) || (edge == 1 && dx < 0f)
                        if (outward) {
                            // Take ownership of the gesture as soon as an outward
                            // drag starts at an edge. This prevents child views from
                            // swallowing the gesture and makes the gesture work from
                            // the whole calendar surface, not only near the screen edge.
                            edgeGesture = true
                            lastX = event.x
                            touchChild = getChildAt(0)
                            touchChild?.animate()?.cancel()
                            touchChild?.translationX = 0f
                            return true
                        }
                    }
                }
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                    edgeGesture = false
                }
            }
            return if (edgeGesture) true else super.onInterceptTouchEvent(event)
        }

        override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
            val child = getChildAt(0)
            when (event.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    downX = event.x
                    lastX = event.x
                    edgeOverscroll = 0f
                    edgeDirection = 0
                    transitionSent = false
                    edgeGesture = false
                    touchChild = child
                    child?.animate()?.cancel()
                    child?.translationX = 0f
                }

                android.view.MotionEvent.ACTION_MOVE -> {
                    val dx = event.x - lastX
                    val edge = edgeState()

                    if (edgeGesture) {
                        val outward = (edge == -1 && dx > 0f) || (edge == 1 && dx < 0f)
                        if (outward && !transitionSent) {
                            val sign = if (dx > 0f) 1 else -1
                            if (edgeDirection == 0 || edgeDirection == sign) {
                                edgeDirection = sign
                                edgeOverscroll += kotlin.math.abs(dx)
                            } else {
                                edgeOverscroll = 0f
                                edgeDirection = sign
                            }

                            val resistance = 0.32f
                            val stretch = (edgeOverscroll * resistance).coerceAtMost(dp(54).toFloat())
                            child?.translationX = if (edge == -1) stretch else -stretch

                            if (edgeOverscroll >= dp(weekSwipeTriggerDp)) {
                                transitionSent = true
                                child?.animate()?.translationX(0f)?.setDuration(90)?.start()
                                // Physical direction is authoritative:
                                // right swipe at left edge -> previous week (-1)
                                // left swipe at right edge -> next week (+1)
                                onEdgeWeekChange?.invoke(if (edge == -1) -1 else 1)
                                edgeOverscroll = 0f
                                edgeDirection = 0
                            }
                        } else if (!transitionSent) {
                            edgeOverscroll = (edgeOverscroll - kotlin.math.abs(dx) * 1.5f).coerceAtLeast(0f)
                            val resistance = 0.32f
                            val stretch = (edgeOverscroll * resistance).coerceAtMost(dp(54).toFloat())
                            child?.translationX = if (edge == -1) stretch else -stretch
                        }
                        lastX = event.x
                        return true
                    }

                    lastX = event.x
                }

                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                    if (edgeGesture) {
                        if (!transitionSent) resetEdgeStretch(true) else resetEdgeStretch(false)
                        transitionSent = false
                        touchChild = null
                        return true
                    }
                }
            }
            return super.onTouchEvent(event)
        }
    }

    companion object {
        private const val REQ_EXPORT = 1001
        private const val REQ_IMPORT = 1002
        private const val REQ_SUMMARY = 1003
        // Versione approvata visualizzata nell'app: cambia solo quando una copia supera i test.
        private const val APPROVED_VERSION_LABEL = "2.8 Beta"
        private const val APPROVED_VERSION_STATUS = "IN PROVA"
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        // CoachFlow usa una superficie edge-to-edge: lo sfondo dell'app continua
        // dietro status bar e barra di navigazione, mentre i contenuti ricevono
        // gli inset necessari per non finire sotto le barre di sistema.
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (android.os.Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(false)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        loadData()
        purgeExpiredTrash()
        saveData()
        maybeAutoBackup()
        build()
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            onBackInvokedDispatcher.registerOnBackInvokedCallback(
                android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                android.window.OnBackInvokedCallback { handleCoachFlowBack() }
            )
        }
        intent?.let { incoming -> window.decorView.postDelayed({ handleClientModuleIntent(incoming) }, 250L) }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) { setIntent(intent); window.decorView.postDelayed({ handleClientModuleIntent(intent) }, 150L) }
    }

    override fun onPause() {
        if (currentScreen == "CALENDAR") calendarNeedsResumeRefresh = true
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (calendarNeedsResumeRefresh) {
            calendarNeedsResumeRefresh = false
            window.decorView.postDelayed({
                if (!isFinishing && currentScreen == "CALENDAR" && popupBackdropCurrentDialog == null) {
                    // Manteniamo settimana e viewport correnti: calendarScreen() usa
                    // calendarScrollX/calendarScrollY già salvati e ricrea soltanto la UI.
                    calendarScreen()
                }
            }, 90L)
        }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        handleCoachFlowBack()
    }

    private fun dismissQuestionnaireOverlay() {
        clientQuestionnaireOverlay?.let { (it.parent as? ViewGroup)?.removeView(it) }
        clientQuestionnaireOverlay = null
        questionnaireHasUnsavedChanges = null
    }

    private fun closeQuestionnaireSafely() {
        if (questionnaireHasUnsavedChanges?.invoke() == true) {
            AlertDialog.Builder(this)
                .setTitle("Modifiche non salvate")
                .setMessage("Vuoi uscire dalla scheda cliente senza salvare le modifiche?")
                .setNegativeButton("CONTINUA", null)
                .setPositiveButton("ESCI SENZA SALVARE") { _, _ -> dismissQuestionnaireOverlay() }
                .create().also { styleOneUiDialog(it); it.show() }
        } else dismissQuestionnaireOverlay()
    }

    /** Impronta dei controlli modificabili; non include etichette o testo statico. */
    private fun formDraftFingerprint(view: View): String = buildString {
        fun visit(v: View) {
            when (v) {
                is EditText -> { append("E:"); append(v.text.toString().length); append(':'); append(v.text); append(';') }
                is CompoundButton -> { append("C:"); append(v.isChecked); append(';') }
                is Spinner -> { append("S:"); append(v.selectedItemPosition); append(';') }
            }
            if (v is ViewGroup) for (i in 0 until v.childCount) visit(v.getChildAt(i))
        }
        visit(view)
    }

    private fun confirmDiscardDraft(dialog: Dialog, initial: String, content: View, afterDiscard: () -> Unit = { dialog.dismiss() }) {
        if (formDraftFingerprint(content) == initial) {
            afterDiscard()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Modifiche non salvate")
            .setMessage("Vuoi uscire senza salvare i dati che hai inserito?")
            .setNegativeButton("CONTINUA", null)
            .setPositiveButton("ESCI SENZA SALVARE") { _, _ -> afterDiscard() }
            .create().also { styleOneUiDialog(it); it.show() }
    }

    private fun protectDraftBack(dialog: Dialog, initial: String, content: View, afterDiscard: () -> Unit = { dialog.dismiss() }) {
        dialog.setOnKeyListener { _, code, event ->
            if (code == android.view.KeyEvent.KEYCODE_BACK) {
                if (event.action == android.view.KeyEvent.ACTION_UP) confirmDiscardDraft(dialog, initial, content, afterDiscard)
                true
            } else false
        }
        // Android 13+: lo swipe Indietro non viene inviato come KEYCODE_BACK.
        // Registriamo il callback sulla Window del dialogo (non sull'Activity),
        // e lo rimuoviamo con la Window per non intercettare schermate successive.
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            val decor = dialog.window?.decorView
            if (decor != null) {
                val callback = android.window.OnBackInvokedCallback {
                    confirmDiscardDraft(dialog, initial, content, afterDiscard)
                }
                val listener = object : View.OnAttachStateChangeListener {
                    private var dispatcher: android.window.OnBackInvokedDispatcher? = null
                    override fun onViewAttachedToWindow(v: View) {
                        if (dispatcher == null) {
                            dialog.onBackInvokedDispatcher.also {
                                it.registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_OVERLAY, callback)
                                dispatcher = it
                            }
                        }
                    }
                    override fun onViewDetachedFromWindow(v: View) {
                        dispatcher?.unregisterOnBackInvokedCallback(callback)
                        dispatcher = null
                        v.removeOnAttachStateChangeListener(this)
                    }
                }
                decor.addOnAttachStateChangeListener(listener)
                if (decor.isAttachedToWindow) listener.onViewAttachedToWindow(decor)
            }
        }
    }

    private fun handleCoachFlowBack() {
        if (clientQuestionnaireOverlay != null) {
            closeQuestionnaireSafely()
            return
        }
        if (clientOverlay != null) {
            clientOverlay?.let{(it.parent as? ViewGroup)?.removeView(it)};clientOverlay=null
            return
        }
        if (paymentsOverlay != null) {
            paymentsOverlay?.let { (it.parent as? ViewGroup)?.removeView(it) }
            paymentsOverlay = null
            return
        }
        if (settingsSubpageOverlay != null) {
            closeSettingsSubpage()
            return
        }
        if (trashReturnToSettings) {
            trashReturnToSettings = false
            settings()
            return
        }
        if (settingsOverlay != null) {
            settingsOverlay?.animate()?.cancel()
            settingsOverlayContent?.animate()?.cancel()
            detachSettingsOverlay()
            restoreHomeSystemBars()
            build()
            return
        }
        if (currentScreen == "CALENDAR") {
            build()
            return
        }
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastHomeBackAt <= 2000L) {
            finish()
        } else {
            lastHomeBackAt = now
            Toast.makeText(this, "Scorri di nuovo per uscire", Toast.LENGTH_SHORT).show()
        }
    }

    private fun prepareEdgeToEdgeRoot(root: View) {
        val baseLeft = root.paddingLeft
        val baseTop = root.paddingTop
        val baseRight = root.paddingRight
        val baseBottom = root.paddingBottom
        root.setOnApplyWindowInsetsListener { v, insets ->
            val bars = if (android.os.Build.VERSION.SDK_INT >= 30) {
                insets.getInsets(android.view.WindowInsets.Type.systemBars())
            } else {
                android.graphics.Insets.of(
                    insets.systemWindowInsetLeft,
                    insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight,
                    insets.systemWindowInsetBottom
                )
            }
            v.setPadding(baseLeft, baseTop + bars.top, baseRight, baseBottom + bars.bottom)
            insets
        }
        root.requestApplyInsets()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    /**
     * Ruota oraria con vero effetto "lente": il valore centrale viene
     * ingrandito e quelli vicini si deformano gradualmente, senza disegnare
     * una fascia/pill sopra il picker. L'overlay precedente è stato rimosso
     * perché duplicava il testo del NumberPicker.
     */
    private class FreeEventTimeLens(
        context: Context,
        private val values: List<String>,
        initialIndex: Int
    ) : View(context) {
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
            isSubpixelText = true
        }
        private val glassPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var selectedIndex = initialIndex.coerceIn(0, (values.size - 1).coerceAtLeast(0))
        private var dragOffset = 0f
        private var lastY = 0f
        private var touchStartY = 0f
        private var touchStartScrollPos = 0f
        private var dragging = false
        private var snapAnimator: ValueAnimator? = null
        private val rowHeight get() = dpLocal(45f)

        init {
            isClickable = true
            isFocusable = true
            setWillNotDraw(false)
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            if (values.isEmpty()) return
            val w = width.toFloat()
            val h = height.toFloat()
            val cx = w / 2f
            val cy = h / 2f

            // Riflesso ottico quasi invisibile: non è una fascia, serve solo
            // a dare profondità alla zona della lente.
            glassPaint.shader = RadialGradient(
                cx, cy, w * 0.48f,
                intArrayOf(
                    Color.argb(10, 255, 255, 255),
                    Color.argb(4, 225, 242, 255),
                    Color.argb(0, 220, 240, 255)
                ),
                floatArrayOf(0f, 0.58f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawRect(0f, cy - rowHeight * 1.05f, w, cy + rowHeight * 1.05f, glassPaint)
            glassPaint.shader = null

            // Disegno non lineare: è questo che crea la lente ottica.
            for (offset in -3..3) {
                val logical = selectedIndex + offset
                if (logical !in values.indices) continue
                val y = cy + offset * rowHeight + dragOffset
                val distance = kotlin.math.abs(y - cy) / rowHeight
                if (distance > 3.05f) continue

                val focus = kotlin.math.exp(-distance * 1.35f).toFloat()
                val scale = 1f + 0.20f * focus
                val alpha = (90f + 165f * focus).roundToInt().coerceIn(0, 255)
                textPaint.alpha = alpha
                textPaint.color = Color.rgb(32, 36, 42)
                textPaint.textSize = dpLocal(21f) * scale
                val fm = textPaint.fontMetrics
                val baseline = y - (fm.ascent + fm.descent) / 2f
                canvas.drawText(values[logical], cx, baseline, textPaint)
            }
            textPaint.alpha = 255
        }

        override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
            when (event.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    snapAnimator?.cancel()
                    lastY = event.y
                    touchStartY = event.y
                    dragging = true
                    return true
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    val dy = event.y - lastY
                    lastY = event.y
                    dragOffset += dy
                    while (dragOffset <= -rowHeight && selectedIndex < values.lastIndex) {
                        dragOffset += rowHeight
                        selectedIndex++
                    }
                    while (dragOffset >= rowHeight && selectedIndex > 0) {
                        dragOffset -= rowHeight
                        selectedIndex--
                    }
                    invalidate()
                    return true
                }
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                    dragging = false
                    snapToNearest()
                    return true
                }
            }
            return true
        }

        private fun snapToNearest() {
            val target = when {
                dragOffset < -rowHeight * 0.35f && selectedIndex < values.lastIndex -> selectedIndex + 1
                dragOffset > rowHeight * 0.35f && selectedIndex > 0 -> selectedIndex - 1
                else -> selectedIndex
            }
            val startOffset = dragOffset
            val targetOffset = when {
                target > selectedIndex -> startOffset + rowHeight
                target < selectedIndex -> startOffset - rowHeight
                else -> 0f
            }
            snapAnimator = ValueAnimator.ofFloat(startOffset, targetOffset).apply {
                duration = 150L
                addUpdateListener {
                    dragOffset = it.animatedValue as Float
                    invalidate()
                }
                addListener(object : android.animation.AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: android.animation.Animator) {
                        if (target != selectedIndex) selectedIndex = target
                        dragOffset = 0f
                        invalidate()
                    }
                })
                start()
            }
        }

        fun currentValue(): String = values[selectedIndex]
        fun currentIndex(): Int = selectedIndex
        private fun dpLocal(v: Float): Float = v * resources.displayMetrics.density
    }

    private fun dpf(value: Float): Float = value * resources.displayMetrics.density

    /**
     * Crea un vero livello "vetro" dietro la finestra popup.
     * La finestra/dialog rimane una Window separata e quindi resta perfettamente nitida.
     * Su Android 12+ il contenuto dell'Activity viene sfocato con RenderEffect;
     * sotto Android 12 manteniamo il fallback al solo dim nativo.
     */
    private fun popupBlurRadiusDp(): Int {
        val intensity = popupBackdropIntensity.coerceIn(0, 100) / 100f
        val base = when (popupBackdropEffect) {
            // Resa precedente, mantenuta invariata: ora si chiama Satinato.
            "SATIN" -> 24
            // Resa dell'attuale Liquid Glass, conservata e rinominata Vetro Soft.
            "VETRO_SOFT" -> 10
            // Nuovo Liquid Glass ultra-trasparente: vetro leggero, poca distorsione e massima leggibilità del fondo.
            "LIQUID" -> 4
            else -> 0
        }
        return (base * intensity).roundToInt().coerceIn(0, base)
    }

    private fun savePopupVisualPreferences() {
        getSharedPreferences("gestione_pagamenti", MODE_PRIVATE).edit()
            .putString("popupBackdropEffect", popupBackdropEffect)
            .putString("popupBackdropMode", popupBackdropMode)
            .putInt("popupBackdropIntensity", popupBackdropIntensity)
            .apply()
    }

    /** Applica la trasparenza immersiva alle superfici bianche interne, comprese quelle
     * contenute dentro ScrollView/NestedScrollView. I controlli interattivi restano invariati. */
    private fun applyImmersiveSurfaces(view: View) {
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) applyImmersiveSurfaces(view.getChildAt(i))
        }
        if (view is Button || view is EditText || view is Spinner || view is SeekBar ||
            view is RadioButton || view is CheckBox || view is AutoCompleteTextView) return
        val bg = view.background ?: return
        if (bg is android.graphics.drawable.GradientDrawable) {
            val c = bg.color?.defaultColor
            if (c != null && android.graphics.Color.red(c) >= 235 &&
                android.graphics.Color.green(c) >= 235 && android.graphics.Color.blue(c) >= 235) {
                // Solo la superficie: niente modifica ai bordi o ai colori dei controlli.
                bg.alpha = 150
            }
        } else if (bg is android.graphics.drawable.ColorDrawable) {
            val c = bg.color
            if (android.graphics.Color.red(c) >= 235 && android.graphics.Color.green(c) >= 235 &&
                android.graphics.Color.blue(c) >= 235) {
                bg.alpha = 150
            }
        }
    }

    private fun applyPopupBackdropEffect(currentDialog: Dialog? = popupBackdropCurrentDialog) {
        if (currentDialog != null && !popupBackdropDialogs.contains(currentDialog)) popupBackdropDialogs.add(currentDialog)
        popupBackdropCurrentDialog = currentDialog ?: popupBackdropDialogs.lastOrNull()
        val activeDialog = popupBackdropCurrentDialog
        if (popupBackdropEffect == "NONE") { clearPopupBackdropEffect(); return }

        val stackIndex = activeDialog?.let { popupBackdropDialogs.indexOf(it) } ?: -1
        val underlyingDialog = if (stackIndex > 0) popupBackdropDialogs[stackIndex - 1] else null
        val underlyingDecor = underlyingDialog?.window?.decorView as? ViewGroup
        val root: ViewGroup = underlyingDecor?.findViewById<ViewGroup>(android.R.id.content)
            ?: underlyingDecor
            ?: findViewById<ViewGroup>(android.R.id.content)
            ?: return

        clearPopupBackdropEffect()
        val target: View = root.getChildAt(0) ?: root
        popupBackdropTarget = target
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            val radius = popupBlurRadiusDp()
            if (radius > 0) target.setRenderEffect(android.graphics.RenderEffect.createBlurEffect(dp(radius).toFloat(), dp(radius).toFloat(), android.graphics.Shader.TileMode.CLAMP))
        }

        val intensity = popupBackdropIntensity.coerceIn(0,100) / 100f
        val satin = popupBackdropEffect == "SATIN"
        val softGlass = popupBackdropEffect == "VETRO_SOFT"
        val liquid = popupBackdropEffect == "LIQUID"
        val alpha = when {
            satin -> (52 * intensity).roundToInt().coerceIn(0,70)
            softGlass -> (28 * intensity).roundToInt().coerceIn(0,48)
            liquid -> (7 * intensity).roundToInt().coerceIn(0,16)
            else -> 0
        }
        val overlay = View(this).apply {
            background = when {
                satin -> android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(alpha,248,251,255))
                softGlass -> {
                    val softA = alpha.coerceAtLeast(8)
                    android.graphics.drawable.GradientDrawable(
                        android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                        intArrayOf(
                            android.graphics.Color.argb(softA + 8, 190, 222, 255),
                            android.graphics.Color.argb(softA, 235, 247, 255),
                            android.graphics.Color.argb((softA * 0.45f).roundToInt(), 255, 255, 255)
                        )
                    )
                }
                liquid -> android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                    intArrayOf(
                        android.graphics.Color.argb(alpha + 4, 150, 205, 255),
                        android.graphics.Color.argb(alpha + 2, 230, 244, 255),
                        android.graphics.Color.argb((alpha * 0.12f).roundToInt(), 255, 255, 255),
                        android.graphics.Color.argb(alpha + 2, 190, 225, 255)
                    )
                )
                else -> null
            }
            isClickable=false; isFocusable=false
        }
        root.addView(overlay, 0, ViewGroup.LayoutParams(-1,-1))
        popupBackdropOverlay = overlay

        // Immersivo: la finestra stessa diventa una superficie vetro traslucida.
        // Il contenuto resta nitido, ma lo sfondo della popup lascia filtrare
        // il livello sottostante: in questo modo la differenza con Contorno è reale.
        if (popupBackdropMode == "IMMERSIVE" && activeDialog?.window != null) {
            val window = activeDialog.window!!
            val content = window.findViewById<ViewGroup>(android.R.id.content)
            val panel = content?.getChildAt(0)
            if (panel != null) {
                if (!popupDialogOriginalBackgrounds.containsKey(panel)) {
                    popupDialogOriginalBackgrounds[panel] = panel.background?.constantState?.newDrawable()?.mutate() ?: panel.background
                }
                if (!popupDialogOriginalWindowBackgrounds.containsKey(activeDialog)) {
                    popupDialogOriginalWindowBackgrounds[activeDialog] = window.decorView.background?.constantState?.newDrawable()?.mutate() ?: window.decorView.background
                }
                val glass = android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                    when {
                        liquid -> intArrayOf(
                            android.graphics.Color.argb((92 + 62 * intensity).roundToInt().coerceIn(92,154), 178, 218, 250),
                            android.graphics.Color.argb((72 + 52 * intensity).roundToInt().coerceIn(72,124), 245, 250, 255),
                            android.graphics.Color.argb((86 + 58 * intensity).roundToInt().coerceIn(86,144), 188, 225, 250)
                        )
                        softGlass -> intArrayOf(
                            android.graphics.Color.argb((150 + 55 * intensity).roundToInt().coerceIn(150,205), 222, 239, 253),
                            android.graphics.Color.argb((132 + 48 * intensity).roundToInt().coerceIn(132,180), 252, 253, 255),
                            android.graphics.Color.argb((145 + 52 * intensity).roundToInt().coerceIn(145,197), 218, 235, 251)
                        )
                        else -> intArrayOf(
                            android.graphics.Color.argb((178 + 45 * intensity).roundToInt().coerceIn(178,223), 238, 245, 252),
                            android.graphics.Color.argb((160 + 42 * intensity).roundToInt().coerceIn(160,202), 255, 255, 255),
                            android.graphics.Color.argb((174 + 44 * intensity).roundToInt().coerceIn(174,218), 230, 240, 250)
                        )
                    }
                )
                glass.cornerRadius = dp(28).toFloat()
                val edgeAlpha = (55 + 60 * intensity).roundToInt().coerceIn(55,115)
                glass.setStroke(dp(1), android.graphics.Color.argb(edgeAlpha, 170, 215, 255))
                panel.background = glass
                window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))
                // Importante: la pagina può contenere ScrollView con card create separatamente.
                // Rendiamo trasparenti anche quelle superfici, così lo scrolling non scopre zone bianche.
                applyImmersiveSurfaces(panel)
                popupDialogGlassOverlay = panel
            }
        }
    }
    private fun clearPopupBackdropEffect() {
        popupBackdropOverlay?.let { (it.parent as? ViewGroup)?.removeView(it) }
        popupBackdropOverlay = null
        popupDialogGlassOverlay?.let { panel ->
            popupDialogOriginalBackgrounds.remove(panel)?.let { original -> panel.background = original }
        }
        popupDialogGlassOverlay = null
        popupDialogOriginalWindowBackgrounds.forEach { (dialog, original) ->
            if (dialog.isShowing) dialog.window?.setBackgroundDrawable(original)
        }
        popupDialogOriginalWindowBackgrounds.clear()
        popupBackdropTarget?.setRenderEffect(null)
        popupBackdropTarget = null
    }

    private fun removePopupBackdropDialog(dialog: Dialog) {
        popupBackdropDialogs.remove(dialog)
        if (popupBackdropCurrentDialog === dialog) popupBackdropCurrentDialog = popupBackdropDialogs.lastOrNull()
        clearPopupBackdropEffect()
        if (popupBackdropEffect != "NONE" && popupBackdropCurrentDialog != null) applyPopupBackdropEffect(popupBackdropCurrentDialog)
    }

    private fun preparePopupBackdrop(dialog: Dialog) {
        dialog.setOnDismissListener { removePopupBackdropDialog(dialog) }
    }

    private fun clientNameAutoCompleteAdapter(items: List<String>): ArrayAdapter<String> =
        object : ArrayAdapter<String>(this, 0, items) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = (convertView as? TextView) ?: TextView(this@MainActivity)
                v.text = getItem(position) ?: ""
                v.textSize = 16f
                v.setTextColor(Color.rgb(24,31,40))
                v.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                v.gravity = Gravity.CENTER_VERTICAL
                v.setPadding(dp(16), 0, dp(16), 0)
                v.background = ColorDrawable(Color.TRANSPARENT)
                v.layoutParams = AbsListView.LayoutParams(-1, dp(48))
                return v
            }
        }

    private fun styleClientNameSuggestions(field: AutoCompleteTextView) {
        field.setDropDownBackgroundDrawable(
            liquidInteractiveSurface(Color.rgb(248,249,251), 20, Color.rgb(220,226,234), 1)
        )
        field.dropDownVerticalOffset = dp(4)
        field.dropDownHorizontalOffset = 0
        field.dropDownWidth = ViewGroup.LayoutParams.MATCH_PARENT
        field.elevation = dp(2).toFloat()
    }

    private fun centeredSpinnerAdapter(items: List<String>): ArrayAdapter<String> =
        object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            init { setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent)
                (v as? TextView)?.apply { gravity = Gravity.CENTER; setTextColor(Color.rgb(24,31,40)); typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL) }
                return v
            }
            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getDropDownView(position, convertView, parent)
                (v as? TextView)?.apply { gravity = Gravity.CENTER; setTextColor(Color.rgb(24,31,40)); typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL) }
                return v
            }
        }
    // Selettore orario degli appuntamenti: stessa estetica del picker Evento libero,
    // ma usa ESCLUSIVAMENTE i valori già forniti dallo spinner. In questo modo la
    // disponibilità, gli slot e tutti i controlli esistenti restano completamente invariati.
    /**
     * Nuovo picker orario: ruota verticale custom con effetto "lente".
     * I valori arrivano dallo Spinner esistente, quindi disponibilita' e slot
     * restano identici. Qui cambiamo soltanto il rendering e lo scroll.
     */
    private class AppointmentWheelView(
        context: Context,
        private val values: List<String>,
        initialIndex: Int,
        private val onSelectionChanged: (Int) -> Unit
    ) : View(context) {
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
        private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(65, 69, 74); strokeWidth = dpLocal(2.2f) }
        private val glassPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var scrollPos = initialIndex.coerceIn(0, (values.size - 1).coerceAtLeast(0)).toFloat()
        private var targetPos = scrollPos
        private var lastY = 0f
        private var touchStartY = 0f
        private var touchStartScrollPos = 0f
        private var dragging = false
        private var velocityTracker: android.view.VelocityTracker? = null
        private var snapAnimator: ValueAnimator? = null
        private val itemHeight = dpLocal(45f)

        var selectedIndex: Int
            get() = targetPos.roundToInt().coerceIn(0, (values.size - 1).coerceAtLeast(0))
            set(value) {
                scrollPos = value.coerceIn(0, (values.size - 1).coerceAtLeast(0)).toFloat()
                targetPos = scrollPos
                invalidate()
            }

        private fun dpLocal(v: Float): Float = v * resources.displayMetrics.density

        init {
            setBackgroundColor(Color.TRANSPARENT)
            isClickable = true
            isFocusable = true
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cy = height / 2f
            val halfBand = itemHeight / 2f

            // Vetro leggermente piu' presente SOLO nella fascia selezionata.
            // Il canvas viene clipppato verticalmente alle due righe.
            canvas.save()
            canvas.clipRect(0f, cy - halfBand, width.toFloat(), cy + halfBand)
            glassPaint.shader = LinearGradient(
                0f, 0f, width.toFloat(), 0f,
                intArrayOf(
                    Color.argb(0, 226, 239, 249),
                    Color.argb(135, 226, 239, 249),
                    Color.argb(222, 226, 239, 249),
                    Color.argb(135, 226, 239, 249),
                    Color.argb(0, 226, 239, 249)
                ),
                floatArrayOf(0f, .20f, .50f, .80f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawRect(0f, cy - halfBand, width.toFloat(), cy + halfBand, glassPaint)
            glassPaint.shader = null
            canvas.restore()

            // Le righe restano esattamente ai bordi della fascia centrale.
            canvas.drawLine(0f, cy - halfBand, width.toFloat(), cy - halfBand, linePaint)
            canvas.drawLine(0f, cy + halfBand, width.toFloat(), cy + halfBand, linePaint)

            val center = scrollPos
            val first = kotlin.math.floor(center - 3f).toInt().coerceAtLeast(0)
            val last = kotlin.math.ceil(center + 3f).toInt().coerceAtMost(values.lastIndex)
            for (index in first..last) {
                val distance = index - center
                val y = cy + distance * itemHeight
                if (y < -itemHeight || y > height + itemHeight) continue

                val normalized = (1f - (kotlin.math.abs(distance) / 2.2f)).coerceIn(0f, 1f)
                val eased = normalized * normalized * (3f - 2f * normalized)
                val scale = 1f + 0.24f * eased
                val alpha = (150f + 105f * eased).toInt().coerceIn(0, 255)
                textPaint.textSize = dpLocal(21f) * scale
                textPaint.alpha = alpha
                textPaint.typeface = if (eased > .70f) {
                    android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                } else {
                    android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
                }
                textPaint.color = Color.rgb(42, 47, 53)
                val baseline = y - (textPaint.ascent() + textPaint.descent()) / 2f
                canvas.drawText(values[index], width / 2f, baseline, textPaint)
            }
            textPaint.alpha = 255
        }

        override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
            when (event.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    snapAnimator?.cancel()
                    velocityTracker?.recycle()
                    velocityTracker = android.view.VelocityTracker.obtain()
                    velocityTracker?.addMovement(event)
                    lastY = event.y
                    touchStartY = event.y
                    touchStartScrollPos = scrollPos
                    dragging = true
                    parent?.requestDisallowInterceptTouchEvent(true)
                    return true
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    if (!dragging) return true
                    velocityTracker?.addMovement(event)
                    // Il trascinamento manuale è ancorato al punto esatto in cui il dito
                    // ha iniziato il gesto: così piccoli movimenti restano perfettamente
                    // 1:1 con il dito e non accumulano micro-errori tra gli eventi touch.
                    lastY = event.y
                    scrollPos = (touchStartScrollPos + (touchStartY - event.y) / itemHeight)
                        .coerceIn(0f, values.lastIndex.toFloat())
                    targetPos = scrollPos
                    invalidate()
                    return true
                }
                android.view.MotionEvent.ACTION_UP -> {
                    if (!dragging) return true
                    velocityTracker?.addMovement(event)
                    velocityTracker?.computeCurrentVelocity(1000)
                    val velocityY = velocityTracker?.yVelocity ?: 0f
                    velocityTracker?.recycle()
                    velocityTracker = null
                    dragging = false
                    parent?.requestDisallowInterceptTouchEvent(false)
                    if (kotlin.math.abs(velocityY) > 220f) {
                        fling(velocityY)
                    } else {
                        snapToNearest()
                    }
                    performClick()
                    return true
                }
                android.view.MotionEvent.ACTION_CANCEL -> {
                    if (!dragging) return true
                    velocityTracker?.recycle()
                    velocityTracker = null
                    dragging = false
                    parent?.requestDisallowInterceptTouchEvent(false)
                    snapToNearest()
                    return true
                }
            }
            return true
        }

        override fun performClick(): Boolean {
            super.performClick()
            return true
        }

        private fun fling(velocityY: Float) {
            // Lo slancio è proporzionato alla velocità del gesto: una passata rapida
            // attraversa più orari e poi rallenta naturalmente fino allo snap.
            val velocityItemsPerSecond = -velocityY / itemHeight
            val distance = (velocityItemsPerSecond * 0.28f)
                .coerceIn(-10f, 10f)
            val target = (scrollPos + distance)
                .coerceIn(0f, values.lastIndex.toFloat())
            val from = scrollPos

            if (kotlin.math.abs(target - from) < 0.01f) {
                snapToNearest()
                return
            }

            targetPos = target
            snapAnimator?.cancel()
            snapAnimator = ValueAnimator.ofFloat(from, target).apply {
                val distancePx = kotlin.math.abs(target - from) * itemHeight
                duration = (280L + distancePx * 0.16f).toLong().coerceIn(280L, 650L)
                interpolator = android.view.animation.DecelerateInterpolator(1.7f)
                addUpdateListener {
                    scrollPos = it.animatedValue as Float
                    invalidate()
                }
                addListener(object : android.animation.AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: android.animation.Animator) {
                        if (animation !== snapAnimator) return
                        scrollPos = target
                        snapToNearest()
                    }
                })
                start()
            }
        }

        private fun snapToNearest() {
            val target = scrollPos.roundToInt().coerceIn(0, values.lastIndex).toFloat()
            val from = scrollPos
            targetPos = target
            if (kotlin.math.abs(target - from) < 0.001f) {
                onSelectionChanged(target.toInt())
                invalidate()
                return
            }
            snapAnimator?.cancel()
            snapAnimator = ValueAnimator.ofFloat(from, target).apply {
                duration = 150L
                interpolator = android.view.animation.DecelerateInterpolator()
                addUpdateListener {
                    scrollPos = it.animatedValue as Float
                    invalidate()
                }
                addListener(object : android.animation.AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: android.animation.Animator) {
                        scrollPos = target
                        onSelectionChanged(target.toInt())
                        invalidate()
                    }
                })
                start()
            }
        }
    }

    private fun installNikiAppointmentTimePicker(spinner: Spinner) {
        spinner.setOnTouchListener { _, event ->
            if (event.action != android.view.MotionEvent.ACTION_UP) return@setOnTouchListener true
            val adapter = spinner.adapter ?: return@setOnTouchListener true
            if (adapter.count == 0) return@setOnTouchListener true

            val values = (0 until adapter.count).mapNotNull { adapter.getItem(it)?.toString() }
            if (values.isEmpty()) return@setOnTouchListener true
            val initial = spinner.selectedItemPosition.coerceIn(0, values.lastIndex)
            var selected = initial

            // Quando il selettore di "Nuovo appuntamento" è aperto, nascondiamo
            // completamente il vecchio campo orario: deve ricomparire solo quando
            // viene confermata una nuova fascia. In caso di Annulla viene ripristinato.
            val originalVisibility = spinner.visibility
            spinner.visibility = View.INVISIBLE

            val pickerView = AppointmentWheelView(this, values, initial) { index -> selected = index }
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(20), dp(18), dp(20), dp(8))
                background = liquidInteractiveSurface(Color.argb(242,226,239,249), 28, Color.rgb(188,215,240), 1)
                elevation = dp(10).toFloat()
            }
            box.addView(TextView(this).apply {
                text = "Orario appuntamento"
                textSize = 22f
                gravity = Gravity.CENTER
                setTextColor(Color.rgb(28,30,33))
            }, LinearLayout.LayoutParams(-1, dp(42)))
            box.addView(TextView(this).apply {
                text = "Seleziona una fascia disponibile"
                textSize = 11.5f
                gravity = Gravity.CENTER
                setTextColor(Color.rgb(95,108,122))
            }, LinearLayout.LayoutParams(-1, dp(28)).apply { setMargins(0,0,0,dp(4)) })

            box.addView(pickerView, LinearLayout.LayoutParams(dp(190), dp(190)).apply { gravity = Gravity.CENTER })

            val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            fun pickerButton(label: String) = TextView(this).apply {
                text = label
                textSize = 13.5f
                gravity = Gravity.CENTER
                setTextColor(Color.rgb(0,125,110))
                setTypeface(null, android.graphics.Typeface.BOLD)
                isClickable = true
                background = liquidInteractiveSurface(Color.argb(70,255,255,255),18,Color.rgb(185,215,225),1)
                applyLiquidControlDepth(this)
            }
            val cancel = pickerButton("Annulla")
            val confirm = pickerButton("Conferma")
            buttons.addView(cancel, LinearLayout.LayoutParams(0,dp(50),1f).apply { setMargins(0,dp(4),dp(5),0) })
            buttons.addView(confirm, LinearLayout.LayoutParams(0,dp(50),1f).apply { setMargins(dp(5),dp(4),0,0) })
            box.addView(buttons, LinearLayout.LayoutParams(-1,dp(54)))

            val td = AlertDialog.Builder(this).setView(box).create()
            preparePopupBackdrop(td)
            td.setOnShowListener {
                popupBackdropCurrentDialog = td
                td.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                td.window?.setDimAmount(0.40f)
                td.window?.setLayout((resources.displayMetrics.widthPixels*0.88f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT)
                td.window?.decorView?.setBackgroundColor(Color.TRANSPARENT)
                box.alpha = 0f
                box.scaleX = 0.94f
                box.scaleY = 0.94f
                box.translationY = dp(18).toFloat()
                box.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
                    .setDuration(300L).setInterpolator(android.view.animation.DecelerateInterpolator()).start()
            }
            td.setOnDismissListener {
                removePopupBackdropDialog(td)
                spinner.clearFocus()
                // Se il popup viene chiuso senza confermare, il valore precedente
                // deve tornare visibile.
                if (spinner.visibility != View.VISIBLE) spinner.visibility = originalVisibility
            }
            fun closePicker() {
                box.animate().alpha(0f).scaleX(0.97f).scaleY(0.97f).translationY(dp(8).toFloat())
                    .setDuration(180L).withEndAction { td.dismiss() }.start()
            }
            cancel.setOnClickListener { closePicker() }
            confirm.setOnClickListener {
                spinner.setSelection(selected)
                spinner.visibility = originalVisibility
                closePicker()
            }
            td.show()
            true
        }
    }

    // Selettore orario Niki UI: un unico pannello arrotondato, senza righe/pillole separate.
    private fun installNikiTimeDropdown(
        spinner: Spinner,
        centerOverAnchor: Boolean = false,
        onPopupShown: (() -> Unit)? = null,
        onPopupDismissed: (() -> Unit)? = null
    ) {
        spinner.setOnTouchListener { v, event ->
            if (event.action != android.view.MotionEvent.ACTION_UP) return@setOnTouchListener true
            val adapter = spinner.adapter ?: return@setOnTouchListener true
            if (adapter.count == 0) return@setOnTouchListener true

            val content = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(6), dp(6), dp(6), dp(6))
                setBackgroundColor(Color.TRANSPARENT)
            }
            val scroll = ScrollView(this).apply {
                isFillViewport = false
                overScrollMode = View.OVER_SCROLL_NEVER
                setBackgroundColor(Color.TRANSPARENT)
            }
            scroll.addView(content, ViewGroup.LayoutParams(-1, -2))

            var popup: PopupWindow? = null
            for (i in 0 until adapter.count) {
                val label = adapter.getItem(i)?.toString() ?: continue
                val row = TextView(this).apply {
                    text = label
                    textSize = 16.5f
                    setTextColor(Color.rgb(24, 31, 40))
                    typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(14), 0, dp(14), 0)
                    background = liquidInteractiveSurface(
                        if (i == spinner.selectedItemPosition) Color.rgb(232, 243, 255) else Color.rgb(248,249,251),
                        16, Color.rgb(210,226,242), 1
                    )
                    applyLiquidControlDepth(this)
                    isClickable = true
                    setOnClickListener {
                        spinner.setSelection(i)
                        popup?.dismiss()
                    }
                }
                content.addView(row, LinearLayout.LayoutParams(-1, dp(44)).apply {
                    if (i > 0) setMargins(0, dp(1), 0, 0)
                })
            }

            val maxHeight = dp(360)
            val popupW = if (centerOverAnchor) v.width.coerceAtLeast(dp(84)) else dp(220)
            content.measure(
                View.MeasureSpec.makeMeasureSpec(popupW - dp(12), View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(maxHeight - dp(12), View.MeasureSpec.AT_MOST)
            )
            val popupH = content.measuredHeight.coerceIn(dp(52), maxHeight)
            popup = PopupWindow(scroll, popupW, popupH, true).apply {
                setBackgroundDrawable(liquidInteractiveSurface(Color.WHITE, 24, Color.rgb(190,220,246), 1))
                elevation = dp(12).toFloat()
                isOutsideTouchable = true
                isFocusable = true
                setOnDismissListener {
                    spinner.clearFocus()
                    onPopupDismissed?.invoke()
                }
            }

            val location = IntArray(2)
            v.getLocationOnScreen(location)
            val screenH = resources.displayMetrics.heightPixels
            if (centerOverAnchor) {
                // Il pannello orari ha la stessa larghezza dello slot e il suo centro
                // coincide esattamente con il centro dello slot da cui viene aperto.
                // Leggermente verso sinistra rispetto all'asse del campo: evita
                // l'effetto "attaccato al bordo" visto sui giorni a destra.
                val x = location[0] + (v.width - popupW) / 2 - dp(16)
                val y = location[1] + (v.height - popupH) / 2
                val clampedX = x.coerceIn(dp(8), resources.displayMetrics.widthPixels - popupW - dp(8))
                val clampedY = y.coerceIn(dp(12), screenH - popupH - dp(12))
                onPopupShown?.invoke()
                popup.showAtLocation(v, Gravity.TOP or Gravity.START, clampedX, clampedY)
            } else {
                val gapPx = dp(4)
                val belowY = location[1] + v.height + gapPx
                val fitsBelow = belowY + popupH <= screenH - dp(12)
                val xOffset = ((v.width - popupW) / 2).coerceIn(-dp(24), dp(24))
                if (fitsBelow) popup.showAsDropDown(v, xOffset, gapPx)
                else popup.showAsDropDown(v, xOffset, -(v.height + popupH + gapPx))
            }
            true
        }
    }
    // Esattamente la stessa superficie dei campi Cliente, Data e Costo:
    // condivide materiali, colore, intensità del vetro, bordo e curvatura.
    // Conserviamo la firma per compatibilità con il precedente picker Niki UI.
    private fun packageSelectorSurface(withChevron: Boolean = false, expanded: Boolean = false): Drawable =
        liquidInteractiveSurface(Color.rgb(247, 248, 250), 18, Color.rgb(222, 226, 232), 1)

    /**
     * Picker a fisarmonica limitato al form "Nuovo pacchetto".
     * Lo Spinner rimane nel layout (ma non visibile) come modello dei dati: il
     * salvataggio, gli indici e il controllo delle modifiche restano invariati.
     * L'intera card ha un unico background, una sola bordatura e nessun popup.
     */
    private fun accordionPackageSelector(
        spinner: Spinner,
        title: String,
        scroll: ScrollView,
        beforeExpand: ((() -> Unit) -> Unit),
        afterCollapse: () -> Unit
    ): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = packageSelectorSurface()
            applyLiquidControlDepth(this)
            clipChildren = true
            clipToPadding = true
            clipToOutline = true
        }
        val header = FrameLayout(this).apply {
            isClickable = true
            isFocusable = true
        }
        val value = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 16f
            setTextColor(Color.rgb(29, 39, 52))
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            setSingleLine(true)
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(dp(45), 0, dp(45), 0)
        }
        val arrow = TextView(this).apply {
            text = "⌄"
            gravity = Gravity.CENTER
            textSize = 27f
            setTextColor(Color.rgb(83, 112, 145))
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        header.addView(value, FrameLayout.LayoutParams(-1, -1))
        header.addView(arrow, FrameLayout.LayoutParams(dp(45), -1, Gravity.END))
        card.addView(header, LinearLayout.LayoutParams(-1, dp(52)))

        val rows = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(7), 0, dp(7), dp(5))
        }
        val reveal = FrameLayout(this).apply {
            clipChildren = true
            clipToPadding = true
            addView(rows, FrameLayout.LayoutParams(-1, -2))
        }
        card.addView(reveal, LinearLayout.LayoutParams(-1, 0))
        spinner.visibility = View.GONE
        card.addView(spinner, LinearLayout.LayoutParams(0, 0))

        fun refreshValue() {
            value.text = spinner.selectedItem?.toString().orEmpty()
            header.contentDescription = "$title: ${value.text}. Tocca per scegliere."
        }
        refreshValue()

        var expanded = false
        var running: ValueAnimator? = null
        fun animateReveal(targetHeight: Int, onFinished: (() -> Unit)? = null) {
            running?.removeAllListeners()
            running?.cancel()
            val current = reveal.layoutParams.height.coerceAtLeast(0)
            if (current == targetHeight) {
                onFinished?.invoke()
                return
            }
            running = ValueAnimator.ofInt(current, targetHeight).apply {
                duration = 235L
                interpolator = android.view.animation.DecelerateInterpolator()
                addUpdateListener { animation ->
                    val h = animation.animatedValue as Int
                    reveal.layoutParams = (reveal.layoutParams as LinearLayout.LayoutParams).apply { height = h }
                    rows.alpha = if (targetHeight > 0) (h.toFloat() / targetHeight).coerceIn(0f, 1f)
                        else (h.toFloat() / current.coerceAtLeast(1)).coerceIn(0f, 1f)
                }
                addListener(object : android.animation.AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: android.animation.Animator) {
                        running = null
                        onFinished?.invoke()
                    }
                })
                start()
            }
        }
        fun ensureVisible() {
            card.post {
                if (!expanded || !card.isAttachedToWindow) return@post
                val cardPos = IntArray(2)
                val scrollPos = IntArray(2)
                card.getLocationOnScreen(cardPos)
                scroll.getLocationOnScreen(scrollPos)
                val visibleBottom = scrollPos[1] + scroll.height - dp(12)
                val cardBottom = cardPos[1] + card.height
                if (cardBottom > visibleBottom) scroll.smoothScrollBy(0, cardBottom - visibleBottom)
            }
        }
        fun close() {
            if (!expanded) return
            expanded = false
            arrow.text = "⌄"
            header.contentDescription = "$title: ${value.text}. Tocca per scegliere."
            animateReveal(0)
            afterCollapse()
        }
        fun expandCard() {
            if (expanded) return
            beforeExpand { close() }
            expanded = true
            arrow.text = "⌃"
            header.contentDescription = "$title: ${value.text}. Tocca per chiudere."
            rows.removeAllViews()
            val adapter = spinner.adapter ?: return
            for (i in 0 until adapter.count) {
                if (i == spinner.selectedItemPosition) continue
                val label = adapter.getItem(i)?.toString() ?: continue
                val option = TextView(this).apply {
                    text = label
                    // Ogni opzione ha ESATTAMENTE tipografia, colore e centro
                    // geometrico del valore visualizzato nello slot chiuso.
                    textSize = 16f
                    typeface = value.typeface
                    setTextColor(value.currentTextColor)
                    gravity = Gravity.CENTER
                    setSingleLine(true)
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    setPadding(dp(45), 0, dp(45), 0)
                    isClickable = true
                    isFocusable = true
                    contentDescription = "$title: $label"
                    setOnClickListener {
                        spinner.setSelection(i)
                        refreshValue()
                        close()
                    }
                }
                rows.addView(option, LinearLayout.LayoutParams(-1, dp(48)))
            }
            // L'altezza vera delle opzioni viene aggiunta al normale flusso del form.
            // I campi sottostanti scivolano verso il basso senza venir coperti.
            val target = dp(5) + rows.childCount * dp(48)
            animateReveal(target) { ensureVisible() }
        }
        header.setOnClickListener { if (expanded) close() else expandCard() }
        return card
    }

    // Selettore tipo appuntamento Niki UI: stesso pannello flottante del selettore orari.
    private fun installNikiTypeDropdown(
        spinner: Spinner,
        centerOnSpinner: Boolean = false,
        slightlyMoreOpaque: Boolean = false,
        replaceAnchor: Boolean = false,
        packageSlot: Boolean = false,
        onPopupShown: (() -> Unit)? = null,
        onPopupDismissed: (() -> Unit)? = null
    ) {
        spinner.setOnTouchListener { v, event ->
            if (event.action != android.view.MotionEvent.ACTION_UP) return@setOnTouchListener true
            val adapter = spinner.adapter ?: return@setOnTouchListener true
            if (adapter.count == 0) return@setOnTouchListener true

            val content = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(6), if (packageSlot) dp(2) else dp(6), dp(6), if (packageSlot) dp(2) else dp(6))
                setBackgroundColor(Color.TRANSPARENT)
            }
            val scroll = ScrollView(this).apply {
                overScrollMode = View.OVER_SCROLL_NEVER
                setBackgroundColor(Color.TRANSPARENT)
            }
            scroll.addView(content, ViewGroup.LayoutParams(-1, -2))
            var popup: PopupWindow? = null
            for (i in 0 until adapter.count) {
                val label = adapter.getItem(i)?.toString() ?: continue
                val row = TextView(this).apply {
                    text = label
                    textSize = 16f
                    setTextColor(Color.rgb(35,42,52))
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(14),0,dp(14),0)
                    isClickable = true
                    background = if (packageSlot) {
                        // Un unico pannello vetro: le righe non devono sembrare
                        // tre card flottanti separate o mostrare il testo sottostante.
                        if (i == spinner.selectedItemPosition)
                            roundedSurface(Color.rgb(229, 241, 254), 16, Color.rgb(200, 223, 246), 1)
                        else ColorDrawable(Color.TRANSPARENT)
                    } else liquidInteractiveSurface(
                        if (i == spinner.selectedItemPosition) Color.rgb(232,243,255) else Color.rgb(248,249,251),
                        16, Color.rgb(210,226,242), 1
                    )
                    if (!packageSlot) applyLiquidControlDepth(this)
                    setOnClickListener { spinner.setSelection(i); popup?.dismiss() }
                }
                content.addView(row, LinearLayout.LayoutParams(-1, dp(48)).apply {
                    if (i > 0) setMargins(0, dp(1), 0, 0)
                })
            }
            val popupW = if (replaceAnchor) v.width.coerceAtLeast(dp(110)) else dp(260)
            val maxHeight = dp(360)
            val popupH = ((if (packageSlot) dp(4) else dp(12)) + adapter.count * dp(48)).coerceAtMost(maxHeight)
            val originalVisibility = v.visibility
            popup = PopupWindow(scroll, popupW, popupH, true).apply {
                setBackgroundDrawable(if (packageSlot) {
                    packageSelectorSurface(expanded = true)
                } else if (slightlyMoreOpaque) {
                    GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
                        Color.argb(218, 252, 253, 254),
                        Color.argb(208, 246, 249, 252),
                        Color.argb(218, 250, 252, 254)
                    )).apply { cornerRadius=dp(24).toFloat(); setStroke(dp(1), Color.argb(215,190,220,246)) }
                } else {
                    liquidInteractiveSurface(Color.WHITE,24,Color.rgb(190,220,246),1)
                })
                elevation = dp(12).toFloat()
                isOutsideTouchable = true
                isFocusable = true
                setOnDismissListener {
                    spinner.clearFocus()
                    if (replaceAnchor) v.visibility = originalVisibility
                    onPopupDismissed?.invoke()
                }
            }

            val location = IntArray(2)
            v.getLocationOnScreen(location)
            val screenH = resources.displayMetrics.heightPixels
            val gapPx = dp(4)
            val belowY = location[1] + v.height + gapPx
            val fitsBelow = belowY + popupH <= screenH - dp(12)
            val xOffset = if (centerOnSpinner) ((v.width - popupW) / 2).coerceAtLeast(-dp(24)) else (v.width - popupW)

            if (replaceAnchor) {
                // Nel Nuovo appuntamento il pannello deve espandersi ESATTAMENTE
                // dal campo "Tipo appuntamento". Il popup resta ancorato al campo:
                // il bordo superiore coincide sempre con quello del campo,
                // indipendentemente da status/navigation bar e dimensioni dello schermo.
                v.visibility = View.INVISIBLE
                val anchorX = if (centerOnSpinner) ((v.width - popupW) / 2) else 0
                val anchorY = -v.height
                onPopupShown?.invoke()
                popup.showAsDropDown(v, anchorX, anchorY)
                scroll.alpha = 0f
                scroll.scaleY = 0.94f
                // Il form pacchetto apre dall'alto dello stesso slot, non dal basso.
                scroll.pivotY = if (packageSlot) 0f else scroll.height.toFloat().coerceAtLeast(dp(1).toFloat())
                scroll.animate().alpha(1f).scaleY(1f).setDuration(180L)
                    .setInterpolator(android.view.animation.DecelerateInterpolator()).start()
            } else if (fitsBelow) {
                popup.showAsDropDown(v, xOffset, gapPx)
            } else {
                popup.showAsDropDown(v, xOffset, -(v.height + popupH + gapPx))
            }
            true
        }
    }
    private fun typeBgForColor(c:Int):Int = Color.rgb((Color.red(c)+255)/2,(Color.green(c)+255)/2,(Color.blue(c)+255)/2)
    private fun ensureAppointmentTypes(){
        if(appointmentTypes.isEmpty()){
            appointmentTypes.add(AppointmentType("TYPE1","ALLENAMENTO",Color.rgb(45,135,210)))
            appointmentTypes.add(AppointmentType("TYPE2","MEZZ'ORA",Color.rgb(215,55,55)))
        }else if(appointmentTypes.none{it.id=="TYPE1"}){
            appointmentTypes.add(0,AppointmentType("TYPE1","ALLENAMENTO",Color.rgb(45,135,210)))
        }
    }
    private fun normalizedType(type:String):String = when(type){"ALLENAMENTO"->"TYPE1";"MEZZ'ORA"->"TYPE2";else->type}
    private fun typeIndex(type:String):Int {
        ensureAppointmentTypes()
        val id=normalizedType(type)
        val found=appointmentTypes.indexOfFirst{it.id==id}
        if(found>=0)return found
        val legacy=when(id){"TYPE1"->0;"TYPE2"->1;else->-1}
        return if(legacy>=0&&legacy<appointmentTypes.size)legacy else 0
    }
    private fun typeLabel(type:String):String { ensureAppointmentTypes(); return appointmentTypes.getOrNull(typeIndex(type))?.name ?: appointmentTypes.first().name }
    private fun typeColor(type:String):Int { ensureAppointmentTypes(); return appointmentTypes.getOrNull(typeIndex(type))?.color ?: appointmentTypes.first().color }
    private fun typeIdAt(index:Int):String { ensureAppointmentTypes(); return appointmentTypes.getOrNull(index)?.id ?: appointmentTypes.first().id }

    private fun roundedSurface(color:Int, radius:Int=16, strokeColor:Int=Color.TRANSPARENT, strokeWidth:Int=0): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius=dp(radius).toFloat(); if(strokeWidth>0) setStroke(dp(strokeWidth),strokeColor) }

    /** Niki UI: vetro interno appena azzurrato, meno trasparente della finestra.
     * Non dipende dallo stile globale degli appuntamenti e non altera i testi. */
    private fun layeredPopupCard(radius: Int = 22, light: Boolean = false): GradientDrawable {
        val colors = if (light) intArrayOf(
            Color.argb(240, 247, 252, 255),
            Color.argb(224, 227, 241, 253),
            Color.argb(234, 242, 249, 255)
        ) else intArrayOf(
            Color.argb(243, 249, 253, 255),
            Color.argb(230, 235, 246, 255),
            Color.argb(239, 244, 250, 255)
        )
        return GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), Color.argb(196, 188, 216, 242))
        }
    }

    /**
     * Vetro cristallino riservato al menu di scelta del nuovo pacchetto.
     * Superficie traslucida + piccoli riflessi speculari che seguono la curvatura:
     * non modifica le superfici globali, gli altri dialog o i selettori a tendina.
     */
    private fun polishedPackageGlassSurface(radius: Int = 22, quiet: Boolean = false, outer: Boolean = false): Drawable = object : Drawable() {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var overallAlpha = 255
        override fun draw(canvas: Canvas) {
            val x = bounds.left.toFloat()
            val y = bounds.top.toFloat()
            val w = bounds.width().toFloat()
            val h = bounds.height().toFloat()
            if (w <= 0f || h <= 0f) return
            val r = dp(radius).toFloat().coerceAtMost(minOf(w, h) / 2f)
            val saved = canvas.saveLayerAlpha(x, y, x + w, y + h, overallAlpha)
            val silhouette = Path().apply { addRoundRect(RectF(x,y,x+w,y+h),r,r,Path.Direction.CW) }
            canvas.save()
            canvas.clipPath(silhouette)

            val base = when {
                outer -> intArrayOf(
                    Color.argb(177, 205, 231, 250),
                    Color.argb(162, 235, 247, 255),
                    Color.argb(168, 194, 222, 246)
                )
                quiet -> intArrayOf(
                    Color.argb(123, 247, 253, 255),
                    Color.argb(103, 226, 242, 255),
                    Color.argb(117, 235, 248, 255)
                )
                else -> intArrayOf(
                    Color.argb(190, 246, 253, 255),
                    Color.argb(165, 220, 240, 255),
                    Color.argb(179, 232, 246, 255)
                )
            }
            paint.style = Paint.Style.FILL
            paint.shader = LinearGradient(x,y,x+w,y+h,base,null,Shader.TileMode.CLAMP)
            canvas.drawRoundRect(RectF(x,y,x+w,y+h),r,r,paint)

            // Riflesso diffuso nell'angolo superiore sinistro, senza banda bianca piatta.
            paint.shader = RadialGradient(
                x+w*0.16f,y+h*0.02f,maxOf(w*0.94f,h*0.64f),
                intArrayOf(Color.argb(if (outer) 91 else if (quiet) 50 else 84,255,255,255),
                    Color.argb(14,255,255,255),Color.TRANSPARENT),
                floatArrayOf(0f,0.47f,1f),Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(RectF(x,y,x+w,y+h),r,r,paint)

            // Luce radente e un delicato riflesso blu sul fianco destro.
            paint.shader = LinearGradient(x,y,x,y+h*0.58f,
                intArrayOf(Color.argb(if(outer) 52 else 46,255,255,255),
                    Color.argb(12,255,255,255),Color.TRANSPARENT),
                floatArrayOf(0f,0.32f,1f),Shader.TileMode.CLAMP)
            canvas.drawRoundRect(RectF(x,y,x+w,y+h),r,r,paint)
            paint.shader = LinearGradient(x+w*0.62f,y,x+w,y+h,
                Color.TRANSPARENT,Color.argb(if(quiet) 12 else 24,95,179,241),Shader.TileMode.CLAMP)
            canvas.drawRoundRect(RectF(x,y,x+w,y+h),r,r,paint)
            canvas.restore()

            // Bordo sottile con differenza di luminanza: superiore cristallino, inferiore azzurrato.
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = dp(1).toFloat()
            paint.shader = LinearGradient(x,y,x+w,y+h,
                intArrayOf(Color.argb(219,255,255,255),Color.argb(142,229,247,255),Color.argb(91,125,184,227)),
                null,Shader.TileMode.CLAMP)
            val inset=paint.strokeWidth/2f
            canvas.drawRoundRect(RectF(x+inset,y+inset,x+w-inset,y+h-inset),r-inset,r-inset,paint)
            paint.strokeWidth = dp(1).toFloat()
            paint.strokeCap = Paint.Cap.ROUND
            paint.shader = LinearGradient(x+r,y+dp(1).toFloat(),x+w-r,y+dp(1).toFloat(),
                intArrayOf(Color.argb(224,255,255,255),Color.argb(139,255,255,255),Color.TRANSPARENT),
                null,Shader.TileMode.CLAMP)
            canvas.drawLine(x+r,y+dp(1).toFloat(),x+w-r,y+dp(1).toFloat(),paint)
            paint.shader = null
            paint.style = Paint.Style.FILL
            canvas.restoreToCount(saved)
        }
        override fun setAlpha(alpha: Int) { overallAlpha=alpha.coerceIn(0,255);invalidateSelf() }
        override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) { paint.colorFilter=colorFilter;invalidateSelf() }
        override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
    }

    /** Tre pittogrammi a tratto coordinati, senza emoji o scritte dentro le icone. */
    private fun subtlePackageIconDrawable(kind: String): Drawable = object : Drawable() {
        private val ink = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(26, 109, 187)
            style = Paint.Style.STROKE
            strokeWidth = 2.6f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        override fun draw(canvas: Canvas) {
            val checkpoint = canvas.save()
            canvas.translate(bounds.left.toFloat(), bounds.top.toFloat())
            canvas.scale(bounds.width() / 48f, bounds.height() / 48f)
            when (kind) {
                "WEEK" -> {
                    canvas.drawRoundRect(RectF(9f, 12f, 39f, 38f), 4f, 4f, ink)
                    canvas.drawLine(9f, 21f, 39f, 21f, ink)
                    canvas.drawLine(17f, 8f, 17f, 16f, ink)
                    canvas.drawLine(31f, 8f, 31f, 16f, ink)
                    canvas.drawLine(17f, 28f, 22f, 28f, ink)
                    canvas.drawLine(27f, 28f, 32f, 28f, ink)
                }
                "CUSTOM" -> {
                    canvas.drawLine(10f, 13f, 38f, 13f, ink)
                    canvas.drawLine(10f, 24f, 38f, 24f, ink)
                    canvas.drawLine(10f, 35f, 38f, 35f, ink)
                    ink.style = Paint.Style.FILL
                    listOf(19f to 13f, 30f to 24f, 22f to 35f).forEach { (x, y) ->
                        canvas.drawCircle(x, y, 4.5f, ink)
                    }
                    ink.color = Color.rgb(244, 251, 255)
                    listOf(19f to 13f, 30f to 24f, 22f to 35f).forEach { (x, y) ->
                        canvas.drawCircle(x, y, 1.7f, ink)
                    }
                    ink.color = Color.rgb(26, 109, 187)
                    ink.style = Paint.Style.STROKE
                }
                else -> {
                    canvas.drawRoundRect(RectF(10f, 9f, 38f, 39f), 4f, 4f, ink)
                    for (y in listOf(18f, 26f, 34f)) {
                        canvas.drawCircle(17f, y, 1.2f, ink)
                        canvas.drawLine(23f, y, 32f, y, ink)
                    }
                }
            }
            canvas.restoreToCount(checkpoint)
        }
        override fun setAlpha(alpha: Int) { ink.alpha = alpha }
        override fun setColorFilter(filter: android.graphics.ColorFilter?) { ink.colorFilter = filter }
        override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
    }

    /**
     * Controllo Liquid Glass: superficie leggermente gonfia/3D, traslucida e
     * lucida, pensata per campi e pulsanti. Il contenuto rimane sempre nitido.
     * Fuori dal profilo LIQUID restituisce volutamente lo stile precedente.
     */
    private fun liquidInteractiveSurface(color:Int, radius:Int=18, strokeColor:Int=Color.TRANSPARENT, strokeWidth:Int=1): GradientDrawable {
        if (popupBackdropEffect != "LIQUID") return roundedSurface(color, radius, strokeColor, strokeWidth)
        val r=Color.red(color); val g=Color.green(color); val b=Color.blue(color)
        // I controlli Liquid Glass seguono ora l'intensità scelta: a intensità bassa
        // la superficie lascia filtrare maggiormente lo sfondo, mentre al 100%
        // mantiene esattamente la resa attuale della 1.2.
        val t = popupBackdropIntensity.coerceIn(0,100) / 100f
        val factor = 0.20f + 0.80f * t
        fun a(base:Int) = (base * factor).roundToInt().coerceIn(0,255)
        val strokeA = (210 * factor).roundToInt().coerceIn(0,255)
        return GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
            Color.argb(a(145), minOf(255,r+22), minOf(255,g+24), minOf(255,b+28)),
            Color.argb(a(102), minOf(255,r+8), minOf(255,g+12), minOf(255,b+16)),
            Color.argb(a(132), r, g, b),
            Color.argb(a(155), minOf(255,r+18), minOf(255,g+22), minOf(255,b+26))
        )).apply {
            cornerRadius=dp(radius).toFloat()
            if(strokeWidth>0) setStroke(dp(strokeWidth), Color.argb(strokeA, 190, 225, 255))
        }
    }

    private fun applyLiquidControlDepth(view: View) {
        if (popupBackdropEffect == "LIQUID") {
            view.elevation=dp(3).toFloat()
            view.translationZ=dp(0.5f.roundToInt()).toFloat()
        } else {
            view.elevation=0f
            view.translationZ=0f
        }
    }

    /** Superfici dell'interfaccia principale: la scelta del vetro influenza anche
     * schede, pulsanti e blocchi, non solo le finestre popup. Il contenuto resta
     * sempre nitido; qui lavoriamo esclusivamente sulla superficie. */
    /** Superficie leggibile per i dialog: mantiene il tema scelto ma aumenta
     * l'opacità delle card quando sotto c'è una schermata complessa.
     * Il testo non deve mai confondersi con il contenuto sottostante. */
    private fun dialogReadableSurface(color:Int, radius:Int=20, strokeColor:Int=Color.TRANSPARENT, strokeWidth:Int=1): GradientDrawable {
        if (popupBackdropEffect == "NONE") return roundedSurface(color, radius, strokeColor, strokeWidth)
        val alpha = when (popupBackdropEffect) {
            "SATIN" -> 232
            "VETRO_SOFT" -> 218
            "LIQUID" -> 198
            else -> 232
        }
        val edge = when (popupBackdropEffect) {
            "SATIN" -> if (strokeColor == Color.TRANSPARENT) Color.rgb(214,226,239) else strokeColor
            else -> if (strokeColor == Color.TRANSPARENT) Color.argb(185,175,215,248) else strokeColor
        }
        return GradientDrawable().apply {
            cornerRadius=dp(radius).toFloat()
            if (popupBackdropEffect == "LIQUID") {
                setColors(intArrayOf(
                    Color.argb(alpha,Color.red(color),Color.green(color),Color.blue(color)),
                    Color.argb((alpha*0.96f).toInt(),minOf(255,Color.red(color)+8),minOf(255,Color.green(color)+10),minOf(255,Color.blue(color)+14)),
                    Color.argb((alpha*0.98f).toInt(),Color.red(color),Color.green(color),Color.blue(color))
                ) )
            } else {
                setColor(Color.argb(alpha,Color.red(color),Color.green(color),Color.blue(color)))
            }
            if(strokeWidth>0) setStroke(dp(strokeWidth),edge)
        }
    }

    private fun appGlassSurface(color:Int, radius:Int=16, strokeColor:Int=Color.TRANSPARENT, strokeWidth:Int=1): GradientDrawable {
        if (popupBackdropEffect == "NONE") return roundedSurface(color, radius, strokeColor, strokeWidth)
        val a = when (popupBackdropEffect) {
            "SATIN" -> 208
            "VETRO_SOFT" -> 172
            "LIQUID" -> 122
            else -> 210
        }
        val edge = when (popupBackdropEffect) {
            "SATIN" -> if (strokeColor == Color.TRANSPARENT) Color.rgb(218,228,239) else strokeColor
            "VETRO_SOFT", "LIQUID" -> Color.argb(155, 175, 215, 248)
            else -> strokeColor
        }
        return GradientDrawable().apply {
            cornerRadius = dp(radius).toFloat()
            when (popupBackdropEffect) {
                "LIQUID" -> setColors(intArrayOf(
                    Color.argb(a, Color.red(color), Color.green(color), Color.blue(color)),
                    Color.argb((a * 0.78f).toInt(), minOf(255, Color.red(color)+12), minOf(255, Color.green(color)+16), minOf(255, Color.blue(color)+20)),
                    Color.argb((a * 0.90f).toInt(), Color.red(color), Color.green(color), Color.blue(color))
                ))
                "VETRO_SOFT" -> setColors(intArrayOf(
                    Color.argb(a, Color.red(color), Color.green(color), Color.blue(color)),
                    Color.argb((a * 0.90f).toInt(), minOf(255, Color.red(color)+8), minOf(255, Color.green(color)+10), minOf(255, Color.blue(color)+14))
                ))
                else -> setColor(Color.argb(a, Color.red(color), Color.green(color), Color.blue(color)))
            }
            if (strokeWidth > 0) setStroke(dp(strokeWidth), edge)
        }
    }

    /**
     * Superficie Liquid Glass "a goccia" per il calendario.
     * Il volume è costruito solo con luce, gradiente e bordi sfalsati:
     * nessun ovale o disegno interno.
     */
    private inner class LiquidDepthDrawable(
        private val radiusPx:Float,
        private val intensity:Float,
        private val accent:Int
    ) : Drawable() {
        private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val highlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val r = RectF()
        private val inner = RectF()

        override fun draw(canvas: Canvas) {
            val b = bounds
            if (b.width() <= 0 || b.height() <= 0) return
            val t = intensity.coerceIn(0f, 1f)
            val small = radiusPx <= dp(12)
            val inset = (0.9f + 0.7f * t).dp()
            r.set(b.left + inset, b.top + inset, b.right - inset, b.bottom - inset)

            // L'appuntamento è il livello "acqua" sopra la lastra: il colore del tipo
            // viene usato solo come riflesso, non come riempimento pieno.
            val ar = Color.red(accent)
            val ag = Color.green(accent)
            val ab = Color.blue(accent)
            val softR = ((ar * 0.20f) + 255f * 0.80f).roundToInt().coerceAtMost(255)
            val softG = ((ag * 0.20f) + 255f * 0.80f).roundToInt().coerceAtMost(255)
            val softB = ((ab * 0.20f) + 255f * 0.80f).roundToInt().coerceAtMost(255)

            // Corpo traslucido: più luminoso in alto e leggermente più denso in basso,
            // come una piccola lente d'acqua appoggiata sulla lastra.
            val topA = if (small) 102 + (20 * t).roundToInt() else 110 + (24 * t).roundToInt()
            val midA = if (small) 56 + (18 * t).roundToInt() else 64 + (20 * t).roundToInt()
            val bottomA = if (small) 82 + (24 * t).roundToInt() else 92 + (26 * t).roundToInt()
            fillPaint.shader = LinearGradient(
                r.left, r.top, r.left, r.bottom,
                intArrayOf(
                    Color.argb(topA, 255,255,255),
                    Color.argb(midA, softR,softG,softB),
                    Color.argb(bottomA, softR,softG,softB),
                    Color.argb((bottomA + 5).coerceAtMost(165), 246,251,255)
                ),
                floatArrayOf(0f,0.32f,0.78f,1f), Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(r, radiusPx, radiusPx, fillPaint)

            // Volume ottico centrale: una lente d'acqua non è uniforme come una card.
            // Una luce morbida attraversa il centro e si concentra verso la parte alta,
            // mentre il bordo inferiore rimane appena più denso. Le dimensioni restano
            // identiche: aumentiamo solo la percezione della curvatura.
            val bulge = RectF(r.left + 1.2f.dp(), r.top + 1.4f.dp(), r.right - 1.2f.dp(), r.bottom - 1.2f.dp())
            glowPaint.shader = RadialGradient(
                bulge.left + bulge.width()*0.50f, bulge.top + bulge.height()*0.34f,
                bulge.width()*0.62f,
                intArrayOf(
                    Color.argb((46 + 28*t).roundToInt(),255,255,255),
                    Color.argb((18 + 16*t).roundToInt(),255,255,255),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f,0.48f,1f), Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(bulge, radiusPx*0.92f, radiusPx*0.92f, glowPaint)

            // Riflesso diffuso superiore: la superficie sembra leggermente bombata.
            glowPaint.shader = RadialGradient(
                r.left + r.width()*0.34f, r.top + r.height()*0.12f,
                r.width()*0.72f,
                intArrayOf(
                    Color.argb((72 + 38*t).roundToInt(),255,255,255),
                    Color.argb((22 + 20*t).roundToInt(),255,255,255),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f,0.42f,1f), Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(r, radiusPx, radiusPx, glowPaint)

            // Rifrazione interna: una fascia chiarissima e molto trasparente appena
            // sotto il bordo superiore, come la luce che attraversa una superficie
            // d'acqua. Non aumenta lo spessore della card.
            val refraction = RectF(r.left + 2.4f.dp(), r.top + 4.0f.dp(), r.right - 2.4f.dp(), r.top + r.height()*0.46f)
            glowPaint.shader = LinearGradient(
                refraction.left, refraction.top, refraction.left, refraction.bottom,
                Color.argb((42 + 28*t).roundToInt(),255,255,255),
                Color.TRANSPARENT,
                Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(refraction, radiusPx*0.72f, radiusPx*0.72f, glowPaint)

            // Piccolo riflesso laterale, volutamente bianco/fumé: niente bordo blu pieno.
            edgePaint.shader = null
            edgePaint.strokeWidth = (if (small) 1.15f else 1.45f + 0.25f*t).dp()
            edgePaint.color = Color.argb((88 + 38*t).roundToInt(), 205, 226, 239)
            canvas.drawRoundRect(r, radiusPx, radiusPx, edgePaint)

            inner.set(r.left + 1.5f.dp(), r.top + 1.5f.dp(), r.right - 1.5f.dp(), r.bottom - 1.5f.dp())

            // Highlight superiore continuo: è il punto che deve far leggere "acqua".
            val hi = if (small) 108 + (38*t).roundToInt() else 122 + (42*t).roundToInt()
            highlightPaint.strokeWidth = (if (small) 1.45f else 1.8f).dp()
            highlightPaint.color = Color.argb(hi,255,255,255)
            val topPath = Path()
            topPath.moveTo(inner.left + inner.width()*0.13f, inner.top + 1f.dp())
            topPath.quadTo(inner.left + inner.width()*0.50f, inner.top - 0.9f.dp(), inner.right - inner.width()*0.13f, inner.top + 1f.dp())
            canvas.drawPath(topPath, highlightPaint)

            // Riflesso corto sul lato sinistro.
            val sidePath = Path()
            sidePath.moveTo(inner.left + 0.7f.dp(), inner.top + inner.height()*0.20f)
            sidePath.quadTo(inner.left - 0.1f.dp(), inner.top + inner.height()*0.38f, inner.left + 0.7f.dp(), inner.top + inner.height()*0.55f)
            highlightPaint.strokeWidth = (if (small) 1.15f else 1.35f).dp()
            highlightPaint.color = Color.argb((48 + 35*t).roundToInt(),255,255,255)
            canvas.drawPath(sidePath, highlightPaint)

            // Riflesso inferiore molto sottile: leggermente cromatico, ma attenuato.
            val low = Path()
            low.moveTo(inner.left + inner.width()*0.16f, inner.bottom - 0.7f.dp())
            low.quadTo(inner.left + inner.width()*0.50f, inner.bottom + 0.45f.dp(), inner.right - inner.width()*0.16f, inner.bottom - 0.7f.dp())
            highlightPaint.strokeWidth = (if (small) 1.45f else 1.75f).dp()
            highlightPaint.color = Color.argb((50 + 34*t).roundToInt(), softR, softG, softB)
            canvas.drawPath(low, highlightPaint)
        }

        private fun Float.dp():Float = this * resources.displayMetrics.density
        override fun setAlpha(alpha:Int) {}
        override fun setColorFilter(colorFilter:android.graphics.ColorFilter?) {}
        override fun getOpacity():Int = android.graphics.PixelFormat.TRANSLUCENT
    }

    /**
     * Base estetica comune del calendario: il profilo Liquid Glass attuale è il
     * riferimento visivo per tutti e quattro gli stili. In questa fase non
     * differenziamo ancora Standard, Satinato e Vetro Soft: li prepariamo sulla
     * stessa base funzionante, così la futura personalizzazione potrà separarli
     * senza cambiare la struttura degli slot.
     */
    private fun liquidDepthSurface(color:Int, radius:Int=12, accent:Int=Color.rgb(160,211,247)):Drawable =
        LiquidDepthDrawable(dp(radius).toFloat(), popupBackdropIntensity.coerceIn(0,100)/100f, accent)

    private fun calendarGlassBackground(): Drawable {
        if (popupBackdropEffect != "LIQUID") return ColorDrawable(Color.rgb(238,241,244))
        // Base neutra fredda: il vetro deve emergere dal piano senza rendere
        // l'interfaccia azzurra.
        return GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
            Color.rgb(224,228,232),
            Color.rgb(216,220,224),
            Color.rgb(230,233,236),
            Color.rgb(212,217,221)
        ))
    }

    private inner class LargeSlotStyleDrawable(
        private val style:Int,
        private val z:Float,
        private val accent:Int = Color.rgb(160,211,247)
    ) : Drawable() {
        private val fill=Paint(Paint.ANTI_ALIAS_FLAG)
        private val edge=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeCap=Paint.Cap.ROUND}
        private val glow=Paint(Paint.ANTI_ALIAS_FLAG)
        private val r=RectF()
        override fun draw(canvas:Canvas){
            if(bounds.width()<=0||bounds.height()<=0)return
            val d=resources.displayMetrics.density
            fun dp(v:Number)=v.toFloat()*d
            val w=bounds.width().toFloat(); val h=bounds.height().toFloat()
            val radius=when(style){1->dp(7);2->dp(13);3->dp(18);4->dp(18);5->dp(16);6->dp(20);7->dp(16);8->dp(18);9->dp(22);else->dp(12)}
            val inset=when(style){1->dp(.8f);5->dp(1.0f);else->dp(1.1f)}
            r.set(bounds.left+inset,bounds.top+inset,bounds.right-inset,bounds.bottom-inset)
            val ar=Color.red(accent);val ag=Color.green(accent);val ab=Color.blue(accent)
            when(style){
                1->{
                    fill.shader=LinearGradient(r.left,r.top,r.left,r.bottom,intArrayOf(Color.argb(42,255,255,255),Color.argb(22,230,236,242)),null,Shader.TileMode.CLAMP)
                    canvas.drawRoundRect(r,radius,radius,fill)
                    edge.strokeWidth=dp(1f);edge.color=Color.argb(115,150,160,172);canvas.drawRoundRect(r,radius,radius,edge)
                }
                2->{
                    fill.shader=LinearGradient(r.left,r.top,r.right,r.bottom,intArrayOf(Color.argb(125,255,255,255),Color.argb(86,225,232,240),Color.argb(118,247,249,252)),null,Shader.TileMode.CLAMP)
                    canvas.drawRoundRect(r,radius,radius,fill)
                    edge.strokeWidth=dp(1.25f);edge.color=Color.argb(105,255,255,255);canvas.drawRoundRect(r,radius,radius,edge)
                }
                3->{
                    fill.shader=LinearGradient(r.left,r.top,r.left,r.bottom,intArrayOf(Color.argb(100,255,255,255),Color.argb(64,190,225,244),Color.argb(90,232,244,250)),null,Shader.TileMode.CLAMP)
                    canvas.drawRoundRect(r,radius,radius,fill)
                    edge.strokeWidth=dp(1.8f);edge.color=Color.argb(190,145,218,247);canvas.drawRoundRect(r,radius,radius,edge)
                    edge.strokeWidth=dp(.65f);edge.color=Color.argb(105,255,255,255);canvas.drawRoundRect(RectF(r.left+dp(2),r.top+dp(2),r.right-dp(2),r.bottom-dp(2)),radius-dp(1),radius-dp(1),edge)
                }
                4->{
                    fill.shader=LinearGradient(r.left,r.top,r.right,r.bottom,intArrayOf(Color.argb(120,225,236,255),Color.argb(105,242,225,242),Color.argb(115,255,237,220)),null,Shader.TileMode.CLAMP)
                    canvas.drawRoundRect(r,radius,radius,fill)
                    edge.strokeWidth=dp(1.1f);edge.color=Color.argb(120,177,190,232);canvas.drawRoundRect(r,radius,radius,edge)
                    edge.color=Color.argb(90,245,207,185);canvas.drawRoundRect(r,radius,radius,edge)
                }
                5->{
                    fill.shader=LinearGradient(r.left,r.top,r.left,r.bottom,intArrayOf(Color.argb(178,52,62,74),Color.argb(148,36,44,55),Color.argb(176,68,78,91)),null,Shader.TileMode.CLAMP)
                    canvas.drawRoundRect(r,radius,radius,fill)
                    edge.strokeWidth=dp(1.25f);edge.color=Color.argb(175,125,139,155);canvas.drawRoundRect(r,radius,radius,edge)
                    edge.strokeWidth=dp(.7f);edge.color=Color.argb(100,220,230,240);canvas.drawRoundRect(RectF(r.left+dp(2),r.top+dp(2),r.right-dp(2),r.bottom-dp(2)),radius-dp(1),radius-dp(1),edge)
                }
                6->{
                    fill.shader=LinearGradient(r.left,r.top,r.right,r.bottom,intArrayOf(Color.argb(118,213,248,242),Color.argb(92,194,238,235),Color.argb(122,220,249,242)),null,Shader.TileMode.CLAMP)
                    canvas.drawRoundRect(r,radius,radius,fill)
                    edge.strokeWidth=dp(1.35f);edge.color=Color.argb(150,116,222,205);canvas.drawRoundRect(r,radius,radius,edge)
                    glow.shader=RadialGradient(r.left+w*.32f,r.top+h*.18f,w*.58f,Color.argb(75,255,255,255),Color.TRANSPARENT,Shader.TileMode.CLAMP);canvas.drawRoundRect(r,radius,radius,glow)
                }
                7->{
                    // Acciaio lucido: riflesso metallico continuo, senza arco/baffo.
                    fill.shader=LinearGradient(r.left,r.top,r.right,r.bottom,
                        intArrayOf(
                            Color.rgb(238,242,246),
                            Color.rgb(185,194,204),
                            Color.rgb(252,253,254),
                            Color.rgb(168,178,188),
                            Color.rgb(241,244,247)
                        ),null,Shader.TileMode.CLAMP)
                    canvas.drawRoundRect(r,radius,radius,fill)
                    edge.strokeWidth=dp(1.35f);edge.color=Color.argb(175,125,137,149);canvas.drawRoundRect(r,radius,radius,edge)
                    edge.strokeWidth=dp(.65f);edge.color=Color.argb(210,255,255,255);canvas.drawRoundRect(RectF(r.left+dp(1.5f),r.top+dp(1.5f),r.right-dp(1.5f),r.bottom-dp(1.5f)),radius-dp(1),radius-dp(1),edge)
                }
                8->{
                    fill.shader=LinearGradient(r.left,r.top,r.left,r.bottom,intArrayOf(Color.argb(105,240,249,255),Color.argb(80,196,226,247),Color.argb(105,226,240,255)),null,Shader.TileMode.CLAMP)
                    canvas.drawRoundRect(r,radius,radius,fill)
                    glow.style=Paint.Style.STROKE;glow.strokeWidth=dp(4.2f);glow.color=Color.argb(40,105,205,255);canvas.drawRoundRect(r,radius,radius,glow)
                    edge.strokeWidth=dp(1.5f);edge.color=Color.argb(185,118,214,247);canvas.drawRoundRect(r,radius,radius,edge)
                }
                9->{
                    fill.shader=LinearGradient(r.left,r.top,r.right,r.bottom,intArrayOf(Color.argb(110,252,224,242),Color.argb(100,223,215,250),Color.argb(112,211,245,235)),null,Shader.TileMode.CLAMP)
                    canvas.drawRoundRect(r,radius,radius,fill)
                    glow.shader=RadialGradient(r.left+w*.72f,r.top+h*.18f,w*.55f,Color.argb(65,255,255,255),Color.TRANSPARENT,Shader.TileMode.CLAMP);canvas.drawRoundRect(r,radius,radius,glow)
                    edge.strokeWidth=dp(1.15f);edge.color=Color.argb(125,235,205,235);canvas.drawRoundRect(r,radius,radius,edge)
                }
                else->{
                    // Stile 10 è gestito da largeSlotStyleDrawable() con il Liquid Glass attuale.
                    // Manteniamo qui un fallback semplice e privo di logica aggiuntiva.
                    fill.shader=LinearGradient(r.left,r.top,r.left,r.bottom,
                        Color.argb(90,255,255,255),Color.argb(60,220,235,247),Shader.TileMode.CLAMP)
                    canvas.drawRoundRect(r,radius,radius,fill)
                    edge.strokeWidth=dp(1.2f)
                    edge.color=Color.argb(100,205,226,239)
                    canvas.drawRoundRect(r,radius,radius,edge)
                }
            }
            fill.shader=null;glow.shader=null
        }
        override fun setAlpha(alpha:Int){}
        override fun setColorFilter(colorFilter:android.graphics.ColorFilter?){}
        override fun getOpacity():Int=android.graphics.PixelFormat.TRANSLUCENT
    }

    private fun largeSlotStyleDrawable(style:Int,z:Float,slot:Int=0):Drawable {
        val accent=if(slot%2==0)Color.rgb(160,211,247) else Color.rgb(174,218,248)
        return if(style==10) liquidDepthSurface(accent,12,accent) else LargeSlotStyleDrawable(style,z,accent)
    }

    private fun calendarSlotSurface(z:Float, slot:Int): Drawable {
        return largeSlotStyleDrawable(largeSlotStyle,z,slot)
    }

    private fun applyCalendarSlotDepth(view: View) {
        // La base comune Liquid Glass non viene sollevata dal piano.
        view.elevation=0f
        view.translationZ=0f
    }


    private fun appGlassBackground(): Drawable {
        return when (popupBackdropEffect) {
            "SATIN" -> GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
                Color.rgb(244,247,250), Color.rgb(231,236,241), Color.rgb(244,247,250)
            ))
            "VETRO_SOFT" -> GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
                Color.rgb(232,238,244), Color.rgb(214,222,230), Color.rgb(239,243,247)
            ))
            "LIQUID" -> GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
                Color.rgb(218,227,235), Color.rgb(226,224,231), Color.rgb(215,232,235), Color.rgb(235,229,234)
            ))
            else -> ColorDrawable(Color.rgb(240,242,244))
        }
    }


    private fun modernEditText(): EditText = EditText(this).apply {
        textSize = 16f
        setSingleLine(true)
        setTextColor(Color.rgb(24,31,40))
        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        setHintTextColor(Color.rgb(130,135,142))
        setPadding(dp(14),0,dp(14),0)
        background = liquidInteractiveSurface(Color.rgb(247,248,250),18,Color.rgb(222,226,232),1)
        applyLiquidControlDepth(this)
        stateListAnimator = null
    }

    private fun paymentButtonStyle(): Button = Button(this).apply {
        text = "PAGA"
        setAllCaps(false)
        textSize = 13.5f
        minWidth = 0; minimumWidth = 0
        minHeight = 0; minimumHeight = 0
        setPadding(0,0,0,0)
        setTextColor(Color.rgb(20,91,165))
        background = liquidInteractiveSurface(Color.rgb(238,246,255),17,Color.rgb(190,218,248),1)
        applyLiquidControlDepth(this)
        stateListAnimator = null
    }

    private fun menuIconButtonStyle(): Button = Button(this).apply {
        text = "⋮"
        textSize = 18f
        minWidth = 0; minimumWidth = 0
        minHeight = 0; minimumHeight = 0
        setPadding(0,0,0,dp(1))
        setTextColor(Color.rgb(55,58,63))
        background = liquidInteractiveSurface(Color.rgb(246,248,250),16,Color.rgb(225,229,234),1)
        applyLiquidControlDepth(this)
        stateListAnimator = null
    }

    private fun editIconButtonStyle(): Button = Button(this).apply {
        text = "✎"
        setAllCaps(false)
        textSize = 15f
        minWidth = 0; minimumWidth = 0
        minHeight = 0; minimumHeight = 0
        setPadding(0,0,0,dp(1))
        setTextColor(Color.rgb(20,91,165))
        background = liquidInteractiveSurface(Color.rgb(246,249,253),17,Color.rgb(205,220,238),1)
        applyLiquidControlDepth(this)
        stateListAnimator = null
    }

    private fun buttonStyle(textValue: String): Button = Button(this).apply {
        text = textValue; textSize = 13.5f; setTextColor(Color.rgb(35,38,42)); gravity = Gravity.CENTER; setPadding(0,0,0,0)
        minHeight = 0; minimumHeight = 0; setAllCaps(false); stateListAnimator = null
        background = liquidInteractiveSurface(Color.rgb(241,243,246),18,Color.rgb(226,229,234),1)
        applyLiquidControlDepth(this)
    }

    private fun whitePersonDrawable(): Drawable = object : Drawable() {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(25,92,170); style = Paint.Style.FILL }
        override fun draw(canvas: Canvas) {
            val w = bounds.width().toFloat(); val h = bounds.height().toFloat()
            canvas.drawCircle(w * 0.5f, h * 0.28f, w * 0.18f, paint)
            val body = android.graphics.RectF(w * 0.23f, h * 0.50f, w * 0.77f, h * 0.94f)
            canvas.drawRoundRect(body, w * 0.16f, w * 0.16f, paint)
        }
        override fun setAlpha(alpha: Int) { paint.alpha = alpha }
        override fun setColorFilter(filter: android.graphics.ColorFilter?) { paint.colorFilter = filter }
        override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
        override fun getIntrinsicWidth(): Int = dp(18)
        override fun getIntrinsicHeight(): Int = dp(18)
    }

    private fun primaryButtonStyle(textValue: String): Button = Button(this).apply {
        text = textValue; textSize = 13.5f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0,0,0,0)
        minHeight = 0; minimumHeight = 0; setAllCaps(false); stateListAnimator = null
        background = liquidInteractiveSurface(Color.rgb(20,112,232),20,Color.rgb(145,205,255),1)
        applyLiquidControlDepth(this)
    }

    private fun softBlueButtonStyle(textValue: String): Button = Button(this).apply {
        text = textValue; textSize = 13.5f; setTextColor(Color.rgb(30,83,145)); gravity = Gravity.CENTER; setPadding(0,0,0,0)
        minHeight = 0; minimumHeight = 0; setAllCaps(false); stateListAnimator = null
        background = liquidInteractiveSurface(Color.rgb(235,244,255),18,Color.rgb(205,224,248),1)
        applyLiquidControlDepth(this)
    }

    private fun build() {
        currentScreen = "HOME"
        lastHomeBackAt = 0L
        clearPopupBackdropEffect()
        popupBackdropCurrentDialog=null
        popupBackdropDialogs.clear()
        detachSettingsOverlay()
        trashReturnToSettings=false
        if(::searchInput.isInitialized) searchInput.setText("")
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(14),dp(16),dp(10));background=appGlassBackground()}
        val titleRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val brand=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        brand.addView(TextView(this).apply{text="➤";textSize=31f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(20,91,165));gravity=Gravity.CENTER;rotation=-18f},LinearLayout.LayoutParams(dp(42),dp(52)))
        val brandText=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL}
        val brandName=TextView(this).apply{
            text=android.text.SpannableStringBuilder().apply{append("Coach");setSpan(android.text.style.ForegroundColorSpan(Color.rgb(25,62,112)),0,5,android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);append("Flow");setSpan(android.text.style.ForegroundColorSpan(Color.rgb(20,128,235)),5,9,android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)}
            textSize=29f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER_VERTICAL;setIncludeFontPadding(false)
        }
        brandText.addView(brandName,LinearLayout.LayoutParams(-1,dp(36)))
        brandText.addView(TextView(this).apply{text="ALLENA  •  ORGANIZZA  •  CRESCI";textSize=7.5f;setTextColor(Color.rgb(115,125,140));letterSpacing=0.18f;gravity=Gravity.CENTER_VERTICAL;setIncludeFontPadding(false)},LinearLayout.LayoutParams(-1,dp(16)))
        brand.addView(brandText,LinearLayout.LayoutParams(0,dp(54),1f))
        titleRow.addView(brand,LinearLayout.LayoutParams(0,dp(56),1f))
        val dashButton=Button(this).apply{
            text=if(dashboardEnabled)"DASH  ●" else "DASH  ○";textSize=12.5f;setTextColor(Color.rgb(70,74,80));gravity=Gravity.CENTER;minHeight=0;minimumHeight=0;setPadding(dp(8),0,dp(8),0);setAllCaps(false);stateListAnimator=null
            background=roundedSurface(if(dashboardEnabled)Color.rgb(235,241,248)else Color.rgb(248,249,250),18,Color.rgb(220,223,227),1)
            setOnClickListener{dashboardEnabled=!dashboardEnabled;saveData();updateDashboardButton(this);render()}
        }
        titleRow.addView(dashButton,LinearLayout.LayoutParams(dp(78),dp(42)).apply{setMargins(dp(6),0,dp(4),0)})
        val settingsButton=Button(this).apply{
            text="⚙";textSize=21f;setTextColor(Color.rgb(55,58,63));gravity=Gravity.CENTER;minHeight=0;minimumHeight=0;setPadding(0,0,0,dp(2));setAllCaps(false);stateListAnimator=null
            contentDescription="Impostazioni"
            background=roundedSurface(Color.rgb(248,249,251),18,Color.rgb(220,223,227),1);setOnClickListener{settings()}
        }
        titleRow.addView(settingsButton,LinearLayout.LayoutParams(dp(48),dp(42)))
        root.addView(titleRow,LinearLayout.LayoutParams(-1,dp(56)))
        // Navigazione principale compatta: le sezioni restano sempre riconoscibili,
        // mentre le etichette testuali vengono eliminate per recuperare spazio verticale.
        val navRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER}
        fun navButton(label:String,icon:View,active:Boolean=false,action:()->Unit):View{
            val b=LinearLayout(this).apply{
                orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;isClickable=true;isFocusable=true
                background=liquidInteractiveSurface(if(active)Color.rgb(232,243,255) else Color.rgb(247,249,251),18,if(active)Color.rgb(175,210,244) else Color.rgb(220,228,236),1)
                setPadding(0,dp(3),0,dp(2));setOnClickListener{action()}
            }
            b.addView(icon,LinearLayout.LayoutParams(dp(22),dp(22)).apply{gravity=Gravity.CENTER})
            b.addView(TextView(this).apply{text=label;textSize=8.5f;setTextColor(if(active)Color.rgb(20,95,175) else Color.rgb(88,96,106));gravity=Gravity.CENTER;setIncludeFontPadding(false)},LinearLayout.LayoutParams(-1,dp(13)))
            return b
        }
        navRow.addView(navButton("Clienti",ImageView(this).apply{setImageDrawable(whitePersonDrawable())},false){clientsScreen()},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,dp(2),dp(4),dp(4))})
        navRow.addView(navButton("Calendario",ImageView(this).apply{setImageDrawable(calendarIconDrawable(Color.rgb(45,105,170)))},false){calendarAutoFocusOnOpen=true;calendarSwipeArmed=0;calendarScreen()},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(2),dp(2),dp(2),dp(4))})
        navRow.addView(navButton("Pagamenti",TextView(this).apply{text="€";textSize=20f;setTextColor(Color.rgb(20,105,190));gravity=Gravity.CENTER},false){paymentsPlaceholderScreen()},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(4),dp(2),0,dp(4))})
        root.addView(navRow,LinearLayout.LayoutParams(-1,dp(54)))

        lateinit var searchWrap: LinearLayout
        val actionRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(4),0,dp(4))}
        val searchAction=softBlueButtonStyle("⌕  Cerca").apply{
            textSize=15f;contentDescription="Cerca cliente"
            setOnClickListener{
                actionRow.visibility=View.GONE;searchWrap.visibility=View.VISIBLE;searchInput.visibility=View.VISIBLE;searchInput.requestFocus()
                (getSystemService(Context.INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager)?.showSoftInput(searchInput,android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            }
        }
        actionRow.addView(searchAction,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(6),0)})
        actionRow.addView(softBlueButtonStyle("＋  Nuovo").apply{setOnClickListener{newPackageMenu()}},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(6),0,0,0)})
        root.addView(actionRow,LinearLayout.LayoutParams(-1,dp(56)))
        searchWrap=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;visibility=View.GONE}
        searchInput=modernEditText().apply{
            hint="Cerca cliente...";textSize=15f;setSingleLine(true);setPadding(dp(14),0,dp(14),0);background=roundedSurface(Color.WHITE,18,Color.rgb(226,229,234),1)
            addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){render()};override fun afterTextChanged(s:Editable?){}})
        }
        searchWrap.addView(searchInput,LinearLayout.LayoutParams(0,dp(48),1f))
        searchWrap.addView(buttonStyle("×").apply{textSize=24f;contentDescription="Chiudi ricerca";setOnClickListener{searchInput.setText("");searchWrap.visibility=View.GONE;actionRow.visibility=View.VISIBLE;(getSystemService(Context.INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager)?.hideSoftInputFromWindow(searchInput.windowToken,0)}},LinearLayout.LayoutParams(dp(48),dp(48)).apply{setMargins(dp(6),0,0,0)})
        root.addView(searchWrap,LinearLayout.LayoutParams(-1,dp(56)))
        list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,dp(4),0,dp(10))}
        val scroll=ScrollView(this).apply{addView(list,ViewGroup.LayoutParams(-1,-2))}
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))

        prepareEdgeToEdgeRoot(root)
        setContentView(root);render()
    }

    private fun updateDashboardButton(button:Button){button.text=if(dashboardEnabled)"DASH  ●" else "DASH  ○";button.background=appGlassSurface(if(dashboardEnabled)Color.rgb(235,241,248)else Color.rgb(248,249,250),18,Color.rgb(210,222,235),1)}

    private fun mainMoreMenu(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(4),dp(18),dp(8))}
        var optionsDialog: AlertDialog? = null
        var pendingOptionAction: (() -> Unit)? = null
        fun option(title:String,subtitle:String,icon:String,action:()->Unit){
            val row=LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL
                gravity=Gravity.CENTER_VERTICAL
                setPadding(dp(14),dp(12),dp(12),dp(12))
                background=roundedSurface(Color.rgb(246,248,250),20,Color.rgb(228,231,235),1)
                isClickable=true
                isFocusable=true
            }
            row.addView(TextView(this).apply{
                text=icon;textSize=22f;gravity=Gravity.CENTER
                setBackground(roundedSurface(Color.WHITE,16))
                setPadding(dp(8),dp(6),dp(8),dp(6))
            },LinearLayout.LayoutParams(dp(50),dp(50)))
            val texts=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
            texts.addView(TextView(this@MainActivity).apply{
                text=title;textSize=16f;setTextColor(Color.rgb(25,28,32))
                setTypeface(null,android.graphics.Typeface.BOLD)
            })
            texts.addView(TextView(this@MainActivity).apply{
                text=subtitle;textSize=12.5f;setTextColor(Color.rgb(100,104,110))
                setPadding(0,dp(3),0,0)
            })
            row.addView(texts,LinearLayout.LayoutParams(0,-2,1f))
            row.addView(TextView(this@MainActivity).apply{
                text="›";textSize=28f;setTextColor(Color.rgb(120,124,130));gravity=Gravity.CENTER
            },LinearLayout.LayoutParams(dp(28),dp(50)))
            row.setOnClickListener{
                pendingOptionAction=action
                optionsDialog?.dismiss()
            }
            box.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))})
        }
        option("Clienti","Modulo cliente • Schede • Importa","👤"){clientsScreen()}
        option("Backup e dati","Automatico • Esporta • Importa","☁"){backupMenu()}
        val trashCount=trashItems.size
        option("Cestino",if(trashCount==0)"Vuoto" else "$trashCount elementi • eliminazione automatica dopo 10 giorni","🗑"){trashScreen()}
        option("Impostazioni","Preferenze e gestione dell'app","⚙"){settings()}
        val close=Button(this).apply{
            text="Chiudi";setAllCaps(false);textSize=14f;setTextColor(Color.rgb(0,125,110))
            setBackgroundColor(Color.TRANSPARENT);stateListAnimator=null
        }
        box.addView(close,LinearLayout.LayoutParams(-1,dp(46)).apply{setMargins(0,dp(4),0,0)})
        val dialog=AlertDialog.Builder(this).setTitle("Altre opzioni").setView(box).create()
        optionsDialog=dialog
        preparePopupBackdrop(dialog)
        dialog.setOnShowListener{
            popupBackdropCurrentDialog=dialog
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28))
            applyPopupBackdropEffect(dialog)
            dialog.window?.setDimAmount(0.42f)
            close.setOnClickListener{dialog.dismiss()}
        }
        dialog.setOnDismissListener{
            removePopupBackdropDialog(dialog)
            optionsDialog=null
            val next=pendingOptionAction
            pendingOptionAction=null
            next?.invoke()
        }
        dialog.show()
    }

    private fun newPackageMenu(){
        // Unica finestra Glass. Il contenuto del form è già nella stessa gerarchia:
        // al click cambiamo solo la visibilità e allarghiamo la Window, senza creare
        // o rimuovere View durante l'interazione.
        val scroll=ScrollView(this).apply{isFillViewport=true;clipToPadding=false;overScrollMode=View.OVER_SCROLL_NEVER}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(8),dp(18),dp(12))}
        scroll.addView(box,ViewGroup.LayoutParams(-1,-2))

        val titleRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER}
        titleRow.addView(ImageView(this).apply{setImageDrawable(packageIconDrawable(Color.rgb(26,109,187)));setPadding(dp(3),dp(3),dp(3),dp(3))},LinearLayout.LayoutParams(dp(30),dp(30)).apply{setMargins(0,0,dp(9),0)})
        titleRow.addView(TextView(this).apply{text="Nuovo pacchetto";textSize=22f;setTextColor(Color.rgb(28,38,49));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.NORMAL)})
        box.addView(titleRow,LinearLayout.LayoutParams(-1,dp(38)))
        val packageSubtitle=TextView(this).apply{text="Scegli il tipo di pacchetto da creare";textSize=14f;setTextColor(Color.rgb(95,100,108));gravity=Gravity.CENTER;setPadding(0,0,0,dp(8))}
        box.addView(packageSubtitle,LinearLayout.LayoutParams(-1,dp(30)))

        val options=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        fun makeOption(title:String,subtitle:String,icon:String)=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(14),dp(12),dp(10),dp(12))
            background=liquidInteractiveSurface(Color.rgb(247,248,250),22,Color.rgb(222,226,232),1)
            applyLiquidControlDepth(this)
            isClickable=true;isFocusable=true
            val iconView=ImageView(this@MainActivity).apply{
                val style=when(icon){"PACKAGE_ICON"->"WEEK";"WEEKLY_CUSTOM_ICON"->"CUSTOM";else->"SESSIONS"}
                setImageDrawable(subtlePackageIconDrawable(style))
                setPadding(dp(9),dp(9),dp(9),dp(9))
                background=liquidInteractiveSurface(Color.rgb(247,248,250),16,Color.rgb(222,226,232),1)
                contentDescription=title
            }
            addView(iconView,LinearLayout.LayoutParams(dp(50),dp(50)))
            val texts=LinearLayout(this@MainActivity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
            texts.addView(TextView(this@MainActivity).apply{text=title;textSize=16f;setTextColor(Color.rgb(25,28,32));setTypeface(null,android.graphics.Typeface.BOLD)})
            texts.addView(TextView(this@MainActivity).apply{text=subtitle;textSize=12.5f;setTextColor(Color.rgb(100,104,110));setPadding(0,dp(3),0,0)})
            addView(texts,LinearLayout.LayoutParams(0,-2,1f))
            addView(TextView(this@MainActivity).apply{text="›";textSize=28f;setTextColor(Color.rgb(120,124,130));gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(28),dp(50)))
        }
        val weeklyOption=makeOption("Classico 12 settimane","3 rate • Bronze / Silver / Gold","PACKAGE_ICON")
        val weeklyCustomOption=makeOption("Settimanale su misura","Durata, frequenza e tipologie","WEEKLY_CUSTOM_ICON")
        val customOption=makeOption("Pacchetto a sedute","Sedute configurabili per tipologia","SESSION_CUSTOM_ICON")
        options.addView(weeklyOption,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))})
        options.addView(weeklyCustomOption,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))})
        options.addView(customOption,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))})
        box.addView(options)

        fun label(t:String)=TextView(this).apply{text=t;textSize=13f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(82,87,94));setPadding(dp(2),0,0,dp(4))}
        fun field(title:String,hint:String,inputTypeValue:Int=0):LinearLayout{
            val group=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
            group.addView(label(title))
            val edit=modernEditText().apply{this.hint=hint;inputType=if(inputTypeValue==0) android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS else inputTypeValue;setSingleLine(true);textSize=16f;setPadding(dp(14),0,dp(14),0)}
            group.addView(edit,LinearLayout.LayoutParams(-1,dp(52)))
            return group
        }

        val form=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE}
        val nameGroup=field("Cliente","Cognome e Nome")
        val name=nameGroup.getChildAt(1) as EditText
        val selectedClient=attachClientSuggestions(name,nameGroup)
        val dateGroup=field("Prima settimana","Seleziona la settimana di inizio",2)
        val dateLabel=dateGroup.getChildAt(0) as TextView
        val date=dateGroup.getChildAt(1) as EditText
        setupDateInput(date)
        date.setText(mondayOfWeek(LocalDate.now()).format(fmt))
        // Le due card condividono il vetro e si aprono inline, senza PopupWindow.
        // Chiudiamo l'altra card prima di aprirne una, evitando espansioni multiple.
        var closeActivePackageSelector: (() -> Unit)? = null
        fun beforeExpandPackageSelector(closeThis: () -> Unit) {
            closeActivePackageSelector?.invoke()
            closeActivePackageSelector = closeThis
        }
        fun afterCollapsePackageSelector() { closeActivePackageSelector = null }
        val typeGroup=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE}
        typeGroup.addView(label("Tipo pacchetto"))
        val type=Spinner(this).apply{
            adapter=centeredSpinnerAdapter(listOf("BRONZE • 12 sedute","SILVER • 24 sedute","GOLD • 36 sedute"))
        }
        typeGroup.addView(accordionPackageSelector(
            type,"Tipo pacchetto",scroll,::beforeExpandPackageSelector,::afterCollapsePackageSelector
        ),LinearLayout.LayoutParams(-1,-2))
        val includedTypeGroup=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE}
        includedTypeGroup.addView(label("Tipo di appuntamento incluso"))
        val includedType=Spinner(this).apply{
            val values=appointmentTypes.filter{it.name.isNotBlank()}.map{it.name}
            adapter=centeredSpinnerAdapter(values.ifEmpty{listOf("Nessun tipo disponibile")})
        }
        includedTypeGroup.addView(accordionPackageSelector(
            includedType,"Tipo appuntamento",scroll,::beforeExpandPackageSelector,::afterCollapsePackageSelector
        ),LinearLayout.LayoutParams(-1,-2))
        val sessionGroup=field("Sedute disponibili","Numero sedute",2).apply{visibility=View.GONE}
        val sessions=sessionGroup.getChildAt(1) as EditText
        val costGroup=field("Costo totale","Costo totale (€)",2)
        val cost=costGroup.getChildAt(1) as EditText
        form.addView(nameGroup,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})
        form.addView(dateGroup,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})
        form.addView(typeGroup,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})
        form.addView(includedTypeGroup,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})
        form.addView(sessionGroup,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})
        form.addView(costGroup,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(16))})
        val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val cancel=TextView(this).apply{text="ANNULLA";textSize=14f;setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);isClickable=true;background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(218,225,234),1);applyLiquidControlDepth(this)}
        val create=TextView(this).apply{text="CREA PACCHETTO";textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;isClickable=true;background=liquidInteractiveSurface(Color.rgb(232,243,255),20,Color.rgb(188,211,238),1);applyLiquidControlDepth(this)}
        buttons.addView(cancel,LinearLayout.LayoutParams(0,dp(48),1f));buttons.addView(create,LinearLayout.LayoutParams(0,dp(48),1.25f))
        form.addView(buttons,LinearLayout.LayoutParams(-1,dp(52)))
        box.addView(form,LinearLayout.LayoutParams(-1,-2))

        val close=Button(this).apply{text="Chiudi";setAllCaps(false);textSize=14f;setTextColor(Color.rgb(20,91,165));minHeight=0;minimumHeight=0;stateListAnimator=null;background=liquidInteractiveSurface(Color.rgb(247,248,250),18,Color.rgb(222,226,232),1);applyLiquidControlDepth(this)}
        box.addView(close,LinearLayout.LayoutParams(-1,dp(46)).apply{setMargins(0,dp(6),0,0)})

        val dialog=AlertDialog.Builder(this).setView(scroll).create()
        styleOneUiDialog(dialog)
        var initialPackageDraft = formDraftFingerprint(form)
        // Menu e form condividono lo STESSO materiale scelto in Impostazioni.
        // Nessun override di trasparenza, bordo o blur durante il cambio schermata.
        dialog.setOnShowListener{
            popupBackdropCurrentDialog=dialog
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28))
            applyPopupBackdropEffect(dialog)
            dialog.window?.setDimAmount(0.38f)
        }

        fun showPackageForm(weekly:Boolean){
            packageSubtitle.text=if(weekly)"Configura il pacchetto 12 settimane" else "Configura il pacchetto a sedute"
            options.visibility=View.GONE
            close.visibility=View.GONE
            form.visibility=View.VISIBLE
            typeGroup.visibility=if(weekly) View.VISIBLE else View.GONE
            includedTypeGroup.visibility=if(weekly) View.VISIBLE else View.GONE
            sessionGroup.visibility=if(weekly) View.GONE else View.VISIBLE
            if(weekly){
                val activeTypes=appointmentTypes.filter{it.name.isNotBlank()}
                includedType.adapter=centeredSpinnerAdapter(activeTypes.map{it.name}.ifEmpty{listOf("Nessun tipo disponibile")})
                if(activeTypes.isNotEmpty())includedType.setSelection(0)
            }
            dateLabel.text=if(weekly)"Prima settimana" else "Data di inizio"
            date.hint=if(weekly)"Seleziona la settimana di inizio" else "Data (gg/mm/aaaa)"
            date.isFocusable=!weekly
            date.isClickable=weekly
            date.isCursorVisible=!weekly
            if(weekly){
                date.setText(mondayOfWeek(LocalDate.now()).format(fmt))
                date.setCompoundDrawablesWithIntrinsicBounds(calendarIconDrawable(Color.rgb(20,91,165)),null,null,null)
                date.compoundDrawablePadding=dp(8)
            }else{
                date.setText(LocalDate.now().format(fmt))
                date.setCompoundDrawablesWithIntrinsicBounds(null,null,null,null)
            }
            // La scelta del tipo e la data proposta non sono modifiche dell'utente.
            initialPackageDraft = formDraftFingerprint(form)
            protectDraftBack(dialog,initialPackageDraft,form)
            form.requestLayout()
            scroll.post{
                val w=dialog.window ?: return@post
                val m=resources.displayMetrics
                w.setLayout((m.widthPixels*0.92f).toInt(),(m.heightPixels*0.86f).toInt())
                w.setGravity(Gravity.CENTER)
                w.attributes = w.attributes.apply { gravity = Gravity.CENTER; x = 0; y = dp(80) }
                scroll.fullScroll(View.FOCUS_UP)
            }
        }

        fun showWeeklyStartPicker(){
            val selectedStart=try{mondayOfWeek(parseDate(date.text.toString()))}catch(_:Exception){mondayOfWeek(LocalDate.now())}
            var workingWeek=selectedStart
            val dialog=Dialog(this)
            val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(16));background=dialogReadableSurface(Color.rgb(250,252,255),24,Color.rgb(198,220,242),1);clipToPadding=false}
            root.addView(TextView(this).apply{text="Seleziona la prima settimana";textSize=21f;setTextColor(Color.rgb(24,27,31));setTypeface(null,android.graphics.Typeface.BOLD)})
            root.addView(TextView(this).apply{text="Scegli direttamente una settimana. Il pacchetto partirà sempre dal lunedì selezionato.";textSize=13f;setTextColor(Color.rgb(82,96,112));setLineSpacing(0f,1.08f);setPadding(0,dp(4),0,dp(14))})

            val monthHeader=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            val prev=Button(this).apply{text="‹";setAllCaps(false);textSize=28f;setTextColor(Color.rgb(20,91,165));background=dialogReadableSurface(Color.rgb(240,247,255),18,Color.rgb(210,228,246),1);stateListAnimator=null}
            val monthTitle=TextView(this).apply{textSize=18f;gravity=Gravity.CENTER;setTextColor(Color.rgb(24,27,31));setTypeface(null,android.graphics.Typeface.BOLD)}
            val next=Button(this).apply{text="›";setAllCaps(false);textSize=28f;setTextColor(Color.rgb(20,91,165));background=dialogReadableSurface(Color.rgb(240,247,255),18,Color.rgb(210,228,246),1);stateListAnimator=null}
            monthHeader.addView(prev,LinearLayout.LayoutParams(dp(46),dp(46)));monthHeader.addView(monthTitle,LinearLayout.LayoutParams(0,dp(46),1f));monthHeader.addView(next,LinearLayout.LayoutParams(dp(46),dp(46)))
            root.addView(monthHeader)

            val dayHeader=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            dayHeader.addView(TextView(this).apply{text="Settimana";textSize=11f;setTextColor(Color.rgb(95,105,116));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(dp(76),dp(32)))
            listOf("Lun","Mar","Mer","Gio","Ven").forEach{label->dayHeader.addView(TextView(this).apply{text=label;textSize=11f;gravity=Gravity.CENTER;setTextColor(Color.rgb(35,43,53))},LinearLayout.LayoutParams(0,dp(32),1f))}
            root.addView(dayHeader)

            val weeksBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
            val weeksScroll=ScrollView(this).apply{isFillViewport=true;overScrollMode=View.OVER_SCROLL_IF_CONTENT_SCROLLS;addView(weeksBox)}
            root.addView(weeksScroll,LinearLayout.LayoutParams(-1,0,1f).apply{setMargins(0,0,0,dp(8))})

            val selectedInfo=TextView(this).apply{textSize=13f;setTextColor(Color.rgb(20,91,165));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);setPadding(0,dp(4),0,dp(10))}
            fun refreshSelectedInfo(){selectedInfo.text="Settimana: ${workingWeek.format(fmt)} → ${workingWeek.plusDays(4).format(fmt)}"}
            var shownMonth=workingWeek.withDayOfMonth(1)
            fun rebuildMonth(){
                monthTitle.text=shownMonth.format(DateTimeFormatter.ofPattern("MMMM yyyy",java.util.Locale.ITALIAN)).replaceFirstChar{it.uppercase()}
                weeksBox.removeAllViews()
                val first=shownMonth.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
                val last=shownMonth.withDayOfMonth(shownMonth.lengthOfMonth()).with(TemporalAdjusters.nextOrSame(DayOfWeek.MONDAY))
                var week=first
                while(!week.isAfter(last)){
                    val weekStart=week
                    val weekEnd=weekStart.plusDays(4)
                    val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(2),dp(4),dp(2),dp(4))}
                    val checked=weekStart==workingWeek
                    row.background=if(checked)dialogReadableSurface(Color.rgb(225,240,255),16,Color.rgb(85,157,224),1) else dialogReadableSurface(Color.rgb(252,253,255),16,Color.rgb(224,232,240),1)
                    row.addView(TextView(this).apply{text="${weekStart.format(DateTimeFormatter.ofPattern("dd/MM"))}";textSize=10.5f;setTextColor(if(checked)Color.rgb(20,91,165)else Color.rgb(95,105,116));gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(76),dp(48)))
                    for(i in 0..4){
                        val day=weekStart.plusDays(i.toLong())
                        row.addView(TextView(this).apply{text=day.dayOfMonth.toString();textSize=12f;gravity=Gravity.CENTER;setTextColor(if(checked)Color.rgb(20,91,165)else Color.rgb(35,43,53))},LinearLayout.LayoutParams(0,dp(48),1f))
                    }
                    row.setOnClickListener{workingWeek=weekStart;refreshSelectedInfo();rebuildMonth()}
                    weeksBox.addView(row,LinearLayout.LayoutParams(-1,dp(58)).apply{setMargins(0,0,0,dp(6))})
                    week=week.plusDays(7)
                }
            }
            prev.setOnClickListener{shownMonth=shownMonth.minusMonths(1);rebuildMonth()}
            next.setOnClickListener{shownMonth=shownMonth.plusMonths(1);rebuildMonth()}

            root.addView(selectedInfo)
            refreshSelectedInfo()

            val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            val cancel=Button(this).apply{text="Annulla";setAllCaps(false);textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,91,145));background=dialogReadableSurface(Color.rgb(245,249,253),17,Color.rgb(208,224,239),1);stateListAnimator=null}
            val done=Button(this).apply{text="Conferma";setAllCaps(false);textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.WHITE);background=roundedSurface(Color.rgb(30,112,230),17,Color.rgb(30,112,230),1);stateListAnimator=null}
            actions.addView(cancel,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(5),0)});actions.addView(done,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(5),0,0,0)})
            root.addView(actions)
            cancel.setOnClickListener{dialog.dismiss()}
            done.setOnClickListener{date.setText(workingWeek.format(fmt));dialog.dismiss()}
            dialog.setContentView(root)
            dialog.window?.let{w->w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));w.setLayout((resources.displayMetrics.widthPixels*0.94f).toInt(),(resources.displayMetrics.heightPixels*0.82f).toInt());w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)}
            dialog.setOnShowListener{dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.94f).toInt(),(resources.displayMetrics.heightPixels*0.82f).toInt())}
            rebuildMonth();dialog.show();dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.94f).toInt(),(resources.displayMetrics.heightPixels*0.82f).toInt())
        }

        date.setOnClickListener{if(typeGroup.visibility==View.VISIBLE)showWeeklyStartPicker()}
        weeklyOption.setOnClickListener{showPackageForm(true)}
        weeklyCustomOption.setOnClickListener{dialog.dismiss();newCustomWeeklyPack()}
        customOption.setOnClickListener{dialog.dismiss();newCustomSessionPack()}
        close.setOnClickListener{confirmDiscardDraft(dialog,initialPackageDraft,form)}
        cancel.setOnClickListener{confirmDiscardDraft(dialog,initialPackageDraft,form)}
        create.setOnClickListener{
            try{
                val n=enteredClientName(name.text.toString());val d=parseDate(date.text.toString());val c=cost.text.toString().trim().toInt();require(n.isNotEmpty()&&c>0)
                if(typeGroup.visibility==View.VISIBLE){
                    val k=when(type.selectedItemPosition){0->"BRONZE";1->"SILVER";else->"GOLD"}
                    val weeklyStart=mondayOfWeek(d)
                    val activeTypes=appointmentTypes.filter{it.name.isNotBlank()}
                    require(activeTypes.isNotEmpty())
                    val includedTypeId=activeTypes.getOrNull(includedType.selectedItemPosition)?.id ?: throw IllegalArgumentException("Tipo appuntamento non disponibile")
                    val created=Pack(n,weeklyStart,c,0,null,k,when(k){"BRONZE"->12;"SILVER"->24;else->36},true,0,12,mutableMapOf(),includedTypeId,selectedClient())
                    packs.add(created)
                    promptClientLinkAfterCreation(n,created.clientId){id->created.clientId=id}
                }else{
                    val total=sessions.text.toString().trim().toInt();require(total>0)
                    val created=SessionPack(nextSessionPackId++,n,d,total,c,0,true,clientId=selectedClient())
                    sessionPacks.add(created)
                    promptClientLinkAfterCreation(n,created.clientId){id->created.clientId=id}
                }
                saveData();render();dialog.dismiss()
            }catch(_:Exception){Toast.makeText(this,if(typeGroup.visibility==View.VISIBLE)"Controlla nome, data, tipo e costo." else "Controlla nome, data, numero sedute e costo.",Toast.LENGTH_LONG).show()}
        }
        listOf<View>(name,date,sessions,cost).forEach{field->field.setOnFocusChangeListener{_,hasFocus->if(hasFocus)scroll.post{scroll.smoothScrollTo(0,(field.top-dp(24)).coerceAtLeast(0))}}}
        dialog.show()
    }

    private fun newSessionPack(){
        val page=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(8),dp(18),dp(12))}
        val scroll=ScrollView(this).apply{isFillViewport=true;clipToPadding=false}
        scroll.addView(page,ViewGroup.LayoutParams(-1,-2))
        // Il titolo e\"Nuovo pacchetto sedute\" non viene ripetuto: la card introduttiva identifica gia il tipo di pacchetto.
        val intro=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(12));background=roundedSurface(Color.rgb(239,247,255),20,Color.rgb(205,224,248),1)}
        intro.addView(TextView(this).apply{text="🏋️";textSize=22f;gravity=Gravity.CENTER;setBackground(roundedSurface(Color.WHITE,16));setPadding(dp(8),dp(6),dp(8),dp(6))},LinearLayout.LayoutParams(dp(50),dp(50)))
        val introText=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
        introText.addView(TextView(this@MainActivity).apply{text="Pacchetto a sedute";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,55,85))})
        introText.addView(TextView(this@MainActivity).apply{text="Pagamento unico • consumo sincronizzato con il calendario";textSize=12.5f;setTextColor(Color.rgb(75,100,125));setPadding(0,dp(3),0,0)})
        intro.addView(introText,LinearLayout.LayoutParams(0,-2,1f));page.addView(intro,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(16))})
        fun field(title:String,hint:String,inputTypeValue:Int=0):EditText{
            page.addView(TextView(this).apply{text=title;textSize=13f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(82,87,94));setPadding(dp(2),0,0,dp(4))})
            return modernEditText().apply{this.hint=hint;inputType=if(inputTypeValue==0) android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS else inputTypeValue;setSingleLine(true);textSize=16f;setPadding(dp(14),0,dp(14),0)}
        }
        val name=field("Cliente","Cognome e Nome").apply{
            isFocusable=true
            isFocusableInTouchMode=true
            isClickable=true
            showSoftInputOnFocus=true
            setOnTouchListener { v, event ->
                if(event.action == android.view.MotionEvent.ACTION_DOWN){
                    v.requestFocusFromTouch()
                }
                false
            }
        }
        page.addView(name,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(12))})
        val selectedClient=attachClientSuggestions(name,page)
        val date=field("Data di inizio","Data (gg/mm/aaaa)",2);setupDateInput(date);date.setText(LocalDate.now().format(fmt))
        page.addView(date,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(12))})
        val sessions=field("Sedute disponibili","Numero sedute",2)
        page.addView(sessions,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(12))})
        val cost=field("Importo del pacchetto","Costo totale (€)",2)
        page.addView(cost,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(16))})
        val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val cancel=TextView(this).apply{text="ANNULLA";textSize=14f;setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);isClickable=true;background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(218,225,234),1);applyLiquidControlDepth(this)}
        val create=TextView(this).apply{text="CREA PACCHETTO";textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;isClickable=true;background=liquidInteractiveSurface(Color.rgb(232,243,255),20,Color.rgb(188,211,238),1);applyLiquidControlDepth(this)}
        buttons.addView(cancel,LinearLayout.LayoutParams(0,dp(48),1f));buttons.addView(create,LinearLayout.LayoutParams(0,dp(48),1.25f))
        page.addView(buttons,LinearLayout.LayoutParams(-1,dp(52)))
        val dialog=AlertDialog.Builder(this).setView(scroll).create()
        styleFullPageCoachDialog(dialog)
        // Il focus iniziale resta sulla pagina: il primo tocco sul nome deve
        // dare subito focus al campo e aprire la tastiera.
        scroll.isFocusableInTouchMode=true
        scroll.requestFocus()
        dialog.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        cancel.setOnClickListener{dialog.dismiss();window.decorView.post{newPackageMenu()}}
        create.setOnClickListener{
            try{val n=enteredClientName(name.text.toString());val d=parseDate(date.text.toString());val total=sessions.text.toString().trim().toInt();val c=cost.text.toString().trim().toInt();require(n.isNotEmpty()&&total>0&&c>0)
                val created=SessionPack(nextSessionPackId++,n,d,total,c,0,true,clientId=selectedClient())
                sessionPacks.add(created);saveData();render();dialog.dismiss()
                promptClientLinkAfterCreation(n,created.clientId){id->created.clientId=id}
            }catch(_:Exception){Toast.makeText(this,"Controlla nome, data, numero sedute e costo.",Toast.LENGTH_LONG).show()}
        }
        listOf<View>(name,date,sessions,cost).forEach{field->
            field.setOnFocusChangeListener{view,hasFocus->
                if(hasFocus){
                    scroll.post{scroll.smoothScrollTo(0,(field.top-dp(24)).coerceAtLeast(0))}
                }
            }
        }
        dialog.show()
        dialog.window?.decorView?.post{ name.clearFocus(); scroll.requestFocus(); val imm=getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager; imm.hideSoftInputFromWindow(name.windowToken,0) }
    }

    private fun newCustomWeeklyPack(){
        ensureAppointmentTypes()
        val page=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(8),dp(18),dp(12))}
        val scroll=ScrollView(this).apply{
            isFillViewport=true
            clipToPadding=false
            isVerticalScrollBarEnabled=false
            overScrollMode=View.OVER_SCROLL_NEVER
            // L'editor deve restare fisicamente fermo quando si apre/chiude un
            // secondo popup (ora, conferma eliminazione). Evitiamo qualsiasi
            // scroll automatico causato dal focus/re-layout della finestra.
            descendantFocusability=ViewGroup.FOCUS_AFTER_DESCENDANTS
            addView(page,ViewGroup.LayoutParams(-1,-1))
        }
        val intro=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(12));background=roundedSurface(Color.rgb(239,247,255),20,Color.rgb(205,224,248),1)}
        intro.addView(TextView(this).apply{text="✦";textSize=22f;gravity=Gravity.CENTER;setTextColor(Color.rgb(20,105,190));setBackground(roundedSurface(Color.WHITE,16));setPadding(dp(8),dp(6),dp(8),dp(6))},LinearLayout.LayoutParams(dp(50),dp(50)))
        val introText=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
        introText.addView(TextView(this).apply{text="Pacchetto settimanale personalizzato";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,55,85))})
        introText.addView(TextView(this).apply{text="Costruisci la tua settimana tipo: settimane, quantità e tipologie";textSize=12.5f;setTextColor(Color.rgb(75,100,125));setPadding(0,dp(3),0,0)})
        intro.addView(introText,LinearLayout.LayoutParams(0,-2,1f));page.addView(intro,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(16))})
        fun label(t:String)=TextView(this).apply{text=t;textSize=13f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(82,87,94));setPadding(dp(2),0,0,dp(4))}
        page.addView(label("Cliente"))
        val name=modernEditText().apply{hint="Cognome e Nome";inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS;setSingleLine(true);textSize=16f;setPadding(dp(14),0,dp(14),0)}
        page.addView(name,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(12))})
        val selectedClient=attachClientSuggestions(name,page)
        page.addView(label("Prima settimana"))
        val date=modernEditText().apply{hint="Seleziona la settimana di inizio";inputType=2;setSingleLine(true);textSize=16f;setPadding(dp(14),0,dp(14),0);isFocusable=false;isClickable=true}
        date.setText(mondayOfWeek(LocalDate.now()).format(fmt));date.setCompoundDrawablesWithIntrinsicBounds(calendarIconDrawable(Color.rgb(20,91,165)),null,null,null);date.compoundDrawablePadding=dp(8)
        page.addView(date,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(12))})
        page.addView(label("Durata del pacchetto (settimane)"))
        val weeks=modernEditText().apply{hint="Numero settimane";inputType=2;setSingleLine(true);textSize=16f;setText("12");setPadding(dp(14),0,dp(14),0)}
        page.addView(weeks,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(12))})
        page.addView(label("Appuntamenti per settimana"))
        val weeklyTotal=TextView(this).apply{text="Totale settimana: 0";textSize=13f;setTextColor(Color.rgb(25,91,145));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(dp(2),0,0,dp(8))}
        page.addView(weeklyTotal)
        page.addView(TextView(this).apply{text="Distribuisci gli appuntamenti tra i tipi attivi nelle Impostazioni. La somma delle quantità è la tua settimana tipo.";textSize=12.5f;setTextColor(Color.rgb(95,100,108));setPadding(dp(2),0,dp(2),dp(10))})
        val rows=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val quantityFields=mutableMapOf<String,EditText>()
        appointmentTypes.forEach{t->
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),dp(6),dp(8),dp(6));background=roundedSurface(Color.rgb(248,250,253),18,Color.rgb(224,230,238),1)}
            row.addView(TextView(this).apply{text=t.name;textSize=14.5f;setTextColor(Color.rgb(35,40,48));setPadding(0,0,0,0)},LinearLayout.LayoutParams(0,dp(52),1f))
            val q=modernEditText().apply{hint="0";inputType=2;setSingleLine(true);gravity=Gravity.CENTER;textSize=15f;setText("0");setPadding(dp(8),0,dp(8),0)}
            quantityFields[t.id]=q;row.addView(q,LinearLayout.LayoutParams(dp(72),dp(48)));rows.addView(row,LinearLayout.LayoutParams(-1,dp(64)).apply{setMargins(0,0,0,dp(6))})
        }
        page.addView(rows,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})
        fun updateWeeklyTotal(){val total=quantityFields.values.sumOf{it.text.toString().toIntOrNull()?.coerceAtLeast(0)?:0};weeklyTotal.text="Totale settimana: $total appuntamenti"}
        quantityFields.values.forEach{e->e.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){updateWeeklyTotal()};override fun afterTextChanged(s:Editable?){} })}
        page.addView(label("Costo totale del pacchetto"))
        val cost=modernEditText().apply{hint="Costo totale (€)";inputType=2;setSingleLine(true);textSize=16f;setPadding(dp(14),0,dp(14),0)}
        page.addView(cost,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(16))})
        val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val cancel=TextView(this).apply{text="ANNULLA";textSize=14f;setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(218,225,234),1);isClickable=true;applyLiquidControlDepth(this)}
        val create=TextView(this).apply{text="CREA PACCHETTO";textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;background=liquidInteractiveSurface(Color.rgb(232,243,255),20,Color.rgb(188,211,238),1);isClickable=true;applyLiquidControlDepth(this)}
        buttons.addView(cancel,LinearLayout.LayoutParams(0,dp(48),1f));buttons.addView(create,LinearLayout.LayoutParams(0,dp(48),1.25f));page.addView(buttons,LinearLayout.LayoutParams(-1,dp(52)))
        val dialog=AlertDialog.Builder(this).setView(scroll).create();styleFullPageCoachDialog(dialog)
        val initialWeeklyDraft = formDraftFingerprint(page)
        protectDraftBack(dialog,initialWeeklyDraft,page)
        date.setOnClickListener{
            val selectedStart=try{mondayOfWeek(parseDate(date.text.toString()))}catch(_:Exception){mondayOfWeek(LocalDate.now())}
            var workingWeek=selectedStart
            val picker=Dialog(this)
            val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(16));background=dialogReadableSurface(Color.rgb(250,252,255),24,Color.rgb(198,220,242),1);clipToPadding=false}
            root.addView(TextView(this).apply{text="Seleziona la prima settimana";textSize=21f;setTextColor(Color.rgb(24,27,31));setTypeface(null,android.graphics.Typeface.BOLD)})
            root.addView(TextView(this).apply{text="Scegli direttamente una settimana. Il pacchetto partirà sempre dal lunedì selezionato.";textSize=13f;setTextColor(Color.rgb(82,96,112));setLineSpacing(0f,1.08f);setPadding(0,dp(4),0,dp(14))})
            val monthHeader=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            val prev=Button(this).apply{text="‹";setAllCaps(false);textSize=28f;setTextColor(Color.rgb(20,91,165));background=dialogReadableSurface(Color.rgb(240,247,255),18,Color.rgb(210,228,246),1);stateListAnimator=null}
            val monthTitle=TextView(this).apply{textSize=18f;gravity=Gravity.CENTER;setTextColor(Color.rgb(24,27,31));setTypeface(null,android.graphics.Typeface.BOLD)}
            val next=Button(this).apply{text="›";setAllCaps(false);textSize=28f;setTextColor(Color.rgb(20,91,165));background=dialogReadableSurface(Color.rgb(240,247,255),18,Color.rgb(210,228,246),1);stateListAnimator=null}
            monthHeader.addView(prev,LinearLayout.LayoutParams(dp(46),dp(46)));monthHeader.addView(monthTitle,LinearLayout.LayoutParams(0,dp(46),1f));monthHeader.addView(next,LinearLayout.LayoutParams(dp(46),dp(46)));root.addView(monthHeader)
            val dayHeader=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            dayHeader.addView(TextView(this).apply{text="Settimana";textSize=11f;setTextColor(Color.rgb(95,105,116));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(dp(76),dp(32)))
            listOf("Lun","Mar","Mer","Gio","Ven").forEach{dlabel->dayHeader.addView(TextView(this).apply{text=dlabel;textSize=11f;gravity=Gravity.CENTER;setTextColor(Color.rgb(35,43,53))},LinearLayout.LayoutParams(0,dp(32),1f))}
            root.addView(dayHeader)
            val weeksBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
            val weeksScroll=ScrollView(this).apply{isFillViewport=true;overScrollMode=View.OVER_SCROLL_IF_CONTENT_SCROLLS;addView(weeksBox)}
            root.addView(weeksScroll,LinearLayout.LayoutParams(-1,0,1f).apply{setMargins(0,0,0,dp(8))})
            val selectedInfo=TextView(this).apply{textSize=13f;setTextColor(Color.rgb(20,91,165));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);setPadding(0,dp(4),0,dp(10))}
            fun refreshSelectedInfo(){selectedInfo.text="Settimana: ${workingWeek.format(fmt)} → ${workingWeek.plusDays(4).format(fmt)}"}
            var shownMonth=workingWeek.withDayOfMonth(1)
            fun rebuildMonth(){
                monthTitle.text=shownMonth.format(DateTimeFormatter.ofPattern("MMMM yyyy",java.util.Locale.ITALIAN)).replaceFirstChar{it.uppercase()}
                weeksBox.removeAllViews()
                val first=shownMonth.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
                val last=shownMonth.withDayOfMonth(shownMonth.lengthOfMonth()).with(TemporalAdjusters.nextOrSame(DayOfWeek.MONDAY))
                var week=first
                while(!week.isAfter(last)){
                    val weekStart=week
                    val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(2),dp(4),dp(2),dp(4))}
                    val checked=weekStart==workingWeek
                    row.background=if(checked)dialogReadableSurface(Color.rgb(225,240,255),16,Color.rgb(85,157,224),1) else dialogReadableSurface(Color.rgb(252,253,255),16,Color.rgb(224,232,240),1)
                    row.addView(TextView(this).apply{text="${weekStart.format(DateTimeFormatter.ofPattern("dd/MM"))}";textSize=10.5f;setTextColor(if(checked)Color.rgb(20,91,165)else Color.rgb(95,105,116));gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(76),dp(48)))
                    for(i in 0..4){val day=weekStart.plusDays(i.toLong());row.addView(TextView(this).apply{text=day.dayOfMonth.toString();textSize=12f;gravity=Gravity.CENTER;setTextColor(if(checked)Color.rgb(20,91,165)else Color.rgb(35,43,53))},LinearLayout.LayoutParams(0,dp(48),1f))}
                    row.setOnClickListener{workingWeek=weekStart;refreshSelectedInfo();rebuildMonth()}
                    weeksBox.addView(row,LinearLayout.LayoutParams(-1,dp(58)).apply{setMargins(0,0,0,dp(6))})
                    week=week.plusDays(7)
                }
            }
            prev.setOnClickListener{shownMonth=shownMonth.minusMonths(1);rebuildMonth()}
            next.setOnClickListener{shownMonth=shownMonth.plusMonths(1);rebuildMonth()}
            root.addView(selectedInfo);refreshSelectedInfo()
            val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            val cancelPicker=Button(this).apply{text="Annulla";setAllCaps(false);textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,91,145));background=dialogReadableSurface(Color.rgb(245,249,253),17,Color.rgb(208,224,239),1);stateListAnimator=null}
            val donePicker=Button(this).apply{text="Conferma";setAllCaps(false);textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.WHITE);background=roundedSurface(Color.rgb(30,112,230),17,Color.rgb(30,112,230),1);stateListAnimator=null}
            actions.addView(cancelPicker,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(5),0)});actions.addView(donePicker,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(5),0,0,0)});root.addView(actions)
            cancelPicker.setOnClickListener{picker.dismiss()}
            donePicker.setOnClickListener{date.setText(workingWeek.format(fmt));picker.dismiss()}
            picker.setContentView(root);picker.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));picker.setOnShowListener{picker.window?.setLayout((resources.displayMetrics.widthPixels*0.94f).toInt(),(resources.displayMetrics.heightPixels*0.82f).toInt())};rebuildMonth();picker.show();picker.window?.setLayout((resources.displayMetrics.widthPixels*0.94f).toInt(),(resources.displayMetrics.heightPixels*0.82f).toInt())
        }
        cancel.setOnClickListener{confirmDiscardDraft(dialog,initialWeeklyDraft,page)}
        create.setOnClickListener{
            try{
                val n=enteredClientName(name.text.toString());val d=mondayOfWeek(parseDate(date.text.toString()));val w=weeks.text.toString().trim().toInt();val c=cost.text.toString().trim().toInt();require(n.isNotEmpty()&&w>0&&c>0)
                val q=mutableMapOf<String,Int>();quantityFields.forEach{(id,e)->val v=e.text.toString().trim().toIntOrNull()?:0;if(v>0)q[id]=v};require(q.isNotEmpty());val perWeek=q.values.sum();require(perWeek>0)
                val totalSessions=perWeek*w
                // Per i pacchetti settimanali il campo total rappresenta il costo,
                // mentre sessionTotal rappresenta il numero complessivo di sedute.
                // Prima erano invertiti: €900 diventava il totale sedute/costo e le rate risultavano errate.
                val created=Pack(n,d,c,0,null,"WEEKLY_CUSTOM",totalSessions,true,0,w,q,clientId=selectedClient())
                packs.add(created);saveData();render();dialog.dismiss()
                promptClientLinkAfterCreation(n,created.clientId){id->created.clientId=id}
            }catch(_:Exception){Toast.makeText(this,"Controlla nome, settimane, quantità e costo.",Toast.LENGTH_LONG).show()}
        }
        dialog.show();dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.94f).toInt(),(resources.displayMetrics.heightPixels*0.88f).toInt())
    }

    private fun newCustomSessionPack(){
        ensureAppointmentTypes()
        val page=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(8),dp(18),dp(12))}
        val scroll=ScrollView(this).apply{isFillViewport=true;clipToPadding=false;addView(page,ViewGroup.LayoutParams(-1,-2))}
        val intro=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(12));background=roundedSurface(Color.rgb(239,247,255),20,Color.rgb(205,224,248),1)}
        intro.addView(TextView(this).apply{text="✦";textSize=22f;gravity=Gravity.CENTER;setTextColor(Color.rgb(20,105,190));setBackground(roundedSurface(Color.WHITE,16));setPadding(dp(8),dp(6),dp(8),dp(6))},LinearLayout.LayoutParams(dp(50),dp(50)))
        val introText=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
        introText.addView(TextView(this).apply{text="Pacchetto personalizzato";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,55,85))})
        introText.addView(TextView(this).apply{text="Quantità indipendenti per ogni tipo di appuntamento";textSize=12.5f;setTextColor(Color.rgb(75,100,125));setPadding(0,dp(3),0,0)})
        intro.addView(introText,LinearLayout.LayoutParams(0,-2,1f));page.addView(intro,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(16))})
        fun label(t:String)=TextView(this).apply{text=t;textSize=13f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(82,87,94));setPadding(dp(2),0,0,dp(4))}
        page.addView(label("Cliente"))
        val name=modernEditText().apply{hint="Cognome e Nome";inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS;setSingleLine(true);textSize=16f;setPadding(dp(14),0,dp(14),0)}
        page.addView(name,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(12))})
        val selectedClient=attachClientSuggestions(name,page)
        page.addView(label("Data di inizio"))
        val date=modernEditText().apply{hint="Data (gg/mm/aaaa)";inputType=2;setSingleLine(true);textSize=16f;setPadding(dp(14),0,dp(14),0)}
        setupDateInput(date);date.setText(LocalDate.now().format(fmt));page.addView(date,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(14))})
        page.addView(label("Tipologie incluse nel pacchetto"))
        page.addView(TextView(this).apply{text="Seleziona i tipi attivi e indica quante sedute acquistate comprende ciascuno.";textSize=12.5f;setTextColor(Color.rgb(95,100,108));setPadding(dp(2),0,dp(2),dp(10))})
        val rows=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val quantityFields=mutableMapOf<String,EditText>()
        val checks=mutableMapOf<String,CheckBox>()
        appointmentTypes.forEach{t->
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),dp(6),dp(8),dp(6));background=roundedSurface(Color.rgb(248,250,253),18,Color.rgb(224,230,238),1)}
            val cb=CheckBox(this).apply{text=t.name;textSize=14.5f;setTextColor(Color.rgb(35,40,48));setPadding(0,0,0,0)}
            val q=modernEditText().apply{hint="0";inputType=2;setSingleLine(true);gravity=Gravity.CENTER;textSize=15f;isEnabled=false;setText("0");setPadding(dp(8),0,dp(8),0)}
            cb.setOnCheckedChangeListener{_,checked->q.isEnabled=checked;if(!checked)q.setText("0")}
            checks[t.id]=cb;quantityFields[t.id]=q
            row.addView(cb,LinearLayout.LayoutParams(0,dp(52),1f));row.addView(q,LinearLayout.LayoutParams(dp(72),dp(48)))
            rows.addView(row,LinearLayout.LayoutParams(-1,dp(64)).apply{setMargins(0,0,0,dp(6))})
        }
        page.addView(rows,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})
        val totalInfo=TextView(this).apply{text="Totale sedute: 0";textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,91,145));gravity=Gravity.CENTER;setPadding(0,dp(5),0,dp(10))}
        page.addView(totalInfo,LinearLayout.LayoutParams(-1,dp(36)))
        fun updateTotal(){var total=0;quantityFields.forEach{(_,e)->if(e.isEnabled)total+=e.text.toString().toIntOrNull()?:0};totalInfo.text="Totale sedute: $total"}
        quantityFields.values.forEach{e->e.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){updateTotal()};override fun afterTextChanged(s:Editable?){} })}
        val costLabel=label("Importo del pacchetto");page.addView(costLabel)
        val cost=modernEditText().apply{hint="Costo totale (€)";inputType=2;setSingleLine(true);textSize=16f;setPadding(dp(14),0,dp(14),0)}
        page.addView(cost,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(16))})
        val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val cancel=TextView(this).apply{text="ANNULLA";textSize=14f;setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(218,225,234),1);isClickable=true;applyLiquidControlDepth(this)}
        val create=TextView(this).apply{text="CREA PACCHETTO";textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;background=liquidInteractiveSurface(Color.rgb(232,243,255),20,Color.rgb(188,211,238),1);isClickable=true;applyLiquidControlDepth(this)}
        buttons.addView(cancel,LinearLayout.LayoutParams(0,dp(48),1f));buttons.addView(create,LinearLayout.LayoutParams(0,dp(48),1.25f));page.addView(buttons,LinearLayout.LayoutParams(-1,dp(52)))
        val dialog=AlertDialog.Builder(this).setView(scroll).create();styleFullPageCoachDialog(dialog)
        val initialSessionsDraft = formDraftFingerprint(page)
        protectDraftBack(dialog,initialSessionsDraft,page)
        cancel.setOnClickListener{confirmDiscardDraft(dialog,initialSessionsDraft,page)}
        create.setOnClickListener{
            try{
                val n=enteredClientName(name.text.toString());val d=parseDate(date.text.toString());val c=cost.text.toString().trim().toInt();require(n.isNotEmpty()&&c>0)
                val q=mutableMapOf<String,Int>();quantityFields.forEach{(id,e)->if(checks[id]?.isChecked==true){val v=e.text.toString().trim().toInt();require(v>0);q[id]=v}}
                require(q.isNotEmpty())
                val total=q.values.sum()
                val created=SessionPack(nextSessionPackId++,n,d,total,c,0,true,null,q,selectedClient())
                sessionPacks.add(created);saveData();render();dialog.dismiss()
                promptClientLinkAfterCreation(n,created.clientId){id->created.clientId=id}
            }catch(_:Exception){Toast.makeText(this,"Seleziona almeno un tipo, inserisci quantità valide e controlla il costo.",Toast.LENGTH_LONG).show()}
        }
        dialog.show();dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.94f).toInt(),(resources.displayMetrics.heightPixels*0.86f).toInt())
    }

    private fun normalizeDisplayName(value:String):String{
        return value.trim().split(Regex("\\s+")).filter{it.isNotBlank()}.joinToString(" "){word->
            word.lowercase().replaceFirstChar{if(it.isLowerCase())it.titlecase() else it.toString()}
        }
    }

    private fun identityKey(value:String):String{
        return value.trim().lowercase().split(Regex("\\s+")).filter{it.isNotBlank()}.sorted().joinToString(" ")
    }

    private fun newPack(){
        val page=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(8),dp(18),dp(12))}
        val scroll=ScrollView(this).apply{isFillViewport=true;clipToPadding=false}
        scroll.addView(page,ViewGroup.LayoutParams(-1,-2))
        // Il titolo e\"Nuovo pacchetto 12 settimane\" non viene ripetuto: la card introduttiva identifica gia il tipo di pacchetto.
        val intro=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(12));background=roundedSurface(Color.rgb(239,247,255),20,Color.rgb(205,224,248),1)}
        intro.addView(TextView(this).apply{text="📦";textSize=22f;gravity=Gravity.CENTER;setBackground(roundedSurface(Color.WHITE,16));setPadding(dp(8),dp(6),dp(8),dp(6))},LinearLayout.LayoutParams(dp(50),dp(50)))
        val it=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
        it.addView(TextView(this@MainActivity).apply{text="Pacchetto 12 settimane";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,55,85))})
        it.addView(TextView(this@MainActivity).apply{text="Bronze • Silver • Gold • programmazione dal calendario";textSize=12.5f;setTextColor(Color.rgb(75,100,125));setPadding(0,dp(3),0,0)})
        intro.addView(it,LinearLayout.LayoutParams(0,-2,1f));page.addView(intro,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(16))})
        fun label(t:String)=TextView(this).apply{text=t;textSize=13f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(82,87,94));setPadding(dp(2),0,0,dp(4))}
        val name=modernEditText().apply{hint="Cognome e Nome";setSingleLine(true);textSize=16f}
        val date=modernEditText().apply{hint="Data di inizio (gg/mm/aaaa)";inputType=2;setSingleLine(true);textSize=16f};setupDateInput(date);date.setText(LocalDate.now().format(fmt));date.setOnFocusChangeListener{_,hasFocus->if(!hasFocus)runCatching{date.setText(mondayOfWeek(parseDate(date.text.toString())).format(fmt))}}
        val type=Spinner(this).also{installNikiTypeDropdown(it, true, true)}.apply{adapter=centeredSpinnerAdapter(listOf("BRONZE • 12 sedute","SILVER • 24 sedute","GOLD • 36 sedute"))}
        val cost=modernEditText().apply{hint="Costo totale (€)";inputType=2;setSingleLine(true);textSize=16f}
        page.addView(label("Cliente"));page.addView(name,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(12))})
        val selectedClient=attachClientSuggestions(name,page)
        page.addView(label("Data di inizio"));page.addView(date,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(12))})
        page.addView(label("Tipo pacchetto"));page.addView(type,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(12))})
        page.addView(label("Costo totale"));page.addView(cost,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(16))})
        val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val cancel=TextView(this).apply{text="ANNULLA";textSize=14f;setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);isClickable=true;background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(218,225,234),1);applyLiquidControlDepth(this)}
        val create=TextView(this).apply{text="CREA PACCHETTO";textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;isClickable=true;background=liquidInteractiveSurface(Color.rgb(232,243,255),20,Color.rgb(188,211,238),1);applyLiquidControlDepth(this)}
        buttons.addView(cancel,LinearLayout.LayoutParams(0,dp(48),1f));buttons.addView(create,LinearLayout.LayoutParams(0,dp(48),1.25f));page.addView(buttons,LinearLayout.LayoutParams(-1,dp(52)))
        val dialog=AlertDialog.Builder(this).setView(scroll).create();styleFullPageCoachDialog(dialog)
        scroll.isFocusableInTouchMode=true
        scroll.requestFocus()
        dialog.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        cancel.setOnClickListener{dialog.dismiss();window.decorView.post{newPackageMenu()}}
        create.setOnClickListener{try{val n=enteredClientName(name.text.toString());val d=mondayOfWeek(parseDate(date.text.toString()));val c=cost.text.toString().trim().toInt();require(n.isNotEmpty()&&c>0);val kind=when(type.selectedItemPosition){0->"BRONZE";1->"SILVER";else->"GOLD"};val created=Pack(n,d,c,0,null,kind,when(kind){"BRONZE"->12;"SILVER"->24;else->36},true,clientId=selectedClient())
                packs.add(created);saveData();render();dialog.dismiss()
                promptClientLinkAfterCreation(n,created.clientId){id->created.clientId=id}}catch(_:Exception){Toast.makeText(this,"Controlla nome, data, tipo e costo.",Toast.LENGTH_LONG).show()}}
        listOf<View>(name,date,cost).forEach{field->field.setOnFocusChangeListener{_,hasFocus->if(hasFocus)scroll.post{scroll.smoothScrollTo(0,(field.top-dp(24)).coerceAtLeast(0))}}}
        dialog.show()
        dialog.window?.decorView?.post{ name.clearFocus(); scroll.requestFocus(); val imm=getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager; imm.hideSoftInputFromWindow(name.windowToken,0) }
    }

    private fun setupDateInput(edit:EditText){edit.addTextChangedListener(object:TextWatcher{private var editing=false;override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){};override fun afterTextChanged(s:Editable?){if(editing||s==null)return;val digits=s.toString().filter{it.isDigit()}.take(8);val formatted=buildString{digits.forEachIndexed{i,c->if(i==2||i==4)append('/');append(c)}};if(formatted!=s.toString()){editing=true;edit.setText(formatted);edit.setSelection(formatted.length);editing=false}}})}
    private fun mondayOfWeek(date:LocalDate):LocalDate = date.minusDays((date.dayOfWeek.value - 1).toLong())
    private fun parseDate(value:String):LocalDate=LocalDate.parse(value.trim(),fmt)

    private fun prepareSettingsSystemBars(){
        // Prima di mostrare la finestra Settings rendiamo già la system bar della
        // Activity sottostante identica a quella delle Settings. In questo modo
        // durante il passaggio non rimane per un attimo la Home con icone bianche
        // sotto al nuovo pannello bianco.
        window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor=Color.WHITE
        window.navigationBarColor=Color.WHITE
        if(android.os.Build.VERSION.SDK_INT >= 28) window.navigationBarDividerColor=Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        if(android.os.Build.VERSION.SDK_INT >= 30){
            window.insetsController?.setSystemBarsAppearance(
                android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,
                android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            )
        }
    }

    private fun restoreSettingsSystemBars(){
        window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor=Color.TRANSPARENT
        window.navigationBarColor=Color.TRANSPARENT
        if(android.os.Build.VERSION.SDK_INT >= 28) window.navigationBarDividerColor=Color.TRANSPARENT
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        if(android.os.Build.VERSION.SDK_INT >= 30){
            window.insetsController?.setSystemBarsAppearance(
                android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,
                android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            )
            window.setDecorFitsSystemWindows(false)
        }
    }

    private fun restoreHomeSystemBars(){
        window.statusBarColor=Color.TRANSPARENT
        window.navigationBarColor=Color.TRANSPARENT
        if(android.os.Build.VERSION.SDK_INT >= 28) window.navigationBarDividerColor=Color.TRANSPARENT
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        if(android.os.Build.VERSION.SDK_INT >= 30){
            window.insetsController?.setSystemBarsAppearance(
                android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,
                android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            )
        }
    }

    private fun detachSettingsOverlay(){
        settingsSubpageOverlay?.let { page ->
            (page.parent as? ViewGroup)?.removeView(page)
        }
        settingsSubpageOverlay=null
        settingsOverlay?.let { overlay ->
            (overlay.parent as? ViewGroup)?.removeView(overlay)
        }
        settingsOverlay=null
        settingsOverlayContent=null
        settingsTransitionPending=false
    }

    private fun weeklyCustomPackageIconDrawable(accent:Int = Color.rgb(20,105,190)): Drawable = object : Drawable() {
        private val p=Paint(Paint.ANTI_ALIAS_FLAG)
        override fun draw(c:Canvas){
            val w=bounds.width().toFloat();val h=bounds.height().toFloat();val stroke=maxOf(dp(1),(w*.075f).toInt()).toFloat()
            p.style=Paint.Style.STROKE;p.strokeWidth=stroke;p.strokeCap=Paint.Cap.ROUND;p.strokeJoin=Paint.Join.ROUND;p.color=accent
            val r=RectF(w*.13f,h*.18f,w*.87f,h*.84f);c.drawRoundRect(r,w*.13f,w*.13f,p)
            p.style=Paint.Style.FILL;c.drawRoundRect(w*.13f,h*.18f,w*.87f,h*.36f,w*.13f,w*.13f,p)
            p.color=Color.WHITE;c.drawCircle(w*.31f,h*.27f,w*.035f,p);c.drawCircle(w*.69f,h*.27f,w*.035f,p)
            p.color=accent;p.style=Paint.Style.STROKE;p.strokeWidth=maxOf(dp(1),(w*.055f).toInt()).toFloat()
            c.drawLine(w*.25f,h*.49f,w*.75f,h*.49f,p);c.drawLine(w*.25f,h*.64f,w*.75f,h*.64f,p);c.drawLine(w*.25f,h*.76f,w*.55f,h*.76f,p)
            p.style=Paint.Style.FILL;c.drawCircle(w*.75f,h*.76f,w*.07f,p)
        }
        override fun setAlpha(a:Int){p.alpha=a};override fun setColorFilter(f:android.graphics.ColorFilter?){p.colorFilter=f};override fun getOpacity():Int=android.graphics.PixelFormat.TRANSLUCENT;override fun getIntrinsicWidth():Int=dp(24);override fun getIntrinsicHeight():Int=dp(24)
    }

    private fun sessionCustomPackageIconDrawable(accent:Int = Color.rgb(20,105,190)): Drawable = object : Drawable() {
        private val p=Paint(Paint.ANTI_ALIAS_FLAG)
        override fun draw(c:Canvas){
            val w=bounds.width().toFloat();val h=bounds.height().toFloat();val stroke=maxOf(dp(1),(w*.075f).toInt()).toFloat()
            p.style=Paint.Style.STROKE;p.strokeWidth=stroke;p.strokeCap=Paint.Cap.ROUND;p.strokeJoin=Paint.Join.ROUND;p.color=accent
            c.drawRoundRect(RectF(w*.18f,h*.18f,w*.78f,h*.78f),w*.11f,w*.11f,p);c.drawRoundRect(RectF(w*.28f,h*.28f,w*.88f,h*.88f),w*.11f,w*.11f,p)
            p.style=Paint.Style.FILL;p.color=accent;c.drawCircle(w*.40f,h*.47f,w*.045f,p);c.drawCircle(w*.58f,h*.47f,w*.045f,p);c.drawCircle(w*.40f,h*.65f,w*.045f,p);c.drawCircle(w*.58f,h*.65f,w*.045f,p)
            p.style=Paint.Style.STROKE;p.strokeWidth=stroke;p.color=accent;c.drawCircle(w*.76f,h*.76f,w*.16f,p);c.drawLine(w*.76f,h*.69f,w*.76f,h*.83f,p);c.drawLine(w*.69f,h*.76f,w*.83f,h*.76f,p)
        }
        override fun setAlpha(a:Int){p.alpha=a};override fun setColorFilter(f:android.graphics.ColorFilter?){p.colorFilter=f};override fun getOpacity():Int=android.graphics.PixelFormat.TRANSLUCENT;override fun getIntrinsicWidth():Int=dp(24);override fun getIntrinsicHeight():Int=dp(24)
    }

    private fun packageIconDrawable(accent:Int = Color.rgb(20,105,190)): Drawable = object : Drawable() {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun draw(c: Canvas) {
            val w=bounds.width().toFloat(); val h=bounds.height().toFloat()
            val stroke=maxOf(dp(1),(w*.07f).toInt()).toFloat()
            p.style=Paint.Style.STROKE; p.strokeWidth=stroke; p.strokeCap=Paint.Cap.ROUND; p.strokeJoin=Paint.Join.ROUND; p.color=accent
            val back=RectF(w*.20f,h*.16f,w*.68f,h*.73f); c.drawRoundRect(back,w*.10f,w*.10f,p)
            val front=RectF(w*.30f,h*.27f,w*.78f,h*.84f); c.drawRoundRect(front,w*.10f,w*.10f,p)
            p.style=Paint.Style.FILL; p.color=accent; c.drawRoundRect(w*.30f,h*.27f,w*.78f,h*.39f,w*.10f,w*.10f,p)
            p.color=Color.WHITE; c.drawRoundRect(w*.36f,h*.31f,w*.72f,h*.36f,w*.025f,w*.025f,p)
            p.style=Paint.Style.FILL; p.color=Color.WHITE; c.drawCircle(w*.73f,h*.73f,w*.18f,p)
            p.style=Paint.Style.STROKE; p.strokeWidth=stroke; p.color=accent
            c.drawCircle(w*.73f,h*.73f,w*.18f,p)
            c.drawLine(w*.73f,h*.65f,w*.73f,h*.81f,p); c.drawLine(w*.65f,h*.73f,w*.81f,h*.73f,p)
        }
        override fun setAlpha(a:Int){p.alpha=a}
        override fun setColorFilter(f:android.graphics.ColorFilter?){p.colorFilter=f}
        override fun getOpacity():Int=android.graphics.PixelFormat.TRANSLUCENT
        override fun getIntrinsicWidth():Int=dp(24)
        override fun getIntrinsicHeight():Int=dp(24)
    }

    private fun calendarIconDrawable(accent:Int = Color.rgb(45,105,170)): Drawable = object : Drawable() {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun draw(c: Canvas) {
            val w=bounds.width().toFloat(); val h=bounds.height().toFloat()
            p.style=Paint.Style.STROKE; p.strokeWidth=maxOf(dp(1),(w*0.075f).toInt()).toFloat(); p.strokeCap=Paint.Cap.ROUND; p.color=accent
            val r=RectF(w*.13f,h*.17f,w*.87f,h*.87f); c.drawRoundRect(r,w*.12f,w*.12f,p)
            p.style=Paint.Style.FILL; c.drawRoundRect(w*.13f,h*.17f,w*.87f,h*.34f,w*.12f,w*.12f,p)
            p.color=Color.WHITE; c.drawCircle(w*.31f,h*.22f,w*.035f,p); c.drawCircle(w*.69f,h*.22f,w*.035f,p)
            p.color=accent; p.style=Paint.Style.STROKE; p.strokeWidth=maxOf(dp(1),(w*0.055f).toInt()).toFloat()
            for(i in 1..3){val x=w*(.30f+i*.14f);c.drawLine(x,h*.43f,x,h*.76f,p)}
            for(i in 1..2){val y=h*(.52f+i*.12f);c.drawLine(w*.24f,y,w*.76f,y,p)}
        }
        override fun setAlpha(a:Int){p.alpha=a}
        override fun setColorFilter(f:android.graphics.ColorFilter?){p.colorFilter=f}
        override fun getOpacity():Int=android.graphics.PixelFormat.TRANSLUCENT
        override fun getIntrinsicWidth():Int=dp(22)
        override fun getIntrinsicHeight():Int=dp(22)
    }

    private fun backupIconDrawable(accent:Int = Color.rgb(20,112,232)): Drawable = object : Drawable() {
        private val p=Paint(Paint.ANTI_ALIAS_FLAG)
        override fun draw(c:Canvas){
            val w=bounds.width().toFloat(); val h=bounds.height().toFloat(); val sw=maxOf(dp(1),(w*.075f).toInt()).toFloat()
            p.style=Paint.Style.STROKE;p.strokeWidth=sw;p.strokeCap=Paint.Cap.ROUND;p.strokeJoin=Paint.Join.ROUND;p.color=accent
            val cloud=Path();cloud.moveTo(w*.20f,h*.68f);cloud.cubicTo(w*.11f,h*.68f,w*.10f,h*.51f,w*.23f,h*.48f);cloud.cubicTo(w*.23f,h*.31f,w*.43f,h*.23f,w*.53f,h*.35f);cloud.cubicTo(w*.66f,h*.24f,w*.87f,h*.34f,w*.84f,h*.51f);cloud.cubicTo(w*.95f,h*.53f,w*.94f,h*.70f,w*.80f,h*.70f);cloud.close();c.drawPath(cloud,p)
            c.drawLine(w*.50f,h*.48f,w*.50f,h*.79f,p);c.drawLine(w*.50f,h*.79f,w*.39f,h*.68f,p);c.drawLine(w*.50f,h*.79f,w*.61f,h*.68f,p)
        }
        override fun setAlpha(a:Int){p.alpha=a};override fun setColorFilter(f:android.graphics.ColorFilter?){p.colorFilter=f};override fun getOpacity()=android.graphics.PixelFormat.TRANSLUCENT;override fun getIntrinsicWidth()=dp(28);override fun getIntrinsicHeight()=dp(28)
    }
    private fun backupCloudIconDrawable(accent:Int)=backupIconDrawable(accent)
    private fun backupExportIconDrawable(accent:Int):Drawable=object:Drawable(){private val p=Paint(Paint.ANTI_ALIAS_FLAG);override fun draw(c:Canvas){val w=bounds.width().toFloat();val h=bounds.height().toFloat();p.color=accent;p.style=Paint.Style.STROKE;p.strokeWidth=maxOf(dp(1),(w*.08f).toInt()).toFloat();p.strokeCap=Paint.Cap.ROUND;c.drawLine(w*.5f,h*.76f,w*.5f,h*.25f,p);c.drawLine(w*.5f,h*.25f,w*.34f,h*.41f,p);c.drawLine(w*.5f,h*.25f,w*.66f,h*.41f,p);c.drawRoundRect(RectF(w*.22f,h*.74f,w*.78f,h*.86f),w*.06f,w*.06f,p)};override fun setAlpha(a:Int){p.alpha=a};override fun setColorFilter(f:android.graphics.ColorFilter?){p.colorFilter=f};override fun getOpacity()=android.graphics.PixelFormat.TRANSLUCENT;override fun getIntrinsicWidth()=dp(26);override fun getIntrinsicHeight()=dp(26)}
    private fun backupImportIconDrawable(accent:Int):Drawable=object:Drawable(){private val p=Paint(Paint.ANTI_ALIAS_FLAG);override fun draw(c:Canvas){val w=bounds.width().toFloat();val h=bounds.height().toFloat();p.color=accent;p.style=Paint.Style.STROKE;p.strokeWidth=maxOf(dp(1),(w*.08f).toInt()).toFloat();p.strokeCap=Paint.Cap.ROUND;c.drawLine(w*.5f,h*.24f,w*.5f,h*.75f,p);c.drawLine(w*.5f,h*.75f,w*.34f,h*.59f,p);c.drawLine(w*.5f,h*.75f,w*.66f,h*.59f,p);c.drawRoundRect(RectF(w*.22f,h*.14f,w*.78f,h*.26f),w*.06f,w*.06f,p)};override fun setAlpha(a:Int){p.alpha=a};override fun setColorFilter(f:android.graphics.ColorFilter?){p.colorFilter=f};override fun getOpacity()=android.graphics.PixelFormat.TRANSLUCENT;override fun getIntrinsicWidth()=dp(26);override fun getIntrinsicHeight()=dp(26)}
    private fun backupRestoreIconDrawable(accent:Int):Drawable=object:Drawable(){private val p=Paint(Paint.ANTI_ALIAS_FLAG);override fun draw(c:Canvas){val w=bounds.width().toFloat();val h=bounds.height().toFloat();p.color=accent;p.style=Paint.Style.STROKE;p.strokeWidth=maxOf(dp(1),(w*.08f).toInt()).toFloat();p.strokeCap=Paint.Cap.ROUND;c.drawArc(RectF(w*.20f,h*.20f,w*.80f,h*.80f),-70f,285f,false,p);c.drawLine(w*.75f,h*.22f,w*.76f,h*.40f,p);c.drawLine(w*.75f,h*.22f,w*.58f,h*.25f,p)};override fun setAlpha(a:Int){p.alpha=a};override fun setColorFilter(f:android.graphics.ColorFilter?){p.colorFilter=f};override fun getOpacity()=android.graphics.PixelFormat.TRANSLUCENT;override fun getIntrinsicWidth()=dp(26);override fun getIntrinsicHeight()=dp(26)}

    private fun settings(){
        lastHomeBackAt = 0L
        // Impostazioni non è più una AlertDialog/Window separata: è un overlay
        // della stessa Activity. Così la status bar resta sotto il controllo
        // della stessa Window durante tutta la transizione Home → Impostazioni.
        if(settingsOverlay != null){
            settingsTransitionPending=false
            restoreSettingsSystemBars()
            settingsOverlayContent?.animate()?.cancel()
            settingsOverlayContent?.apply{
                alpha=0f
                translationX=dp(34).toFloat()
                scaleX=0.985f
                scaleY=0.985f
                animate().alpha(1f).translationX(0f).scaleX(1f).scaleY(1f)
                    .setDuration(210)
                    .setInterpolator(android.view.animation.DecelerateInterpolator(1.15f))
                    .withLayer().start()
            }
            return
        }

        prepareSettingsSystemBars()
        val contentRoot=findViewById<ViewGroup>(android.R.id.content)
        val overlay=FrameLayout(this).apply{
            background=appGlassBackground()
            elevation=dp(12).toFloat()
            isClickable=true
            isFocusable=true
        }
        val scroll=ScrollView(this).apply{
            isFillViewport=true
            overScrollMode=View.OVER_SCROLL_IF_CONTENT_SCROLLS
            clipToPadding=false
        }
        val box=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(14),dp(8),dp(14),dp(18))
        }
        box.addView(TextView(this).apply{
            text="Impostazioni"
            textSize=24f
            setTextColor(Color.rgb(24,27,31))
            setTypeface(null,android.graphics.Typeface.BOLD)
            gravity=Gravity.CENTER
            setPadding(0,dp(4),0,dp(14))
        })

        fun card(title:String,subtitle:String,icon:String,enabled:Boolean=true,onClick:()->Unit={}){
            val row=LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL
                gravity=Gravity.CENTER_VERTICAL
                setPadding(dp(14),dp(11),dp(12),dp(11))
                isClickable=enabled
                isFocusable=enabled
                background=appGlassSurface(if(enabled)Color.WHITE else Color.rgb(246,247,249),20,Color.rgb(205,220,235),1)
                alpha=if(enabled)1f else 0.52f
                if(enabled)setOnClickListener{
                    settingsTransitionPending=true
                    scroll.animate().cancel()
                    scroll.animate().translationX((-dp(34)).toFloat()).alpha(0f)
                        .setDuration(145)
                        .setInterpolator(android.view.animation.AccelerateInterpolator(1.15f))
                        .withLayer()
                        .withEndAction{onClick()}
                        .start()
                }
            }
            val iconBox=FrameLayout(this).apply{
                background=roundedSurface(if(enabled)Color.rgb(239,246,255) else Color.rgb(238,239,241),16)
                val iconView=if(icon=="CALENDAR_ICON") ImageView(this@MainActivity).apply{setImageDrawable(calendarIconDrawable(Color.rgb(45,105,170)));setPadding(dp(12),dp(12),dp(12),dp(12))} else TextView(this@MainActivity).apply{text=icon;textSize=21f;gravity=Gravity.CENTER;setPadding(dp(7),dp(5),dp(7),dp(5))}
                addView(iconView,FrameLayout.LayoutParams(-1,-1))
            }
            row.addView(iconBox,LinearLayout.LayoutParams(dp(50),dp(50)))
            val texts=LinearLayout(this).apply{
                orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),0,dp(8),0)
            }
            texts.addView(TextView(this@MainActivity).apply{
                text=title;textSize=16.5f;setTextColor(Color.rgb(25,28,32));setTypeface(null,android.graphics.Typeface.BOLD);setIncludeFontPadding(false)
            })
            texts.addView(TextView(this@MainActivity).apply{
                text=subtitle;textSize=12.5f;setTextColor(Color.rgb(95,99,105));setPadding(0,dp(5),0,0);setMaxLines(2);ellipsize=android.text.TextUtils.TruncateAt.END
            })
            row.addView(texts,LinearLayout.LayoutParams(0,-2,1f))
            row.addView(TextView(this).apply{
                text=if(enabled)"›" else "In arrivo";textSize=if(enabled)28f else 11f
                setTextColor(if(enabled)Color.rgb(105,110,116) else Color.rgb(115,120,126));gravity=Gravity.CENTER
            },LinearLayout.LayoutParams(if(enabled)dp(30) else dp(62),dp(50)))
            box.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})
        }

        card("Generali","Aspetto e preferenze dell'app","⚙"){generalSettingsDialog()}
        card("Personalizzazione","Effetti visivi di finestre e slot","✨"){personalizationSettingsDialog()}
        card("Calendario","Giorni, griglia e personalizzazione dei pulsanti","CALENDAR_ICON"){calendarSettingsDialog()}
        card("Appuntamenti","Tipi, durata e capienza","👥"){appointmentSettingsDialog()}
        card("Pagamenti","Rate, metodi e preferenze","💳",false)
        card("Chiusura ferie","Periodi di chiusura e recupero scadenze","🌴"){closureSettingsDialog()}
        card("Notifiche","Promemoria e avvisi","🔔",false)
        card("Backup e dati","Backup automatico, esportazione e importazione","☁"){backupMenu()}
        card("Cestino","Elementi eliminati e ripristino","🗑"){trashScreen(true)}
        card("Guida CoachFlow","Manuale e consigli per usare l'app","📖",false)
        card("Informazioni","Versione approvata e supporto","ⓘ"){versionInfoDialog()}

        scroll.addView(box,ViewGroup.LayoutParams(-1,-2))
        overlay.addView(scroll,FrameLayout.LayoutParams(-1,-1))
        contentRoot.addView(overlay,ViewGroup.LayoutParams(-1,-1))
        settingsOverlay=overlay
        settingsOverlayContent=scroll

        overlay.setOnApplyWindowInsetsListener { v,insets ->
            val bars=if(android.os.Build.VERSION.SDK_INT>=30){
                insets.getInsets(android.view.WindowInsets.Type.systemBars())
            }else{
                android.graphics.Insets.of(insets.systemWindowInsetLeft,insets.systemWindowInsetTop,insets.systemWindowInsetRight,insets.systemWindowInsetBottom)
            }
            scroll.setPadding(0,bars.top,0,bars.bottom)
            insets
        }
        overlay.requestApplyInsets()

        restoreSettingsSystemBars()
        scroll.alpha=0f
        scroll.translationX=dp(24).toFloat()
        scroll.animate().alpha(1f).translationX(0f)
            .setDuration(210)
            .setInterpolator(android.view.animation.DecelerateInterpolator(1.15f))
            .withLayer().start()
    }

    private fun showSettingsSubpage(content:View,title:String){
        val parent=settingsOverlay ?: return
        settingsSubpageOverlay?.let{(it.parent as? ViewGroup)?.removeView(it)}
        val page=FrameLayout(this).apply{background=appGlassBackground();isClickable=true;isFocusable=true;elevation=dp(16).toFloat()}
        val header=FrameLayout(this).apply{background=appGlassSurface(Color.WHITE,0,Color.TRANSPARENT,0)}
        val back=TextView(this).apply{text="‹";textSize=36f;setTextColor(Color.rgb(55,60,66));gravity=Gravity.CENTER;setPadding(0,0,0,dp(3));isClickable=true;setOnClickListener{closeSettingsSubpage()}}
        header.addView(back,FrameLayout.LayoutParams(dp(52),dp(56),Gravity.START or Gravity.TOP))
        header.addView(TextView(this).apply{text=title;textSize=19f;setTextColor(Color.rgb(24,27,31));setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setIncludeFontPadding(false)},FrameLayout.LayoutParams(-1,dp(56),Gravity.TOP))
        page.addView(header,FrameLayout.LayoutParams(-1,dp(56),Gravity.TOP))
        val body=FrameLayout(this).apply{addView(content,FrameLayout.LayoutParams(-1,-1));setPadding(0,dp(56),0,0);clipToPadding=false}
        page.addView(body,FrameLayout.LayoutParams(-1,-1))
        parent.addView(page,FrameLayout.LayoutParams(-1,-1))
        settingsSubpageOverlay=page
        page.setOnApplyWindowInsetsListener{v,insets->
            val bars=if(android.os.Build.VERSION.SDK_INT>=30)insets.getInsets(android.view.WindowInsets.Type.systemBars()) else android.graphics.Insets.of(insets.systemWindowInsetLeft,insets.systemWindowInsetTop,insets.systemWindowInsetRight,insets.systemWindowInsetBottom)
            header.setPadding(dp(8),bars.top,dp(14),0)
            body.setPadding(0,dp(56),0,bars.bottom)
            insets
        }
        page.requestApplyInsets()
        page.alpha=0f;page.translationX=dp(28).toFloat();page.scaleX=.985f;page.scaleY=.985f
        page.animate().alpha(1f).translationX(0f).scaleX(1f).scaleY(1f).setDuration(210).setInterpolator(android.view.animation.DecelerateInterpolator(1.15f)).withLayer().start()
    }

    private fun closeSettingsSubpage(revealSettings:Boolean=true){
        val page=settingsSubpageOverlay ?: return
        val parent=settingsOverlay
        val settingsContent=settingsOverlayContent
        page.animate().cancel()
        // The Settings list is intentionally hidden while a subpage is open.
        // Reveal it at the same time the subpage slides away, so Android back/swipe
        // never exposes a blank layer or the Home underneath.
        if(revealSettings){
            settingsContent?.animate()?.cancel()
            settingsContent?.apply{
                alpha=0f
                translationX=(-dp(18)).toFloat()
                animate().alpha(1f).translationX(0f)
                    .setDuration(190)
                    .setInterpolator(android.view.animation.DecelerateInterpolator(1.1f))
                    .withLayer().start()
            }
        }
        page.animate().alpha(0f).translationX(dp(28).toFloat()).setDuration(170)
            .setInterpolator(android.view.animation.DecelerateInterpolator(1.1f)).withLayer().withEndAction{
                (page.parent as? ViewGroup)?.removeView(page)
                settingsSubpageOverlay=null
                if(parent==null)settingsContent?.alpha=1f
            }.start()
    }

    private fun versionInfoDialog(){
        val box=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(18),dp(10),dp(18),dp(22))
        }
        val versionCard=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(16),dp(14),dp(14),dp(14))
            background=liquidInteractiveSurface(Color.rgb(242,247,253),22,Color.rgb(205,225,245),1)
            applyLiquidControlDepth(this)
        }
        versionCard.addView(TextView(this).apply{
            text="✓";textSize=24f;gravity=Gravity.CENTER
            setTextColor(Color.rgb(20,112,232))
            background=appGlassSurface(Color.WHITE,18,Color.rgb(210,228,247),1)
        },LinearLayout.LayoutParams(dp(52),dp(52)))
        val texts=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,dp(8),0)}
        texts.addView(TextView(this).apply{
            text="Versione approvata";textSize=13f;setTextColor(Color.rgb(82,96,112))
        })
        texts.addView(TextView(this).apply{
            text=APPROVED_VERSION_LABEL;textSize=21f;setTextColor(Color.rgb(24,45,70));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(0,dp(2),0,0)
        })
        texts.addView(TextView(this).apply{
            text="Questa è la versione di riferimento approvata.";textSize=12.5f;setTextColor(Color.rgb(96,108,122));setPadding(0,dp(3),0,0)
        })
        versionCard.addView(texts,LinearLayout.LayoutParams(0,-2,1f))
        versionCard.addView(TextView(this).apply{
            text=APPROVED_VERSION_STATUS;textSize=10.5f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER
            setTextColor(Color.rgb(20,112,232));setPadding(dp(9),dp(6),dp(9),dp(6))
            background=appGlassSurface(Color.rgb(232,242,255),14,Color.rgb(195,220,247),1)
        },LinearLayout.LayoutParams(-2,dp(34)))
        box.addView(versionCard,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(14))})
        val note=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL;setPadding(dp(15),dp(13),dp(15),dp(13))
            background=appGlassSurface(Color.rgb(248,250,252),18,Color.rgb(226,230,235),1)
        }
        note.addView(TextView(this).apply{
            text="Sistema di versionamento";textSize=15f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,40,46))
        })
        note.addView(TextView(this).apply{
            text="Ogni nuova modifica viene prima testata in una copia di lavoro. Solo dopo l'approvazione la copia viene promossa alla versione successiva o alla nuova versione stabile.";textSize=12.5f;setTextColor(Color.rgb(100,106,114));setPadding(0,dp(6),0,0)
        })
        box.addView(note,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(14))})
        val close=Button(this).apply{text="Chiudi";setAllCaps(false);textSize=14f;setTextColor(Color.WHITE);background=appGlassSurface(Color.rgb(20,112,232),18);stateListAnimator=null}
        box.addView(close,LinearLayout.LayoutParams(-1,dp(48)))
        showSettingsSubpage(box,"Informazioni")
        close.setOnClickListener{closeSettingsSubpage()}
    }

    private fun generalSettingsDialog(){
        val scroll=ScrollView(this).apply{isFillViewport=true;clipToPadding=false;overScrollMode=View.OVER_SCROLL_IF_CONTENT_SCROLLS}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(32))}

        // Hero introduttivo Niki UI: crea respiro sotto la barra del titolo e lascia spazio
        // naturale alle sezioni che verranno aggiunte in futuro.
        val hero=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(16),dp(14),dp(16),dp(14))
            background=appGlassSurface(Color.rgb(244,248,253),22,Color.rgb(210,226,243),1)
        }
        val heroIcon=TextView(this).apply{
            text="⚙";textSize=27f;gravity=Gravity.CENTER
            setTextColor(Color.rgb(20,112,232))
            background=appGlassSurface(Color.rgb(231,242,255),18,Color.rgb(196,220,244),1)
        }
        hero.addView(heroIcon,LinearLayout.LayoutParams(dp(52),dp(52)))
        val heroTexts=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(13),0,0,0)}
        heroTexts.addView(TextView(this).apply{
            text="Impostazioni generali";textSize=16f;setTextColor(Color.rgb(28,42,58));setTypeface(null,android.graphics.Typeface.BOLD)
        })
        heroTexts.addView(TextView(this).apply{
            text="Preferenze di base dell'app";textSize=12.5f;setTextColor(Color.rgb(91,108,125));setPadding(0,dp(4),0,0)
        })
        hero.addView(heroTexts,LinearLayout.LayoutParams(0,-2,1f))
        box.addView(hero,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(16))})

        fun sectionCard(title:String, subtitle:String?=null): LinearLayout {
            val card=LinearLayout(this).apply{
                orientation=LinearLayout.VERTICAL
                setPadding(dp(16),dp(14),dp(16),dp(14))
                background=appGlassSurface(Color.rgb(249,251,254),20,Color.rgb(213,226,240),1)
            }
            card.addView(TextView(this).apply{
                text=title;textSize=15f;setTextColor(Color.rgb(32,38,46));setTypeface(null,android.graphics.Typeface.BOLD)
            })
            if(!subtitle.isNullOrBlank()) card.addView(TextView(this).apply{
                text=subtitle;textSize=12.5f;setTextColor(Color.rgb(105,111,118));setPadding(0,dp(4),0,dp(10))
            })
            return card
        }

        box.addView(TextView(this).apply{
            text="Configura le preferenze generali dell'app."
            textSize=13f;setTextColor(Color.rgb(82,101,122));setPadding(dp(14),dp(12),dp(14),dp(12));background=appGlassSurface(Color.rgb(240,247,255),16,Color.rgb(214,229,244),1)
        })

        val displayCard=sectionCard("Visualizzazione","Come vengono mostrati i nomi dei clienti.")
        val displayGroup=RadioGroup(this).apply{orientation=RadioGroup.VERTICAL}
        val a=RadioButton(this).apply{text="Cognome Nome";textSize=15f;isChecked=surnameFirstDisplay;buttonTintList=android.content.res.ColorStateList.valueOf(Color.rgb(20,91,165));id=View.generateViewId()}
        val b=RadioButton(this).apply{text="Nome Cognome";textSize=15f;isChecked=!surnameFirstDisplay;buttonTintList=android.content.res.ColorStateList.valueOf(Color.rgb(20,91,165));id=View.generateViewId()}
        displayGroup.addView(a,RadioGroup.LayoutParams(-1,dp(44)));displayGroup.addView(b,RadioGroup.LayoutParams(-1,dp(44)))
        displayCard.addView(displayGroup)
        box.addView(displayCard,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(10),0,dp(14))})

        val infoCard=sectionCard("Preferenze","Le modifiche vengono registrate automaticamente.")
        infoCard.addView(TextView(this).apply{text="Le impostazioni future verranno aggiunte come nuove sezioni, mantenendo separate quelle già configurate.";textSize=12.5f;setTextColor(Color.rgb(105,111,118));setPadding(0,dp(2),0,0)})
        box.addView(infoCard,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(14))})

        val closeGeneral=Button(this).apply{tag="general_close";text="Chiudi";setAllCaps(false);textSize=14f;setTextColor(Color.WHITE);background=appGlassSurface(Color.rgb(20,112,232),18,Color.rgb(20,112,232),1);stateListAnimator=null}
        box.addView(closeGeneral,LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(2),0,0)})
        scroll.addView(box,ViewGroup.LayoutParams(-1,-2));showSettingsSubpage(scroll,"Generali")
        val close=box.findViewWithTag<Button>("general_close")
        close?.setOnClickListener{surnameFirstDisplay=a.isChecked;saveData();closeSettingsSubpage()}
    }

    private fun personalizationSettingsDialog(){
        val scroll=ScrollView(this).apply{isFillViewport=true;clipToPadding=false;overScrollMode=View.OVER_SCROLL_IF_CONTENT_SCROLLS}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(32))}

        // Header visuale Niki UI: ogni sottopagina mantiene lo stesso linguaggio di Generali.
        val hero=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(16),dp(14),dp(16),dp(14))
            background=appGlassSurface(Color.rgb(244,248,253),22,Color.rgb(210,226,243),1)
        }
        val heroIcon=TextView(this).apply{
            text="✦";textSize=27f;gravity=Gravity.CENTER
            setTextColor(Color.rgb(20,112,232))
            background=appGlassSurface(Color.rgb(231,242,255),18,Color.rgb(196,220,244),1)
        }
        hero.addView(heroIcon,LinearLayout.LayoutParams(dp(52),dp(52)))
        val heroTexts=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(13),0,0,0)}
        heroTexts.addView(TextView(this).apply{
            text="Personalizzazione";textSize=16f;setTextColor(Color.rgb(28,42,58));setTypeface(null,android.graphics.Typeface.BOLD)
        })
        heroTexts.addView(TextView(this).apply{
            text="Aspetto e stile dell'app";textSize=12.5f;setTextColor(Color.rgb(91,108,125));setPadding(0,dp(4),0,0)
        })
        hero.addView(heroTexts,LinearLayout.LayoutParams(0,-2,1f))
        box.addView(hero,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(16))})

        fun sectionCard(title:String, subtitle:String?=null): LinearLayout {
            val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(14),dp(16),dp(14));background=appGlassSurface(Color.rgb(249,251,254),20,Color.rgb(213,226,240),1)}
            card.addView(TextView(this).apply{text=title;textSize=15f;setTextColor(Color.rgb(32,38,46));setTypeface(null,android.graphics.Typeface.BOLD)})
            if(!subtitle.isNullOrBlank()) card.addView(TextView(this).apply{text=subtitle;textSize=12.5f;setTextColor(Color.rgb(105,111,118));setPadding(0,dp(4),0,dp(10))})
            return card
        }
        box.addView(TextView(this).apply{text="Personalizza gli effetti visivi delle finestre pop-up e degli slot del calendario.";textSize=13f;setTextColor(Color.rgb(82,101,122));setPadding(dp(14),dp(12),dp(14),dp(12));background=appGlassSurface(Color.rgb(240,247,255),16,Color.rgb(214,229,244),1)},LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(14))})
        val effectCard=sectionCard("Effetti finestre pop-up","Scegli lo stile e regola l'intensità senza cambiare il contenuto delle finestre.")
        val effectGroup=RadioGroup(this).apply{orientation=RadioGroup.VERTICAL}
        fun effectChoice(label:String,value:String)=RadioButton(this).apply{
            text=label;textSize=13.5f;setTextColor(Color.rgb(35,42,52));isChecked=popupBackdropEffect==value
            buttonTintList=android.content.res.ColorStateList.valueOf(Color.rgb(20,91,165));id=View.generateViewId();setPadding(dp(2),0,0,0)
        }
        val none=effectChoice("Predefinito","NONE")
        val satin=effectChoice("Satinato","SATIN")
        val soft=effectChoice("Glass","VETRO_SOFT")
        val liquid=effectChoice("Liquid Glass","LIQUID")
        val effectRow1=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val effectRow2=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        effectRow1.addView(none,LinearLayout.LayoutParams(0,dp(46),1f));effectRow1.addView(satin,LinearLayout.LayoutParams(0,dp(46),1f))
        effectRow2.addView(soft,LinearLayout.LayoutParams(0,dp(46),1f));effectRow2.addView(liquid,LinearLayout.LayoutParams(0,dp(46),1f))
        effectGroup.addView(effectRow1);effectGroup.addView(effectRow2)
        effectCard.addView(effectGroup)

        effectCard.addView(TextView(this).apply{
            text="Modalità effetto";textSize=13.5f;setTextColor(Color.rgb(65,71,79));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(0,dp(12),0,dp(4))
        })
        val modeGroup=RadioGroup(this).apply{orientation=RadioGroup.HORIZONTAL}
        val contour=RadioButton(this).apply{text="Contorno";textSize=13.5f;isChecked=popupBackdropMode!="IMMERSIVE";buttonTintList=android.content.res.ColorStateList.valueOf(Color.rgb(20,91,165));id=View.generateViewId()}
        val immersive=RadioButton(this).apply{text="Immersivo";textSize=13.5f;isChecked=popupBackdropMode=="IMMERSIVE";buttonTintList=android.content.res.ColorStateList.valueOf(Color.rgb(20,91,165));id=View.generateViewId()}
        modeGroup.addView(contour,LinearLayout.LayoutParams(0,dp(46),1f));modeGroup.addView(immersive,LinearLayout.LayoutParams(0,dp(46),1f));effectCard.addView(modeGroup)
        none.isChecked=popupBackdropEffect=="NONE";satin.isChecked=popupBackdropEffect=="SATIN";soft.isChecked=popupBackdropEffect=="VETRO_SOFT";liquid.isChecked=popupBackdropEffect=="LIQUID"

        effectCard.addView(TextView(this).apply{
            text="Intensità effetto";textSize=13.5f;setTextColor(Color.rgb(65,71,79));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(0,dp(12),0,dp(2))
        })
        val intensityRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val slider=SeekBar(this).apply{max=100;progress=popupBackdropIntensity;splitTrack=false}
        val value=TextView(this).apply{text="${popupBackdropIntensity}%";textSize=14f;setTextColor(Color.rgb(20,91,165));gravity=Gravity.RIGHT;setTypeface(null,android.graphics.Typeface.BOLD)}
        intensityRow.addView(slider,LinearLayout.LayoutParams(0,dp(42),1f));intensityRow.addView(value,LinearLayout.LayoutParams(dp(54),dp(42)));effectCard.addView(intensityRow)

        val previewHost=FrameLayout(this).apply{
            setPadding(dp(12),dp(12),dp(12),dp(12));background=appGlassSurface(Color.rgb(246,249,253),18,Color.rgb(220,229,239),1);visibility=View.VISIBLE
        }
        val previewTitle=TextView(this).apply{text="Anteprima live";textSize=13f;setTextColor(Color.rgb(20,91,165));setTypeface(null,android.graphics.Typeface.BOLD)}
        previewHost.addView(previewTitle,FrameLayout.LayoutParams(-1,dp(24),Gravity.TOP))
        val previewScene=FrameLayout(this).apply{clipToOutline=true;outlineProvider=object:android.view.ViewOutlineProvider(){override fun getOutline(v:View,o:android.graphics.Outline){o.setRoundRect(0,0,v.width,v.height,dp(18).toFloat())}};setBackgroundColor(Color.rgb(225,232,240))}
        val fakeTop=View(this).apply{setBackgroundColor(Color.rgb(180,210,245))};previewScene.addView(fakeTop,FrameLayout.LayoutParams(-1,dp(34),Gravity.TOP))
        val fakeLine=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(10),dp(14),0)}
        repeat(3){i->fakeLine.addView(View(this).apply{setBackgroundColor(if(i==0)Color.rgb(205,220,238) else Color.rgb(232,237,243))},LinearLayout.LayoutParams(-1,dp(18)).apply{setMargins(0,0,0,dp(7))})}
        previewScene.addView(fakeLine,FrameLayout.LayoutParams(-1,-1))
        val previewWindow=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(14),dp(8),dp(14),dp(8));background=appGlassSurface(Color.WHITE,18,Color.rgb(205,224,248),1);elevation=dp(5).toFloat()}
        previewWindow.addView(TextView(this).apply{text="Nuovo appuntamento";textSize=14f;setTextColor(Color.rgb(25,31,38));setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER})
        previewWindow.addView(TextView(this).apply{text="Anteprima in tempo reale";textSize=11f;setTextColor(Color.rgb(105,111,118));gravity=Gravity.CENTER;setPadding(0,dp(3),0,0)})
        previewScene.addView(previewWindow,FrameLayout.LayoutParams((resources.displayMetrics.widthPixels*.56f).toInt(),dp(72),Gravity.CENTER))
        previewHost.addView(previewScene,FrameLayout.LayoutParams(-1,dp(150)).apply{topMargin=dp(26)})
        val previewHint=TextView(this).apply{text="Sposta la levetta per vedere l'effetto cambiare in tempo reale.";textSize=11.5f;setTextColor(Color.rgb(100,106,114));gravity=Gravity.CENTER;setPadding(dp(4),dp(7),dp(4),0)}
        previewHost.addView(previewHint,FrameLayout.LayoutParams(-1,dp(30),Gravity.BOTTOM))
        effectCard.addView(previewHost,LinearLayout.LayoutParams(-1,dp(218)).apply{setMargins(0,dp(8),0,0)})

        val reset=Button(this).apply{text="↺  Ripristina predefiniti";setAllCaps(false);textSize=13f;setTextColor(Color.rgb(30,83,145));background=appGlassSurface(Color.rgb(238,246,255),16,Color.rgb(211,228,247),1);stateListAnimator=null}
        effectCard.addView(reset,LinearLayout.LayoutParams(-1,dp(42)).apply{setMargins(0,dp(10),0,0)})
        box.addView(effectCard,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})

        val largeCard=sectionCard("Stili slot grandi","Scegli l’aspetto grafico degli slot grandi vuoti nel calendario. Lo stile 10 è quello attuale e resta il predefinito.")
        val largeGroup=RadioGroup(this).apply{orientation=RadioGroup.VERTICAL}
        val largeNames=listOf("Minimal","Satinato","Glass Bordo","Soft Gradient","Dark Glass","Color Light","Cromato Lucido","Outline Glow","Blurred Gradient","Predefinito (Attuale)")
        val largeDescriptions=listOf("Pulito e minimale, linee sottili.","Vetro satinato classico.","Bordo luminoso e vetro trasparente.","Gradiente morbido e moderno.","Vetro scuro elegante.","Tonalità colorata soft.","Rilievo chiaro e discreto.","Contorno luminoso con effetto glow.","Sfumatura morbida multitonale.","Liquid Glass attuale.")
        val largeButtons=mutableListOf<RadioButton>()
        for(i in 1..10){
            val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(2),dp(5),dp(2),dp(5))}
            val rb=RadioButton(this).apply{text="${i}. ${largeNames[i-1]}";textSize=13.5f;setTextColor(Color.rgb(35,42,52));isChecked=largeSlotStyle==i;buttonTintList=android.content.res.ColorStateList.valueOf(Color.rgb(20,91,165));id=View.generateViewId()}
            largeButtons.add(rb)
            row.addView(rb,LinearLayout.LayoutParams(-1,dp(42)))
            val preview=TextView(this).apply{text="Slot disponibile";textSize=12.5f;setTextColor(if(i==5)Color.WHITE else Color.rgb(42,55,70));gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),0,dp(10),0);background=largeSlotStyleDrawable(i,1f,0)}
            row.addView(preview,LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(dp(8),0,dp(8),dp(2))})
            row.addView(TextView(this).apply{text=largeDescriptions[i-1];textSize=11.5f;setTextColor(Color.rgb(105,111,118));setPadding(dp(8),dp(3),dp(8),0)})
            largeGroup.addView(row,LinearLayout.LayoutParams(-1,-2))
        }
        largeCard.addView(largeGroup)
        largeButtons.forEachIndexed{idx,rb->rb.setOnClickListener{largeSlotStyle=idx+1;largeButtons.forEachIndexed{j,b->b.isChecked=j==idx};saveData()}}
        largeCard.addView(TextView(this).apply{text="Gli slot appuntamento mantengono i loro effetti indipendenti.";textSize=11.5f;setTextColor(Color.rgb(105,111,118));setPadding(dp(2),dp(10),dp(2),0)})
        box.addView(largeCard,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})

        val appointmentStyleCard=sectionCard("Stili slot appuntamenti","9 nuovi stili completamente diversi + il Liquid Glass attuale come predefinito. Questa scelta è indipendente dagli stili degli slot grandi.")
        val appointmentStyleGroup=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val appointmentStyleNames=listOf("Capsula","Tag Smussato","Facettato","Ribbon","Dark Glass","Neon Outline","Cromato","Crystal","Soft Slab","Predefinito (Liquid Glass)")
        val appointmentStyleDescriptions=listOf("Sagoma a capsula, morbida e compatta.","Angoli tagliati e profilo asimmetrico.","Geometria sfaccettata con tagli diagonali.","Corpo con fascia superiore separata.","Vetro scuro con bordo metallico e testo chiaro.","Superficie quasi trasparente, bordo luminoso.","Metallo rigido con finitura cromata.","Pannello cristallino con diagonale interna.","Lastra sottile e quasi piatta.","Liquid Glass attuale: resta il predefinito.")
        val appointmentStyleButtons=mutableListOf<RadioButton>()
        val appointmentStylePreviews=mutableListOf<TextView>()
        for(i in 1..10){
            val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(2),dp(5),dp(2),dp(5))}
            val rb=RadioButton(this).apply{text="${i}. ${appointmentStyleNames[i-1]}";textSize=13.5f;setTextColor(Color.rgb(35,42,52));isChecked=appointmentSlotStyle==i;buttonTintList=android.content.res.ColorStateList.valueOf(Color.rgb(20,91,165));id=View.generateViewId()}
            appointmentStyleButtons.add(rb);row.addView(rb,LinearLayout.LayoutParams(-1,dp(42)))
            val preview=TextView(this).apply{text="Rossi Mario";textSize=12.5f;setTextColor(if(i==5)Color.WHITE else Color.rgb(42,55,70));gravity=Gravity.CENTER;setPadding(dp(8),0,dp(8),0);background=if(i==10)liquidAppointmentSurface(Color.rgb(45,135,210)) else AppointmentSlotStyleDrawable(i,1f,Color.rgb(45,135,210))}
            appointmentStylePreviews.add(preview)
            row.addView(preview,LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(dp(8),0,dp(8),dp(2))})
            row.addView(TextView(this).apply{text=appointmentStyleDescriptions[i-1];textSize=11.5f;setTextColor(Color.rgb(105,111,118));setPadding(dp(8),dp(3),dp(8),0)})
            appointmentStyleGroup.addView(row,LinearLayout.LayoutParams(-1,-2))
        }
        fun selectAppointmentStyle(index:Int){
            appointmentSlotStyle=index.coerceIn(1,10)
            appointmentStyleButtons.forEachIndexed{j,b->b.isChecked=j==appointmentSlotStyle-1}
            appointmentStylePreviews.forEachIndexed{j,v->
                v.background=if(j+1==10) liquidAppointmentSurface(Color.rgb(45,135,210)) else AppointmentSlotStyleDrawable(j+1,1f,Color.rgb(45,135,210))
                v.setTextColor(if(j+1==5) Color.WHITE else Color.rgb(42,55,70))
            }
            // La selezione è una preferenza grafica: non deve mai aprire il Calendario.
            saveData()
        }
        appointmentStyleCard.addView(appointmentStyleGroup)
        appointmentStyleButtons.forEachIndexed{idx,rb->
            rb.setOnClickListener{selectAppointmentStyle(idx+1)}
        }
        box.addView(appointmentStyleCard,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})

        val infoCard=sectionCard("Preferenze","Le modifiche vengono registrate automaticamente.")
        infoCard.addView(TextView(this).apply{text="Gli effetti degli slot restano indipendenti dalle altre impostazioni visive.";textSize=12.5f;setTextColor(Color.rgb(105,111,118));setPadding(0,dp(2),0,0)})
        box.addView(infoCard,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})
        val close=Button(this).apply{text="Chiudi";setAllCaps(false);textSize=14f;setTextColor(Color.WHITE);background=appGlassSurface(Color.rgb(20,112,232),18,Color.rgb(20,112,232),1);stateListAnimator=null}
        box.addView(close,LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(2),0,0)})
        scroll.addView(box,ViewGroup.LayoutParams(-1,-2));showSettingsSubpage(scroll,"Personalizzazione")
        close.setOnClickListener{closeSettingsSubpage()}
        fun persistVisuals(){
            popupBackdropMode=if(modeGroup.checkedRadioButtonId==immersive.id)"IMMERSIVE" else "CONTOUR"
            popupBackdropIntensity=slider.progress.coerceIn(0,100)
            savePopupVisualPreferences();value.text="${popupBackdropIntensity}%"
        }
        fun refreshPreview(){
            val intensity=slider.progress.coerceIn(0,100)
            val effect=popupBackdropEffect
            val satin = effect=="SATIN"
            val softGlass = effect=="VETRO_SOFT"
            val liquid = effect=="LIQUID"
            val immersiveMode=popupBackdropMode=="IMMERSIVE"

            previewHost.visibility=View.VISIBLE
            if (effect=="NONE") {
                fakeLine.setRenderEffect(null)
                previewScene.setBackgroundColor(Color.rgb(225,232,240))
                fakeTop.setBackgroundColor(Color.rgb(205,220,238))
                previewWindow.background=appGlassSurface(Color.WHITE,18,Color.rgb(205,224,248),1)
                previewWindow.elevation=dp(5).toFloat()
                previewHint.text="Anteprima del comportamento senza effetto."
                return
            }

            val base=when { satin->24; softGlass->10; liquid->4; else->0 }
            val radius=(base*(intensity/100f)).roundToInt().coerceIn(0,base)
            if(android.os.Build.VERSION.SDK_INT>=31 && radius>0) fakeLine.setRenderEffect(android.graphics.RenderEffect.createBlurEffect(dp(radius).toFloat(),dp(radius).toFloat(),android.graphics.Shader.TileMode.CLAMP)) else fakeLine.setRenderEffect(null)

            if (satin) {
                val a=(52*(intensity/100f)).roundToInt().coerceIn(0,70)
                fakeTop.setBackgroundColor(android.graphics.Color.rgb(190,214,242))
                previewScene.setBackgroundColor(android.graphics.Color.rgb(218 + (a/20).coerceIn(0,2),225 + (a/30).coerceIn(0,2),233))
                previewWindow.background=appGlassSurface(if(immersiveMode)android.graphics.Color.argb(242,248,251,255) else Color.WHITE,18,Color.rgb(205,224,248),if(immersiveMode)2 else 1)
                previewHint.text=if(immersiveMode)"Satinato • Immersivo • ${intensity}%" else "Satinato • Contorno • ${intensity}%"
            } else if (softGlass) {
                val a=(28*(intensity/100f)).roundToInt().coerceIn(0,40)
                fakeTop.setBackgroundColor(android.graphics.Color.rgb(190,214,242))
                previewScene.setBackgroundColor(android.graphics.Color.rgb(222,230,239))
                previewWindow.background=appGlassSurface(if(immersiveMode)android.graphics.Color.argb(242,248,251,255) else Color.WHITE,18,Color.rgb(205,224,248),if(immersiveMode)1 else 1)
                previewWindow.elevation=dp(5).toFloat()
                previewHint.text=if(immersiveMode)"Vetro Soft • Immersivo • ${intensity}%" else "Vetro Soft • Contorno • ${intensity}%"
            } else if (liquid) {
                val a=(7*(intensity/100f)).roundToInt().coerceIn(0,16)
                fakeTop.setBackgroundColor(android.graphics.Color.rgb(180,218,250))
                previewScene.setBackgroundColor(android.graphics.Color.rgb(226,235,243))
                previewWindow.background=appGlassSurface(
                    if(immersiveMode)android.graphics.Color.argb(232,246,251,255) else android.graphics.Color.WHITE,
                    18,
                    android.graphics.Color.rgb(155,205,245),
                    1
                )
                previewWindow.elevation=dp(7).toFloat()
                previewHint.text=if(immersiveMode)"Liquid Glass • Immersivo • ${intensity}%" else "Liquid Glass • Contorno • ${intensity}%"
            }
        }
        fun chooseEffect(value:String){
            popupBackdropEffect=value
            none.isChecked=value=="NONE"
            satin.isChecked=value=="SATIN"
            soft.isChecked=value=="VETRO_SOFT"
            liquid.isChecked=value=="LIQUID"
            savePopupVisualPreferences();refreshPreview()
        }
        none.setOnClickListener{chooseEffect("NONE")}
        satin.setOnClickListener{chooseEffect("SATIN")}
        soft.setOnClickListener{chooseEffect("VETRO_SOFT")}
        liquid.setOnClickListener{chooseEffect("LIQUID")}
        modeGroup.setOnCheckedChangeListener{_,_->persistVisuals();refreshPreview()}
        slider.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(s:SeekBar?,p:Int,fromUser:Boolean){popupBackdropIntensity=p.coerceIn(0,100);value.text="${popupBackdropIntensity}%";savePopupVisualPreferences();refreshPreview()}
            override fun onStartTrackingTouch(s:SeekBar?){refreshPreview()}
            override fun onStopTrackingTouch(s:SeekBar?){refreshPreview()}
        })
        reset.setOnClickListener{
            popupBackdropEffect="NONE";popupBackdropMode="CONTOUR";popupBackdropIntensity=65
            none.isChecked=true;satin.isChecked=false;soft.isChecked=false;liquid.isChecked=false;modeGroup.check(contour.id);slider.progress=65;savePopupVisualPreferences();saveData();value.text="65%";refreshPreview()
        }
        refreshPreview()
    }

    private fun calendarWeekEnd(start:LocalDate):LocalDate{
        val endOffset=when{calendarVisibleDays.all{it}->6;calendarVisibleDays.take(5).all{it} && calendarVisibleDays.drop(5).none{it}->4;else->calendarVisibleDays.indexOfLast{it}.coerceAtLeast(4)}
        return start.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).plusDays(endOffset.toLong())
    }

    private fun closureWeekLabel():String{
        return if(calendarVisibleDays.all{it}) "Lunedì → Domenica" else if(calendarVisibleDays.take(5).all{it} && calendarVisibleDays.drop(5).none{it}) "Lunedì → Venerdì" else "Lunedì → ${dayShort(calendarVisibleDays.indexOfLast{it}.coerceAtLeast(4))}"
    }

    private fun normalizedClosureStart(date:LocalDate)=date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    private fun normalizedClosureEnd(date:LocalDate)=calendarWeekEnd(normalizedClosureStart(date))

    private fun ensureClosurePeriods(){
        if(closurePeriods.isEmpty() && ferieStart!=null && ferieEnd!=null){
            closurePeriods.add(ClosurePeriod(ferieStart!!,ferieEnd!!))
        }
        if(closurePeriods.isNotEmpty()){ferieStart=closurePeriods.first().start;ferieEnd=closurePeriods.first().end}
    }

    // Una chiusura dello studio esclude dal conteggio del pacchetto qualsiasi
    // appuntamento che cade nella settimana di chiusura. L'appuntamento resta
    // comunque nel calendario come storico e non viene cancellato.
    private fun isStudioClosed(date:LocalDate, periods:List<ClosurePeriod> = closurePeriods):Boolean{
        return periods.any{!date.isBefore(it.start) && !date.isAfter(it.end)}
    }

    private fun closureAppointmentsFor(periods:List<ClosurePeriod>):List<Appointment>{
        return appointments.filter{a->
            if(a.recovery || !isStudioClosed(a.date,periods)) return@filter false

            // La conferma della chiusura deve mostrare tutti gli appuntamenti
            // che verranno esclusi dal conteggio di un pacchetto: sia
            // settimanale sia a sedute. Per i pacchetti a sedute l'appuntamento
            // può essere collegato direttamente tramite sessionPackId oppure,
            // per i dati più vecchi, tramite il nome del cliente.
            val weekly = regularPackFor(a.name,a.date)!=null
            val session = sessionPacks.any{s->
                s.active && (
                    (a.sessionPackId!=0L && a.sessionPackId==s.id) ||
                    (a.sessionPackId==0L && identityKey(a.name)==identityKey(s.name))
                )
            }
            weekly || session
        }.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time}.thenBy{it.name.lowercase()})
    }

    private fun closureSettingsDialog(){
        ensureClosurePeriods()
        val scroll=ScrollView(this).apply{isFillViewport=true;overScrollMode=View.OVER_SCROLL_IF_CONTENT_SCROLLS;clipToPadding=false}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(32));clipToPadding=false}

        val hero=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(16),dp(14),dp(16),dp(14))
            background=appGlassSurface(Color.rgb(244,248,253),22,Color.rgb(210,226,243),1);elevation=dp(3).toFloat()
        }
        hero.addView(TextView(this).apply{text="🌴";textSize=30f;gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(54),dp(54)).apply{setMargins(0,0,dp(14),0)})
        hero.addView(LinearLayout(this).apply{orientation=LinearLayout.VERTICAL
            addView(TextView(this@MainActivity).apply{text="CHIUSURA FERIE";textSize=11f;setTextColor(Color.rgb(20,112,232));setTypeface(null,android.graphics.Typeface.BOLD)})
            addView(TextView(this@MainActivity).apply{text="Seleziona le settimane di chiusura";textSize=20f;setTextColor(Color.rgb(24,27,31));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(0,dp(2),0,0)})
            addView(TextView(this@MainActivity).apply{text="Tocca una o più settimane. Verranno selezionate automaticamente secondo il calendario dello studio.";textSize=13f;setTextColor(Color.rgb(100,108,116));setPadding(0,dp(3),0,0)})
        },LinearLayout.LayoutParams(0,-2,1f))
        box.addView(hero,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(14))})

        box.addView(TextView(this).apply{
            text="Le chiusure si impostano per settimane complete (\"${closureWeekLabel()}\"). I giorni non inclusi nel calendario restano visibili ma non vengono usati per definire la settimana. La chiusura dello studio estende il pacchetto e non genera recuperi del cliente."
            textSize=13f;setTextColor(Color.rgb(55,88,125));setPadding(dp(14),dp(12),dp(14),dp(12))
            background=appGlassSurface(Color.rgb(239,247,255),16,Color.rgb(207,226,247),1)
        },LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(16))})

        val working=closurePeriods.map{ClosurePeriod(it.start,it.end)}.toMutableList()
        val selectedWeeks=linkedSetOf<LocalDate>()
        fun addWeeksFromPeriods(periods:List<ClosurePeriod>){
            periods.forEach{p->
                var d=normalizedClosureStart(p.start)
                val end=normalizedClosureStart(p.end)
                while(!d.isAfter(end)){selectedWeeks.add(d);d=d.plusDays(7)}
            }
        }
        addWeeksFromPeriods(working)

        val selectedCard=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(14),dp(14),dp(14));background=appGlassSurface(Color.rgb(249,251,254),20,Color.rgb(213,226,240),1);elevation=dp(2).toFloat()}
        val selectedTitle=TextView(this).apply{textSize=16f;setTextColor(Color.rgb(30,34,40));setTypeface(null,android.graphics.Typeface.BOLD)}
        selectedCard.addView(selectedTitle)
        val selectedList=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        selectedCard.addView(selectedList,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(10),0,0)})
        box.addView(selectedCard,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})

        fun rebuildSelected(){
            selectedList.removeAllViews()
            selectedTitle.text="Settimane selezionate (${selectedWeeks.size})"
            if(selectedWeeks.isEmpty()){
                selectedList.addView(TextView(this).apply{text="Nessuna settimana selezionata.";textSize=13f;setTextColor(Color.rgb(95,105,116));setPadding(dp(10),dp(10),dp(10),dp(10));background=appGlassSurface(Color.rgb(244,248,253),14,Color.rgb(216,228,240),1)})
                return
            }
            selectedWeeks.sorted().forEach{st->
                val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),dp(7),dp(8),dp(7));background=appGlassSurface(Color.rgb(239,247,255),14,Color.rgb(213,229,247),1)}
                val dateWrap=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                dateWrap.addView(ImageView(this).apply{setImageDrawable(calendarIconDrawable(Color.rgb(20,91,165)));setPadding(dp(2),dp(2),dp(2),dp(2))},LinearLayout.LayoutParams(dp(24),dp(24)))
                dateWrap.addView(TextView(this).apply{text="${st.format(fmt)} → ${calendarWeekEnd(st).format(fmt)}";textSize=12.5f;setTextColor(Color.rgb(20,91,165));setPadding(dp(5),0,0,0)},LinearLayout.LayoutParams(0,-2,1f))
                row.addView(dateWrap,LinearLayout.LayoutParams(0,-2,1f))
                row.addView(TextView(this).apply{text="×";textSize=20f;gravity=Gravity.CENTER;setTextColor(Color.rgb(20,91,165));setOnClickListener{selectedWeeks.remove(st);rebuildSelected()}},LinearLayout.LayoutParams(dp(34),dp(34)))
                selectedList.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(6))})
            }
        }
        rebuildSelected()

        val openCalendar=Button(this).apply{
            text="Apri calendario e seleziona settimane";setAllCaps(false);textSize=14f;setTextColor(Color.rgb(20,91,165));stateListAnimator=null
            setCompoundDrawablesWithIntrinsicBounds(calendarIconDrawable(Color.rgb(20,91,165)),null,null,null)
            compoundDrawablePadding=dp(8)
            background=appGlassSurface(Color.rgb(239,247,255),16,Color.rgb(205,224,248),1)
        }
        box.addView(openCalendar,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(14))})

        fun showWeekPicker(){
            val dialog=Dialog(this)
            val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(16));background=dialogReadableSurface(Color.rgb(250,252,255),24,Color.rgb(198,220,242),1);clipToPadding=false}
            val title=TextView(this).apply{text="Seleziona settimane";textSize=21f;setTextColor(Color.rgb(24,27,31));setTypeface(null,android.graphics.Typeface.BOLD)}
            root.addView(title)
            root.addView(TextView(this).apply{text="Calendario: ${closureWeekLabel()}\nTocca una riga per selezionare la settimana";textSize=13f;setTextColor(Color.rgb(82,96,112));setLineSpacing(0f,1.08f);setPadding(0,dp(4),0,dp(14))})

            val monthHeader=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            val prev=Button(this).apply{text="‹";setAllCaps(false);textSize=28f;setTextColor(Color.rgb(20,91,165));background=dialogReadableSurface(Color.rgb(240,247,255),18,Color.rgb(210,228,246),1);stateListAnimator=null}
            val monthTitle=TextView(this).apply{textSize=18f;gravity=Gravity.CENTER;setTextColor(Color.rgb(24,27,31));setTypeface(null,android.graphics.Typeface.BOLD)}
            val next=Button(this).apply{text="›";setAllCaps(false);textSize=28f;setTextColor(Color.rgb(20,91,165));background=dialogReadableSurface(Color.rgb(240,247,255),18,Color.rgb(210,228,246),1);stateListAnimator=null}
            monthHeader.addView(prev,LinearLayout.LayoutParams(dp(46),dp(46)));monthHeader.addView(monthTitle,LinearLayout.LayoutParams(0,dp(46),1f));monthHeader.addView(next,LinearLayout.LayoutParams(dp(46),dp(46)))
            root.addView(monthHeader)

            val dayHeader=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            dayHeader.addView(TextView(this).apply{text="Settimana";textSize=11f;setTextColor(Color.rgb(95,105,116));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(dp(76),dp(32)))
            listOf("Lun","Mar","Mer","Gio","Ven","Sab","Dom").forEachIndexed{idx,label->
                dayHeader.addView(TextView(this).apply{text=label;textSize=11f;gravity=Gravity.CENTER;setTextColor(if(calendarVisibleDays[idx])Color.rgb(35,43,53)else Color.rgb(145,151,158))},LinearLayout.LayoutParams(0,dp(32),1f))
            }
            root.addView(dayHeader)
            val weeksBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
            root.addView(weeksBox,LinearLayout.LayoutParams(-1,0,1f).apply{setMargins(0,0,0,dp(8))})

            var shownMonth=LocalDate.now().withDayOfMonth(1)
            fun rebuildMonth(){
                monthTitle.text=shownMonth.format(DateTimeFormatter.ofPattern("MMMM yyyy",java.util.Locale.ITALIAN)).replaceFirstChar{it.uppercase()}
                weeksBox.removeAllViews()
                val first=shownMonth.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
                val last=shownMonth.withDayOfMonth(shownMonth.lengthOfMonth()).with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY))
                var week=first
                while(!week.isAfter(last)){
                    val weekStart=week
                    val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(2),dp(4),dp(2),dp(4))}
                    val checked=selectedWeeks.contains(weekStart)
                    val weekEnd=calendarWeekEnd(weekStart)
                    row.background=if(checked)dialogReadableSurface(Color.rgb(225,240,255),16,Color.rgb(85,157,224),1) else dialogReadableSurface(Color.rgb(252,253,255),16,Color.rgb(224,232,240),1)
                    row.addView(TextView(this).apply{text="${weekStart.format(DateTimeFormatter.ofPattern("dd/MM"))}";textSize=10.5f;setTextColor(if(checked)Color.rgb(20,91,165)else Color.rgb(95,105,116));gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(76),dp(48)))
                    for(i in 0..6){
                        val day=weekStart.plusDays(i.toLong())
                        val active=calendarVisibleDays[i]
                        val tv=TextView(this).apply{
                            text=day.dayOfMonth.toString();textSize=12f;gravity=Gravity.CENTER
                            setTextColor(if(!active)Color.rgb(160,166,173)else if(checked)Color.rgb(20,91,165)else Color.rgb(35,43,53))
                            alpha=if(active)1f else .62f
                        }
                        row.addView(tv,LinearLayout.LayoutParams(0,dp(48),1f))
                    }
                    row.setOnClickListener{
                        if(selectedWeeks.contains(weekStart))selectedWeeks.remove(weekStart) else selectedWeeks.add(weekStart)
                        rebuildMonth();rebuildSelected()
                    }
                    weeksBox.addView(row,LinearLayout.LayoutParams(-1,dp(58)).apply{setMargins(0,0,0,dp(6))})
                    week=week.plusDays(7)
                }
            }
            prev.setOnClickListener{shownMonth=shownMonth.minusMonths(1);rebuildMonth()}
            next.setOnClickListener{shownMonth=shownMonth.plusMonths(1);rebuildMonth()}
            val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            val cancel=Button(this).apply{text="Annulla";setAllCaps(false);textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,91,145));background=dialogReadableSurface(Color.rgb(245,249,253),17,Color.rgb(208,224,239),1);stateListAnimator=null}
            val done=Button(this).apply{text="Conferma";setAllCaps(false);textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.WHITE);background=roundedSurface(Color.rgb(30,112,230),17,Color.rgb(30,112,230),1);stateListAnimator=null}
            actions.addView(cancel,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(5),0)});actions.addView(done,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(5),0,0,0)})
            root.addView(actions)
            cancel.setOnClickListener{dialog.dismiss()}
            done.setOnClickListener{dialog.dismiss()}
            dialog.setContentView(root)
            dialog.window?.let{w->w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));w.setLayout((resources.displayMetrics.widthPixels*0.94f).toInt(),(resources.displayMetrics.heightPixels*0.82f).toInt());w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)}
            dialog.setOnShowListener{dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.94f).toInt(),(resources.displayMetrics.heightPixels*0.82f).toInt())}
            rebuildMonth();dialog.show();dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.94f).toInt(),(resources.displayMetrics.heightPixels*0.82f).toInt())
        }
        openCalendar.setOnClickListener{showWeekPicker()}

        val clear=Button(this).apply{text="Cancella tutte";setAllCaps(false);textSize=13.5f;setTextColor(Color.rgb(205,55,55));background=appGlassSurface(Color.rgb(255,247,247),16,Color.rgb(245,220,220),1);stateListAnimator=null}
        val close=Button(this).apply{text="Chiudi";setAllCaps(false);textSize=13.5f;setTextColor(Color.rgb(20,91,165));background=appGlassSurface(Color.rgb(240,247,255),16,Color.rgb(205,224,248),1);stateListAnimator=null}
        val save=Button(this).apply{text="Salva";setAllCaps(false);textSize=13.5f;setTextColor(Color.WHITE);background=appGlassSurface(Color.rgb(20,112,232),16,Color.rgb(20,112,232),1);stateListAnimator=null}
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        actions.addView(clear,LinearLayout.LayoutParams(0,dp(46),1f).apply{setMargins(0,0,dp(5),0)});actions.addView(close,LinearLayout.LayoutParams(0,dp(46),.8f).apply{setMargins(dp(5),0,dp(5),0)});actions.addView(save,LinearLayout.LayoutParams(dp(86),dp(44)).apply{setMargins(dp(5),0,0,0)})
        box.addView(actions)
        scroll.addView(box);showSettingsSubpage(scroll,"Chiusura ferie")

        clear.setOnClickListener{selectedWeeks.clear();rebuildSelected()}
        close.setOnClickListener{closeSettingsSubpage()}
        save.setOnClickListener{
            try{
                val sorted=selectedWeeks.sorted()
                val parsed=mutableListOf<ClosurePeriod>()
                var i=0
                while(i<sorted.size){
                    val start=sorted[i];var end=start;i++
                    while(i<sorted.size && sorted[i]==end.plusDays(7)){end=sorted[i];i++}
                    parsed.add(ClosurePeriod(start,calendarWeekEnd(end)))
                }
                val affected=closureAppointmentsFor(parsed)
                fun applyClosures(){
                    closurePeriods=parsed.toMutableList()
                    if(closurePeriods.isEmpty()){ferieStart=null;ferieEnd=null}else{ferieStart=closurePeriods.first().start;ferieEnd=closurePeriods.first().end}
                    saveData();closeSettingsSubpage();Toast.makeText(this,"Chiusure salvate: ${closurePeriods.size} periodo/i.",Toast.LENGTH_SHORT).show()
                }
                if(affected.isNotEmpty()){
                    closureAppointmentsConfirmDialog(affected){applyClosures()}
                }else applyClosures()
            }catch(_:Exception){Toast.makeText(this,"Impossibile salvare le settimane selezionate.",Toast.LENGTH_LONG).show()}
        }
    }

    private fun appointmentSettingsDialog(){
        val scroll=ScrollView(this).apply{isFillViewport=true;overScrollMode=View.OVER_SCROLL_IF_CONTENT_SCROLLS}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(30));clipToPadding=false}

        val hero=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(16),dp(14),dp(16),dp(14))
            background=appGlassSurface(Color.rgb(244,248,253),22,Color.rgb(210,226,243),1)
        }
        val heroIcon=TextView(this).apply{
            text="👥";textSize=27f;gravity=Gravity.CENTER
            setBackground(roundedSurface(Color.rgb(231,242,255),18,Color.rgb(202,223,245),1))
            setPadding(dp(8),dp(6),dp(8),dp(6))
        }
        hero.addView(heroIcon,LinearLayout.LayoutParams(dp(58),dp(58)))
        val heroText=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),0,0,0)}
        heroText.addView(TextView(this).apply{text="Impostazioni appuntamenti";textSize=18f;setTextColor(Color.rgb(28,38,50));setTypeface(null,android.graphics.Typeface.BOLD);setIncludeFontPadding(false)})
        heroText.addView(TextView(this).apply{text="Tipi, colori, durata e capienza degli appuntamenti";textSize=12.5f;setTextColor(Color.rgb(91,108,124));setPadding(0,dp(5),0,0)})
        hero.addView(heroText,LinearLayout.LayoutParams(0,-2,1f))
        box.addView(hero,LinearLayout.LayoutParams(-1,-2))

        box.addView(TextView(this).apply{
            text="Configura i tipi di appuntamento e il numero massimo di persone per fascia."
            textSize=13f;setTextColor(Color.rgb(82,101,122));setPadding(dp(14),dp(12),dp(14),dp(12))
            background=appGlassSurface(Color.rgb(240,247,255),16,Color.rgb(214,229,244),1)
        },LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(12),0,dp(16))})

        box.addView(TextView(this).apply{text="Tipi di appuntamento";textSize=17f;setTextColor(Color.rgb(30,34,40));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(dp(2),0,dp(2),dp(8))})

        val working=appointmentTypes.map{it.copy()}.toMutableList()
        val fields=mutableListOf<EditText>()
        val colorViews=mutableListOf<TextView>()
        val capacitySpinners=mutableListOf<Spinner>()
        val rows=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val palette=listOf(
            Color.rgb(45,135,210), Color.rgb(0,145,125), Color.rgb(220,75,75),
            Color.rgb(235,145,35), Color.rgb(135,90,190), Color.rgb(35,155,175),
            Color.rgb(70,120,75), Color.rgb(210,75,135), Color.rgb(90,105,120)
        )

        fun chooseColor(index:Int){
            val title=TextView(this).apply{text="Colore appuntamento";textSize=20f;setTextColor(Color.rgb(25,28,32));setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setPadding(dp(8),dp(4),dp(8),dp(8))}
            val grid=GridLayout(this).apply{columnCount=3;setPadding(dp(12),dp(4),dp(12),dp(10))}
            lateinit var cd:AlertDialog
            palette.forEach{c->
                val swatch=TextView(this).apply{
                    text=if(working[index].color==c)"✓" else "";textSize=18f;gravity=Gravity.CENTER;setTextColor(Color.WHITE)
                    background=appGlassSurface(c,18,Color.WHITE,2);setOnClickListener{
                        working[index].color=c
                        colorViews.getOrNull(index)?.apply{setTextColor(c);background=appGlassSurface(Color.WHITE,16,c,2)}
                        cd.dismiss()
                    }
                }
                grid.addView(swatch,GridLayout.LayoutParams().apply{width=dp(64);height=dp(56);setMargins(dp(7),dp(7),dp(7),dp(7))})
            }
            val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),dp(8),dp(10),dp(8));addView(title);addView(grid)}
            cd=AlertDialog.Builder(this).setView(content).create()
            preparePopupBackdrop(cd)
            cd.setOnShowListener{popupBackdropCurrentDialog=cd;cd.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28));applyPopupBackdropEffect(cd);cd.window?.setDimAmount(.40f);cd.window?.setLayout((resources.displayMetrics.widthPixels*.86f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT)}
            cd.show();cd.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28));cd.window?.setDimAmount(.40f);cd.window?.setLayout((resources.displayMetrics.widthPixels*.86f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT)
        }

        fun render(){
            rows.removeAllViews();fields.clear();colorViews.clear();capacitySpinners.clear()
            working.forEachIndexed{i,t->
                val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(10),dp(12),dp(10));background=appGlassSurface(Color.WHITE,20,Color.rgb(226,229,234),1)}
                val head=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                val swatch=TextView(this).apply{text="●";textSize=26f;gravity=Gravity.CENTER;setTextColor(t.color);background=appGlassSurface(Color.WHITE,16,t.color,2);isClickable=true;setOnClickListener{chooseColor(i)}}
                colorViews.add(swatch);head.addView(swatch,LinearLayout.LayoutParams(dp(52),dp(52)))
                val f=modernEditText().apply{setSingleLine(true);setText(t.name);hint="Nome appuntamento";gravity=Gravity.CENTER_VERTICAL}
                fields.add(f);head.addView(f,LinearLayout.LayoutParams(0,dp(52),1f).apply{setMargins(dp(10),0,0,0)})
                card.addView(head)
                val info=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(8),0,0)}
                info.addView(TextView(this).apply{text="Capienza";textSize=13f;setTextColor(Color.rgb(92,96,102));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,dp(42),1f))
                val current=calendarRoutines.getOrNull(activeRoutineIndex)?.maxByType?.getOrNull(i) ?: calendarRoutines.getOrNull(activeRoutineIndex)?.maxTotal ?: 3
                val cap=Spinner(this).also{installNikiTimeDropdown(it)}.apply{adapter=centeredSpinnerAdapter((1..10).map{it.toString()});setSelection(current.coerceIn(1,10)-1)}
                capacitySpinners.add(cap);info.addView(cap,LinearLayout.LayoutParams(dp(105),dp(42)))
                card.addView(info)
                rows.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(7),0,dp(10))})
            }
        }
        render();box.addView(rows)

        val add=softBlueButtonStyle("＋ Aggiungi tipo di appuntamento")
        box.addView(add,LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(4),0,dp(12))})
        add.setOnClickListener{
            val id="TYPE${((working.map{it.id.removePrefix("TYPE").toIntOrNull()?:0}.maxOrNull()?:0)+1)}"
            working.add(AppointmentType(id,"Nuovo appuntamento",palette[working.size%palette.size]));render();scroll.post{scroll.smoothScrollTo(0,box.measuredHeight)}
        }

        box.addView(TextView(this).apply{text="Durata slot del calendario";textSize=15f;setTextColor(Color.rgb(55,59,64));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(0,dp(10),0,dp(4))})
        box.addView(TextView(this).apply{text="Imposta ogni fascia della griglia. La durata non modifica il conteggio delle sedute dei pacchetti.";textSize=12.5f;setTextColor(Color.rgb(105,112,120));setPadding(0,0,0,dp(6))})
        val slotDurations=listOf(15,30,45,60,90)
        val slotDurationSpinner=Spinner(this).also{installNikiTimeDropdown(it)}.apply{adapter=centeredSpinnerAdapter(slotDurations.map{"$it minuti"});setSelection(slotDurations.indexOf(calendarSlotDuration).coerceAtLeast(0))}
        box.addView(slotDurationSpinner,LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,0,0,dp(10))})

        box.addView(TextView(this).apply{text="Intervallo orari suggeriti — Evento libero";textSize=15f;setTextColor(Color.rgb(55,59,64));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(0,dp(4),0,dp(4))})
        box.addView(TextView(this).apply{text="Solo per gli eventi liberi. Gli appuntamenti normali continuano a usare gli slot del calendario.";textSize=12.5f;setTextColor(Color.rgb(105,112,120));setPadding(0,0,0,dp(6))})
        val freeEventStepOptions=listOf(5,10,15,30,45,60)
        val freeEventStepSpinner=Spinner(this).also{installNikiTimeDropdown(it)}.apply{adapter=centeredSpinnerAdapter(freeEventStepOptions.map{"$it minuti"});setSelection(freeEventStepOptions.indexOf(freeEventTimeStep).coerceAtLeast(0))}
        box.addView(freeEventStepSpinner,LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,0,0,dp(10))})

        box.addView(TextView(this).apply{text="Capienza massima complessiva per fascia";textSize=15f;setTextColor(Color.rgb(55,59,64));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(0,dp(4),0,dp(4))})
        val routine=calendarRoutines.getOrNull(activeRoutineIndex)
        val max=Spinner(this).also{installNikiTimeDropdown(it)}.apply{adapter=centeredSpinnerAdapter((1..10).map{it.toString()});setSelection(((routine?.maxTotal?:3).coerceIn(1,10))-1)}
        box.addView(max,LinearLayout.LayoutParams(-1,dp(48)))
        box.addView(TextView(this).apply{text="Tocca il pallino colorato per cambiare il colore.";textSize=12.5f;setTextColor(Color.rgb(120,124,130));gravity=Gravity.CENTER;setPadding(0,dp(8),0,dp(4))})

        val save=Button(this).apply{text="Salva";setAllCaps(false);textSize=14f;setTextColor(Color.WHITE);background=appGlassSurface(Color.rgb(0,125,110),18);stateListAnimator=null}
        box.addView(save,LinearLayout.LayoutParams(dp(96),dp(44)).apply{gravity=Gravity.RIGHT;setMargins(0,dp(12),0,0)})
        scroll.addView(box,ViewGroup.LayoutParams(-1,-2))
        showSettingsSubpage(scroll,"Appuntamenti")
        save.setOnClickListener{
            working.forEachIndexed{i,t->t.name=fields.getOrNull(i)?.text?.toString()?.trim().orEmpty().ifEmpty{"Tipo ${i+1}"}}
            appointmentTypes.clear();appointmentTypes.addAll(working)
            calendarRoutines.forEach{routineItem->
                routineItem.maxTotal=max.selectedItemPosition+1
                while(routineItem.maxByType.size<appointmentTypes.size)routineItem.maxByType.add(routineItem.maxTotal)
                appointmentTypes.forEachIndexed{i,_->routineItem.maxByType[i]=capacitySpinners.getOrNull(i)?.selectedItemPosition?.plus(1)?:routineItem.maxByType.getOrElse(i){routineItem.maxTotal}}
            }
            calendarSlotDuration=slotDurations.getOrElse(slotDurationSpinner.selectedItemPosition){45};freeEventTimeStep=freeEventStepOptions.getOrElse(freeEventStepSpinner.selectedItemPosition){15};saveData();closeSettingsSubpage();Toast.makeText(this,"Impostazioni appuntamenti salvate.",Toast.LENGTH_SHORT).show()
        }
    }

    private fun calendarSettingsDialog(){
        val scroll=ScrollView(this).apply{isFillViewport=true;clipToPadding=false;overScrollMode=View.OVER_SCROLL_IF_CONTENT_SCROLLS}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(30))}

        // Struttura Niki UI condivisa con le altre sottopagine delle Impostazioni.
        val hero=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(16),dp(14),dp(16),dp(14))
            background=appGlassSurface(Color.rgb(244,248,253),22,Color.rgb(210,226,243),1)
        }
        val heroIcon=ImageView(this).apply{
            setImageDrawable(calendarIconDrawable(Color.rgb(45,105,170)))
            setPadding(dp(11),dp(11),dp(11),dp(11))
            background=roundedSurface(Color.rgb(231,242,255),18,Color.rgb(202,223,245),1)
        }
        hero.addView(heroIcon,LinearLayout.LayoutParams(dp(58),dp(58)))
        val heroText=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),0,0,0)}
        heroText.addView(TextView(this).apply{text="Impostazioni calendario";textSize=18f;setTextColor(Color.rgb(28,38,50));setTypeface(null,android.graphics.Typeface.BOLD);setIncludeFontPadding(false)})
        heroText.addView(TextView(this).apply{text="Visualizzazione e pulsanti del calendario";textSize=12.5f;setTextColor(Color.rgb(91,108,124));setPadding(0,dp(5),0,0)})
        hero.addView(heroText,LinearLayout.LayoutParams(0,-2,1f))
        box.addView(hero,LinearLayout.LayoutParams(-1,-2))

        box.addView(TextView(this).apply{
            text="Personalizza come viene mostrato e utilizzato il calendario. Le modifiche vengono registrate automaticamente."
            textSize=13f;setTextColor(Color.rgb(82,101,122));setPadding(dp(14),dp(12),dp(14),dp(12))
            background=appGlassSurface(Color.rgb(240,247,255),16,Color.rgb(214,229,244),1)
        },LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(12),0,dp(14))})

        fun sectionCard(title:String,subtitle:String?=null):LinearLayout{
            val card=LinearLayout(this).apply{
                orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(14),dp(16),dp(14))
                background=appGlassSurface(Color.rgb(249,251,254),20,Color.rgb(213,226,240),1)
            }
            card.addView(TextView(this).apply{text=title;textSize=17f;setTextColor(Color.rgb(30,34,40));setTypeface(null,android.graphics.Typeface.BOLD);setIncludeFontPadding(false)})
            if(!subtitle.isNullOrBlank())card.addView(TextView(this).apply{text=subtitle;textSize=12.5f;setTextColor(Color.rgb(105,111,118));setPadding(0,dp(5),0,dp(10))})
            return card
        }

        val daysCard=sectionCard("Giorni visualizzati","Scegli quali giorni della settimana mostrare nel calendario.")
        val dayChecks=(0..6).map{i->CheckBox(this).apply{
            text=dayShort(i);textSize=15f;isChecked=calendarVisibleDays[i];setPadding(0,0,0,0)
            buttonTintList=android.content.res.ColorStateList.valueOf(Color.rgb(20,112,232))
        }}
        dayChecks.forEach{cb->daysCard.addView(cb,LinearLayout.LayoutParams(-1,dp(40)))}
        box.addView(daysCard,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(14))})

        val buttonsCard=sectionCard("Personalizzazione dei tasti","Scegli quali tasti mostrare sopra e quali sotto. Ogni barra si adatta automaticamente alla larghezza disponibile.")
        val labels=mapOf("APPT" to "＋  Appuntamento","SEARCH" to "🔎  Cerca","TODAY" to "Oggi","PREV" to "‹  Settimana precedente","NEXT" to "›  Settimana successiva")
        val allKeys=listOf("APPT","SEARCH","TODAY","PREV","NEXT")
        val topWorking=calendarTopButtons.filter{it in allKeys}.distinct().toMutableList()
        val bottomWorking=calendarBottomButtons.filter{it in allKeys && it !in topWorking}.distinct().toMutableList()
        if(topWorking.isEmpty()&&bottomWorking.isEmpty()){topWorking.add("APPT");bottomWorking.addAll(listOf("SEARCH","TODAY","PREV","NEXT"))}
        if("PREV" in topWorking && "NEXT" in topWorking && topWorking.indexOf("PREV")>topWorking.indexOf("NEXT")){val a=topWorking.indexOf("PREV");val b=topWorking.indexOf("NEXT");val t=topWorking[a];topWorking[a]=topWorking[b];topWorking[b]=t}
        if("PREV" in bottomWorking && "NEXT" in bottomWorking && bottomWorking.indexOf("PREV")>bottomWorking.indexOf("NEXT")){val a=bottomWorking.indexOf("PREV");val b=bottomWorking.indexOf("NEXT");val t=bottomWorking[a];bottomWorking[a]=bottomWorking[b];bottomWorking[b]=t}
        fun validArrowOrder():Boolean{val combined=topWorking+bottomWorking;val pi=combined.indexOf("PREV");val ni=combined.indexOf("NEXT");return pi<0||ni<0||pi<ni}
        val topContainer=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val bottomContainer=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val preview=TextView(this).apply{textSize=12.5f;setTextColor(Color.rgb(75,100,125));setPadding(0,dp(12),0,dp(2))}
        fun renderPlacement(){
            fun renderList(container:LinearLayout,working:MutableList<String>,other:MutableList<String>){
                container.removeAllViews()
                if(working.isEmpty()){
                    container.addView(TextView(this).apply{text="Nessun tasto in questa barra";textSize=12.5f;setTextColor(Color.GRAY);setGravity(Gravity.CENTER);setPadding(0,dp(10),0,dp(10));background=appGlassSurface(Color.rgb(246,248,250),14,Color.rgb(228,231,235),1)},LinearLayout.LayoutParams(-1,dp(44)))
                }else working.forEachIndexed{i,key->
                    val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(2),dp(4),dp(2));background=appGlassSurface(Color.rgb(248,250,253),16,Color.rgb(220,229,238),1)}
                    row.addView(TextView(this).apply{text=labels[key]?:key;textSize=14f;setTextColor(Color.rgb(30,33,38));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,dp(46),1f))
                    val move=Button(this).apply{text="⇄";setAllCaps(false);textSize=16f;stateListAnimator=null;setTextColor(Color.rgb(20,91,165));setBackgroundColor(Color.TRANSPARENT);setOnClickListener{working.removeAt(i);other.add(key);renderPlacement()}}
                    val up=Button(this).apply{text="↑";setAllCaps(false);textSize=18f;stateListAnimator=null;setTextColor(Color.rgb(20,91,165));setBackgroundColor(Color.TRANSPARENT);isEnabled=i>0;alpha=if(i>0)1f else .35f;setOnClickListener{if(i>0){val c=working[i];working[i]=working[i-1];working[i-1]=c;if(validArrowOrder())renderPlacement()else{val d=working[i];working[i]=working[i-1];working[i-1]=d}}}}
                    val down=Button(this).apply{text="↓";setAllCaps(false);textSize=18f;stateListAnimator=null;setTextColor(Color.rgb(20,91,165));setBackgroundColor(Color.TRANSPARENT);isEnabled=i<working.lastIndex;alpha=if(i<working.lastIndex)1f else .35f;setOnClickListener{if(i<working.lastIndex){val c=working[i];working[i]=working[i+1];working[i+1]=c;if(validArrowOrder())renderPlacement()else{val d=working[i];working[i]=working[i+1];working[i+1]=d}}}}
                    row.addView(move,LinearLayout.LayoutParams(dp(42),dp(46)));row.addView(up,LinearLayout.LayoutParams(dp(40),dp(46)));row.addView(down,LinearLayout.LayoutParams(dp(40),dp(46)))
                    container.addView(row,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,dp(4),0,0)})
                }
            }
            renderList(topContainer,topWorking,bottomWorking);renderList(bottomContainer,bottomWorking,topWorking)
            val topText=if(topWorking.isEmpty())"Nessuno" else topWorking.joinToString("  •  "){labels[it]?:it}
            val bottomText=if(bottomWorking.isEmpty())"Nessuno" else bottomWorking.joinToString("  •  "){labels[it]?:it}
            preview.text="Anteprima:\nSopra: $topText\nSotto: $bottomText\n\nLe frecce ‹ e › mantengono sempre questo ordine."
        }
        buttonsCard.addView(TextView(this).apply{text="Barra superiore";textSize=15.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,38,43));setPadding(0,dp(6),0,dp(2))})
        buttonsCard.addView(topContainer)
        buttonsCard.addView(TextView(this).apply{text="Barra inferiore";textSize=15.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,38,43));setPadding(0,dp(14),0,dp(2))})
        buttonsCard.addView(bottomContainer)
        buttonsCard.addView(TextView(this).apply{text="⇄ sposta  •  ↑ ↓ riordina";textSize=12f;setTextColor(Color.rgb(92,96,102));setPadding(0,dp(8),0,0)})
        buttonsCard.addView(preview)
        renderPlacement()
        box.addView(buttonsCard,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(14))})

        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(4),0,dp(0))}
        val close=Button(this).apply{text="Annulla";setAllCaps(false);textSize=13.5f;setTextColor(Color.rgb(0,125,110));background=ColorDrawable(Color.TRANSPARENT);stateListAnimator=null}
        val save=Button(this).apply{text="Salva";setAllCaps(false);textSize=13.5f;setTextColor(Color.WHITE);background=appGlassSurface(Color.rgb(20,112,232),18,Color.rgb(20,112,232),1);stateListAnimator=null}
        actions.addView(close,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(8),0)})
        actions.addView(save,LinearLayout.LayoutParams(0,dp(48),1f))
        box.addView(actions)
        scroll.addView(box,ViewGroup.LayoutParams(-1,-2))
        showSettingsSubpage(scroll,"Calendario")
        close.setOnClickListener{closeSettingsSubpage()}
        save.setOnClickListener{
            if(dayChecks.none{it.isChecked}){Toast.makeText(this,"Seleziona almeno un giorno del calendario.",Toast.LENGTH_LONG).show();return@setOnClickListener}
            if(!validArrowOrder()){Toast.makeText(this,"Le frecce ‹ e › devono rimanere in questo ordine.",Toast.LENGTH_LONG).show();return@setOnClickListener}
            calendarVisibleDays=BooleanArray(7){i->dayChecks[i].isChecked}
            calendarTopButtons=topWorking.toMutableList();calendarBottomButtons=bottomWorking.toMutableList()
            calendarNavOrder=(calendarTopButtons+calendarBottomButtons).filter{it!="APPT"}.toMutableList()
            calendarNavPosition=if(calendarTopButtons.any{it!="APPT"})0 else 1
            saveData();closeSettingsSubpage(false);Toast.makeText(this,"Impostazioni calendario salvate.",Toast.LENGTH_SHORT).show();calendarScreen()
        }
    }

    private fun paymentsPlaceholderScreen(){
        lastHomeBackAt = 0L
        paymentsOverlay?.let { (it.parent as? ViewGroup)?.removeView(it) }
        val root=FrameLayout(this).apply{background=appGlassBackground()}
        val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(24),dp(24),dp(24),dp(24))}
        val panel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(22),dp(30),dp(22),dp(30));background=roundedSurface(Color.rgb(248,251,255),24,Color.rgb(207,227,246),1)}
        panel.addView(TextView(this).apply{text="€  Pagamenti";textSize=25f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(27,69,113));gravity=Gravity.CENTER})
        panel.addView(TextView(this).apply{text="Sezione attualmente non disponibile.\nSarà attivata in un prossimo aggiornamento.";textSize=15f;setTextColor(Color.rgb(76,94,114));gravity=Gravity.CENTER;setPadding(0,dp(16),0,0)})
        content.addView(panel,LinearLayout.LayoutParams(-1,-2))
        root.addView(content,FrameLayout.LayoutParams(-1,-1))
        root.addView(softBlueButtonStyle("←  Torna ai pacchetti").apply{setOnClickListener{(root.parent as? ViewGroup)?.removeView(root);paymentsOverlay=null}},FrameLayout.LayoutParams(-1,dp(48),Gravity.BOTTOM).apply{setMargins(dp(18),0,dp(18),dp(18))})
        paymentsOverlay = root
        (findViewById<ViewGroup>(android.R.id.content)).addView(root)
    }

    // La scheda e il pacchetto rimangono entità diverse, collegate solo per ID stabile.
    // Il nome serve per il suggerimento: mai collegare senza un'azione esplicita.
    private fun clientNameKey(value:String):String =
        value.trim().lowercase(java.util.Locale.ITALIAN).split(Regex("\\s+"))
            .filter{it.isNotBlank()}.sorted().joinToString(" ")

    private fun matchesClientName(c:ClientProfile,name:String):Boolean =
        name.isNotBlank() && clientNameKey("${c.lastName} ${c.firstName}")==clientNameKey(name)

    private fun nameMatches(name:String):List<ClientProfile> =
        clients.filter{matchesClientName(it,name)}.sortedWith(compareBy({it.lastName.lowercase()},{it.firstName.lowercase()}))

    private fun clientDisplay(c:ClientProfile):String = "${c.lastName} ${c.firstName}".trim()

    private fun clientNameInput(edit:EditText){
        // TYPE_TEXT_FLAG_CAP_WORDS propone l'iniziale maiuscola sulla tastiera.
        // Non riscriviamo il testo: minuscole e grafie volute restano intatte.
        edit.inputType=android.text.InputType.TYPE_CLASS_TEXT or
            android.text.InputType.TYPE_TEXT_VARIATION_PERSON_NAME or
            android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS
        edit.setSingleLine(true)
    }

    // Per i soli nomi CLIENTE non forziamo automaticamente la grafia al salvataggio.
    private fun enteredClientName(value:String):String = value.trim().replace(Regex("\\s+")," ")

    // Suggerimento in tempo reale, non un collegamento implicito.
    // Restituisce l'ID solo se l'utente ha toccato una scheda proposta.
    private fun attachClientSuggestions(edit:EditText,container:LinearLayout):()->Long{
        clientNameInput(edit)
        var chosenId=0L
        var settingText=false
        val suggestions=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE}
        container.addView(suggestions,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))})
        fun refresh(){
            val input=edit.text.toString().trim()
            suggestions.removeAllViews()
            if(input.length<2){suggestions.visibility=View.GONE;return}
            if(chosenId!=0L){
                val c=clients.firstOrNull{it.id==chosenId}
                if(c!=null){
                    val selected=TextView(this).apply{
                        text="✓  Scheda selezionata: ${clientDisplay(c)}    ·    Cambia"
                        textSize=12.5f;setTextColor(Color.rgb(27,105,169));setPadding(dp(12),dp(10),dp(12),dp(10))
                        background=liquidInteractiveSurface(Color.rgb(237,246,255),15,Color.rgb(200,225,248),1)
                        setOnClickListener{chosenId=0L;refresh()}
                    }
                    suggestions.addView(selected);suggestions.visibility=View.VISIBLE;return
                }
                chosenId=0L
            }
            val key=input.lowercase(java.util.Locale.ITALIAN)
            val candidates=clients.filter{c->
                matchesClientName(c,input) || clientDisplay(c).lowercase(java.util.Locale.ITALIAN).contains(key) ||
                    "${c.firstName} ${c.lastName}".lowercase(java.util.Locale.ITALIAN).contains(key)
            }.sortedByDescending{matchesClientName(it,input)}.take(3)
            if(candidates.isEmpty()){suggestions.visibility=View.GONE;return}
            suggestions.visibility=View.VISIBLE
            suggestions.addView(TextView(this).apply{text="SCHEDE GIÀ REGISTRATE · tocca per collegare";textSize=11.5f;setTextColor(Color.rgb(58,100,141));setPadding(dp(4),dp(4),dp(4),dp(4))})
            candidates.forEach{c->
                val row=TextView(this).apply{
                    text="＋  ${clientDisplay(c)}${if(matchesClientName(c,input))"   ·   nome corrispondente" else ""}"
                    textSize=13.5f;setTextColor(Color.rgb(32,60,89));setPadding(dp(12),dp(12),dp(10),dp(12))
                    background=liquidInteractiveSurface(Color.rgb(245,250,255),16,Color.rgb(201,227,247),1)
                    setOnClickListener{
                        chosenId=c.id
                        settingText=true;edit.setText(clientDisplay(c));edit.setSelection(edit.text.length);settingText=false
                        refresh()
                    }
                }
                suggestions.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(4))})
            }
        }
        edit.addTextChangedListener(object:TextWatcher{
            override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
            override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){if(!settingText){chosenId=0L;refresh()}}
            override fun afterTextChanged(s:Editable?){}
        })
        return {chosenId}
    }

    // Finestra personalizzata Niki UI Liquid Glass: ricerca, suggerimento e scelta manuale.
    private fun showClientLinkChooser(packName:String,linkedId:Long,link:(Long)->Unit,onReturn:()->Unit){
        val dialog=Dialog(this)
        val panel=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(16))
            background=appGlassSurface(Color.rgb(239,247,255),26,Color.rgb(175,210,243),1)
        }
        panel.addView(TextView(this).apply{text="♙  Collega scheda cliente";textSize=20f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(29,62,94));gravity=Gravity.CENTER})
        panel.addView(TextView(this).apply{
            text="Scegli una scheda per questo abbonamento. Nessun collegamento avviene senza conferma."
            textSize=12.5f;setTextColor(Color.rgb(77,100,122));gravity=Gravity.CENTER;setPadding(0,dp(6),0,dp(12))
        })
        val query=modernEditText().apply{hint="Cerca nome o cognome";setSingleLine(true);inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS;textSize=14f}
        panel.addView(query,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(10))})
        val rows=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val scroll=ScrollView(this).apply{isFillViewport=false;addView(rows)}
        panel.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val close=softBlueButtonStyle("ANNULLA").apply{setOnClickListener{dialog.dismiss()}}
        panel.addView(close,LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(12),0,0)})
        fun select(id:Long){link(id);dialog.dismiss();onReturn()}
        fun addOption(title:String,subtitle:String,selected:Boolean,onSelect:()->Unit){
            val row=LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
                setPadding(dp(12),dp(11),dp(10),dp(11))
                background=liquidInteractiveSurface(Color.rgb(242,249,255),18,Color.rgb(200,225,248),1)
                isClickable=true;setOnClickListener{onSelect()}
            }
            row.addView(TextView(this).apply{text=if(selected)"✓" else "♙";gravity=Gravity.CENTER;textSize=22f;setTextColor(Color.rgb(35,119,195))},LinearLayout.LayoutParams(dp(38),dp(45)))
            val labels=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
            labels.addView(TextView(this).apply{text=title;textSize=15f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(29,50,72))})
            labels.addView(TextView(this).apply{text=subtitle;textSize=11.5f;setTextColor(Color.rgb(78,104,130));setPadding(0,dp(3),0,0)})
            row.addView(labels,LinearLayout.LayoutParams(0,-2,1f))
            rows.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(7))})
        }
        fun refresh(){
            rows.removeAllViews()
            val search=query.text.toString().trim().lowercase(java.util.Locale.ITALIAN)
            val found=clients.filter{c->search.isBlank() || clientDisplay(c).lowercase(java.util.Locale.ITALIAN).contains(search) ||
                "${c.firstName} ${c.lastName}".lowercase(java.util.Locale.ITALIAN).contains(search) ||
                c.phone.filter{it.isDigit()}.contains(search.filter{it.isDigit()}.takeIf{it.length>=3}?:"¤")
            }.sortedWith(compareByDescending<ClientProfile>{matchesClientName(it,packName)}.thenBy{it.lastName.lowercase()}.thenBy{it.firstName.lowercase()})
            if(search.isBlank() && linkedId!=0L)addOption("Scollega scheda","Mantiene intatti cliente e abbonamento",false){select(0L)}
            if(found.isEmpty())rows.addView(TextView(this).apply{
                text=if(clients.isEmpty())"Nessuna scheda registrata. Importane una dalla sezione Clienti." else "Nessuna scheda trovata. Prova un altro nome."
                textSize=13f;setTextColor(Color.rgb(85,100,115));gravity=Gravity.CENTER;setPadding(0,dp(28),0,dp(28))
            })
            found.forEach{c->
                val match=matchesClientName(c,packName)
                val info=when{
                    match->"✓ Nome corrispondente · conferma per collegare"
                    c.phone.filter{it.isDigit()}.length>=4->"Scheda registrata · telefono ••••${c.phone.filter{it.isDigit()}.takeLast(4)}"
                    else->"Scheda cliente registrata"
                }
                addOption(clientDisplay(c),info,c.id==linkedId){select(c.id)}
            }
        }
        query.addTextChangedListener(object:TextWatcher{
            override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
            override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){refresh()}
            override fun afterTextChanged(s:Editable?){}
        })
        refresh()
        dialog.setContentView(panel)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*.91f).toInt(),(resources.displayMetrics.heightPixels*.70f).toInt())
    }

    private fun promptClientLinkAfterCreation(name:String,selectedId:Long,link:(Long)->Unit){
        if(selectedId!=0L || nameMatches(name).isEmpty())return
        window.decorView.post{
            showClientLinkChooser(name,0L,{id->link(id);saveData()},{render()})
        }
    }

    // Se il modulo arriva DOPO un pacchetto, cerca quelli ancora senza scheda.
    private fun offerMatchingPackagesForProfile(c:ClientProfile){
        val targets=mutableListOf<Pair<String,()->Unit>>()
        packs.filter{it.clientId==0L && matchesClientName(c,it.name)}.forEach{p->
            targets.add("${p.name} · ${p.packageType} · ${p.start.format(fmt)}" to {p.clientId=c.id})
        }
        sessionPacks.filter{it.clientId==0L && matchesClientName(c,it.name)}.forEach{sp->
            targets.add("${sp.name} · Pacchetto a sedute · ${sp.start.format(fmt)}" to {sp.clientId=c.id})
        }
        if(targets.isEmpty())return
        val dialog=Dialog(this)
        val box=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(16));background=appGlassSurface(Color.rgb(239,247,255),26,Color.rgb(185,217,245),1)
        }
        box.addView(TextView(this).apply{text="Abbonamenti da collegare";textSize=20f;gravity=Gravity.CENTER;setTextColor(Color.rgb(29,62,94));setTypeface(null,android.graphics.Typeface.BOLD)})
        box.addView(TextView(this).apply{text="Per ${clientDisplay(c)} ho trovato ${targets.size} possibile/i corrispondenza/e. Seleziona quelli corretti.";textSize=13f;setTextColor(Color.rgb(75,98,121));setPadding(0,dp(10),0,dp(10))})
        val checked=BooleanArray(targets.size)
        val listing=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        targets.forEachIndexed{i,target->
            val check=CheckBox(this).apply{
                text=target.first;textSize=13.5f;setTextColor(Color.rgb(28,50,73));buttonTintList=android.content.res.ColorStateList.valueOf(Color.rgb(27,116,195))
                background=liquidInteractiveSurface(Color.rgb(245,250,255),17,Color.rgb(199,225,248),1)
                setPadding(dp(10),dp(8),dp(10),dp(8));setOnCheckedChangeListener{_,value->checked[i]=value}
            }
            listing.addView(check,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(6))})
        }
        box.addView(ScrollView(this).apply{addView(listing)},LinearLayout.LayoutParams(-1,0,1f))
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        actions.addView(softBlueButtonStyle("NON ORA").apply{setOnClickListener{dialog.dismiss()}},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(6),0)})
        actions.addView(softBlueButtonStyle("COLLEGA SELEZIONATI").apply{setOnClickListener{
            if(checked.none{it}){Toast.makeText(this@MainActivity,"Seleziona almeno un abbonamento.",Toast.LENGTH_SHORT).show();return@setOnClickListener}
            targets.forEachIndexed{i,item->if(checked[i])item.second.invoke()};saveData();dialog.dismiss();render()
            Toast.makeText(this@MainActivity,"Collegamenti salvati.",Toast.LENGTH_SHORT).show()
        }},LinearLayout.LayoutParams(0,dp(48),1.55f))
        box.addView(actions,LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(12),0,0)})
        dialog.setContentView(box);dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*.92f).toInt(),(resources.displayMetrics.heightPixels*.63f).toInt())
    }
    private fun addClientLinkSection(root:LinearLayout,packName:String,linkedId:()->Long,
                                     saveLink:(Long)->Unit,closePackage:()->Unit,reopenPackage:()->Unit){
        val current=clients.firstOrNull{it.id==linkedId()}
        val card=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(14),dp(12),dp(12),dp(12));background=appGlassSurface(Color.rgb(239,247,255),20,Color.rgb(191,221,246),1)}
        card.addView(TextView(this).apply{text="♙";textSize=27f;gravity=Gravity.CENTER;setTextColor(Color.rgb(20,112,200));
            background=appGlassSurface(Color.rgb(247,251,255),16,Color.rgb(213,233,250),1)},LinearLayout.LayoutParams(dp(44),dp(44)))
        val body=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),0,0,0)}
        body.addView(TextView(this).apply{text="Scheda cliente";textSize=15.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(30,60,93))})
        body.addView(TextView(this).apply{text=if(current==null)"Non collegata · tocca per associare" else "${current.lastName} ${current.firstName} · Apri scheda";
            textSize=12f;setTextColor(Color.rgb(76,99,120))})
        card.addView(body,LinearLayout.LayoutParams(0,-2,1f))
        card.addView(TextView(this).apply{text=if(current==null)"+" else "›";textSize=23f;gravity=Gravity.CENTER;setTextColor(Color.rgb(20,105,190))},LinearLayout.LayoutParams(dp(28),dp(44)))
        root.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(12),0,dp(6))})
        card.setOnClickListener{
            if(current!=null){closePackage();window.decorView.post{clientProfileScreen(current,reopenPackage)}}
            else showClientLinkChooser(packName,linkedId(),saveLink){closePackage();window.decorView.post{reopenPackage()}}
        }
        if(current!=null){
            val change=softBlueButtonStyle("CAMBIA COLLEGAMENTO").apply{setOnClickListener{
                showClientLinkChooser(packName,linkedId(),saveLink){closePackage();window.decorView.post{reopenPackage()}}
            }}
            root.addView(change,LinearLayout.LayoutParams(-1,dp(40)).apply{setMargins(0,0,0,dp(6))})
        }
    }

    private fun clientsScreen(){
        lastHomeBackAt = 0L
        clientOverlay?.let{(it.parent as? ViewGroup)?.removeView(it)}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(18))}
        box.addView(TextView(this).apply{text="Clienti";textSize=24f;setTextColor(Color.rgb(25,32,40));setTypeface(null,android.graphics.Typeface.BOLD)})
        box.addView(TextView(this).apply{text="Schede cliente e modulo standard da condividere.";textSize=13f;setTextColor(Color.rgb(95,102,110));setPadding(0,dp(4),0,dp(14))})
        box.addView(softBlueButtonStyle("＋  NUOVO MODULO CLIENTE").apply{setOnClickListener{clientQuestionnaire(null)}},LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,0,0,dp(8))})
        box.addView(softBlueButtonStyle("✈  INVIA MODULO DA COMPILARE").apply{setOnClickListener{shareBlankClientHtml()}},LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,0,0,dp(14))})
        if(clients.isEmpty()) box.addView(TextView(this).apply{text="Nessun cliente registrato.";textSize=15f;setTextColor(Color.DKGRAY);gravity=Gravity.CENTER;setPadding(0,dp(30),0,dp(30))})
        clients.forEach{c->val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(12));background=appGlassSurface(Color.WHITE,20,Color.rgb(224,229,235),1);setOnClickListener{clientProfileScreen(c)}};row.addView(TextView(this).apply{text="${c.lastName} ${c.firstName}";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(30,42,55))});row.addView(TextView(this).apply{text=listOf(c.phone,c.email).filter{it.isNotBlank()}.joinToString(" • ");textSize=12.5f;setTextColor(Color.rgb(100,105,112));setPadding(0,dp(4),0,0)});box.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})}
        val scroll=ScrollView(this).apply{addView(box)}
        val footer=softBlueButtonStyle("←  Torna ai pacchetti").apply{setOnClickListener{clientOverlay?.let{(it.parent as? ViewGroup)?.removeView(it)};clientOverlay=null}}
        clientOverlay=FrameLayout(this).apply{background=appGlassBackground();addView(scroll,FrameLayout.LayoutParams(-1,-1).apply{bottomMargin=dp(76)});addView(footer,FrameLayout.LayoutParams(-1,dp(48),Gravity.BOTTOM).apply{setMargins(dp(18),0,dp(18),dp(18))})}
        (findViewById<ViewGroup>(android.R.id.content)).addView(clientOverlay)
    }

    private fun clientProfileScreen(c:ClientProfile, returnToPackage:(()->Unit)?=null){
        clientQuestionnaireOverlay?.let{(it.parent as? ViewGroup)?.removeView(it)}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(30))}
        val scroll=ScrollView(this).apply{addView(box)}
        val hero=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(16),dp(18),dp(16));background=appGlassSurface(Color.WHITE,22,Color.rgb(205,226,247),1)}
        hero.addView(TextView(this).apply{text="${c.firstName} ${c.lastName}";textSize=23f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,42,60))})
        hero.addView(TextView(this).apply{text="Scheda cliente";textSize=13f;setTextColor(Color.rgb(86,105,124));setPadding(0,dp(4),0,dp(10))})
        hero.addView(softBlueButtonStyle("✎  MODIFICA SCHEDA").apply{setOnClickListener{clientQuestionnaireOverlay?.let{(it.parent as? ViewGroup)?.removeView(it)};clientQuestionnaireOverlay=null;clientQuestionnaire(c)}},LinearLayout.LayoutParams(-1,dp(44)))
        box.addView(hero,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(14))})
        fun section(title:String, rows:List<Pair<String,String>>){
            val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(14),dp(16),dp(14));background=appGlassSurface(Color.WHITE,20,Color.rgb(218,229,240),1)}
            card.addView(TextView(this).apply{text=title;textSize=17f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(31,70,108));setPadding(0,0,0,dp(7))})
            rows.forEach{(label,value)->
                val shown=if(value.isBlank())"Non indicato" else value
                card.addView(TextView(this).apply{text=label;textSize=11.5f;setTextColor(Color.rgb(105,116,128));setPadding(0,dp(7),0,dp(2))})
                card.addView(TextView(this).apply{text=shown;textSize=15f;setTextColor(if(value.isBlank())Color.rgb(145,150,156) else Color.rgb(30,38,47))})
            }
            box.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})
        }
        section("👤 Dati personali",listOf("Data di nascita" to c.birthDate,"Codice fiscale" to c.taxCode,"Telefono" to c.phone,"Email" to c.email,"Indirizzo" to listOf(c.address,c.city).filter{it.isNotBlank()}.joinToString(", ")))
        section("🚨 Contatto di emergenza",listOf("Nome" to c.emergencyName,"Rapporto" to c.emergencyRelation,"Telefono" to c.emergencyPhone))
        section("🏃 Attività fisica",listOf("Attività / sport" to c.sports))
        section("🩺 Situazione fisica",listOf("Dolori o fastidi" to c.pain,"Infortuni recenti" to c.injuries,"Schiena o collo" to c.backNeck,"Problemi articolari" to c.joints,"Interventi chirurgici" to c.surgery,"Patologie / condizioni mediche" to c.medicalConditions,"Farmaci" to c.medications,"Altro" to c.other))
        if(c.signedAt.isNotBlank())section("✓ Modulo cliente",listOf("Ultima compilazione" to c.signedAt))
        val linkedWeekly=packs.filter{it.clientId==c.id}
        val linkedSessions=sessionPacks.filter{it.clientId==c.id}
        if(linkedWeekly.isNotEmpty()||linkedSessions.isNotEmpty()){
            val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(14),dp(16),dp(14));background=appGlassSurface(Color.rgb(241,248,255),20,Color.rgb(204,224,244),1)}
            card.addView(TextView(this).apply{text="Abbonamenti collegati";textSize=17f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(31,70,108))})
            (linkedWeekly.map{"${it.packageType} · ${it.start.format(fmt)}"}+linkedSessions.map{"Pacchetto a sedute · ${it.start.format(fmt)}"}).forEach{label->
                card.addView(TextView(this).apply{text=label;textSize=14f;setTextColor(Color.rgb(45,65,90));setPadding(0,dp(7),0,0)})
            }
            box.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})
        }
        val footer=softBlueButtonStyle(if(returnToPackage!=null)"←  Torna all'abbonamento" else "←  Torna ai clienti").apply{setOnClickListener{
            clientQuestionnaireOverlay?.let{(it.parent as? ViewGroup)?.removeView(it)}
            clientQuestionnaireOverlay=null
            if(returnToPackage!=null)window.decorView.post{returnToPackage()}
        }}
        clientQuestionnaireOverlay=FrameLayout(this).apply{background=appGlassBackground();addView(scroll,FrameLayout.LayoutParams(-1,-1).apply{bottomMargin=dp(76)});addView(footer,FrameLayout.LayoutParams(-1,dp(48),Gravity.BOTTOM).apply{setMargins(dp(18),0,dp(18),dp(18))})}
        (findViewById<ViewGroup>(android.R.id.content)).addView(clientQuestionnaireOverlay)
    }

    private fun clientQuestionnaire(existing:ClientProfile?){
        val c=existing ?: ClientProfile(nextClientId++,"","","","","","","","","","","","","","","","","","","","")
        clientQuestionnaireOverlay?.let{(it.parent as? ViewGroup)?.removeView(it)}
        questionnaireHasUnsavedChanges = null
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(24))};val scroll=ScrollView(this).apply{addView(box)}
        box.addView(softBlueButtonStyle("←  Torna ai clienti").apply{setOnClickListener{closeQuestionnaireSafely()}},LinearLayout.LayoutParams(-1,dp(44)).apply{setMargins(0,0,0,dp(10))})
        fun head(t:String){box.addView(TextView(this).apply{text=t;textSize=19f;setTextColor(Color.rgb(25,38,52));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(0,dp(14),0,dp(8))})}
        fun q(h:String):EditText{val e=EditText(this).apply{hint=h;textSize=15f;setSingleLine(false);setPadding(dp(14),0,dp(14),0);background=roundedSurface(Color.WHITE,16,Color.rgb(220,225,230),1)};box.addView(e,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(8))});return e}
        fun yn(t:String,yes:()->Unit,no:()->Unit){box.addView(TextView(this).apply{text=t;textSize=14.5f;setTextColor(Color.rgb(55,62,70));setPadding(0,dp(6),0,dp(5))});val r=RadioGroup(this).apply{orientation=RadioGroup.HORIZONTAL};val y=RadioButton(this).apply{text="Sì"};val n=RadioButton(this).apply{text="No"};r.addView(y);r.addView(n);box.addView(r);y.setOnClickListener{yes()};n.setOnClickListener{no()}}
        head("👤 Dati anagrafici");val fn=q("Nome *");val ln=q("Cognome *");clientNameInput(fn);clientNameInput(ln);val bd=q("Data di nascita");val cf=q("Codice fiscale");val ph=q("Telefono *");val em=q("Email");val ad=q("Indirizzo");val city=q("Città")
        head("🚨 Contatto di emergenza");val en=q("Nome e cognome");val er=q("Rapporto");val ep=q("Telefono")
        head("🏃 Attività fisica");val sports=q("Quale attività o sport?");sports.visibility=View.GONE;yn("Attualmente pratichi attività fisica?",{sports.visibility=View.VISIBLE},{sports.visibility=View.GONE})
        head("🩺 Situazione fisica");val pain=q("Specifica dolore o fastidio");pain.visibility=View.GONE;yn("Hai attualmente dolori o fastidi fisici?",{pain.visibility=View.VISIBLE},{pain.visibility=View.GONE});val inj=q("Specifica infortunio e quando");inj.visibility=View.GONE;yn("Hai avuto infortuni recentemente?",{inj.visibility=View.VISIBLE},{inj.visibility=View.GONE});val back=q("Specifica");back.visibility=View.GONE;yn("Hai problemi alla schiena o al collo?",{back.visibility=View.VISIBLE},{back.visibility=View.GONE});val joints=q("Specifica");joints.visibility=View.GONE;yn("Hai problemi articolari?",{joints.visibility=View.VISIBLE},{joints.visibility=View.GONE});val surgery=q("Quale e quando?");surgery.visibility=View.GONE;yn("Hai subito interventi chirurgici?",{surgery.visibility=View.VISIBLE},{surgery.visibility=View.GONE});val med=q("Specifica");med.visibility=View.GONE;yn("Hai patologie o condizioni mediche da segnalare?",{med.visibility=View.VISIBLE},{med.visibility=View.GONE});val meds=q("Quali farmaci?");meds.visibility=View.GONE;yn("Assumi farmaci rilevanti per l'attività fisica?",{meds.visibility=View.VISIBLE},{meds.visibility=View.GONE});val other=q("Altro da segnalare")
        if(existing!=null){fn.setText(c.firstName);ln.setText(c.lastName);bd.setText(c.birthDate);cf.setText(c.taxCode);ph.setText(c.phone);em.setText(c.email);ad.setText(c.address);city.setText(c.city);en.setText(c.emergencyName);er.setText(c.emergencyRelation);ep.setText(c.emergencyPhone);sports.setText(c.sports);pain.setText(c.pain);inj.setText(c.injuries);back.setText(c.backNeck);joints.setText(c.joints);surgery.setText(c.surgery);med.setText(c.medicalConditions);meds.setText(c.medications);other.setText(c.other);if(c.sports.isNotBlank())sports.visibility=View.VISIBLE;if(c.pain.isNotBlank())pain.visibility=View.VISIBLE;if(c.injuries.isNotBlank())inj.visibility=View.VISIBLE;if(c.backNeck.isNotBlank())back.visibility=View.VISIBLE;if(c.joints.isNotBlank())joints.visibility=View.VISIBLE;if(c.surgery.isNotBlank())surgery.visibility=View.VISIBLE;if(c.medicalConditions.isNotBlank())med.visibility=View.VISIBLE;if(c.medications.isNotBlank())meds.visibility=View.VISIBLE}
        head("📝 Altro");head("⚠️ Dichiarazioni e consensi");val decl=CheckBox(this).apply{text="Dichiaro che le informazioni fornite sono veritiere e complete."};val health=CheckBox(this).apply{text="Dichiaro di aver segnalato condizioni di salute rilevanti e di comunicare eventuali variazioni."};val privacy=CheckBox(this).apply{text="Ho preso visione dell'informativa privacy."};val comm=CheckBox(this).apply{text="Accetto le comunicazioni relative al servizio tramite i contatti indicati, nei limiti dell'informativa."};val photo=CheckBox(this).apply{text="Acconsento separatamente all'eventuale utilizzo di foto/video per le finalità indicate nell'informativa."};val cert=CheckBox(this).apply{text="Sono consapevole che, quando previsto o richiesto, potrà essere necessario presentare un certificato medico."};listOf(decl,health,privacy,comm,photo,cert).forEach{box.addView(it)}
        box.addView(softBlueButtonStyle(if(existing==null)"SALVA E CONDIVIDI MODULO" else "SALVA MODIFICHE").apply{setOnClickListener{
            if(fn.text.isNullOrBlank()||ln.text.isNullOrBlank()||ph.text.isNullOrBlank()){Toast.makeText(this@MainActivity,"Compila Nome, Cognome e Telefono.",Toast.LENGTH_SHORT).show();return@setOnClickListener}
            c.firstName=fn.text.toString().trim();c.lastName=ln.text.toString().trim();c.birthDate=bd.text.toString();c.taxCode=cf.text.toString();c.phone=ph.text.toString();c.email=em.text.toString();c.address=ad.text.toString();c.city=city.text.toString();c.emergencyName=en.text.toString();c.emergencyRelation=er.text.toString();c.emergencyPhone=ep.text.toString();c.sports=sports.text.toString();c.pain=pain.text.toString();c.injuries=inj.text.toString();c.backNeck=back.text.toString();c.joints=joints.text.toString();c.surgery=surgery.text.toString();c.medicalConditions=med.text.toString();c.medications=meds.text.toString();c.other=other.text.toString();c.signedAt=LocalDateTime.now().toString();if(existing==null)clients.add(c);val saved=saveClientData();if(!saved){Toast.makeText(this@MainActivity,"Salvataggio non riuscito: riprova.",Toast.LENGTH_LONG).show();return@setOnClickListener};questionnaireHasUnsavedChanges=null;if(existing==null)shareClientModule(c) else Toast.makeText(this@MainActivity,"Scheda cliente aggiornata.",Toast.LENGTH_SHORT).show()
            window.decorView.post{offerMatchingPackagesForProfile(c)}
        }},LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(18),0,0)})
        val questionnaireInitialState = formDraftFingerprint(box)
        questionnaireHasUnsavedChanges = { formDraftFingerprint(box) != questionnaireInitialState }
        clientQuestionnaireOverlay=FrameLayout(this).apply{background=appGlassBackground();addView(scroll,FrameLayout.LayoutParams(-1,-1))};(findViewById<ViewGroup>(android.R.id.content)).addView(clientQuestionnaireOverlay)
    }

    private fun shareBlankClientHtml(){
        try{
            val html="""<!doctype html><html lang="it"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>CoachFlow - Modulo Cliente</title><style>
*{box-sizing:border-box}body{margin:0;font-family:system-ui,-apple-system,sans-serif;background:linear-gradient(160deg,#061523,#0b2a45);color:#eef7ff;min-height:100vh}.wrap{max-width:680px;margin:auto;padding:22px}.hero{text-align:center;padding:22px 10px}.hero h1{color:#69bdff;margin:0;font-size:30px}.hero p{opacity:.8}.card{background:rgba(255,255,255,.09);border:1px solid rgba(160,215,255,.24);backdrop-filter:blur(18px);border-radius:22px;padding:18px;margin:14px 0;box-shadow:0 14px 35px #0005}h2{font-size:18px;color:#8fd0ff;margin:0 0 14px}label{display:block;font-size:13px;margin:11px 0 5px;color:#d8ebfa}input,textarea,select{width:100%;padding:13px;border-radius:13px;border:1px solid #ffffff2c;background:#071c2dbd;color:white;font-size:16px}textarea{min-height:80px;resize:vertical}.yn{display:flex;gap:18px;padding:6px 0}.yn label{display:flex;gap:6px;align-items:center;margin:0}.yn input{width:auto}.check{display:flex;gap:10px;align-items:flex-start;margin:12px 0}.check input{width:auto;margin-top:3px}button{width:100%;padding:15px;border:0;border-radius:15px;background:#1688ff;color:white;font-weight:700;font-size:16px;margin-top:14px}.small{font-size:12px;opacity:.72;text-align:center}.req{color:#ff7d7d}</style></head><body><div class="wrap"><div class="hero"><h1>CoachFlow</h1><p>Modulo Cliente</p></div><form id="f">
<div class="card"><h2>👤 Dati anagrafici</h2><label>Nome <span class="req">*</span></label><input name="firstName" required><label>Cognome <span class="req">*</span></label><input name="lastName" required><label>Data di nascita</label><input name="birthDate" placeholder="gg/mm/aaaa"><label>Codice fiscale</label><input name="taxCode"><label>Telefono <span class="req">*</span></label><input name="phone" required inputmode="tel"><label>Email</label><input name="email" type="email"><label>Indirizzo</label><input name="address"><label>Città</label><input name="city"></div>
<div class="card"><h2>🚨 Contatto di emergenza</h2><label>Nome e cognome</label><input name="emergencyName"><label>Rapporto</label><input name="emergencyRelation"><label>Telefono</label><input name="emergencyPhone" inputmode="tel"></div>
<div class="card"><h2>🏃 Attività fisica</h2><label>Pratichi attualmente attività fisica?</label><div class="yn"><label><input type="radio" name="sportsYN" value="no"> No</label><label><input type="radio" name="sportsYN" value="si" data-show="sportsBox"> Sì</label></div><div id="sportsBox" hidden><label>Quale attività o sport?</label><textarea name="sports"></textarea></div></div>
<div class="card"><h2>🩺 Situazione fisica</h2>
<label>Hai attualmente dolori o fastidi fisici?</label><div class="yn"><label><input type="radio" name="painYN" value="no"> No</label><label><input type="radio" name="painYN" value="si" data-show="painBox"> Sì</label></div><div id="painBox" hidden><label>Se vuoi, descrivi dove e che tipo di fastidio</label><textarea name="pain"></textarea></div>
<label>Hai avuto infortuni recentemente?</label><div class="yn"><label><input type="radio" name="injYN" value="no"> No</label><label><input type="radio" name="injYN" value="si" data-show="injBox"> Sì</label></div><div id="injBox" hidden><label>Descrivi l'infortunio e quando è avvenuto</label><textarea name="injuries"></textarea></div>
<label>Hai problemi alla schiena o al collo?</label><div class="yn"><label><input type="radio" name="backYN" value="no"> No</label><label><input type="radio" name="backYN" value="si" data-show="backBox"> Sì</label></div><div id="backBox" hidden><label>Specifica, se necessario</label><textarea name="backNeck"></textarea></div>
<label>Hai problemi articolari?</label><div class="yn"><label><input type="radio" name="jointsYN" value="no"> No</label><label><input type="radio" name="jointsYN" value="si" data-show="jointsBox"> Sì</label></div><div id="jointsBox" hidden><label>Specifica, se necessario</label><textarea name="joints"></textarea></div>
<label>Hai subito interventi chirurgici?</label><div class="yn"><label><input type="radio" name="surgeryYN" value="no"> No</label><label><input type="radio" name="surgeryYN" value="si" data-show="surgeryBox"> Sì</label></div><div id="surgeryBox" hidden><label>Quale e quando?</label><textarea name="surgery"></textarea></div>
<label>Hai patologie o condizioni mediche da segnalare?</label><div class="yn"><label><input type="radio" name="medicalYN" value="no"> No</label><label><input type="radio" name="medicalYN" value="si" data-show="medicalBox"> Sì</label></div><div id="medicalBox" hidden><label>Specifica, se necessario</label><textarea name="medicalConditions"></textarea></div>
<label>Assumi farmaci rilevanti per l'attività fisica?</label><div class="yn"><label><input type="radio" name="medsYN" value="no"> No</label><label><input type="radio" name="medsYN" value="si" data-show="medsBox"> Sì</label></div><div id="medsBox" hidden><label>Quali farmaci?</label><textarea name="medications"></textarea></div>
<label>Altro da segnalare</label><textarea name="other"></textarea></div>
<div class="card"><h2>⚠️ Dichiarazioni e consensi</h2><label class="check"><input type="checkbox" required> <span>Dichiaro che le informazioni fornite sono veritiere e complete.</span></label><label class="check"><input type="checkbox" required> <span>Dichiaro di aver segnalato condizioni di salute rilevanti e di comunicare eventuali variazioni.</span></label><label class="check"><input type="checkbox" required> <span>Ho preso visione dell'informativa privacy fornita dal professionista.</span></label></div>
<button type="submit">GENERA MODULO COMPILATO</button><p class="small">Il file generato contiene esclusivamente i dati inseriti in questo modulo. Inviarlo al proprio trainer tramite WhatsApp o altro canale concordato.</p></form></div><script>
const f=document.getElementById('f');document.querySelectorAll('input[type=radio]').forEach(r=>r.addEventListener('change',()=>{const group=r.name;document.querySelectorAll('input[name=\"'+group+'\"]').forEach(x=>{if(x.dataset.show){const el=document.getElementById(x.dataset.show);if(el)el.hidden=!(x.checked&&x.value==='si');}})}));f.addEventListener('submit',e=>{e.preventDefault();if(!f.reportValidity())return;const fd=new FormData(f),c={};['firstName','lastName','birthDate','taxCode','phone','email','address','city','emergencyName','emergencyRelation','emergencyPhone','sports','pain','injuries','backNeck','joints','surgery','medicalConditions','medications','other'].forEach(k=>c[k]=fd.get(k)||'');c.signedAt=new Date().toISOString();const data={format:'CoachFlowClientModule',version:1,client:c};const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=('CoachFlow_'+(c.lastName||'Cliente')+'_'+(c.firstName||'')+'.cflow').replace(/\s+/g,'_');document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove();alert('Modulo generato. Ora invia il file .cflow al tuo trainer.');},300);});
</script></body></html>"""
            val name="CoachFlow_Modulo_Cliente.html"
            val cv=ContentValues().apply{put(MediaStore.Downloads.DISPLAY_NAME,name);put(MediaStore.Downloads.MIME_TYPE,"text/html");put(MediaStore.Downloads.RELATIVE_PATH,"Download/CoachFlow/")}
            val uri=contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,cv)?:throw Exception("download")
            contentResolver.openOutputStream(uri)?.use{it.write(html.toByteArray(Charsets.UTF_8))}
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="text/html";putExtra(Intent.EXTRA_STREAM,uri);putExtra(Intent.EXTRA_TEXT,"Ciao! 👋 Ti invio il modulo CoachFlow da compilare.\n\nTocca il file allegato e aprilo con Chrome, Samsung Internet o Safari. Compila il questionario e alla fine premi GENERA MODULO COMPILATO. Poi rimandami il file .cflow generato qui su WhatsApp.");addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"Invia modulo al cliente"))
        }catch(e:Exception){Toast.makeText(this,"Impossibile generare il modulo HTML.",Toast.LENGTH_LONG).show()}
    }

    private fun handleClientModuleIntent(incoming:Intent){
        if(incoming.action!=Intent.ACTION_VIEW)return
        val uri=incoming.data?:return
        runCatching{
            val raw=contentResolver.openInputStream(uri)?.bufferedReader()?.use{it.readText()}?:return
            val root=JSONObject(raw);if(root.optString("format")!="CoachFlowClientModule")return
            val o=root.optJSONObject("client")?:return
            val imported=ClientProfile(0L,o.optString("firstName"),o.optString("lastName"),o.optString("birthDate"),o.optString("taxCode"),o.optString("phone"),o.optString("email"),o.optString("address"),o.optString("city"),o.optString("emergencyName"),o.optString("emergencyRelation"),o.optString("emergencyPhone"),o.optString("sports"),o.optString("pain"),o.optString("injuries"),o.optString("backNeck"),o.optString("joints"),o.optString("surgery"),o.optString("medicalConditions"),o.optString("medications"),o.optString("other"),o.optString("signedAt"))
            showClientImportPreview(imported)
        }.onFailure{Toast.makeText(this,"Questo file non è un modulo CoachFlow valido.",Toast.LENGTH_LONG).show()}
    }

    private fun showClientImportPreview(c:ClientProfile){
        val phone=c.phone.filter{it.isDigit()};val email=c.email.trim().lowercase()
        val match=clients.firstOrNull{x->(phone.isNotBlank()&&x.phone.filter{it.isDigit()}==phone)||(email.isNotBlank()&&x.email.trim().lowercase()==email)||(x.firstName.equals(c.firstName,true)&&x.lastName.equals(c.lastName,true)&&c.birthDate.isNotBlank()&&x.birthDate==c.birthDate)}
        val dialog=Dialog(this)
        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(18),dp(20),dp(18));background=appGlassSurface(Color.rgb(239,247,255),26,Color.rgb(170,207,242),1)}
        card.addView(TextView(this).apply{text="⇩  Importa modulo cliente";textSize=21f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(27,61,94))})
        val details=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(12),dp(16),dp(12));background=layeredPopupCard(22);elevation=dp(1).toFloat()}
        details.addView(TextView(this).apply{text="${c.firstName} ${c.lastName}";textSize=19f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(28,36,44));setPadding(0,dp(14),0,dp(4))})
        val summary=listOfNotNull(if(c.birthDate.isNotBlank())"Nascita  ${c.birthDate}" else null,if(c.phone.isNotBlank())"Telefono  ${c.phone}" else null,if(c.email.isNotBlank())"Email  ${c.email}" else null).joinToString("\n")
        details.addView(TextView(this).apply{text=summary;textSize=14f;setTextColor(Color.rgb(70,84,98));setLineSpacing(0f,1.2f)})
        details.addView(TextView(this).apply{text="\n✓  Dati anagrafici\n✓  Situazione fisica\n✓  Attività sportiva\n✓  Dichiarazioni";textSize=14.5f;setTextColor(Color.rgb(34,116,82));setLineSpacing(0f,1.25f)})
        val status=TextView(this).apply{text=if(match!=null)"Cliente già presente: ${match.firstName} ${match.lastName}\nPuoi aggiornare la sua scheda con i dati ricevuti." else "Nessun cliente corrispondente trovato.\nPuoi creare una nuova scheda cliente.";textSize=14f;setTextColor(Color.rgb(55,68,82));setPadding(0,dp(16),0,dp(12))}
        details.addView(status)
        card.addView(details,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(14),0,dp(14))})
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        actions.addView(softBlueButtonStyle("ANNULLA").apply{setOnClickListener{dialog.dismiss()}},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(8),0)})
        actions.addView(softBlueButtonStyle(if(match!=null)"AGGIORNA CLIENTE" else "CREA CLIENTE").apply{setOnClickListener{
            val savedProfile=if(match!=null){copyClientFields(c,match);match}else{c.id=nextClientId++;clients.add(c);c}
            val saved=saveClientData()
            if(!saved){Toast.makeText(this@MainActivity,"Salvataggio non riuscito: riprova prima di chiudere l’app.",Toast.LENGTH_LONG).show();return@setOnClickListener}
            dialog.dismiss();Toast.makeText(this@MainActivity,if(match!=null)"Scheda cliente aggiornata e salvata." else "Nuovo cliente salvato.",Toast.LENGTH_LONG).show()
            clientsScreen();window.decorView.post{offerMatchingPackagesForProfile(savedProfile)}
        }},LinearLayout.LayoutParams(0,dp(48),1.25f))
        card.addView(actions)
        dialog.setContentView(card);dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));dialog.window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);dialog.window?.attributes=dialog.window?.attributes?.apply{dimAmount=0.72f};dialog.show();dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.90).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun copyClientFields(from:ClientProfile,to:ClientProfile){to.firstName=from.firstName;to.lastName=from.lastName;to.birthDate=from.birthDate;to.taxCode=from.taxCode;to.phone=from.phone;to.email=from.email;to.address=from.address;to.city=from.city;to.emergencyName=from.emergencyName;to.emergencyRelation=from.emergencyRelation;to.emergencyPhone=from.emergencyPhone;to.sports=from.sports;to.pain=from.pain;to.injuries=from.injuries;to.backNeck=from.backNeck;to.joints=from.joints;to.surgery=from.surgery;to.medicalConditions=from.medicalConditions;to.medications=from.medications;to.other=from.other;to.signedAt=from.signedAt}

    // Schede sensibili: il file di recupero rimane nello spazio PRIVATO dell'app.
    private fun profileJson(c:ClientProfile):JSONObject=JSONObject().apply{
        put("id",c.id);put("firstName",c.firstName);put("lastName",c.lastName)
        put("birthDate",c.birthDate);put("taxCode",c.taxCode);put("phone",c.phone)
        put("email",c.email);put("address",c.address);put("city",c.city)
        put("emergencyName",c.emergencyName);put("emergencyRelation",c.emergencyRelation)
        put("emergencyPhone",c.emergencyPhone);put("sports",c.sports);put("pain",c.pain)
        put("injuries",c.injuries);put("backNeck",c.backNeck);put("joints",c.joints)
        put("surgery",c.surgery);put("medicalConditions",c.medicalConditions)
        put("medications",c.medications);put("other",c.other);put("signedAt",c.signedAt)
    }
    private fun profileFromJson(o:JSONObject,defaultId:Long):ClientProfile=ClientProfile(
        o.optLong("id",defaultId),o.optString("firstName"),o.optString("lastName"),
        o.optString("birthDate"),o.optString("taxCode"),o.optString("phone"),o.optString("email"),
        o.optString("address"),o.optString("city"),o.optString("emergencyName"),
        o.optString("emergencyRelation"),o.optString("emergencyPhone"),o.optString("sports"),
        o.optString("pain"),o.optString("injuries"),o.optString("backNeck"),
        o.optString("joints"),o.optString("surgery"),o.optString("medicalConditions"),
        o.optString("medications"),o.optString("other"),o.optString("signedAt")
    )
    private fun profilesJson():JSONArray=JSONArray().apply{clients.forEach{put(profileJson(it))}}
    private fun parseProfiles(raw:String):List<ClientProfile>{
        val arr=JSONArray(raw);return (0 until arr.length()).map{index->profileFromJson(arr.getJSONObject(index),index.toLong()+1)}
    }
    private fun saveClientData():Boolean{
        val data=profilesJson().toString()
        val prefs=getSharedPreferences("gestione_pagamenti",MODE_PRIVATE)
        val preferenceSaved=prefs.edit().putString("clients",data).putLong("nextClientId",nextClientId).commit()
        val atomic=android.util.AtomicFile(java.io.File(filesDir,"coachflow_clients.json"))
        var stream:java.io.FileOutputStream?=null
        val copySaved=try{
            stream=atomic.startWrite();stream.write(data.toByteArray(Charsets.UTF_8));atomic.finishWrite(stream);true
        }catch(_:Exception){if(stream!=null)atomic.failWrite(stream);false}
        return preferenceSaved || copySaved
    }
    private fun loadClientData(){
        val prefs=getSharedPreferences("gestione_pagamenti",MODE_PRIVATE)
        val primary=prefs.getString("clients",null)
        // Non mascherare una copia valida con un dato danneggiato o vuoto.
        val fromPrefs=primary?.let{runCatching{parseProfiles(it)}.getOrNull()}
        val fromFile=runCatching{android.util.AtomicFile(java.io.File(filesDir,"coachflow_clients.json"))
            .readFully().toString(Charsets.UTF_8)}.getOrNull()?.let{runCatching{parseProfiles(it)}.getOrNull()}
        val restored=if(!fromPrefs.isNullOrEmpty())fromPrefs else if(!fromFile.isNullOrEmpty())fromFile else fromPrefs?:fromFile?:emptyList()
        clients.clear();clients.addAll(restored)
        nextClientId=maxOf(prefs.getLong("nextClientId",1L),(clients.maxOfOrNull{it.id}?:0L)+1L)
        if(restored.isNotEmpty()&&(fromPrefs.isNullOrEmpty()||fromFile.isNullOrEmpty()))saveClientData()
    }
    private fun restoreProfilesFromBackup(root:JSONObject){
        // Backup storici senza 'clients' non eliminano le schede già presenti.
        if(!root.has("clients"))return
        val restored=parseProfiles(root.getJSONArray("clients").toString())
        clients.clear();clients.addAll(restored)
        nextClientId=maxOf(root.optLong("nextClientId",1L),(clients.maxOfOrNull{it.id}?:0L)+1L)
        if(!saveClientData())Toast.makeText(this,"Attenzione: schede cliente non salvate.",Toast.LENGTH_LONG).show()
    }

    private fun shareClientModule(c:ClientProfile){try{val json=JSONObject().apply{put("format","CoachFlowClientModule");put("version",1);put("client",JSONObject().apply{put("firstName",c.firstName);put("lastName",c.lastName);put("birthDate",c.birthDate);put("taxCode",c.taxCode);put("phone",c.phone);put("email",c.email);put("address",c.address);put("city",c.city);put("emergencyName",c.emergencyName);put("emergencyRelation",c.emergencyRelation);put("emergencyPhone",c.emergencyPhone);put("sports",c.sports);put("pain",c.pain);put("injuries",c.injuries);put("backNeck",c.backNeck);put("joints",c.joints);put("surgery",c.surgery);put("medicalConditions",c.medicalConditions);put("medications",c.medications);put("other",c.other);put("signedAt",c.signedAt)})};val name="CoachFlow_Modulo_${c.lastName}_${c.firstName}.json".replace(" ","_");val cv=ContentValues().apply{put(MediaStore.Downloads.DISPLAY_NAME,name);put(MediaStore.Downloads.MIME_TYPE,"application/json");put(MediaStore.Downloads.RELATIVE_PATH,"Download/CoachFlow/")};val uri=contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,cv)?:throw Exception();contentResolver.openOutputStream(uri)?.use{it.write(json.toString(2).toByteArray())};startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="application/json";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"Condividi modulo"))}catch(e:Exception){Toast.makeText(this,"Modulo salvato, ma condivisione non disponibile.",Toast.LENGTH_LONG).show()}}

    private fun backupMenu(){
        val last=getSharedPreferences("gestione_pagamenti",MODE_PRIVATE).getString("autoBackupDate","")
        val lastText=if(last.isNullOrBlank())"Nessun backup automatico ancora"else"Ultimo backup automatico: $last"
        val scroll=ScrollView(this).apply{isFillViewport=true;clipToPadding=false;overScrollMode=View.OVER_SCROLL_IF_CONTENT_SCROLLS}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_HORIZONTAL;setPadding(dp(18),dp(14),dp(18),dp(28))}

        // Hero Niki UI: rende immediatamente riconoscibile la sezione Backup e dati.
        val hero=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(18),dp(16),dp(18),dp(16))
            background=liquidInteractiveSurface(Color.rgb(239,247,255),24,Color.rgb(194,220,247),1)
            applyLiquidControlDepth(this)
        }
        val heroIcon=ImageView(this).apply{
            setImageDrawable(backupIconDrawable(Color.rgb(20,112,232)))
            setPadding(dp(15),dp(15),dp(15),dp(15))
            background=appGlassSurface(Color.WHITE,22,Color.rgb(205,226,247),1)
        }
        hero.addView(heroIcon,LinearLayout.LayoutParams(dp(70),dp(70)))
        hero.addView(TextView(this).apply{
            text="Backup e dati";textSize=21f;setTextColor(Color.rgb(24,45,70));setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setPadding(0,dp(10),0,0)
        },LinearLayout.LayoutParams(-1,-2))
        hero.addView(TextView(this).apply{
            text="Proteggi, esporta e ripristina i dati di CoachFlow";textSize=12.5f;setTextColor(Color.rgb(82,101,122));gravity=Gravity.CENTER;setPadding(0,dp(4),0,0)
        },LinearLayout.LayoutParams(-1,-2))
        box.addView(hero,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(16))})

        fun option(title:String,subtitle:String,icon:Drawable,action:()->Unit){
            val row=LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(12),dp(12),dp(12))
                background=liquidInteractiveSurface(Color.rgb(248,250,253),22,Color.rgb(211,226,242),1)
                isClickable=true;isFocusable=true
            }
            row.addView(ImageView(this).apply{
                setImageDrawable(icon);setPadding(dp(11),dp(11),dp(11),dp(11));background=appGlassSurface(Color.WHITE,18,Color.rgb(220,231,242),1)
            },LinearLayout.LayoutParams(dp(58),dp(58)))
            val texts=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(13),0,dp(8),0)}
            texts.addView(TextView(this@MainActivity).apply{text=title;textSize=16f;setTextColor(Color.rgb(25,28,32));setTypeface(null,android.graphics.Typeface.BOLD)})
            texts.addView(TextView(this@MainActivity).apply{text=subtitle;textSize=12.5f;setTextColor(Color.rgb(100,104,110));setPadding(0,dp(3),0,0)})
            row.addView(texts,LinearLayout.LayoutParams(0,-2,1f))
            row.addView(TextView(this@MainActivity).apply{text="›";textSize=28f;setTextColor(Color.rgb(120,124,130));gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(28),dp(54)))
            row.setOnClickListener{action()}
            box.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))})
        }
        option("Backup automatico","Attivo • 1 copia automatica al giorno, separata dal manuale",backupCloudIconDrawable(Color.rgb(20,112,232))){maybeAutoBackup();Toast.makeText(this,"$lastText",Toast.LENGTH_LONG).show()}
        option("Esporta backup manuale","Salva una copia completa dove preferisci",backupExportIconDrawable(Color.rgb(20,91,165))){exportData()}
        option("Importa backup manuale","Ripristina una copia precedentemente salvata",backupImportIconDrawable(Color.rgb(20,91,165))){importData()}
        option("Ripristina backup automatico",lastText,backupRestoreIconDrawable(Color.rgb(20,125,110))){restoreAutoBackup()}

        val close=Button(this).apply{
            text="Chiudi";setAllCaps(false);textSize=14f;setTextColor(Color.rgb(20,91,165));stateListAnimator=null
            background=appGlassSurface(Color.rgb(238,246,255),20,Color.rgb(202,222,245),1)
        }
        box.addView(close,LinearLayout.LayoutParams(dp(190),dp(48)).apply{setMargins(0,dp(14),0,0)})
        scroll.addView(box,ViewGroup.LayoutParams(-1,-2))
        showSettingsSubpage(scroll,"Backup e dati")
        close.setOnClickListener{closeSettingsSubpage()}
    }

    private fun exportData(){startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/json";putExtra(Intent.EXTRA_TITLE,"GestionePagamenti_backup.json")},REQ_EXPORT)}
    private fun importData(){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/json"},REQ_IMPORT)}
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode!=RESULT_OK)return
        val uri=data?.data?:return
        if(requestCode==REQ_EXPORT)writeBackup(uri)
        else if(requestCode==REQ_IMPORT){
            backupConfirmDialog(
                "Importare backup manuale?",
                "Il backup selezionato sostituirà i dati attualmente presenti nell'app.\n\nNessun dato verrà modificato prima della tua conferma.",
                "↓",
                "IMPORTA",
                Color.rgb(20,91,165)
            ){readBackup(uri)}
        }else if(requestCode==REQ_SUMMARY)writeSummary(uri)
    }

    private fun backupJson():JSONObject{
        val root=JSONObject();root.put("format","GestionePagamenti");root.put("version",7);root.put("exportedAt",LocalDateTime.now().toString());root.put("clients",profilesJson());root.put("nextClientId",nextClientId);ensureClosurePeriods();root.put("ferieStart",ferieStart?.toString()?:JSONObject.NULL);root.put("ferieEnd",ferieEnd?.toString()?:JSONObject.NULL);root.put("closurePeriods",JSONArray().apply{closurePeriods.forEach{put(JSONObject().apply{put("start",it.start.toString());put("end",it.end.toString())})}});root.put("dashboardEnabled",dashboardEnabled);root.put("surnameFirstDisplay",surnameFirstDisplay);root.put("largeSlotStyle",largeSlotStyle);root.put("appointmentSlotStyle",appointmentSlotStyle);root.put("calendarSlotDuration",calendarSlotDuration);root.put("freeEventTimeStep",freeEventTimeStep);root.put("calendarVisibleDays",JSONArray().apply{calendarVisibleDays.forEach{put(it)}});root.put("calendarNavPosition",calendarNavPosition);root.put("calendarNavOrder",JSONArray().apply{calendarNavOrder.forEach{put(it)}});root.put("calendarTopButtons",JSONArray().apply{calendarTopButtons.forEach{put(it)}});root.put("calendarBottomButtons",JSONArray().apply{calendarBottomButtons.forEach{put(it)}});root.put("appointmentTypes",JSONArray().apply{appointmentTypes.forEach{t->put(JSONObject().apply{put("id",t.id);put("name",t.name);put("color",t.color)})}});root.put("activeRoutineIndex",activeRoutineIndex);root.put("calendarRoutines",JSONArray().apply{calendarRoutines.forEach{r->put(JSONObject().apply{put("name",r.name);put("maxTotal",r.maxTotal);put("maxByType",JSONArray().apply{r.maxByType.forEach{put(it)}})})}})
        val array=JSONArray();packs.forEach{p->val rates=ratesFor(p);val dates=dueDates(p);array.put(JSONObject().apply{put("name",p.name);put("start",p.start.toString());put("total",p.total);put("paid",p.paid);put("dueDates",JSONArray().apply{dates.forEach{put(it.toString())}});put("rateAmounts",JSONArray().apply{rates.forEach{put(it)}});put("packageType",p.packageType);put("sessionTotal",p.sessionTotal);put("active",p.active);put("missedSessions",p.missedSessions);put("weeklyWeeks",p.weeklyWeeks);put("weeklyQuantities",JSONObject().apply{p.weeklyQuantities.forEach{(k,v)->put(k,v)}});put("includedAppointmentType",p.includedAppointmentType);put("clientId",p.clientId)})};root.put("packs",array)
        root.put("sessionPacks",JSONArray().apply{sessionPacks.forEach{s->put(JSONObject().apply{put("id",s.id);put("name",s.name);put("start",s.start.toString());put("totalSessions",s.totalSessions);put("cost",s.cost);put("paid",s.paid);put("active",s.active);put("rateAmounts",JSONArray().apply{sessionRatesFor(s).forEach{put(it)}});put("customQuantities",JSONObject().apply{s.customQuantities.forEach{(k,v)->put(k,v)}});put("clientId",s.clientId)})}})
        root.put("appointments",JSONArray().apply{appointments.forEach{a->put(JSONObject().apply{put("id",a.id);put("name",a.name);put("date",a.date.toString());put("time",a.time);put("type",a.type);put("seriesId",a.seriesId);put("sessionPackId",a.sessionPackId);put("recovery",a.recovery)})}});root.put("freeEvents",JSONArray().apply{freeEvents.forEach{e->put(JSONObject().apply{put("id",e.id);put("title",e.title);put("date",e.date.toString());put("startTime",e.startTime);put("endTime",e.endTime);put("color",e.color)})}});root.put("trashItems",JSONArray().apply{trashItems.forEach{t->put(JSONObject().apply{put("id",t.id);put("kind",t.kind);put("deletedAt",t.deletedAt.toString());put("payload",t.payload)})}});return root
    }

    private fun loadCalendarConfig(root:JSONObject){
        appointmentTypes.clear();root.optJSONArray("appointmentTypes")?.let{ta->for(i in 0 until ta.length()){val t=ta.getJSONObject(i);appointmentTypes.add(AppointmentType(t.optString("id","TYPE${i+1}"),t.optString("name",if(i==0)"ALLENAMENTO" else if(i==1)"MEZZ'ORA" else "Tipo ${i+1}"),t.optInt("color",if(i==0)Color.rgb(45,135,210) else Color.rgb(215,55,55))))}};if(appointmentTypes.isEmpty()){appointmentTypes.add(AppointmentType("TYPE1","ALLENAMENTO",Color.rgb(45,135,210)));appointmentTypes.add(AppointmentType("TYPE2","MEZZ'ORA",Color.rgb(215,55,55)))}
        calendarRoutines.clear();root.optJSONArray("calendarRoutines")?.let{ra->for(i in 0 until ra.length()){val r=ra.getJSONObject(i);val limits=mutableListOf<Int>();r.optJSONArray("maxByType")?.let{ja->for(j in 0 until ja.length())limits.add(ja.optInt(j,3))};if(limits.isEmpty()){limits.add(2);limits.add(3)};while(limits.size<appointmentTypes.size)limits.add(r.optInt("maxTotal",3));calendarRoutines.add(CalendarRoutine(r.optString("name","Routine ${i+1}"),r.optInt("maxTotal",3),limits))}};if(calendarRoutines.isEmpty())calendarRoutines.add(CalendarRoutine("Personalizzata",3,MutableList(appointmentTypes.size){if(it==0)2 else 3}));activeRoutineIndex=root.optInt("activeRoutineIndex",0).coerceIn(0,calendarRoutines.lastIndex);calendarNavPosition=root.optInt("calendarNavPosition",1).coerceIn(0,1);calendarNavOrder=mutableListOf<String>().apply{root.optJSONArray("calendarNavOrder")?.let{ja->for(i in 0 until ja.length())add(ja.optString(i))}}.filter{it in listOf("PREV","SEARCH","TODAY","NEXT")}.toMutableList().also{if(it.size==3&&it.distinct().size==3){val ni=it.indexOf("NEXT");if(ni>=0)it.add(ni,"TODAY") else it.add("TODAY")};if(it.size!=4||it.distinct().size!=4)it.clear();if(it.isEmpty())it.addAll(listOf("PREV","SEARCH","TODAY","NEXT"));if(it.indexOf("PREV")>it.indexOf("NEXT")){val pi=it.indexOf("PREV");val ni=it.indexOf("NEXT");it[pi]="NEXT";it[ni]="PREV"}};calendarTopButtons=mutableListOf<String>().apply{root.optJSONArray("calendarTopButtons")?.let{ja->for(i in 0 until ja.length())add(ja.optString(i))}}.filter{it in listOf("APPT","SEARCH","TODAY","PREV","NEXT")}.toMutableList();calendarBottomButtons=mutableListOf<String>().apply{root.optJSONArray("calendarBottomButtons")?.let{ja->for(i in 0 until ja.length())add(ja.optString(i))}}.filter{it in listOf("APPT","SEARCH","TODAY","PREV","NEXT")}.toMutableList();if(calendarTopButtons.isEmpty()&&calendarBottomButtons.isEmpty()){if(calendarNavPosition==0){calendarTopButtons.add("APPT");calendarTopButtons.addAll(calendarNavOrder)}else{calendarTopButtons.add("APPT");calendarBottomButtons.addAll(calendarNavOrder)}};if(calendarTopButtons.contains("APPT")||calendarBottomButtons.contains("APPT")){calendarTopButtons.remove("APPT");calendarBottomButtons.remove("APPT");calendarTopButtons.add(0,"APPT")};calendarTopButtons=calendarTopButtons.distinct().toMutableList();calendarBottomButtons=calendarBottomButtons.filter{it !in calendarTopButtons}.distinct().toMutableList();val combined=calendarTopButtons+calendarBottomButtons;if("PREV" in combined&&"NEXT" in combined&&combined.indexOf("PREV")>combined.indexOf("NEXT")){val pi=combined.indexOf("PREV");val ni=combined.indexOf("NEXT");if(pi<calendarTopButtons.size&&ni<calendarTopButtons.size){val t=calendarTopButtons[pi];calendarTopButtons[pi]=calendarTopButtons[ni];calendarTopButtons[ni]=t}else if(pi>=calendarTopButtons.size&&ni>=calendarTopButtons.size){val a=pi-calendarTopButtons.size;val b=ni-calendarTopButtons.size;val t=calendarBottomButtons[a];calendarBottomButtons[a]=calendarBottomButtons[b];calendarBottomButtons[b]=t}else{calendarTopButtons=mutableListOf("APPT","PREV");calendarBottomButtons=mutableListOf("SEARCH","TODAY","NEXT")}}
    }
    private fun writeSummary(uri:Uri){try{contentResolver.openOutputStream(uri)?.use{it.write(pendingSummaryText.toByteArray(Charsets.UTF_8))};Toast.makeText(this,"Riepilogo esportato.",Toast.LENGTH_LONG).show()}catch(_:Exception){Toast.makeText(this,"Impossibile esportare il riepilogo.",Toast.LENGTH_LONG).show()}}

    private fun weeklyPackageEnd(p:Pack):LocalDate = advance(p.start,(p.weeklyWeeks.coerceAtLeast(1)*7)).minusDays(1)

    private fun regularPackFor(name:String, date:LocalDate):Pack? = packs.filter {
        it.active && identityKey(it.name)==identityKey(name) && !date.isBefore(it.start) && !date.isAfter(weeklyPackageEnd(it))
    }.maxByOrNull { it.start }


    // Bronze/Silver/Gold possono essere associati a un solo tipo di appuntamento.
    // I vecchi pacchetti senza il campo restano perfettamente compatibili.
    private fun standardPackFor(name:String,date:LocalDate):Pack? = packs.filter{
        it.active && (it.packageType=="BRONZE"||it.packageType=="SILVER"||it.packageType=="GOLD") &&
            identityKey(it.name)==identityKey(name) && !date.isBefore(it.start) && !date.isAfter(weeklyPackageEnd(it))
    }.maxByOrNull{it.start}

    // Restituisce il pacchetto settimanale attivo più recente già iniziato.
    // Serve anche per gli appuntamenti successivi alla fine del pacchetto: in
    // quel caso possiamo segnalare che serve un nuovo pacchetto.
    private fun weeklyPackageForAppointment(name:String, date:LocalDate):Pack? = packs.filter {
        it.active && identityKey(it.name)==identityKey(name) && !date.isBefore(it.start)
    }.maxByOrNull { it.start }

    private fun recoveryUsedForPack(p:Pack):Int = 0

    private fun weeklyCustomPerWeek(p:Pack):Int = if(p.packageType=="WEEKLY_CUSTOM") p.weeklyQuantities.values.sum().coerceAtLeast(0) else when(p.packageType){"GOLD"->3;"SILVER"->2;"BRONZE"->1;else->0}
    private fun weeklyCustomExpectedForType(p:Pack,type:String):Int = p.weeklyQuantities[type] ?: 0
    private fun weeklyExpectedForType(p:Pack,type:String):Int = when {
        p.packageType=="WEEKLY_CUSTOM" -> p.weeklyQuantities[type] ?: 0
        (p.packageType=="BRONZE"||p.packageType=="SILVER"||p.packageType=="GOLD") && p.includedAppointmentType==type -> when(p.packageType){"GOLD"->3;"SILVER"->2;else->1}
        else -> 0
    }
    private fun weeklyWeekStart(p:Pack,date:LocalDate):LocalDate = p.start.plusWeeks(((java.time.temporal.ChronoUnit.DAYS.between(p.start,date).coerceAtLeast(0))/7))
    private fun weeklyCustomCountInWeek(p:Pack,weekStart:LocalDate,type:String):Int{
        val weekEnd=weekStart.plusDays(6)
        return appointments.count{identityKey(it.name)==identityKey(p.name)&&it.date>=weekStart&&it.date<=weekEnd&&it.type==type&&!it.recovery}
    }

    private fun weeklyCustomCumulativeRecovery(p:Pack,date:LocalDate,type:String):Int{
        val limit=weeklyCustomExpectedForType(p,type)
        if(limit<=0)return 0
        val selectedWeek=weeklyWeekStart(p,date)
        var recovery=0
        var week=p.start
        while(week.isBefore(selectedWeek)){
            val used=weeklyCustomCountInWeek(p,week,type)
            recovery += (limit-used.coerceAtMost(limit)).coerceAtLeast(0)
            week=week.plusWeeks(1)
        }
        val recoveryUsed=appointments.count{identityKey(it.name)==identityKey(p.name)&&it.recovery&&it.type==type&&it.date>=p.start&&it.date<selectedWeek}
        return (recovery-recoveryUsed).coerceAtLeast(0)
    }

    private fun weeklyRemainingThisWeek(p:Pack,date:LocalDate,type:String):Int{
        val limit=weeklyExpectedForType(p,type)
        if(limit<=0)return 0
        val ws=weeklyWeekStart(p,date)
        val used=appointments.count{identityKey(it.name)==identityKey(p.name)&&it.date>=ws&&it.date<=ws.plusDays(6)&&it.type==type&&!it.recovery}
        // Le disponibilità settimanali e i recuperi sono due contatori distinti:
        // i recuperi non aumentano mai le disponibilità della settimana.
        return (limit-used).coerceAtLeast(0)
    }
    private fun weeklyCustomRemainingThisWeek(p:Pack,date:LocalDate,type:String):Int = weeklyRemainingThisWeek(p,date,type)

    private fun weeklyRecoveryForType(p:Pack,type:String):Int = recoveryBreakdownForPack(p).firstOrNull{it.first==type}?.second ?: 0

    private fun weeklyQuotaWarning(p:Pack,date:LocalDate,type:String):String?{
        val expected=weeklyExpectedForType(p,type)
        if(expected<=0) return "${typeLabel(type)} non è prevista nel pacchetto ${p.packageType}."
        val remaining=weeklyRemainingThisWeek(p,date,type)
        if(remaining>0) return null
        val recovery=weeklyRecoveryForType(p,type)
        return if(recovery>0){
            "La quota settimanale di ${typeLabel(type)} è esaurita. Sono disponibili $recovery recuperi ${typeLabel(type)}. Puoi usarne uno oppure creare comunque l'appuntamento."
        }else{
            "La quota settimanale di ${typeLabel(type)} è esaurita. Vuoi comunque creare l'appuntamento?"
        }
    }

    private fun weeklyRepeatQuotaWarning(p:Pack,start:LocalDate,end:LocalDate,selected:Set<Int>,type:String,dayTimes:Map<Int,String>?):String?{
        val expected=weeklyExpectedForType(p,type)
        if(expected<=0)return "${typeLabel(type)} non è prevista nel pacchetto ${p.packageType}."
        val planned=mutableMapOf<LocalDate,Int>()
        var d=start
        while(!d.isAfter(end)){
            if(selected.contains(d.dayOfWeek.value) && !d.isBefore(p.start) && !d.isAfter(weeklyPackageEnd(p))){
                val ws=weeklyWeekStart(p,d)
                val existing=appointments.count{identityKey(it.name)==identityKey(p.name)&&it.date>=ws&&it.date<=ws.plusDays(6)&&it.type==type&&!it.recovery}
                val current=existing+(planned[ws]?:0)
                if(current>=expected){
                    val recovery=weeklyRecoveryForType(p,type)
                    return if(recovery>0){
                        "La quota settimanale di ${typeLabel(type)} è esaurita. Sono disponibili $recovery recuperi ${typeLabel(type)}. Puoi usarne uno oppure creare comunque l'appuntamento."
                    }else{
                        "La quota settimanale di ${typeLabel(type)} è esaurita. Vuoi comunque creare l'appuntamento?"
                    }
                }
                planned[ws]=(planned[ws]?:0)+1
            }
            d=d.plusDays(1)
        }
        return null
    }
    private fun weeklyCustomTypeOverLimit(p:Pack,a:Appointment):Boolean{
        if(p.packageType!="WEEKLY_CUSTOM") return false
        val limit=weeklyCustomExpectedForType(p,a.type)
        if(limit<=0) return true
        val ws=weeklyWeekStart(p,a.date);val we=ws.plusDays(6)
        val count=appointments.count{identityKey(it.name)==identityKey(p.name)&&it.date>=ws&&it.date<=we&&it.type==a.type&&!it.recovery&&(it.date.isBefore(a.date)||(it.date==a.date&&it.time<=a.time))}
        return count>limit
    }

    private fun recoveriesForPack(p:Pack):Int {
        val end=weeklyPackageEnd(p)
        val target=weeklyCustomPerWeek(p)
        if(target<=0)return 0
        val inWindow=appointments.filter{
            identityKey(it.name)==identityKey(p.name) &&
            !it.date.isBefore(p.start) && !it.date.isAfter(end) &&
            !isStudioClosed(it.date)
        }
        if(inWindow.isEmpty())return 0
        var deficit=0
        var surplus=0
        for(week in 0 until p.weeklyWeeks.coerceAtLeast(1)){
            val ws=p.start.plusWeeks(week.toLong())
            val we=calendarWeekEnd(ws)
            val count=inWindow.count{!it.date.isBefore(ws)&&!it.date.isAfter(we)}
            if(count==0)continue
            if(count<target) deficit += target-count
            else if(count>target) surplus += count-target
        }
        return (deficit-surplus).coerceAtLeast(0)
    }

    // Dettaglio dei recuperi per tipologia. Per i pacchetti personalizzati
    // usa le quantità settimanali configurate; il conteggio resta identico a
    // quello già usato da recoveriesForPack(), ma viene separato per tipo.
    private fun recoveryBreakdownForPack(p:Pack):List<Pair<String,Int>>{
        if(p.packageType=="WEEKLY_CUSTOM" && p.weeklyQuantities.isNotEmpty()){
            val end=weeklyPackageEnd(p)
            return p.weeklyQuantities.entries
                .filter{it.value>0}
                .mapNotNull{(type,limit)->
                    var deficit=0
                    var surplus=0
                    for(week in 0 until p.weeklyWeeks.coerceAtLeast(1)){
                        val ws=p.start.plusWeeks(week.toLong())
                        val we=calendarWeekEnd(ws)
                        val count=appointments.count{
                            identityKey(it.name)==identityKey(p.name) &&
                            !it.date.isBefore(ws) && !it.date.isAfter(we) &&
                            !isStudioClosed(it.date) &&
                            it.type==type && !it.recovery
                        }
                        if(count>0){
                            if(count<limit) deficit += limit-count
                            else if(count>limit) surplus += count-limit
                        }
                    }
                    val used=appointments.count{
                        identityKey(it.name)==identityKey(p.name) &&
                        it.recovery && it.type==type &&
                        !it.date.isBefore(p.start) && !it.date.isAfter(end) &&
                        !isStudioClosed(it.date)
                    }
                    val available=(deficit-surplus-used).coerceAtLeast(0)
                    if(available>0) type to available else null
                }
        }

        // Nei pacchetti standard la tipologia è unica e viene presa dalle
        // impostazioni associate al pacchetto. Anche qui i recuperi restano
        // separati dalla quota settimanale.
        val type=p.includedAppointmentType
        if((p.packageType=="BRONZE"||p.packageType=="SILVER"||p.packageType=="GOLD") && !type.isNullOrBlank()){
            val limit=weeklyExpectedForType(p,type)
            if(limit<=0)return emptyList()
            val end=weeklyPackageEnd(p)
            var deficit=0
            var surplus=0
            for(week in 0 until p.weeklyWeeks.coerceAtLeast(1)){
                val ws=p.start.plusWeeks(week.toLong())
                val we=calendarWeekEnd(ws)
                val count=appointments.count{
                    identityKey(it.name)==identityKey(p.name) &&
                    !it.date.isBefore(ws) && !it.date.isAfter(we) &&
                    !isStudioClosed(it.date) && it.type==type && !it.recovery
                }
                if(count>0){
                    if(count<limit) deficit += limit-count
                    else if(count>limit) surplus += count-limit
                }
            }
            val used=appointments.count{
                identityKey(it.name)==identityKey(p.name) && it.recovery && it.type==type &&
                !it.date.isBefore(p.start) && !it.date.isAfter(end) && !isStudioClosed(it.date)
            }
            val available=(deficit-surplus-used).coerceAtLeast(0)
            if(available>0)return listOf(type to available)
        }
        return emptyList()
    }

    private fun recoveryBreakdownLabel(p:Pack):String = recoveryBreakdownForPack(p)
        .joinToString(" • "){(type,count)->"$count ${typeLabel(type)}"}

    private fun sessionsForPack(p:Pack,until:LocalDate=LocalDate.now()):List<Appointment>{
        val end=weeklyPackageEnd(p)
        val now=LocalDateTime.now()
        return appointments.filter{
            identityKey(it.name)==identityKey(p.name) &&
            !it.date.isBefore(p.start) &&
            !it.date.isAfter(until) &&
            !it.date.isAfter(end) &&
            !isStudioClosed(it.date) &&
            (it.date.isBefore(until) || (it.date==until && (until.isBefore(now.toLocalDate()) || appointmentHasPassed(it,now))))
        }.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
    }

    private fun sessionsForSessionPack(s:SessionPack,until:LocalDate=LocalDate.now()):List<Appointment>{
        val now=LocalDateTime.now()
        return sessionAppointments(s).filter{
            !it.date.isBefore(s.start) &&
            !it.date.isAfter(until) &&
            (it.date.isBefore(until) || (it.date==until && (until.isBefore(now.toLocalDate()) || appointmentHasPassed(it,now))))
        }.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
    }

    private fun summaryForPack(p: Pack): String {
        val today = LocalDate.now()
        val packageEnd = weeklyPackageEnd(p)
        val done = sessionsForPack(p, today)
        val expected = p.sessionTotal
        val recoveryDue = recoveriesForPack(p)
        val scheduledInWindow = appointments.count {
            identityKey(it.name)==identityKey(p.name) &&
            !it.date.isBefore(p.start) && !it.date.isAfter(packageEnd)
        }
        val remaining = (expected - scheduledInWindow).coerceAtLeast(0)
        val futurePackage = appointments.filter {
            identityKey(it.name) == identityKey(p.name) &&
            it.date.isAfter(today) && !it.date.isAfter(packageEnd) && !it.date.isBefore(p.start) && !isStudioClosed(it.date)
        }.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        val usedRecoveries = appointments.filter {
            it.recovery && identityKey(it.name)==identityKey(p.name) &&
            !it.date.isBefore(p.start) && !it.date.isAfter(packageEnd) && !isStudioClosed(it.date)
        }.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        return buildString {
            appendLine("📊 RIEPILOGO PROGRAMMAZIONE")
            appendLine()
            appendLine("Cliente: ${displaySurnameFirst(p.name)}")
            appendLine("Pacchetto: ${p.packageType} • $expected sedute • 12 settimane")
            appendLine("Periodo: ${p.start.format(fmt)} → ${packageEnd.format(fmt)}")
            appendLine()
            appendLine("SITUAZIONE")
            appendLine("• Sedute effettuate: ${done.size}")
            appendLine("• Sedute rimaste: $remaining")
            appendLine("• Recuperi disponibili: $recoveryDue")
            appendLine()
            appendLine("SEDUTE EFFETTUATE")
            if (done.isEmpty()) appendLine("Nessuna seduta effettuata.")
            done.forEachIndexed { index, a ->
                appendLine("${index + 1}. ${a.date.format(fmt)} • ${a.time} • ${typeLabel(a.type)}")
            }
            appendLine()
            appendLine("RECUPERI")
            if (usedRecoveries.isEmpty()) appendLine("Nessun recupero utilizzato.")
            usedRecoveries.forEachIndexed { index, a ->
                appendLine("${index + 1}. ${a.date.format(fmt)} • ${a.time} • RECUPERO • ${typeLabel(a.type)}")
            }
            appendLine("Disponibili: $recoveryDue")
            appendLine()
            appendLine("PROSSIMI APPUNTAMENTI")
            if (futurePackage.isEmpty()) appendLine("Nessun appuntamento futuro nel pacchetto.")
            futurePackage.forEachIndexed { index, a ->
                appendLine("${index + 1}. ${a.date.format(fmt)} • ${a.time} • ${typeLabel(a.type)}")
            }
        }
    }

    private fun summaryForSessionPack(s: SessionPack): String {
        val today = LocalDate.now()
        val done = sessionsForSessionPack(s, today)
        val futurePackage = sessionAppointments(s).filter { it.date.isAfter(today) }
            .sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        val annualFuture = appointments.filter {
            identityKey(it.name)==identityKey(s.name) && it.date.isAfter(today) && it.sessionPackId != s.id
        }.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        return buildString {
            appendLine("📋 PROGRAMMAZIONE ${displaySurnameFirst(s.name).uppercase()}")
            appendLine("Pacchetto • ${s.totalSessions} sedute")
            appendLine("Periodo pacchetto: ${s.start.format(fmt)} → aperto fino a esaurimento sedute")
            appendLine()
            appendLine("📊 SITUAZIONE")
            appendLine("• Sedute previste: ${s.totalSessions}")
            appendLine("• Sedute effettuate: ${done.size}")
            appendLine("• Sedute prenotate nel pacchetto: ${futurePackage.size}")
            appendLine("• Sedute rimanenti: ${(s.totalSessions-done.size).coerceAtLeast(0)}")
            appendLine()
            appendLine("🗓 PROGRAMMAZIONE DEL PACCHETTO")
            if(futurePackage.isEmpty()) appendLine("Nessun appuntamento futuro nel pacchetto.")
            futurePackage.forEachIndexed{index,a->
                val type=typeLabel(a.type)
                appendLine("${index+1}. ${a.date.format(fmt)} • ${a.time} • $type")
            }
            if(annualFuture.isNotEmpty()){
                appendLine()
                appendLine("▦ PROGRAMMAZIONE SUCCESSIVA")
                appendLine("Gli appuntamenti successivi restano nel calendario e verranno considerati per il prossimo pacchetto.")
                annualFuture.forEachIndexed{index,a->
                    val type=typeLabel(a.type)
                    appendLine("${index+1}. ${a.date.format(fmt)} • ${a.time} • $type")
                }
            }
        }
    }

    private fun copySummaryToClipboard(text:String,name:String){
        pendingSummaryText=text
        val clipboard=getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Riepilogo $name",text))
        val preview=TextView(this).apply{this.text=text;textSize=14f;setTextColor(Color.rgb(35,35,35));setPadding(dp(16),dp(8),dp(16),dp(8))}
        val dialog=AlertDialog.Builder(this).setTitle("📊 Riepilogo pronto per WhatsApp").setMessage("Il riepilogo è già stato copiato negli appunti. Puoi incollarlo direttamente su WhatsApp.").setView(ScrollView(this).apply{addView(preview)}).setPositiveButton("COPIA DI NUOVO"){_,_->
            clipboard.setPrimaryClip(ClipData.newPlainText("Riepilogo $name",text))
            Toast.makeText(this,"Riepilogo copiato negli appunti.",Toast.LENGTH_SHORT).show()
        }.setNegativeButton("CHIUDI",null).create()
        styleOneUiDialog(dialog)
        dialog.show()
    }

    private fun exportSummary(text:String,name:String){copySummaryToClipboard(text,name)}

    private fun maybeAutoBackup(){
        val prefs=getSharedPreferences("gestione_pagamenti",MODE_PRIVATE)
        val today=LocalDate.now().format(fmt)
        if(prefs.getString("autoBackupDate","")==today)return
        if(writeAutoBackup())prefs.edit().putString("autoBackupDate",today).apply()
    }

    private fun writeAutoBackup():Boolean{
        return try{
            val json=backupJson().toString(2).toByteArray(Charsets.UTF_8)
            val day=LocalDate.now().toString()
            val fileName="GestionePagamenti_auto_${day}.json"
            if(android.os.Build.VERSION.SDK_INT>=29){
                val resolver=contentResolver
                val projection=arrayOf(MediaStore.Downloads._ID)
                val selection="${MediaStore.Downloads.DISPLAY_NAME}=? AND ${MediaStore.Downloads.RELATIVE_PATH}=?"
                val args=arrayOf(fileName,"Download/GestionePagamenti/Backup automatici/")
                var uri:Uri?=null
                resolver.query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,projection,selection,args,null)?.use{c->if(c.moveToFirst())uri=Uri.withAppendedPath(MediaStore.Downloads.EXTERNAL_CONTENT_URI,c.getLong(0).toString())}
                val target=uri ?: resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,ContentValues().apply{
                    put(MediaStore.Downloads.DISPLAY_NAME,fileName)
                    put(MediaStore.Downloads.MIME_TYPE,"application/json")
                    put(MediaStore.Downloads.RELATIVE_PATH,"Download/GestionePagamenti/Backup automatici/")
                })
                target!=null && resolver.openOutputStream(target,"wt")?.use{it.write(json);true}==true
            }else{
                val dir=java.io.File(filesDir,"auto_backup");if(!dir.exists())dir.mkdirs()
                java.io.File(dir,fileName).writeBytes(json);true
            }
        }catch(_:Exception){false}
    }

    private fun backupConfirmDialog(title:String,message:String,icon:String,positiveText:String,positiveColor:Int,onConfirm:()->Unit){
        val root=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(20),dp(16),dp(20),dp(20))
            background=roundedSurface(Color.WHITE,28)
        }
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        top.addView(Space(this),LinearLayout.LayoutParams(0,dp(36),1f))
        val close=TextView(this).apply{
            text="×";textSize=28f;gravity=Gravity.CENTER;setTextColor(Color.rgb(70,82,105))
            background=roundedSurface(Color.rgb(246,248,252),18)
        }
        top.addView(close,LinearLayout.LayoutParams(dp(36),dp(36)))
        root.addView(top)
        val iconView=TextView(this).apply{
            text=icon;textSize=25f;gravity=Gravity.CENTER
            setTextColor(positiveColor);background=roundedSurface(Color.rgb(232,249,242),32)
        }
        root.addView(iconView,LinearLayout.LayoutParams(dp(66),dp(66)).apply{gravity=Gravity.CENTER;setMargins(0,dp(4),0,dp(14))})
        root.addView(TextView(this).apply{
            text=title;textSize=21f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER
            setTextColor(Color.rgb(25,32,45))
        },LinearLayout.LayoutParams(-1,-2))
        root.addView(TextView(this).apply{
            text=message;textSize=15.5f;gravity=Gravity.CENTER
            setTextColor(Color.rgb(70,82,105));setPadding(dp(8),dp(8),dp(8),dp(18))
        },LinearLayout.LayoutParams(-1,-2))
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val cancel=Button(this).apply{
            text="Annulla";setAllCaps(false);textSize=14f;setTextColor(Color.rgb(35,65,110));
            background=roundedSurface(Color.rgb(244,247,252),18,Color.rgb(203,218,239),1)
            minHeight=0;minimumHeight=0;minWidth=0;minimumWidth=0;stateListAnimator=null
        }
        val confirm=Button(this).apply{
            text=positiveText;setAllCaps(false);textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.WHITE)
            background=roundedSurface(positiveColor,18);minHeight=0;minimumHeight=0;minWidth=0;minimumWidth=0;stateListAnimator=null
        }
        actions.addView(cancel,LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(0,0,dp(6),0)})
        actions.addView(confirm,LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(dp(6),0,0,0)})
        root.addView(actions)
        val dialog=AlertDialog.Builder(this).setView(root).create()
        preparePopupBackdrop(dialog)
        dialog.setOnShowListener{
            popupBackdropCurrentDialog=dialog
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.TRANSPARENT,28))
            applyPopupBackdropEffect(dialog)
            dialog.window?.setDimAmount(0.42f)
            dialog.window?.let{w->w.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT)}
        }
        close.setOnClickListener{dialog.dismiss()}
        cancel.setOnClickListener{dialog.dismiss()}
        confirm.setOnClickListener{dialog.dismiss();onConfirm()}
        dialog.show()
    }

    private fun restoreAutoBackup(){
        try{
            val text=if(android.os.Build.VERSION.SDK_INT>=29){
                val resolver=contentResolver
                val projection=arrayOf(MediaStore.Downloads._ID,MediaStore.Downloads.DISPLAY_NAME)
                val selection="${MediaStore.Downloads.DISPLAY_NAME} LIKE ? AND ${MediaStore.Downloads.RELATIVE_PATH}=?"
                val args=arrayOf("GestionePagamenti_auto_%.json","Download/GestionePagamenti/Backup automatici/")
                var uri:Uri?=null;var latestName=""
                resolver.query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,projection,selection,args,"${MediaStore.Downloads.DISPLAY_NAME} DESC")?.use{c->if(c.moveToFirst()){latestName=c.getString(1);uri=Uri.withAppendedPath(MediaStore.Downloads.EXTERNAL_CONTENT_URI,c.getLong(0).toString())}}
                uri?.let{resolver.openInputStream(it)?.use{ins->BufferedReader(InputStreamReader(ins,Charsets.UTF_8)).readText()}}
            }else{
                val dir=java.io.File(filesDir,"auto_backup")
                dir.listFiles()?.sortedByDescending{it.name}?.firstOrNull()?.takeIf{it.exists()}?.readText()
            } ?: throw Exception()
            val root=JSONObject(text);require(root.optString("format")=="GestionePagamenti")
            val exportedAt=root.optString("exportedAt", "data non disponibile")
            backupConfirmDialog(
                "Ripristinare backup automatico?",
                "Il backup automatico sostituirà i dati attualmente presenti nell'app.\n\nBackup del: $exportedAt",
                "↺",
                "RIPRISTINA",
                Color.rgb(0,145,125)
            ){restoreFromJson(root)}
        }catch(_:Exception){Toast.makeText(this,"Nessun backup automatico disponibile.",Toast.LENGTH_LONG).show()}
    }

    private fun restoreFromJson(root:JSONObject){
        try{
            val newPacks=mutableListOf<Pack>();val array=root.getJSONArray("packs");for(i in 0 until array.length()){val o=array.getJSONObject(i);newPacks.add(Pack(o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("total"),o.optInt("paid",0),o.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}},o.optString("packageType","PERSONALIZZATO"),o.optInt("sessionTotal",12),o.optBoolean("active",true),o.optInt("missedSessions",0),o.optInt("weeklyWeeks",12),o.optJSONObject("weeklyQuantities")?.let{jo->mutableMapOf<String,Int>().apply{jo.keys().forEach{key->put(key,jo.optInt(key,0))}}} ?: mutableMapOf(), o.optString("includedAppointmentType","").ifBlank{null},o.optLong("clientId",0L)))}
            val newSessionPacks=mutableListOf<SessionPack>();val sp=root.optJSONArray("sessionPacks");if(sp!=null)for(i in 0 until sp.length()){val o=sp.getJSONObject(i);newSessionPacks.add(SessionPack(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("totalSessions"),o.getInt("cost"),o.optInt("paid",o.optInt("cost",0)),o.optBoolean("active",true),o.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}}, o.optJSONObject("customQuantities")?.let{jo->mutableMapOf<String,Int>().apply{jo.keys().forEach{key->put(key,jo.optInt(key,0))}}} ?: mutableMapOf(),o.optLong("clientId",0L)))}
            val newAppointments=mutableListOf<Appointment>();val ap=root.optJSONArray("appointments");if(ap!=null)for(i in 0 until ap.length()){val o=ap.getJSONObject(i);newAppointments.add(Appointment(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("date")),o.getString("time"),normalizedType(o.optString("type","TYPE1")),o.optLong("seriesId",0L),o.optLong("sessionPackId",0L),o.optBoolean("recovery",false)))}
            packs.clear();packs.addAll(newPacks);sessionPacks.clear();sessionPacks.addAll(newSessionPacks);appointments.clear();appointments.addAll(newAppointments);nextAppointmentId=(appointments.maxOfOrNull{it.id}?:0L)+1;nextSessionPackId=(sessionPacks.maxOfOrNull{it.id}?:0L)+1
            closurePeriods.clear();root.optJSONArray("closurePeriods")?.let{ja->for(i in 0 until ja.length()){val o=ja.getJSONObject(i);closurePeriods.add(ClosurePeriod(LocalDate.parse(o.getString("start")),LocalDate.parse(o.getString("end"))))}};ferieStart=if(root.isNull("ferieStart"))null else LocalDate.parse(root.getString("ferieStart"));ferieEnd=if(root.isNull("ferieEnd"))null else LocalDate.parse(root.getString("ferieEnd"));ensureClosurePeriods();dashboardEnabled=root.optBoolean("dashboardEnabled",false);surnameFirstDisplay=root.optBoolean("surnameFirstDisplay",true);largeSlotStyle=root.optInt("largeSlotStyle",10).coerceIn(1,10);appointmentSlotStyle=root.optInt("appointmentSlotStyle",10).coerceIn(1,10);calendarSlotDuration=root.optInt("calendarSlotDuration",45).let{if(it in listOf(15,30,45,60,90))it else 45};freeEventTimeStep=root.optInt("freeEventTimeStep",15).let{if(it in listOf(5,10,15,30,45,60))it else 15};freeEventDefaultColor=root.optInt("freeEventDefaultColor",Color.rgb(92,120,190));loadCalendarConfig(root);calendarVisibleDays=booleanArrayOf(true,true,true,true,true,false,false);root.optJSONArray("calendarVisibleDays")?.let{ja->if(ja.length()==7)calendarVisibleDays=BooleanArray(7){i->ja.optBoolean(i,i<5)}}
            restoreProfilesFromBackup(root);saveData();build();Toast.makeText(this,"Backup automatico ripristinato.",Toast.LENGTH_LONG).show()
        }catch(_:Exception){Toast.makeText(this,"Backup automatico non valido.",Toast.LENGTH_LONG).show()}
    }

    private fun writeBackup(uri:Uri){try{contentResolver.openOutputStream(uri)?.use{it.write(backupJson().toString(2).toByteArray(Charsets.UTF_8))};Toast.makeText(this,"Backup esportato correttamente.",Toast.LENGTH_LONG).show()}catch(_:Exception){Toast.makeText(this,"Impossibile esportare il backup.",Toast.LENGTH_LONG).show()}}
    private fun readBackup(uri:Uri){try{val text=contentResolver.openInputStream(uri)?.use{BufferedReader(InputStreamReader(it,Charsets.UTF_8)).readText()}?:throw Exception();val root=JSONObject(text);require(root.optString("format")=="GestionePagamenti");val newPacks=mutableListOf<Pack>();val array=root.getJSONArray("packs");for(i in 0 until array.length()){val o=array.getJSONObject(i);newPacks.add(Pack(o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("total"),o.optInt("paid",0), o.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}}, o.optString("packageType","PERSONALIZZATO"), o.optInt("sessionTotal",when(o.optString("packageType","PERSONALIZZATO")){"BRONZE"->12;"SILVER"->24;"GOLD"->36;else->12}), o.optBoolean("active",true), o.optInt("missedSessions",0), o.optInt("weeklyWeeks",12), o.optJSONObject("weeklyQuantities")?.let{jo->mutableMapOf<String,Int>().apply{jo.keys().forEach{key->put(key,jo.optInt(key,0))}}} ?: mutableMapOf(), o.optString("includedAppointmentType","").ifBlank{null},o.optLong("clientId",0L)))};closurePeriods.clear();root.optJSONArray("closurePeriods")?.let{ja->for(i in 0 until ja.length()){val o=ja.getJSONObject(i);closurePeriods.add(ClosurePeriod(LocalDate.parse(o.getString("start")),LocalDate.parse(o.getString("end"))))}};ferieStart=if(root.isNull("ferieStart"))null else LocalDate.parse(root.getString("ferieStart"));ferieEnd=if(root.isNull("ferieEnd"))null else LocalDate.parse(root.getString("ferieEnd"));ensureClosurePeriods();dashboardEnabled=root.optBoolean("dashboardEnabled",false);surnameFirstDisplay=root.optBoolean("surnameFirstDisplay",true);largeSlotStyle=root.optInt("largeSlotStyle",10).coerceIn(1,10);appointmentSlotStyle=root.optInt("appointmentSlotStyle",10).coerceIn(1,10);calendarSlotDuration=root.optInt("calendarSlotDuration",45).let{if(it in listOf(15,30,45,60,90))it else 45};loadCalendarConfig(root);calendarVisibleDays=booleanArrayOf(true,true,true,true,true,false,false);root.optJSONArray("calendarVisibleDays")?.let{ja->if(ja.length()==7)calendarVisibleDays=BooleanArray(7){i->ja.optBoolean(i,i<5)}};val newSessionPacks=mutableListOf<SessionPack>();val sp=root.optJSONArray("sessionPacks");if(sp!=null)for(i in 0 until sp.length()){val o=sp.getJSONObject(i);newSessionPacks.add(SessionPack(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("totalSessions"),o.getInt("cost"),o.optInt("paid",o.optInt("cost",0)),o.optBoolean("active",true),o.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}}, o.optJSONObject("customQuantities")?.let{jo->mutableMapOf<String,Int>().apply{jo.keys().forEach{key->put(key,jo.optInt(key,0))}}} ?: mutableMapOf(),o.optLong("clientId",0L)))};val newAppointments=mutableListOf<Appointment>();val ap=root.optJSONArray("appointments");if(ap!=null)for(i in 0 until ap.length()){val o=ap.getJSONObject(i);newAppointments.add(Appointment(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("date")),o.getString("time"),normalizedType(o.optString("type","TYPE1")),o.optLong("seriesId",0L),o.optLong("sessionPackId",0L),o.optBoolean("recovery",false)))};freeEvents.clear();val fe=root.optJSONArray("freeEvents");if(fe!=null)for(i in 0 until fe.length()){val o=fe.getJSONObject(i);freeEvents.add(FreeEvent(o.getLong("id"),o.optString("title","Evento libero"),LocalDate.parse(o.getString("date")),o.getString("startTime"),o.getString("endTime"),o.optInt("color",freeEventDefaultColor)))};nextFreeEventId=(freeEvents.maxOfOrNull{it.id}?:0L)+1;val newTrash=mutableListOf<TrashItem>();val tr=root.optJSONArray("trashItems");if(tr!=null)for(i in 0 until tr.length()){val o=tr.getJSONObject(i);runCatching{newTrash.add(TrashItem(o.optLong("id",i.toLong()+1),o.optString("kind","APPOINTMENT"),LocalDateTime.parse(o.optString("deletedAt")),o.optString("payload","")))}};packs.clear();packs.addAll(newPacks);sessionPacks.clear();sessionPacks.addAll(newSessionPacks);appointments.clear();appointments.addAll(newAppointments);trashItems.clear();trashItems.addAll(newTrash);nextAppointmentId=(appointments.maxOfOrNull{it.id}?:0L)+1;nextSessionPackId=(sessionPacks.maxOfOrNull{it.id}?:0L)+1;nextTrashId=(trashItems.maxOfOrNull{it.id}?:0L)+1;restoreProfilesFromBackup(root);saveData();build();Toast.makeText(this,"Backup importato: dati, ferie, pagamenti e appuntamenti ripristinati.",Toast.LENGTH_LONG).show()}catch(_:Exception){Toast.makeText(this,"Backup non valido o non leggibile.",Toast.LENGTH_LONG).show()}}

    private fun saveData(){
        val prefs=getSharedPreferences("gestione_pagamenti",MODE_PRIVATE);val array=JSONArray();packs.forEach{p->array.put(JSONObject().apply{put("name",p.name);put("start",p.start.toString());put("total",p.total);put("paid",p.paid);put("rateAmounts",JSONArray().apply{ratesFor(p).forEach{put(it)}});put("packageType",p.packageType);put("sessionTotal",p.sessionTotal);put("active",p.active);put("missedSessions",p.missedSessions);put("weeklyWeeks",p.weeklyWeeks);put("weeklyQuantities",JSONObject().apply{p.weeklyQuantities.forEach{(k,v)->put(k,v)}});put("includedAppointmentType",p.includedAppointmentType);put("clientId",p.clientId)})};val sp=JSONArray();sessionPacks.forEach{s->sp.put(JSONObject().apply{put("id",s.id);put("name",s.name);put("start",s.start.toString());put("totalSessions",s.totalSessions);put("cost",s.cost);put("paid",s.paid);put("active",s.active);put("rateAmounts",JSONArray().apply{sessionRatesFor(s).forEach{put(it)}});put("customQuantities",JSONObject().apply{s.customQuantities.forEach{(k,v)->put(k,v)}});put("clientId",s.clientId)})};val ap=JSONArray();appointments.forEach{a->ap.put(JSONObject().apply{put("id",a.id);put("name",a.name);put("date",a.date.toString());put("time",a.time);put("type",a.type);put("seriesId",a.seriesId);put("sessionPackId",a.sessionPackId);put("recovery",a.recovery)})};val fe=JSONArray();freeEvents.forEach{e->fe.put(JSONObject().apply{put("id",e.id);put("title",e.title);put("date",e.date.toString());put("startTime",e.startTime);put("endTime",e.endTime);put("color",e.color)})};prefs.edit().putString("packs",array.toString()).putString("sessionPacks",sp.toString()).putString("appointments",ap.toString()).putString("freeEvents",fe.toString()).putInt("freeEventDefaultColor",freeEventDefaultColor).putInt("freeEventTimeStep",freeEventTimeStep).putString("ferieStart",ferieStart?.toString()).putString("ferieEnd",ferieEnd?.toString()).putString("closurePeriods",JSONArray().apply{closurePeriods.forEach{put(JSONObject().apply{put("start",it.start.toString());put("end",it.end.toString())})}}.toString()).putBoolean("dashboardEnabled",dashboardEnabled).putBoolean("surnameFirstDisplay",surnameFirstDisplay).putString("popupBackdropEffect",popupBackdropEffect).putString("popupBackdropMode",popupBackdropMode).putInt("popupBackdropIntensity",popupBackdropIntensity).putInt("largeSlotStyle",largeSlotStyle.coerceIn(1,10)).putInt("appointmentSlotStyle",appointmentSlotStyle.coerceIn(1,10)).putInt("calendarSlotDuration",calendarSlotDuration).putString("calendarVisibleDays",calendarVisibleDays.joinToString(","){if(it)"1" else "0"}).putInt("calendarNavPosition",calendarNavPosition).putString("calendarNavOrder",calendarNavOrder.joinToString(",")).putString("calendarTopButtons",calendarTopButtons.joinToString(",")).putString("calendarBottomButtons",calendarBottomButtons.joinToString(",")).putString("appointmentTypes",JSONArray().apply{appointmentTypes.forEach{t->put(JSONObject().apply{put("id",t.id);put("name",t.name);put("color",t.color)})}}.toString()).putInt("activeRoutineIndex",activeRoutineIndex).putString("calendarRoutines",JSONArray().apply{calendarRoutines.forEach{r->put(JSONObject().apply{put("name",r.name);put("maxTotal",r.maxTotal);put("maxByType",JSONArray().apply{r.maxByType.forEach{put(it)}})})}}.toString()).putLong("nextAppointmentId",nextAppointmentId).putLong("nextFreeEventId",nextFreeEventId).putLong("nextSessionPackId",nextSessionPackId).putString("trashItems",JSONArray().apply{trashItems.forEach{t->put(JSONObject().apply{put("id",t.id);put("kind",t.kind);put("deletedAt",t.deletedAt.toString());put("payload",t.payload)})}}.toString()).putLong("nextTrashId",nextTrashId).apply();maybeAutoBackup()
    }
    private fun loadData(){
        val prefs=getSharedPreferences("gestione_pagamenti",MODE_PRIVATE);packs.clear();sessionPacks.clear();appointments.clear();freeEvents.clear();trashItems.clear();loadClientData();val saved=prefs.getString("packs",null);if(!saved.isNullOrEmpty())try{val array=JSONArray(saved);for(i in 0 until array.length()){val o=array.getJSONObject(i);packs.add(Pack(o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("total"),o.optInt("paid",0), o.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}}, o.optString("packageType","PERSONALIZZATO"), o.optInt("sessionTotal",when(o.optString("packageType","PERSONALIZZATO")){"BRONZE"->12;"SILVER"->24;"GOLD"->36;else->12}), o.optBoolean("active",true), o.optInt("missedSessions",0), o.optInt("weeklyWeeks",12), o.optJSONObject("weeklyQuantities")?.let{jo->mutableMapOf<String,Int>().apply{jo.keys().forEach{key->put(key,jo.optInt(key,0))}}} ?: mutableMapOf(), o.optString("includedAppointmentType","").ifBlank{null},o.optLong("clientId",0L)))}}catch(_:Exception){packs.clear()};val ap=prefs.getString("appointments",null);if(!ap.isNullOrEmpty())try{val array=JSONArray(ap);for(i in 0 until array.length()){val o=array.getJSONObject(i);appointments.add(Appointment(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("date")),o.getString("time"),normalizedType(o.optString("type","TYPE1")),o.optLong("seriesId",0L),o.optLong("sessionPackId",0L),o.optBoolean("recovery",false)))}}catch(_:Exception){appointments.clear()};val savedFree=prefs.getString("freeEvents",null);if(!savedFree.isNullOrEmpty())try{val array=JSONArray(savedFree);for(i in 0 until array.length()){val o=array.getJSONObject(i);freeEvents.add(FreeEvent(o.getLong("id"),o.optString("title","Evento libero"),LocalDate.parse(o.getString("date")),o.getString("startTime"),o.getString("endTime"),o.optInt("color",freeEventDefaultColor)))}}catch(_:Exception){freeEvents.clear()};nextFreeEventId=maxOf(prefs.getLong("nextFreeEventId",1L),(freeEvents.maxOfOrNull{it.id}?:0L)+1);val savedSp=prefs.getString("sessionPacks",null);if(!savedSp.isNullOrEmpty())try{val array=JSONArray(savedSp);for(i in 0 until array.length()){val o=array.getJSONObject(i);sessionPacks.add(SessionPack(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("totalSessions"),o.getInt("cost"),o.optInt("paid",o.optInt("cost",0)),o.optBoolean("active",true),o.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}}, o.optJSONObject("customQuantities")?.let{jo->mutableMapOf<String,Int>().apply{jo.keys().forEach{key->put(key,jo.optInt(key,0))}}} ?: mutableMapOf(),o.optLong("clientId",0L)))}}catch(_:Exception){sessionPacks.clear()};val savedTrash=prefs.getString("trashItems",null);if(!savedTrash.isNullOrEmpty())try{val array=JSONArray(savedTrash);for(i in 0 until array.length()){val o=array.getJSONObject(i);trashItems.add(TrashItem(o.optLong("id",i.toLong()+1),o.optString("kind","APPOINTMENT"),LocalDateTime.parse(o.optString("deletedAt")),o.optString("payload","")))}}catch(_:Exception){trashItems.clear()};nextTrashId=maxOf(prefs.getLong("nextTrashId",1L),(trashItems.maxOfOrNull{it.id}?:0L)+1);nextAppointmentId=maxOf(prefs.getLong("nextAppointmentId",1L),(appointments.maxOfOrNull{it.id}?:0L)+1);nextSessionPackId=maxOf(prefs.getLong("nextSessionPackId",1L),(sessionPacks.maxOfOrNull{it.id}?:0L)+1)
        appointments.filter{it.sessionPackId==0L}.forEach{a->activeSessionPackFor(a.name)?.let{sp->a.sessionPackId=sp.id}}
        ferieStart=prefs.getString("ferieStart",null)?.let{runCatching{LocalDate.parse(it)}.getOrNull()};ferieEnd=prefs.getString("ferieEnd",null)?.let{runCatching{LocalDate.parse(it)}.getOrNull()};closurePeriods.clear();prefs.getString("closurePeriods",null)?.let{runCatching{val ja=JSONArray(it);for(i in 0 until ja.length()){val o=ja.getJSONObject(i);closurePeriods.add(ClosurePeriod(LocalDate.parse(o.getString("start")),LocalDate.parse(o.getString("end"))))}}};ensureClosurePeriods();dashboardEnabled=prefs.getBoolean("dashboardEnabled",false);surnameFirstDisplay=prefs.getBoolean("surnameFirstDisplay",true);popupBackdropEffect=prefs.getString("popupBackdropEffect","NONE")?.uppercase()?.takeIf{it in setOf("NONE","SATIN","VETRO_SOFT","LIQUID")}?:"NONE";popupBackdropMode=prefs.getString("popupBackdropMode","CONTOUR")?.uppercase()?.takeIf{it in setOf("CONTOUR","IMMERSIVE")}?:"CONTOUR";popupBackdropIntensity=prefs.getInt("popupBackdropIntensity",65).coerceIn(0,100);largeSlotStyle=prefs.getInt("largeSlotStyle",10).coerceIn(1,10);appointmentSlotStyle=prefs.getInt("appointmentSlotStyle",10).coerceIn(1,10);calendarSlotDuration=prefs.getInt("calendarSlotDuration",45).let{if(it in listOf(15,30,45,60,90))it else 45};freeEventTimeStep=prefs.getInt("freeEventTimeStep",15).let{if(it in listOf(5,10,15,30,45,60))it else 15};val savedDays=prefs.getString("calendarVisibleDays",null);calendarVisibleDays=if(!savedDays.isNullOrBlank()){val parts=savedDays.split(",");if(parts.size==7)BooleanArray(7){i->parts[i]=="1"}else booleanArrayOf(true,true,true,true,true,false,false)}else booleanArrayOf(true,true,true,true,true,false,false);calendarNavPosition=prefs.getInt("calendarNavPosition",1).coerceIn(0,1);calendarNavOrder=prefs.getString("calendarNavOrder",null)?.split(",")?.filter{it in listOf("PREV","SEARCH","TODAY","NEXT")}?.toMutableList()?:mutableListOf("PREV","SEARCH","TODAY","NEXT");if(calendarNavOrder.size==3&&calendarNavOrder.distinct().size==3){val ni=calendarNavOrder.indexOf("NEXT");if(ni>=0)calendarNavOrder.add(ni,"TODAY") else calendarNavOrder.add("TODAY")};if(calendarNavOrder.size!=4||calendarNavOrder.distinct().size!=4)calendarNavOrder=mutableListOf("PREV","SEARCH","TODAY","NEXT");if(calendarNavOrder.indexOf("PREV")>calendarNavOrder.indexOf("NEXT")){val pi=calendarNavOrder.indexOf("PREV");val ni=calendarNavOrder.indexOf("NEXT");calendarNavOrder[pi]="NEXT";calendarNavOrder[ni]="PREV"};calendarTopButtons=prefs.getString("calendarTopButtons",null)?.split(",")?.filter{it in listOf("APPT","SEARCH","TODAY","PREV","NEXT")}?.toMutableList()?:mutableListOf();calendarBottomButtons=prefs.getString("calendarBottomButtons",null)?.split(",")?.filter{it in listOf("APPT","SEARCH","TODAY","PREV","NEXT")}?.toMutableList()?:mutableListOf();if(calendarTopButtons.isEmpty()&&calendarBottomButtons.isEmpty()){calendarTopButtons.add("APPT");if(calendarNavPosition==0)calendarTopButtons.addAll(calendarNavOrder)else calendarBottomButtons.addAll(calendarNavOrder)};calendarTopButtons=calendarTopButtons.distinct().toMutableList();calendarBottomButtons=calendarBottomButtons.filter{it !in calendarTopButtons}.distinct().toMutableList();appointmentTypes.clear();prefs.getString("appointmentTypes",null)?.let{runCatching{val a=JSONArray(it);for(i in 0 until a.length()){val t=a.getJSONObject(i);appointmentTypes.add(AppointmentType(t.optString("id","TYPE${i+1}"),t.optString("name",if(i==0)"ALLENAMENTO" else if(i==1)"MEZZ'ORA" else "Tipo ${i+1}"),t.optInt("color",if(i==0)Color.rgb(45,135,210) else Color.rgb(215,55,55))))}}};if(appointmentTypes.isEmpty()){appointmentTypes.add(AppointmentType("TYPE1","ALLENAMENTO",Color.rgb(45,135,210)));appointmentTypes.add(AppointmentType("TYPE2","MEZZ'ORA",Color.rgb(215,55,55)))};activeRoutineIndex=prefs.getInt("activeRoutineIndex",0);prefs.getString("calendarRoutines",null)?.let{runCatching{val a=JSONArray(it);calendarRoutines.clear();for(i in 0 until a.length()){val r=a.getJSONObject(i);val limits=mutableListOf<Int>();r.optJSONArray("maxByType")?.let{ja->for(j in 0 until ja.length())limits.add(ja.optInt(j,3))};if(limits.isEmpty()){limits.add(2);limits.add(3)};while(limits.size<appointmentTypes.size)limits.add(r.optInt("maxTotal",3));calendarRoutines.add(CalendarRoutine(r.optString("name","Routine ${i+1}"),r.optInt("maxTotal",3),limits))}}};if(calendarRoutines.isEmpty())calendarRoutines.add(CalendarRoutine("Personalizzata",3,MutableList(appointmentTypes.size){if(it==0)2 else 3}));ensureAppointmentTypes();calendarRoutines.forEach{while(it.maxByType.size<appointmentTypes.size)it.maxByType.add(it.maxTotal)};activeRoutineIndex=activeRoutineIndex.coerceIn(0,calendarRoutines.lastIndex)
    }

    private fun ratesFor(p:Pack):List<Int>{
        val c=p.customRates
        val expectedCount=if(p.packageType=="WEEKLY_CUSTOM") ((p.weeklyWeeks.coerceAtLeast(1)+3)/4) else 3
        if(c!=null&&c.size==expectedCount&&c.all{it>0}&&c.sum()==p.total)return c.toList()
        val count=expectedCount.coerceAtLeast(1)
        val base=p.total/count
        val extra=p.total%count
        return List(count){base+if(it<extra)1 else 0}
    }

    private fun saveRates(p:Pack,rates:List<Int>){p.customRates=rates.toMutableList()}

    private fun registerPayment(p:Pack,index:Int,paidNow:Int){
        try{
            val rates=ratesFor(p)
            val due=rates[index]
            require(paidNow>0)
            require(p.paid+paidNow<=p.total)

            val paidBeforeCurrent=rates.take(index).sum()
            val alreadyPaidOnCurrent=(p.paid-paidBeforeCurrent).coerceAtLeast(0)
            val totalPaidOnCurrent=alreadyPaidOnCurrent+paidNow
            val newRates=rates.toMutableList()

            p.paid+=paidNow

            // Se il cliente paga più della rata prevista, la rata corrente
            // diventa pari a quanto effettivamente versato e il residuo viene
            // redistribuito sulle rate successive.
            if(totalPaidOnCurrent>due){
                newRates[index]=totalPaidOnCurrent
                val remainingCount=newRates.size-index-1
                if(remainingCount>0){
                    val remaining=p.total-rates.take(index).sum()-totalPaidOnCurrent
                    require(remaining>=0)
                    val base=remaining/remainingCount
                    val extra=remaining%remainingCount
                    for(j in index+1 until newRates.size){
                        newRates[j]=base+if(j-index-1<extra)1 else 0
                    }
                } else require(totalPaidOnCurrent==p.total-rates.take(index).sum())
            }

            require(newRates.sum()==p.total)
            saveRates(p,newRates)
            expandedClients.add(identityKey(p.name))
            saveData()
            // Aggiorna immediatamente anche la scheda Gestione pacchetto già aperta.
            // Prima veniva aggiornata solo dopo averla chiusa e riaperta.
            activePackageDialog?.dismiss()
            activePackageDialog = null
            render()
            packageInfoDialog(p)
            val residual=p.total-p.paid
            if(index==rates.lastIndex && residual>0 && totalPaidOnCurrent<due){
                Toast.makeText(this,"Pagamento registrato. Rimangono €$residual da pagare.",Toast.LENGTH_LONG).show()
                proposeResidualRate(p,index,residual)
            } else if(totalPaidOnCurrent>due) Toast.makeText(this,"Pagamento registrato: rate successive ricalcolate automaticamente.",Toast.LENGTH_LONG).show()
            else Toast.makeText(this,"Pagamento di €$paidNow registrato.",Toast.LENGTH_SHORT).show()
        }catch(_:Exception){
            Toast.makeText(this,"Importo non valido o superiore al totale residuo.",Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmPaymentDialog(p:Pack,index:Int,amount:Int){
        val rates=ratesFor(p)
        val (dialog,outer,body)=packActionDialogBase(
            "Conferma pagamento",
            "✓",
            Color.rgb(0,145,112),
            Color.rgb(205,244,233),
            Color.rgb(248,255,252)
        )

        body.addView(dialogBodyText("Confermi il pagamento della rata ${index+1}?"))
        body.addView(dialogInfoCard(
            "€",
            "Importo rata",
            "€$amount",
            Color.rgb(0,145,112),
            Color.rgb(224,248,241)
        ),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,dp(8))})

        body.addView(dialogInfoCard(
            "▣",
            "Rata ${index+1} di ${rates.size}",
            "${dueDates(p)[index]}",
            Color.rgb(25,100,190),
            Color.rgb(235,244,255)
        ),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(14))})

        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        row.addView(dialogButton("Annulla",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(210,220,232)){dialog.dismiss()},
            LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(5),0)})
        row.addView(dialogButton("✓ Conferma",Color.WHITE,Color.rgb(0,145,112),Color.rgb(0,145,112)){
            dialog.dismiss()
            registerPayment(p,index,amount)
        },LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(5),0,0,0)})
        body.addView(row)
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun proposeResidualRate(p:Pack,index:Int,residual:Int){
        if(residual<=0 || index!=ratesFor(p).lastIndex)return
        val dialog=buildResidualRateDialog(
            previousRate=index+1,
            dueAmount=ratesFor(p)[index],
            alreadyPaid=(p.paid-ratesFor(p).dropLast(1).sum()).coerceAtLeast(0),
            residual=residual,
            nextRate=index+2,
            onCreate={
                val current=ratesFor(p).toMutableList()
                val paidOnLast=(p.paid-current.dropLast(1).sum()).coerceAtLeast(0)
                if(paidOnLast>0 && paidOnLast<current.last()){
                    current[current.lastIndex]=paidOnLast
                    current.add(residual)
                    saveRates(p,current)
                    saveData()
                    activePackageDialog?.dismiss();activePackageDialog=null
                    render();packageInfoDialog(p)
                    Toast.makeText(this,"4ª rata creata: €$residual.",Toast.LENGTH_SHORT).show()
                }
            }
        )
        dialog.show()
    }

    private fun addRateDialog(p:Pack){
        val rates=ratesFor(p)
        val lastIndex=rates.lastIndex
        val paidBeforeLast=rates.dropLast(1).sum()
        val paidOnLast=(p.paid-paidBeforeLast).coerceAtLeast(0)
        val residual=(p.total-p.paid).coerceAtLeast(0)
        if(rates.size>=12){Toast.makeText(this,"Numero massimo di rate raggiunto.",Toast.LENGTH_SHORT).show();return}
        if(residual<=0){Toast.makeText(this,"Il pacchetto è già completamente pagato.",Toast.LENGTH_SHORT).show();return}
        if(lastIndex<0 || paidOnLast<=0 || paidOnLast>=rates[lastIndex]){
            Toast.makeText(this,"La 4ª rata viene proposta automaticamente quando l'ultima rata viene pagata solo in parte.",Toast.LENGTH_LONG).show()
            return
        }
        val dialog=AlertDialog.Builder(this)
            .setTitle("Aggiungi 4ª rata")
            .setMessage("Restano €$residual da pagare. Vuoi trasformare il residuo in una 4ª rata con scadenza tra 28 giorni?")
            .setNegativeButton("ANNULLA",null)
            .setPositiveButton("CREA 4ª RATA"){_,_->
                val newRates=rates.toMutableList()
                newRates[lastIndex]=paidOnLast
                newRates.add(residual)
                saveRates(p,newRates)
                saveData()
                activePackageDialog?.dismiss();activePackageDialog=null
                render();packageInfoDialog(p)
                Toast.makeText(this,"4ª rata creata: €$residual.",Toast.LENGTH_SHORT).show()
            }
            .create()
        styleOneUiDialog(dialog);dialog.show()
    }

    private fun paymentAmountDialog(p:Pack,index:Int){
        val rates=ratesFor(p)
        val due=rates[index]
        val (dialog,outer,body)=packActionDialogBase(
            "Modifica importo pagamento",
            "✎",
            Color.rgb(20,91,165),
            Color.rgb(224,238,255),
            Color.WHITE
        )

        body.addView(dialogBodyText("Rata ${index+1} di ${rates.size} • prevista €$due"))
        body.addView(dialogInfoCard(
            "ⓘ",
            "Inserisci il nuovo importo per questa rata.",
            "L'importo originale era €$due.",
            Color.rgb(25,100,190),
            Color.rgb(235,244,255)
        ),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,dp(12))})

        body.addView(TextView(this).apply{
            text="Nuovo importo"
            textSize=12.5f
            setTypeface(null,android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(82,87,94))
            setPadding(dp(2),0,0,dp(5))
        })

        val amount=modernEditText().apply{
            hint="Importo (€)"
            inputType=2
            setSingleLine(true)
            setText(due.toString())
            selectAll()
            textSize=16f
        }
        body.addView(amount,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(14))})

        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        row.addView(dialogButton("Annulla",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(210,220,232)){dialog.dismiss()},
            LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(5),0)})
        row.addView(dialogButton("✓ Conferma",Color.WHITE,Color.rgb(36,112,225),Color.rgb(36,112,225)){
            val value=amount.text.toString().trim().toIntOrNull()
            if(value==null||value<=0||p.paid+value>p.total){
                Toast.makeText(this,"Importo non valido o superiore al totale residuo.",Toast.LENGTH_LONG).show()
            }else{
                dialog.dismiss()
                registerPayment(p,index,value)
            }
        },LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(5),0,0,0)})
        body.addView(row)

        preparePopupBackdrop(dialog)
        dialog.setOnShowListener{
            popupBackdropCurrentDialog=dialog
            dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
            applyPopupBackdropEffect(dialog)
            dialog.window?.setDimAmount(0.40f)
            dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
            amount.clearFocus()
        }
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun paymentOptionsDialog(p:Pack,index:Int){
        val rates=ratesFor(p)
        val (dialog,outer,body)=packActionDialogBase(
            "Opzioni pagamento",
            "✎",
            Color.rgb(20,91,165),
            Color.rgb(224,238,255),
            Color.rgb(248,252,255)
        )

        body.addView(dialogBodyText("Rata ${index+1} di ${rates.size} • €${rates[index]}"))
        val editRow=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(12),dp(10),dp(10),dp(10))
            background=roundedSurface(Color.rgb(235,244,255),18,Color.rgb(205,224,248),1)
        }
        editRow.addView(TextView(this).apply{
            text="✎";textSize=21f;gravity=Gravity.CENTER;setTextColor(Color.rgb(20,91,165));
            background=roundedSurface(Color.rgb(216,234,255),20)
        },LinearLayout.LayoutParams(dp(46),dp(46)))
        val et=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,dp(6),0)}
        et.addView(TextView(this).apply{
            text="Modifica importo da pagare";textSize=15f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,70,125))
        })
        et.addView(TextView(this).apply{
            text="Puoi modificare l'importo di questa rata.";textSize=12.5f;setTextColor(Color.rgb(70,100,130));setPadding(0,dp(3),0,0)
        })
        editRow.addView(et,LinearLayout.LayoutParams(0,-2,1f))
        editRow.addView(TextView(this).apply{text="›";textSize=28f;gravity=Gravity.CENTER;setTextColor(Color.rgb(20,91,165))},LinearLayout.LayoutParams(dp(28),dp(50)))
        body.addView(editRow,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,dp(12))})

        val cancel=dialogButton("Annulla",Color.rgb(20,91,165),Color.rgb(246,249,253),Color.rgb(205,220,238)){dialog.dismiss()}
        body.addView(cancel,LinearLayout.LayoutParams(-1,dp(48)))
        editRow.setOnClickListener{dialog.dismiss();paymentAmountDialog(p,index)}
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun editRateDialog(p:Pack,index:Int){
        val rates=ratesFor(p);val firstUnpaid=p.paidRateIndex(rates);if(index<firstUnpaid){Toast.makeText(this,"Questa rata è già pagata.",Toast.LENGTH_SHORT).show();return}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(8),dp(16),0)}
        val amount=modernEditText().apply{hint="Nuovo importo rata";inputType=2;setSingleLine(true);setText(rates[index].toString())};box.addView(amount)
        val laterCount=rates.size-index-1
        AlertDialog.Builder(this).setTitle("Modifica rata ${index+1}").setMessage(if(laterCount>0)"Modifica questa rata: le rate successive verranno ricalcolate automaticamente per mantenere invariato il totale di €${p.total}." else "Essendo l'ultima rata, l'importo viene calcolato sul residuo del pacchetto.").setView(box).setNegativeButton("Annulla",null).setPositiveButton("SALVA"){_,_->
            try{
                val newAmount=amount.text.toString().trim().toInt();require(newAmount>0)
                val paidBefore=rates.take(index).sum();val alreadyOnRate=p.paid-paidBefore;require(newAmount>=alreadyOnRate)
                val remainingAfter=p.total-paidBefore-newAmount;require(remainingAfter>=0)
                val newRates=rates.toMutableList();newRates[index]=newAmount
                if(laterCount>0){val base=remainingAfter/laterCount;val extra=remainingAfter%laterCount;for(j in index+1 until newRates.size)newRates[j]=base+if(j-index-1<extra)1 else 0}else require(remainingAfter==0)
                require(newRates.sum()==p.total);saveRates(p,newRates);saveData();render()
            }catch(_:Exception){Toast.makeText(this,"Importo non valido: controlla il residuo del pacchetto.",Toast.LENGTH_LONG).show()}
        }.create().also{styleOneUiDialog(it);it.show()}
    }
    private fun dueDates(p:Pack):List<LocalDate>{val count=ratesFor(p).size;val out=mutableListOf<LocalDate>();var d=p.start;repeat(count){out.add(d);d=advance(d,28)};return out}
    private fun advance(d0:LocalDate,days:Int):LocalDate{
        ensureClosurePeriods()
        var d=d0.plusDays(days.toLong())
        val counted=mutableSetOf<String>()
        var guard=0
        while(guard++<50){
            val hit=closurePeriods.firstOrNull{
                val key="${it.start}|${it.end}"
                key !in counted && it.start.isBefore(d.plusDays(1)) && it.end.isAfter(d0)
            } ?: break
            val key="${hit.start}|${hit.end}"
            counted.add(key)
            val weeks=((java.time.temporal.ChronoUnit.DAYS.between(hit.start,hit.end)+1)/7).coerceAtLeast(1)
            d=d.plusWeeks(weeks.toLong())
        }
        return d
    }
    private fun closureText():String{ensureClosurePeriods();return if(closurePeriods.isNotEmpty())"🏖 ${closurePeriods.size} periodo/i di chiusura" else "Nessuna chiusura ferie impostata"}

    private fun displaySurnameFirst(name:String):String{
        val clean=name.trim()
        if(!surnameFirstDisplay)return clean.split(Regex("\\s+")).filter{it.isNotBlank()}.let{parts->if(parts.size<=1)clean else parts.drop(1).joinToString(" ")+" "+parts.first()}
        return clean
    }


    private fun render(){
        // Quando si cambia vista (es. DASH), la lista deve ripartire dall'inizio:
        // altrimenti lo ScrollView può conservare lo scroll precedente e nascondere
        // la sezione SCADUTI lasciando visibile solo una sezione più in basso.
        (list.parent as? ScrollView)?.scrollTo(0,0)
        list.removeAllViews()
        val query=if(::searchInput.isInitialized)searchInput.text.toString().trim().lowercase() else ""
        if(query.isNotEmpty()){
            renderSearchResults(query)
            return
        }
        val filteredBase=packs.filter{it.active}
        val filteredSessionsBase=sessionPacks.filter{it.active&&(query.isEmpty()||it.name.lowercase().contains(query))}
        val filtered=when(homeSortMode){
            1->filteredBase.sortedBy{it.name.lowercase()}
            2->filteredBase.sortedByDescending{it.name.lowercase()}
            else->filteredBase.sortedWith(compareBy<Pack>{statusRank(statusFor(it,ratesFor(it),dueDates(it)))}.thenBy{it.start}.thenBy{it.name.lowercase()})
        }
        val filteredSessions=when(homeSortMode){
            1->filteredSessionsBase.sortedBy{it.name.lowercase()}
            2->filteredSessionsBase.sortedByDescending{it.name.lowercase()}
            else->filteredSessionsBase.sortedWith(compareBy<SessionPack>{statusRank(sessionStatus(it))}.thenBy{it.start}.thenBy{it.name.lowercase()})
        }
        if(dashboardEnabled){renderDashboard(filtered,filteredSessions)}else{
            if(filtered.isEmpty()&&filteredSessions.isEmpty()){
                list.addView(TextView(this).apply{text=if(packs.isEmpty()&&sessionPacks.isEmpty())"Nessun pacchetto inserito." else "Nessun cliente trovato.";textSize=18f;setTextColor(Color.DKGRAY);setPadding(0,dp(12),0,dp(12))})
                return
            }
            val unified=mutableListOf<Any>()
            filtered.forEach{unified.add(it)}
            filteredSessions.forEach{unified.add(it)}
            val ordered=when(homeSortMode){
                1->unified.sortedBy{when(it){is Pack->it.name.lowercase();is SessionPack->it.name.lowercase();else->""}}
                2->unified.sortedByDescending{when(it){is Pack->it.name.lowercase();is SessionPack->it.name.lowercase();else->""}}
                else->unified.sortedWith(compareBy<Any>{when(it){is Pack->statusRank(statusFor(it,ratesFor(it),dueDates(it)));is SessionPack->statusRank(sessionStatus(it));else->Int.MAX_VALUE}}.thenBy{when(it){is Pack->it.start;is SessionPack->it.start;else->LocalDate.MAX}}.thenBy{when(it){is Pack->it.name.lowercase();is SessionPack->it.name.lowercase();else->""}})
            }
            ordered.forEach{item->when(item){is Pack->card(item);is SessionPack->sessionCard(item)}}
        }
    }

    private fun renderSearchResults(query:String){
        val target=if(::searchList.isInitialized)searchList else list
        target.removeAllViews()
        val matchingNames=(packs.filter{it.name.lowercase().contains(query)}.map{it.name}+sessionPacks.filter{it.name.lowercase().contains(query)}.map{it.name}+appointments.filter{it.name.lowercase().contains(query)}.map{it.name}).distinctBy{identityKey(it)}.sortedBy{it.lowercase()}
        val matchingAppointments=appointments.filter{it.name.lowercase().contains(query)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        if(matchingNames.isEmpty()&&matchingAppointments.isEmpty()){
            target.addView(TextView(this).apply{text="Nessun risultato";textSize=17f;setTextColor(Color.DKGRAY);setPadding(dp(8),dp(16),dp(8),dp(16))})
            return
        }
        if(matchingNames.isNotEmpty()){
            target.addView(TextView(this).apply{text="CLIENTI";textSize=12f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(100,104,110));setPadding(dp(6),dp(4),dp(6),dp(6))})
            matchingNames.forEach{name->
                val key=identityKey(name)
                val regular=packs.firstOrNull{it.active&&identityKey(it.name)==key}
                val session=sessionPacks.firstOrNull{it.active&&identityKey(it.name)==key}
                val statusColor=when{regular!=null->statusFor(regular,ratesFor(regular),dueDates(regular)).color;session!=null->sessionStatus(session).color;else->Color.GRAY}
                val future=appointments.filter{identityKey(it.name)==key&&it.date.isAfter(LocalDate.now())}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
                val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;background=roundedSurface(Color.WHITE,18,Color.rgb(228,231,235),1);setPadding(dp(14),dp(10),dp(10),dp(10))}
                val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                top.addView(TextView(this).apply{text=displaySurnameFirst(name);textSize=17f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(24,27,31));gravity=Gravity.CENTER_VERTICAL;maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END},LinearLayout.LayoutParams(0,dp(44),1f))
                top.addView(TextView(this).apply{text=if(future.isNotEmpty())"${future.size} appuntamenti" else "Nessun futuro";textSize=12.5f;setTextColor(Color.rgb(90,94,100));gravity=Gravity.CENTER},LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,dp(44)))
                top.addView(TextView(this).apply{text="●";textSize=18f;setTextColor(statusColor);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(28),dp(44)))
                row.addView(top)
                val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(6),0,0)}
                val program=Button(this).apply{text="📋 Programmazione";setAllCaps(false);textSize=12.5f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(Color.rgb(20,95,150));background=roundedSurface(Color.rgb(240,247,253),15,Color.rgb(190,220,248),1);setOnClickListener{copyProgrammingToClipboard(name)}}
                actions.addView(program,LinearLayout.LayoutParams(0,dp(42),1f).apply{setMargins(0,0,dp(5),0)})
                val packageButton=Button(this).apply{text="📦 Pacchetto";setAllCaps(false);textSize=12.5f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(Color.rgb(65,70,185));background=roundedSurface(Color.rgb(246,246,255),15,Color.rgb(214,214,246),1);setOnClickListener{openPackageFromSearch(name)}}
                actions.addView(packageButton,LinearLayout.LayoutParams(0,dp(42),0.82f).apply{setMargins(0,0,dp(5),0)})
                val open=Button(this).apply{text="Apri";setAllCaps(false);textSize=12.5f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(Color.rgb(0,125,110));background=roundedSurface(Color.rgb(244,249,248),15,Color.rgb(190,225,216),1);setOnClickListener{showSearchClientAppointments(name)}}
                actions.addView(open,LinearLayout.LayoutParams(dp(72),dp(42)))
                row.addView(actions)
                row.setOnClickListener{showSearchClientAppointments(name)}
                target.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})
            }
        }
        if(matchingAppointments.isNotEmpty()){
            target.addView(TextView(this).apply{text="APPUNTAMENTI";textSize=12f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(100,104,110));setPadding(dp(6),dp(10),dp(6),dp(6))})
            matchingAppointments.forEach{a->
                val accent=typeColor(a.type)
                val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;background=roundedSurface(Color.WHITE,16,Color.rgb(228,231,235),1);setPadding(dp(12),dp(8),dp(12),dp(8))}
                row.addView(TextView(this).apply{text=displaySurnameFirst(a.name);textSize=15f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(30,32,36));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,dp(52),1f))
                val closed=isStudioClosed(a.date)
                val info=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER}
                val dateLine=TextView(this).apply{text="${a.date.format(fmt)}\n${a.time} • ${typeLabel(a.type)}";textSize=11.5f;setTextColor(accent);gravity=Gravity.CENTER}
                info.addView(dateLine,LinearLayout.LayoutParams(-1,if(closed)dp(34) else dp(52)))
                if(closed){
                    val closedLine=LinearLayout(this@MainActivity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER}
                    closedLine.addView(ImageView(this@MainActivity).apply{setImageDrawable(DialogLineIconDrawable(1,Color.rgb(25,105,205)));scaleType=ImageView.ScaleType.CENTER},LinearLayout.LayoutParams(dp(16),dp(16)).apply{setMargins(0,0,dp(4),0)})
                    closedLine.addView(TextView(this@MainActivity).apply{text="Studio chiuso · non conteggiato";textSize=8.5f;setTextColor(Color.rgb(25,105,175));setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER_VERTICAL})
                    info.addView(closedLine,LinearLayout.LayoutParams(-1,dp(18)))
                }
                row.addView(info,LinearLayout.LayoutParams(dp(142),dp(52)))
                if(closed){ row.background=liquidInteractiveSurface(Color.rgb(224,240,255),16,Color.rgb(174,211,243),1) }
                row.setOnClickListener{appointmentActions(a)}
                target.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(6))})
            }
        }
    }

    private fun openPackageFromSearch(name:String){
        val key=identityKey(name)
        val regular=packs.firstOrNull{it.active&&identityKey(it.name)==key}
        val session=sessionPacks.firstOrNull{it.active&&identityKey(it.name)==key}
        when{
            regular!=null&&session==null -> packageInfoDialog(regular)
            session!=null&&regular==null -> sessionInfoDialog(session)
            regular!=null&&session!=null -> {
                val choices=arrayOf("📦 ${regular.packageType} • 12 settimane","🎯 Pacchetto a sedute personalizzato • ${session.totalSessions} sedute")
                AlertDialog.Builder(this).setTitle(displaySurnameFirst(name)).setItems(choices){_,which->
                    if(which==0) packageInfoDialog(regular) else sessionInfoDialog(session)
                }.setNegativeButton("ANNULLA",null).create().also{styleOneUiDialog(it);it.show()}
            }
            else -> Toast.makeText(this,"Nessun pacchetto attivo per ${displaySurnameFirst(name)}.",Toast.LENGTH_SHORT).show()
        }
    }

    private fun showSearchClientAppointments(name:String){
        val key=identityKey(name)
        val all=appointments.filter{identityKey(it.name)==key}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        val future=all.filter{it.date.isAfter(LocalDate.now())}
        if(future.isEmpty()){
            Toast.makeText(this,"Nessun appuntamento futuro per ${displaySurnameFirst(name)}.",Toast.LENGTH_SHORT).show()
            return
        }
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(4),dp(16),dp(6))}
        box.addView(TextView(this).apply{text="${future.size} appuntamenti futuri";textSize=13f;setTextColor(Color.rgb(100,104,110));setPadding(0,0,0,dp(8))})
        future.forEach{a->
            val accent=typeColor(a.type)
            box.addView(TextView(this).apply{text="${a.date.format(fmt)} • ${a.time} • ${typeLabel(a.type)}";textSize=14.5f;setTextColor(accent);setPadding(0,dp(5),0,dp(5))})
        }
        val dialog=AlertDialog.Builder(this).setTitle(displaySurnameFirst(name)).setView(box).setNegativeButton("CHIUDI",null).setPositiveButton("📋 COPIA PROGRAMMAZIONE"){_,_->copyProgrammingToClipboard(name)}.create()
        styleOneUiDialog(dialog);dialog.show()
    }

    private fun programmingAppointments(name:String, choice:Int):List<Appointment>{
        val today=LocalDate.now()
        val all=appointments.filter{identityKey(it.name)==identityKey(name)&&it.date.isAfter(today)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        return when(choice){
            0 -> all.take(10)
            1 -> all.take(30)
            2 -> {
                val pack=packs.filter{it.active&&identityKey(it.name)==identityKey(name)}.maxByOrNull{it.start}
                val session=sessionPacks.filter{it.active&&identityKey(it.name)==identityKey(name)}.maxByOrNull{it.start}
                when {
                    pack!=null -> all.filter{!it.date.isAfter(pack.start.plusWeeks(12).minusDays(1))&& !it.date.isBefore(pack.start)}
                    session!=null -> all.filter{it.sessionPackId==session.id}
                    else -> all
                }
            }
            else -> all
        }
    }

    private fun programmingText(name:String, choice:Int):String{
        val selected=programmingAppointments(name,choice)
        if(selected.isEmpty()) return "Nessun appuntamento futuro disponibile."
        val title=when(choice){0->"PROSSIMI 10 APPUNTAMENTI";1->"PROSSIMI 30 APPUNTAMENTI";2->"PROGRAMMAZIONE PACCHETTO";else->"PROGRAMMAZIONE ANNUALE"}
        return buildString{
            appendLine("📋 $title")
            appendLine("Cliente: ${displaySurnameFirst(name)}")
            appendLine()
            selected.forEachIndexed{index,a->
                val type=typeLabel(a.type)
                appendLine("${index+1}. ${a.date.format(fmt)} • ${a.time} • $type")
            }
        }
    }

    private fun programmingOptionsDialog(name:String){
        val options=arrayOf("Prossimi 10 appuntamenti","Prossimi 30 appuntamenti","Tutto il pacchetto","Tutta la programmazione annuale")
        val dialog=AlertDialog.Builder(this)
            .setTitle("📋 Copia programmazione")
            .setItems(options){_,which->
                val text=programmingText(name,which)
                if(text.startsWith("Nessun appuntamento")) Toast.makeText(this,text,Toast.LENGTH_SHORT).show()
                else copyProgrammingTextToClipboard(text,name)
            }
            .setNegativeButton("ANNULLA",null)
            .create()
        styleOneUiDialog(dialog);dialog.show()
    }

    private fun copyProgrammingTextToClipboard(text:String,name:String){
        val clipboard=getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Programmazione $name",text))
        val preview=TextView(this).apply{this.text=text;textSize=14f;setTextColor(Color.rgb(35,35,35));setPadding(dp(16),dp(8),dp(16),dp(8))}
        val dialog=AlertDialog.Builder(this).setTitle("📋 Programmazione pronta").setMessage("La programmazione è già stata copiata negli appunti. Puoi incollarla direttamente su WhatsApp.").setView(ScrollView(this).apply{addView(preview)}).setNegativeButton("CHIUDI",null).setPositiveButton("COPIA DI NUOVO"){_,_->clipboard.setPrimaryClip(ClipData.newPlainText("Programmazione $name",text));Toast.makeText(this,"Programmazione copiata.",Toast.LENGTH_SHORT).show()}.create()
        styleOneUiDialog(dialog);dialog.show()
    }

    private fun copyProgrammingToClipboard(name:String){ programmingOptionsDialog(name) }

    private fun renderDashboard(items:List<Pack>,sessionItems:List<SessionPack>){
        val today=LocalDate.now()
        val activeClients=(items.map{identityKey(it.name)}+sessionItems.map{identityKey(it.name)}).distinct().size
        val todayAppointments=appointments.count{it.date==today}
        val toCollect=packs.filter{it.active}.fold(0){acc,p -> acc + (p.total-p.paid).coerceAtLeast(0)} + sessionPacks.filter{it.active}.fold(0){acc,s -> acc + (s.cost-s.paid).coerceAtLeast(0)}
        val stats=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(0,0,0,dp(10))}
        fun stat(value:String,label:String):View=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(6),dp(8),dp(6),dp(8));background=roundedSurface(Color.WHITE,16,Color.rgb(230,232,236),1)
            addView(TextView(this@MainActivity).apply{text=value;textSize=19f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(28,31,35));gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,dp(28)))
            addView(TextView(this@MainActivity).apply{text=label;textSize=10.5f;setTextColor(Color.rgb(105,108,114));gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,dp(22))) }
        stats.addView(stat(activeClients.toString(),"CLIENTI ATTIVI"),LinearLayout.LayoutParams(0,dp(58),1f).apply{setMargins(0,0,dp(4),0)})
        stats.addView(stat(todayAppointments.toString(),"SEDUTE OGGI"),LinearLayout.LayoutParams(0,dp(58),1f).apply{setMargins(dp(2),0,dp(2),0)})
        stats.addView(stat("€$toCollect","DA INCASSARE"),LinearLayout.LayoutParams(0,dp(58),1f).apply{setMargins(dp(4),0,0,0)})
        list.addView(stats)
        val groups=listOf(
            Triple("SCADUTI",Color.rgb(210,45,45),items.filter{statusFor(it,ratesFor(it),dueDates(it)).label=="SCADUTA"}),
            Triple("IN SCADENZA",Color.rgb(220,160,20),items.filter{statusFor(it,ratesFor(it),dueDates(it)).label=="IN SCADENZA"}),
            Triple("IN REGOLA",Color.rgb(35,150,70),items.filter{statusFor(it,ratesFor(it),dueDates(it)).label=="IN REGOLA"})
        )
        val sessionGroups=listOf(
            Triple("SCADUTI",Color.rgb(210,45,45),sessionItems.filter{sessionStatus(it).label in setOf("SCADUTA","DA PAGARE")}),
            Triple("IN SCADENZA",Color.rgb(220,160,20),sessionItems.filter{sessionStatus(it).label=="IN SCADENZA"}),
            Triple("IN REGOLA",Color.rgb(35,150,70),sessionItems.filter{sessionStatus(it).label=="IN REGOLA"})
        )
        groups.indices.forEach{idx->
            val clients=groups[idx].third
            val sessions=sessionGroups[idx].third
            if(clients.isEmpty()&&sessions.isEmpty())return@forEach
            val label=groups[idx].first;val color=groups[idx].second
            val section=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;background=appGlassSurface(Color.WHITE,18,Color.rgb(218,228,239),1)}
            val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;isClickable=true;isFocusable=true;setPadding(dp(12),dp(4),dp(12),dp(4))}
            header.addView(TextView(this).apply{text="●";textSize=18f;setTextColor(color);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(28),dp(48)))
            val totalCount=clients.size+sessions.size
            header.addView(TextView(this).apply{text="$label ($totalCount)";textSize=17f;setTextColor(Color.rgb(35,35,35));gravity=Gravity.CENTER_VERTICAL;setPadding(dp(8),0,0,0)},LinearLayout.LayoutParams(0,dp(48),1f))
            val arrow=TextView(this).apply{text="▾";textSize=20f;setTextColor(Color.DKGRAY);gravity=Gravity.CENTER}
            header.addView(arrow,LinearLayout.LayoutParams(dp(36),dp(48)));section.addView(header)
            val sectionHasExpandedClient = clients.any{expandedClients.contains(identityKey(it.name))} || sessions.any{expandedClients.contains(identityKey(it.name))}
            val clientsBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=if(sectionHasExpandedClient)View.VISIBLE else View.GONE;setPadding(dp(8),0,dp(8),dp(4))}
            clients.forEach{card(it,clientsBox)};sessions.forEach{sessionCard(it,clientsBox)}
            section.addView(clientsBox)
            arrow.text=if(sectionHasExpandedClient)"▴" else "▾"
            header.setOnClickListener{val open=clientsBox.visibility!=View.VISIBLE;clientsBox.visibility=if(open)View.VISIBLE else View.GONE;arrow.text=if(open)"▴" else "▾"}
            list.addView(section,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})
        }
    }

    private fun card(p:Pack,parent:ViewGroup=list){
        val rates=ratesFor(p);val dates=dueDates(p);val status=statusFor(p,rates,dates)
        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(4),dp(10),dp(4));background=appGlassSurface(Color.WHITE,18,Color.rgb(218,228,239),1)}
        val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;isClickable=true;isFocusable=true;setPadding(dp(2),0,0,0)}
        val nameView=TextView(this).apply{text=displaySurnameFirst(p.name);textSize=17.5f;setTextColor(Color.rgb(20,20,20));gravity=Gravity.CENTER_VERTICAL;maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END}
        header.addView(nameView,LinearLayout.LayoutParams(0,dp(48),1f))
        val menu=menuIconButtonStyle().apply{setOnClickListener{packageInfoDialog(p)}}
        header.addView(menu,LinearLayout.LayoutParams(dp(38),dp(40)).apply{setMargins(dp(6),0,dp(6),0)})
        header.addView(TextView(this).apply{text="●";textSize=18f;setTextColor(status.color);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(26),dp(44)))
        card.addView(header)

        val isExpanded=expandedClients.contains(identityKey(p.name))
        val details=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=if(isExpanded)View.VISIBLE else View.GONE;setPadding(dp(2),dp(4),dp(2),dp(2))}
        details.addView(TextView(this).apply{text="${p.packageType} • ${p.sessionTotal} sedute • Partenza: ${p.start.format(fmt)}    Totale: €${p.total}";textSize=14f;setTextColor(Color.DKGRAY);setPadding(0,dp(2),0,dp(8))})
        for(i in rates.indices){
            val isPaid=p.paid>=rates.take(i+1).sum();val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
            val suffix = if(isPaid) " ✓ pagata" else if(i==p.paidRateIndex(rates)) " • parziale €${p.paid-rates.take(i).sum()}" else ""
            row.addView(TextView(this).apply{this.text="Rata ${i+1}: €${rates[i]} • ${dates[i].format(fmt)}$suffix";textSize=15f;setTextColor(Color.rgb(30,30,30));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,dp(48),1f))
            if(!isPaid){
                if(i==p.paidRateIndex(rates)) row.addView(paymentButtonStyle().apply{setOnClickListener{
                    val alreadyPaidOnCurrent=(p.paid-rates.take(i).sum()).coerceAtLeast(0)
                    val remainingToPay=(rates[i]-alreadyPaidOnCurrent).coerceAtLeast(0)
                    if(remainingToPay>0) confirmPaymentDialog(p,i,remainingToPay)
                }},LinearLayout.LayoutParams(dp(72),dp(40)))
                row.addView(editIconButtonStyle().apply{setOnClickListener{paymentOptionsDialog(p,i)}},LinearLayout.LayoutParams(dp(44),dp(40)))
            }
            details.addView(row)
        }
        card.addView(details)
        header.setOnClickListener{val open=details.visibility!=View.VISIBLE;details.visibility=if(open)View.VISIBLE else View.GONE;if(open)expandedClients.add(identityKey(p.name)) else expandedClients.remove(identityKey(p.name))}
        parent.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})
    }

    private fun programmingDetailDialog(s:SessionPack){
        val now=LocalDateTime.now()
        val today=now.toLocalDate()
        val done=sessionsForSessionPack(s,today)
        val doneCount=done.size
        // Include today's appointments that have not reached their exact time yet.
        val future=sessionAppointments(s).filter{!appointmentHasPassed(it,now)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        val futureCount=future.size
        val remaining=(s.totalSessions-sessionUsed(s)).coerceAtLeast(0)
        val text=summaryForSessionPack(s)
        val typeCards=s.customQuantities.entries
            .filter{it.value>0}
            .sortedBy{typeLabel(it.key).uppercase()}
            .map{entry->
                val type=entry.key
                val total=entry.value
                val used=customSessionPackUsed(s,type,now)
                Triple(type,total,used)
            }
        showProgrammingDetail(
            title="Programmazione",
            name=s.name,
            subtitle="Pacchetto a sedute • ${s.totalSessions} sedute",
            stats=listOf("$doneCount" to "EFFETTUATE","$remaining" to "RIMASTE","$futureCount" to "PRENOTATE"),
            typeCards=typeCards,
            sections=buildList{
                add("Sedute effettuate" to done.map{"${it.date.format(fmt)}  •  ${it.time}  •  ${typeLabel(it.type)}"})
                add("Prossimi appuntamenti" to future.map{"${it.date.format(fmt)}  •  ${it.time}  •  ${typeLabel(it.type)}"})
            },
            shareText=text
        )
    }

    private fun programmingDetailDialog(p:Pack){
        val now=LocalDateTime.now()
        val today=now.toLocalDate()
        val end=weeklyPackageEnd(p)
        val done=sessionsForPack(p,today)
        // Include today's appointments that have not reached their exact time yet.
        val future=appointments.filter{identityKey(it.name)==identityKey(p.name)&&!appointmentHasPassed(it,now)&&!it.date.isAfter(end)&&!it.date.isBefore(p.start)&&!isStudioClosed(it.date)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        val scheduled=appointments.count{identityKey(it.name)==identityKey(p.name)&&!it.date.isBefore(p.start)&&!it.date.isAfter(end)&&!isStudioClosed(it.date)}
        val remaining=(p.sessionTotal-scheduled).coerceAtLeast(0)
        val recoveries=recoveriesForPack(p)
        val usedRecoveries=appointments.filter{it.recovery&&identityKey(it.name)==identityKey(p.name)&&!it.date.isBefore(p.start)&&!it.date.isAfter(end)&&!isStudioClosed(it.date)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        val text=summaryForPack(p)
        showProgrammingDetail(
            title="Programmazione",
            name=p.name,
            subtitle="${p.packageType} • ${p.sessionTotal} sedute • 12 settimane",
            stats=listOf("${done.size}" to "EFFETTUATE","$remaining" to "RIMASTE","$recoveries" to "RECUPERI"),
            sections=buildList{
                add("Sedute effettuate" to done.map{"${it.date.format(fmt)}  •  ${it.time}  •  ${typeLabel(it.type)}"})
                add("Recuperi" to buildList{
                    val breakdown=recoveryBreakdownLabel(p)
                    if(recoveries>0) add(if(breakdown.isNotBlank()) "Disponibili: $breakdown" else "$recoveries recuperi disponibili")
                    if(usedRecoveries.isNotEmpty()) addAll(usedRecoveries.map{"${it.date.format(fmt)}  •  ${it.time}  •  RECUPERO • ${typeLabel(it.type)}"})
                    if(isEmpty()) add("Nessun recupero disponibile")
                })
                add("Prossimi appuntamenti" to future.map{"${it.date.format(fmt)}  •  ${it.time}  •  ${typeLabel(it.type)}"})
            },
            shareText=text
        )
    }

    private fun showProgrammingDetail(title:String,name:String,subtitle:String,stats:List<Pair<String,String>>,typeCards:List<Triple<String,Int,Int>> = emptyList(),sections:List<Pair<String,List<String>>>,shareText:String){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),0,dp(14),dp(10))}
        val scroll=ScrollView(this).apply{isFillViewport=true;addView(root)}
        val head=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(14),dp(12),dp(14),dp(10));background=roundedSurface(Color.rgb(247,249,252),20,Color.rgb(228,232,238),1)}
        val initials=displaySurnameFirst(name).split(" ").filter{it.isNotBlank()}.take(2).joinToString(""){it.first().uppercase()}
        head.addView(TextView(this).apply{text=initials;textSize=18f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(20,70,130));background=roundedSurface(Color.rgb(230,240,252),28)},LinearLayout.LayoutParams(dp(54),dp(54)))
        head.addView(TextView(this).apply{text=displaySurnameFirst(name);textSize=20f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(25,28,32));setPadding(0,dp(7),0,0)},LinearLayout.LayoutParams(-1,dp(34)))
        head.addView(TextView(this).apply{text=subtitle;textSize=13f;gravity=Gravity.CENTER;setTextColor(Color.rgb(85,90,98))},LinearLayout.LayoutParams(-1,dp(24)))
        root.addView(head,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(8),0,dp(10))})

        val statRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        stats.forEachIndexed{index,(value,label)->
            val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(3),dp(8),dp(3),dp(8));background=roundedSurface(Color.WHITE,16,Color.rgb(230,233,238),1)}
            card.addView(TextView(this).apply{text=value;textSize=17f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(25,30,38))},LinearLayout.LayoutParams(-1,dp(27)))
            card.addView(TextView(this).apply{text=label;textSize=9.5f;gravity=Gravity.CENTER;setTextColor(Color.rgb(85,90,98));maxLines=2},LinearLayout.LayoutParams(-1,dp(30)))
            statRow.addView(card,LinearLayout.LayoutParams(0,dp(74),1f).apply{setMargins(if(index==0)0 else dp(2),0,if(index==stats.lastIndex)0 else dp(2),0)})
        }
        root.addView(statRow)

        if(typeCards.isNotEmpty()){
            root.addView(TextView(this).apply{text="Sedute per tipologia";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32));setPadding(dp(2),dp(10),dp(2),dp(4))},LinearLayout.LayoutParams(-1,dp(38)))
            typeCards.forEach{(type,total,used)->
                val remainingByType=(total-used).coerceAtLeast(0)
                val color=appointmentTypes.getOrNull(typeIndex(type))?.color ?: Color.rgb(45,105,170)
                val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(9),dp(14),dp(9));background=roundedSurface(Color.WHITE,18,Color.rgb(230,233,238),1)}
                val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                top.addView(TextView(this).apply{text="●";textSize=18f;setTextColor(color);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(28),dp(30)))
                top.addView(TextView(this).apply{text=typeLabel(type);textSize=15f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,dp(30),1f))
                card.addView(top)
                val mini=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(28),dp(2),0,0)}
                fun miniStat(value:String,label:String):LinearLayout=LinearLayout(this@MainActivity).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL;addView(TextView(this@MainActivity).apply{text=value;textSize=13.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,40,48))},LinearLayout.LayoutParams(-1,dp(21)));addView(TextView(this@MainActivity).apply{text=label;textSize=9.5f;setTextColor(Color.rgb(90,96,105))},LinearLayout.LayoutParams(-1,dp(18)))}
                mini.addView(miniStat(total.toString(),"TOTALI"),LinearLayout.LayoutParams(0,dp(40),1f))
                mini.addView(miniStat(used.toString(),"EFFETTUATE"),LinearLayout.LayoutParams(0,dp(40),1f))
                mini.addView(miniStat(remainingByType.toString(),"RIMASTE"),LinearLayout.LayoutParams(0,dp(40),1f))
                card.addView(mini)
                root.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(4),0,dp(4))})
            }
        }

        sections.forEach{(heading,items)->
            val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(10),dp(14),dp(10));background=roundedSurface(Color.WHITE,18,Color.rgb(230,233,238),1)}
            card.addView(TextView(this).apply{text=heading;textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32))},LinearLayout.LayoutParams(-1,dp(30)))
            if(items.isEmpty()) card.addView(TextView(this).apply{text="Nessuna informazione";textSize=13f;setTextColor(Color.rgb(100,104,110));setPadding(0,dp(3),0,dp(3))})
            else items.forEach{item->card.addView(TextView(this).apply{text=item;textSize=13f;setTextColor(Color.rgb(55,59,65));setPadding(0,dp(4),0,dp(4))})}
            root.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(8),0,0)})
        }
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(10),0,dp(2))}
        fun shareAction(icon:Drawable,label:String,textColor:Int,bgColor:Int,strokeColor:Int,onClick:()->Unit):View = LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;setPadding(dp(12),0,dp(12),0);isClickable=true
            background=liquidInteractiveSurface(bgColor,16,strokeColor,1);applyLiquidControlDepth(this)
            addView(ImageView(this@MainActivity).apply{setImageDrawable(icon);scaleType=ImageView.ScaleType.CENTER},LinearLayout.LayoutParams(dp(22),dp(22)).apply{setMargins(0,0,dp(7),0)})
            addView(TextView(this@MainActivity).apply{text=label;textSize=12f;setTextColor(textColor);setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(-2,-1))
            setOnClickListener{onClick()}
        }
        val copy=shareAction(DialogLineIconDrawable(4,Color.rgb(25,105,195)),"Copia testo",Color.rgb(15,95,180),Color.rgb(224,241,255),Color.rgb(178,211,241)){val cb=getSystemService(CLIPBOARD_SERVICE) as ClipboardManager;cb.setPrimaryClip(ClipData.newPlainText("Programmazione $name",shareText));Toast.makeText(this@MainActivity,"Testo copiato. Puoi incollarlo su WhatsApp.",Toast.LENGTH_SHORT).show()}
        val wa=shareAction(WhatsAppIconDrawable(Color.rgb(24,155,95)),"WhatsApp",Color.rgb(20,145,92),Color.rgb(218,247,232),Color.rgb(171,222,193)){val intent=Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,shareText)};try{intent.setPackage("com.whatsapp");startActivity(intent)}catch(_:Exception){startActivity(Intent.createChooser(intent,"Invia programmazione"))}}
        actions.addView(copy,LinearLayout.LayoutParams(0,dp(46),1f).apply{setMargins(0,0,dp(4),0)})
        actions.addView(wa,LinearLayout.LayoutParams(0,dp(46),1f).apply{setMargins(dp(4),0,0,0)})
        root.addView(actions)
        lateinit var dialog:AlertDialog
        val back=Button(this).apply{text="‹  Indietro";setAllCaps(false);textSize=12f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(Color.rgb(15,95,180));background=liquidInteractiveSurface(Color.rgb(238,246,255),16,Color.rgb(190,218,248),1);applyLiquidControlDepth(this);setOnClickListener{dialog.dismiss()}}
        root.addView(back,LinearLayout.LayoutParams(-1,dp(46)).apply{setMargins(0,dp(10),0,dp(2))})
        val dialogHeader=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),dp(2),dp(10),dp(2))}
        val topBack=TextView(this).apply{text="‹";textSize=32f;gravity=Gravity.CENTER;setTextColor(Color.rgb(25,95,175));setPadding(0,0,0,dp(3));setOnClickListener{dialog.dismiss()}}
        dialogHeader.addView(topBack,LinearLayout.LayoutParams(dp(44),dp(48)))
        dialogHeader.addView(TextView(this).apply{text=title;textSize=20f;setTypeface(null,android.graphics.Typeface.NORMAL);gravity=Gravity.CENTER;setTextColor(Color.rgb(25,28,32))},LinearLayout.LayoutParams(0,dp(48),1f))
        dialogHeader.addView(Space(this),LinearLayout.LayoutParams(dp(44),dp(48)))
        dialog=AlertDialog.Builder(this).setCustomTitle(dialogHeader).setView(scroll).create()
        styleModernCoachDialog(dialog)
        dialog.show()
    }

    private fun packageInfoDialog(p:Pack){
        val rates=ratesFor(p)
        val dates=dueDates(p)
        val status=statusFor(p,rates,dates)
        val expected=p.sessionTotal
        val done=sessionsForPack(p,LocalDate.now()).size
        val recoveries=recoveriesForPack(p)
        val scheduled=appointments.count {
            identityKey(it.name)==identityKey(p.name) &&
            !it.date.isBefore(p.start) && !it.date.isAfter(weeklyPackageEnd(p)) &&
            !isStudioClosed(it.date)
        }
        val remaining=(expected-scheduled).coerceAtLeast(0)

        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),0,dp(14),dp(10))}
        val scroll=ScrollView(this).apply{isFillViewport=true;addView(root)}

        val client=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(10),dp(8),dp(10));background=roundedSurface(Color.rgb(247,249,252),20,Color.rgb(228,232,238),1)}
        val initials=displaySurnameFirst(p.name).split(" ").filter{it.isNotBlank()}.take(2).joinToString(""){it.first().uppercase()}
        client.addView(TextView(this).apply{text=initials;textSize=18f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(20,70,130));background=roundedSurface(Color.rgb(230,240,252),28);},LinearLayout.LayoutParams(dp(52),dp(52)))
        val clientText=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
        clientText.addView(TextView(this@MainActivity).apply{text=displaySurnameFirst(p.name);textSize=18f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32))})
        clientText.addView(TextView(this@MainActivity).apply{text="●  ${status.label}";textSize=13f;setTextColor(status.color);setPadding(0,dp(3),0,0)})
        client.addView(clientText,LinearLayout.LayoutParams(0,-2,1f))
        root.addView(client,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(8),0,dp(10))})
        addClientLinkSection(root,p.name,{p.clientId},{id->p.clientId=id;saveData()},
            {activePackageDialog?.dismiss()},{packageInfoDialog(p)})

        val stats=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        fun stat(value:String,label:String):View=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(4),dp(7),dp(4),dp(7));background=roundedSurface(Color.WHITE,16,Color.rgb(230,233,238),1)
            addView(TextView(this@MainActivity).apply{text=value;textSize=17f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,30,38));gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,dp(27)))
            addView(TextView(this@MainActivity).apply{text=label;textSize=9.5f;setTextColor(Color.rgb(85,90,98));gravity=Gravity.CENTER;maxLines=2},LinearLayout.LayoutParams(-1,dp(30))) }
        stats.addView(stat("$expected","SEDUTE TOTALI"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(0,0,dp(4),0)})
        stats.addView(stat("$remaining","SEDUTE RIMASTE"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(dp(2),0,dp(2),0)})
        stats.addView(stat("$recoveries","RECUPERI"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(dp(2),0,dp(2),0)})
        stats.addView(stat("€${p.total}","TOTALE PACCHETTO"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(dp(4),0,0,0)})
        root.addView(stats)

        val info=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(8),dp(14),dp(8));background=roundedSurface(Color.WHITE,18,Color.rgb(230,233,238),1)}
        fun infoRow(label:String,value:String){val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(7),0,dp(7))};r.addView(TextView(this@MainActivity).apply{text=label;textSize=13f;setTextColor(Color.rgb(85,90,98))},LinearLayout.LayoutParams(0,dp(34),1f));r.addView(TextView(this@MainActivity).apply{text=value;textSize=13.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,40,48));gravity=Gravity.CENTER_VERTICAL});info.addView(r)}
        infoRow("Tipo pacchetto",p.packageType.replace("PERSONALIZZATO","Personalizzato"))
        infoRow("Data di inizio",p.start.format(fmt))
        infoRow("Importo totale","€${p.total}")
        infoRow("Pagato","€${p.paid}")
        infoRow("Stato","${status.label}")
        root.addView(info,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(10),0,dp(14))})

        val rateTitle=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        rateTitle.addView(TextView(this).apply{text="Rate di pagamento";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32))},LinearLayout.LayoutParams(0,dp(42),1f))
        root.addView(rateTitle)
        for(i in rates.indices){
            val isPaid=p.paid>=rates.take(i+1).sum()
            val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),dp(5),dp(6),dp(5));background=roundedSurface(Color.WHITE,16,Color.rgb(230,233,238),1)}
            r.addView(TextView(this).apply{text="${i+1}";textSize=13f;gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);background=roundedSurface(Color.rgb(242,245,249),22);setTextColor(Color.rgb(40,45,52))},LinearLayout.LayoutParams(dp(34),dp(40)))
            r.addView(TextView(this).apply{this.text="€${rates[i]}\n${dates[i].format(fmt)}${if(isPaid)" • ✓ Pagata" else ""}";textSize=13.5f;setTextColor(Color.rgb(35,40,48));setPadding(dp(10),0,0,0)},LinearLayout.LayoutParams(0,dp(52),1f))
            if(!isPaid&&i==p.paidRateIndex(rates)) r.addView(paymentButtonStyle().apply{setOnClickListener{val already=(p.paid-rates.take(i).sum()).coerceAtLeast(0);val amount=(rates[i]-already).coerceAtLeast(0);if(amount>0) confirmPaymentDialog(p,i,amount)}},LinearLayout.LayoutParams(dp(68),dp(40)))
            r.addView(editIconButtonStyle().apply{setOnClickListener{paymentOptionsDialog(p,i)}},LinearLayout.LayoutParams(dp(40),dp(40)).apply{setMargins(dp(5),0,0,0)})
            root.addView(r,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(4),0,dp(4))})
        }

        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(12),0,dp(4))}
        fun actionButton(label:String,accent:Int,bg:Int,click:()->Unit)=Button(this).apply{text=label;setAllCaps(false);textSize=11.5f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(accent);background=liquidInteractiveSurface(bg,18,Color.rgb(205,220,238),1);applyLiquidControlDepth(this);setOnClickListener{click()}}
        actions.addView(actionButton("✓ Segna tutto pagato",Color.rgb(15,95,180),Color.rgb(238,246,255)){
            val remainingToPay=(p.total-p.paid).coerceAtLeast(0)
            if(remainingToPay<=0){
                Toast.makeText(this@MainActivity,"Tutte le rate risultano già pagate.",Toast.LENGTH_SHORT).show()
                return@actionButton
            }
            val (paymentDialog,outer,body)=packActionDialogBase("Conferma pagamento","✓",Color.rgb(0,145,112),Color.rgb(205,244,233),Color.rgb(248,255,252))
            body.addView(dialogBodyText("Vuoi segnare come pagate tutte le rate del pacchetto?"))
            body.addView(dialogInfoCard("≋","Importo ancora da pagare","€$remainingToPay",Color.rgb(0,145,112),Color.rgb(224,248,241)),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,dp(10))})
            body.addView(LinearLayout(this@MainActivity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),dp(9),dp(10),dp(9));background=roundedSurface(Color.rgb(224,248,241),18)
                addView(TextView(this@MainActivity).apply{text="i";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(0,145,112));background=roundedSurface(Color.WHITE,24)},LinearLayout.LayoutParams(dp(34),dp(34)))
                addView(TextView(this@MainActivity).apply{text="Tutte le rate del pacchetto verranno segnate come pagate.";textSize=13.5f;setTextColor(Color.rgb(45,70,65));setPadding(dp(10),0,0,0)},LinearLayout.LayoutParams(0,dp(34),1f))
            },LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(14))})
            val row=LinearLayout(this@MainActivity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            row.addView(dialogButton("Annulla",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(210,220,232)){paymentDialog.dismiss()},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(4),0)})
            row.addView(dialogButton("Conferma",Color.WHITE,Color.rgb(0,145,112),Color.rgb(0,145,112)){
                p.paid=p.total;saveData();paymentDialog.dismiss();activePackageDialog?.dismiss();activePackageDialog=null;render();packageInfoDialog(p);Toast.makeText(this@MainActivity,"Tutte le rate sono state segnate come pagate.",Toast.LENGTH_SHORT).show()
            },LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(4),0,0,0)})
            body.addView(row)
            paymentDialog.show()
            paymentDialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
        },LinearLayout.LayoutParams(0,dp(46),1f).apply{setMargins(0,0,dp(4),0)})
        actions.addView(actionButton("✎ Modifica",Color.rgb(20,91,165),Color.rgb(238,246,255)){editPackDialog(p)},LinearLayout.LayoutParams(0,dp(46),0.7f).apply{setMargins(dp(2),0,dp(2),0)})
        actions.addView(actionButton("⏹ Termina",Color.rgb(120,80,25),Color.rgb(255,248,232)){terminatePackDialog(p)},LinearLayout.LayoutParams(0,dp(46),0.7f).apply{setMargins(dp(2),0,dp(2),0)})
        actions.addView(actionButton("🗑 Elimina",Color.rgb(200,45,45),Color.rgb(255,244,244)){confirmDeletePack(p)},LinearLayout.LayoutParams(0,dp(46),0.7f).apply{setMargins(dp(4),0,0,0)})
        root.addView(actions)
        root.addView(Button(this).apply{text="🗂 Storico cliente";setAllCaps(false);textSize=13f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(Color.rgb(15,95,180));background=liquidInteractiveSurface(Color.rgb(238,246,255),18,Color.rgb(205,220,238),1);applyLiquidControlDepth(this);setOnClickListener{showClientHistory(p.name)}},LinearLayout.LayoutParams(-1,dp(44)).apply{setMargins(0,dp(4),0,dp(2))})
        val programming=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(10),dp(8),dp(10));background=roundedSurface(Color.rgb(238,246,255),20,Color.rgb(190,218,248),1);isClickable=true;isFocusable=true}
        val programIcon=ImageView(this).apply{setImageDrawable(calendarIconDrawable(Color.rgb(45,105,170)));setPadding(dp(10),dp(10),dp(10),dp(10));background=roundedSurface(Color.WHITE,18,Color.rgb(205,224,246),1)}
        programming.addView(programIcon,LinearLayout.LayoutParams(dp(44),dp(44)))
        val programBody=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),0,dp(3),0)}
        programBody.addView(TextView(this).apply{text="Programmazione";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32));setSingleLine(true)},LinearLayout.LayoutParams(-1,dp(24)))
        val programStats=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        fun programStat(value:String,label:String)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL;addView(TextView(this@MainActivity).apply{text=value;textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,75,125));setSingleLine(true)},LinearLayout.LayoutParams(-1,dp(19)));addView(TextView(this@MainActivity).apply{text=label;textSize=8.5f;setTextColor(Color.rgb(85,98,115));setSingleLine(true)},LinearLayout.LayoutParams(-1,dp(16)))}
        programStats.addView(programStat("$scheduled","TOTALI"),LinearLayout.LayoutParams(0,dp(35),1f))
        programStats.addView(programStat("$done","EFFETTUATI"),LinearLayout.LayoutParams(0,dp(35),1f))
        programStats.addView(programStat("$remaining","DISPONIBILI"),LinearLayout.LayoutParams(0,dp(35),1f))
        programBody.addView(programStats,LinearLayout.LayoutParams(-1,dp(35)))
        programming.addView(programBody,LinearLayout.LayoutParams(0,dp(59),1f))
        programming.addView(TextView(this).apply{text="›";textSize=28f;gravity=Gravity.CENTER;setTextColor(Color.rgb(15,95,180))},LinearLayout.LayoutParams(dp(28),dp(52)))
        programming.setOnClickListener{programmingDetailDialog(p)}
        root.addView(programming,LinearLayout.LayoutParams(-1,dp(76)).apply{setMargins(0,dp(8),0,dp(4))})

        activePackageDialog?.dismiss()
        lateinit var packageDialog:AlertDialog
        val dialogHeader=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;setPadding(dp(10),dp(2),dp(10),dp(2))}
        dialogHeader.addView(TextView(this).apply{text="Gestione pacchetto";textSize=20f;setTypeface(null,android.graphics.Typeface.NORMAL);gravity=Gravity.CENTER;setTextColor(Color.rgb(25,28,32));setSingleLine(true)},LinearLayout.LayoutParams(-1,dp(46)))
        val backBottom=Button(this).apply{text="‹  Indietro";setAllCaps(false);textSize=12f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(Color.rgb(15,95,180));background=liquidInteractiveSurface(Color.rgb(238,246,255),16,Color.rgb(190,218,248),1);applyLiquidControlDepth(this)}
        root.addView(backBottom,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(10),0,dp(2))})
        val dialog=AlertDialog.Builder(this).setCustomTitle(dialogHeader).setView(scroll).create()
        packageDialog=dialog
        backBottom.setOnClickListener{packageDialog.dismiss()}
        activePackageDialog=dialog
        styleOneUiDialog(dialog)
        dialog.setOnDismissListener{removePopupBackdropDialog(dialog);if(activePackageDialog===dialog) activePackageDialog=null}
        dialog.show()
    }

    private fun appointmentHasPassed(a:Appointment,now:LocalDateTime=LocalDateTime.now()):Boolean{
        val t=runCatching{LocalTime.parse(a.time,timeFmt)}.getOrNull()?:LocalTime.MIDNIGHT
        return LocalDateTime.of(a.date,t).isBefore(now)
    }

    private fun sessionAppointments(s:SessionPack):List<Appointment>{
        val key=identityKey(s.name)
        return appointments.filter{
            (it.sessionPackId==s.id || (it.sessionPackId==0L && identityKey(it.name)==key)) &&
            !it.date.isBefore(s.start) &&
            !isStudioClosed(it.date)
        }.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
    }

    private fun sessionBooked(s:SessionPack):Int=sessionAppointments(s).size
    private fun sessionUsed(s:SessionPack,now:LocalDateTime=LocalDateTime.now()):Int=sessionAppointments(s).count{appointmentHasPassed(it,now)}
    private fun sessionStatus(s:SessionPack):PackStatus{
        val used=sessionUsed(s)
        val remaining=(s.totalSessions-used).coerceAtLeast(0)
        return when{
            used>=s.totalSessions->PackStatus("SCADUTA",Color.rgb(210,45,45))
            s.paid<s.cost->PackStatus("DA PAGARE",Color.rgb(210,45,45))
            remaining==1->PackStatus("IN SCADENZA",Color.rgb(220,160,20))
            else->PackStatus("IN REGOLA",Color.rgb(35,150,70))
        }
    }
    private fun activeSessionPackFor(name:String):SessionPack?=sessionPacks.filter{it.active&&identityKey(it.name)==identityKey(name)}.maxByOrNull{it.start}

    private fun sessionCard(s:SessionPack,parent:ViewGroup=list){
        val used=sessionUsed(s);val booked=sessionBooked(s);val remaining=(s.totalSessions-used).coerceAtLeast(0);val status=sessionStatus(s)
        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(4),dp(10),dp(4));background=appGlassSurface(Color.WHITE,18,Color.rgb(218,228,239),1)}
        val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;isClickable=true;isFocusable=true;setPadding(dp(2),0,0,0)}
        val name=TextView(this).apply{text=displaySurnameFirst(s.name);textSize=17.5f;setTextColor(Color.rgb(20,20,20));gravity=Gravity.CENTER_VERTICAL;maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END}
        header.addView(name,LinearLayout.LayoutParams(0,dp(48),1f))
        header.addView(TextView(this).apply{text="$remaining rimaste";textSize=13f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(status.color);gravity=Gravity.CENTER_VERTICAL;maxLines=1},LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,dp(44)))
        val menu=menuIconButtonStyle().apply{setOnClickListener{sessionInfoDialog(s)}}
        header.addView(menu,LinearLayout.LayoutParams(dp(38),dp(40)).apply{setMargins(dp(6),0,dp(6),0)})
        header.addView(TextView(this).apply{text="●";textSize=18f;setTextColor(status.color);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(26),dp(44)))
        card.addView(header)

        val details=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE;setPadding(dp(4),dp(4),0,dp(2))}
        details.addView(TextView(this).apply{text="Pacchetto a sedute personalizzato • €${s.cost} • $used effettuate • $booked prenotate";textSize=14f;setTextColor(Color.rgb(75,78,84));setPadding(0,0,0,dp(6))})
        val ordered=sessionAppointments(s)
        val visibleAppointments=ordered.take(6)
        if(visibleAppointments.isNotEmpty()){
            val appointmentBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(8),dp(4),dp(8),dp(4));background=roundedSurface(Color.rgb(247,249,252),14,Color.rgb(228,232,238),1)}
            visibleAppointments.forEachIndexed{idx,a->
                val beyond=idx>=s.totalSessions
                appointmentBox.addView(TextView(this).apply{text="${idx+1}. ${a.date.format(fmt)} • ${a.time} • ${typeLabel(a.type)}${if(beyond)"  ⚠ fuori pacchetto" else ""}";textSize=12.5f;setTextColor(if(beyond)Color.rgb(205,45,55) else Color.rgb(55,62,70));setPadding(0,dp(3),0,dp(3))})
            }
            if(ordered.size>visibleAppointments.size)appointmentBox.addView(TextView(this).apply{text="+ ${ordered.size-visibleAppointments.size} altri appuntamenti";textSize=12f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(20,91,165));setPadding(0,dp(5),0,dp(2))})
            details.addView(appointmentBox,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(6))})
        }
        details.addView(TextView(this).apply{
            text="ALTRE INFORMAZIONI"
            textSize=12.5f
            setTypeface(null,android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(20,91,165))
            gravity=Gravity.CENTER
            isClickable=true
            isFocusable=true
            background=roundedSurface(Color.rgb(238,246,255),16,Color.rgb(190,218,248),1)
            setOnClickListener{sessionOptionsDialog(s)}
        },LinearLayout.LayoutParams(-1,dp(40)).apply{setMargins(0,dp(2),0,dp(2))})
        card.addView(details)
        header.setOnClickListener{val open=details.visibility!=View.VISIBLE;details.visibility=if(open)View.VISIBLE else View.GONE;if(open)expandedClients.add(identityKey(s.name)) else expandedClients.remove(identityKey(s.name))}
        parent.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})
    }

    private fun showHomeSortDialog(){
        val (dialog,outer,body)=packActionDialogBase("Ordina clienti","☷",Color.rgb(20,91,165),Color.rgb(224,238,255),Color.WHITE)
        val labels=arrayOf("Stato","Nome A-Z","Nome Z-A")
        val icons=arrayOf("☷","A↕Z","Z↕A")
        labels.forEachIndexed{index,label->
            val option=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),0,dp(12),0);background=roundedSurface(if(homeSortMode==index)Color.rgb(238,246,255) else Color.WHITE,18,if(homeSortMode==index)Color.rgb(190,218,248) else Color.rgb(228,232,238),1);isClickable=true}
            option.addView(TextView(this).apply{text=icons[index];textSize=20f;gravity=Gravity.CENTER;setTextColor(Color.rgb(20,91,165))},LinearLayout.LayoutParams(dp(42),dp(48)))
            option.addView(TextView(this).apply{text=label;textSize=15.5f;setTypeface(null,if(homeSortMode==index)android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL);setTextColor(Color.rgb(30,38,50));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,dp(48),1f))
            option.addView(TextView(this).apply{text=if(homeSortMode==index)"●" else "○";textSize=22f;gravity=Gravity.CENTER;setTextColor(if(homeSortMode==index)Color.rgb(25,105,210) else Color.rgb(125,132,142))},LinearLayout.LayoutParams(dp(34),dp(48)))
            option.setOnClickListener{homeSortMode=index;dialog.dismiss();render()}
            body.addView(option,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,if(index==0)0 else dp(7),0,0)})
        }
        body.addView(dialogButton("✓  Applica",Color.rgb(30,83,145),Color.rgb(235,244,255),Color.rgb(205,224,248)){dialog.dismiss();render()},LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(14),0,0)})
        dialog.show()
    }

    private fun sessionInfoDialog(s:SessionPack){
        lateinit var dialog: AlertDialog
        val now=LocalDateTime.now()
        val used=sessionUsed(s,now)
        val booked=sessionBooked(s)
        val remaining=(s.totalSessions-booked).coerceAtLeast(0)
        val status=sessionStatus(s)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),0,dp(16),dp(10))}
        val scroll=ScrollView(this).apply{isFillViewport=true;addView(root)}

        val client=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(14),dp(14),dp(14),dp(12));background=roundedSurface(Color.rgb(247,249,252),20,Color.rgb(228,232,238),1)}
        val initials=displaySurnameFirst(s.name).split(" ").filter{it.isNotBlank()}.take(2).joinToString(""){it.first().uppercase()}
        client.addView(TextView(this).apply{text=initials;textSize=19f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(20,70,130));background=roundedSurface(Color.rgb(230,240,252),30)},LinearLayout.LayoutParams(dp(58),dp(58)))
        client.addView(TextView(this).apply{text=displaySurnameFirst(s.name);textSize=21f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32));gravity=Gravity.CENTER;setPadding(0,dp(8),0,0)},LinearLayout.LayoutParams(-1,dp(36)))
        client.addView(TextView(this).apply{text="●  ${status.label}";textSize=13.5f;setTextColor(status.color);gravity=Gravity.CENTER;setPadding(0,dp(2),0,0)},LinearLayout.LayoutParams(-1,dp(24)))
        root.addView(client,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(8),0,dp(12))})
        addClientLinkSection(root,s.name,{s.clientId},{id->s.clientId=id;saveData()},
            {dialog.dismiss()},{sessionInfoDialog(s)})

        val stats=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        fun stat(value:String,label:String):View=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(3),dp(8),dp(3),dp(8));background=roundedSurface(Color.WHITE,16,Color.rgb(230,233,238),1)
            addView(TextView(this@MainActivity).apply{text=value;textSize=17f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,30,38));gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,dp(27)))
            addView(TextView(this@MainActivity).apply{text=label;textSize=9.5f;setTextColor(Color.rgb(85,90,98));gravity=Gravity.CENTER;maxLines=2},LinearLayout.LayoutParams(-1,dp(30)))}
        stats.addView(stat("${s.totalSessions}","SEDUTE TOTALI"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(0,0,dp(4),0)})
        stats.addView(stat("$remaining","SEDUTE RIMASTE"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(dp(2),0,dp(2),0)})
        stats.addView(stat("$used","EFFETTUATE"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(dp(2),0,dp(2),0)})
        stats.addView(stat("€${s.cost}","TOTALE PACCHETTO"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(dp(4),0,0,0)})
        root.addView(stats)

        val info=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(10),dp(16),dp(10));background=roundedSurface(Color.WHITE,20,Color.rgb(224,229,236),1)}
        fun infoRow(label:String,value:String){val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(7),0,dp(7))};r.addView(TextView(this@MainActivity).apply{text=label;textSize=13f;setTextColor(Color.rgb(85,90,98))},LinearLayout.LayoutParams(0,dp(34),1f));r.addView(TextView(this@MainActivity).apply{text=value;textSize=13.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,40,48));gravity=Gravity.CENTER_VERTICAL}) ;info.addView(r)}
        infoRow("Tipo pacchetto","PACCHETTO A SEDUTE")
        infoRow("Data di inizio",s.start.format(fmt))
        infoRow("Numero sedute","${s.totalSessions}")
        if(s.customQuantities.isNotEmpty()) infoRow("Tipologie incluse",customSessionPackInfo(s))
        infoRow("Importo totale","€${s.cost}")
        infoRow("Pagamento",if(s.paid>=s.cost)"Saldato per intero" else "Da pagare • €${s.cost-s.paid}")
        infoRow("Stato",status.label)
        root.addView(info,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(12),0,dp(14))})

        val rates=sessionRatesFor(s)
        val paymentBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        rates.forEachIndexed{index,due->
            val paidBefore=rates.take(index).sum()
            val alreadyOnRate=(s.paid-paidBefore).coerceAtLeast(0)
            val isPaid=s.paid>=rates.take(index+1).sum()
            val remainingOnRate=(due-alreadyOnRate).coerceAtLeast(0)
            val date=s.start.plusDays((28L*index))
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),dp(8),dp(8),dp(8));background=roundedSurface(Color.WHITE,20,Color.rgb(226,231,238),1)}
            row.addView(TextView(this).apply{text=if(isPaid)"✓" else "€";textSize=18f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(if(isPaid)Color.rgb(20,150,95) else Color.rgb(210,45,45));background=roundedSurface(if(isPaid)Color.rgb(232,248,240) else Color.rgb(255,240,240),23)},LinearLayout.LayoutParams(dp(46),dp(46)))
            val details=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),0,dp(5),0)}
            val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            top.addView(TextView(this).apply{text="Rata ${index+1}/${rates.size}";textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,40,48));gravity=Gravity.CENTER_VERTICAL;setSingleLine(true)},LinearLayout.LayoutParams(0,dp(24),1f))
            top.addView(TextView(this).apply{text="€$due";textSize=14.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,40,48));gravity=Gravity.CENTER_VERTICAL;setSingleLine(true)},LinearLayout.LayoutParams(dp(58),dp(24)))
            details.addView(top)
            details.addView(TextView(this).apply{text="${date.format(fmt)}  •  ${if(isPaid)"Pagata" else if(alreadyOnRate>0)"Parziale • €$alreadyOnRate pagati" else "Da pagare • €$remainingOnRate"}";textSize=11.5f;setTextColor(if(isPaid)Color.rgb(20,125,85) else Color.rgb(92,98,108));gravity=Gravity.CENTER_VERTICAL;setSingleLine(true)},LinearLayout.LayoutParams(-1,dp(25)))
            row.addView(details,LinearLayout.LayoutParams(0,dp(54),1f))
            if(!isPaid && index==s.paidRateIndex(rates)){
                row.addView(paymentButtonStyle().apply{setOnClickListener{confirmSessionPaymentDialog(s,index,remainingOnRate,dialog)}},LinearLayout.LayoutParams(dp(68),dp(40)))
                row.addView(editIconButtonStyle().apply{setOnClickListener{sessionPaymentAmountDialog(s,index)}},LinearLayout.LayoutParams(dp(40),dp(40)).apply{setMargins(dp(4),0,0,0)})
            } else if(!isPaid){
                row.addView(TextView(this).apply{text=""},LinearLayout.LayoutParams(dp(112),dp(40)))
            }
            paymentBox.addView(row,LinearLayout.LayoutParams(-1,dp(70)).apply{setMargins(0,0,0,dp(7))})
        }
        root.addView(TextView(this).apply{text="💳  Pagamento";textSize=17f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,35,48));setPadding(dp(2),0,0,0)},LinearLayout.LayoutParams(-1,dp(38)).apply{setMargins(0,dp(2),0,dp(2))})
        root.addView(paymentBox,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})

        val programming=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(10),dp(8),dp(10));background=roundedSurface(Color.rgb(238,246,255),20,Color.rgb(190,218,248),1);isClickable=true;isFocusable=true}
        val programIcon=ImageView(this).apply{setImageDrawable(calendarIconDrawable(Color.rgb(45,105,170)));setPadding(dp(10),dp(10),dp(10),dp(10));background=roundedSurface(Color.WHITE,18,Color.rgb(205,224,246),1)}
        programming.addView(programIcon,LinearLayout.LayoutParams(dp(44),dp(44)))
        val programBody=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),0,dp(3),0)}
        programBody.addView(TextView(this).apply{text="Programmazione";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32));setSingleLine(true)},LinearLayout.LayoutParams(-1,dp(24)))
        val programStats=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        fun programStat(value:String,label:String)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL;addView(TextView(this@MainActivity).apply{text=value;textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,75,125));setSingleLine(true)},LinearLayout.LayoutParams(-1,dp(19)));addView(TextView(this@MainActivity).apply{text=label;textSize=8.5f;setTextColor(Color.rgb(85,98,115));setSingleLine(true)},LinearLayout.LayoutParams(-1,dp(16)))}
        programStats.addView(programStat("$booked","TOTALI"),LinearLayout.LayoutParams(0,dp(35),1f))
        programStats.addView(programStat("$used","EFFETTUATI"),LinearLayout.LayoutParams(0,dp(35),1f))
        programStats.addView(programStat("$remaining","DISPONIBILI"),LinearLayout.LayoutParams(0,dp(35),1f))
        programBody.addView(programStats,LinearLayout.LayoutParams(-1,dp(35)))
        programming.addView(programBody,LinearLayout.LayoutParams(0,dp(59),1f))
        programming.addView(TextView(this).apply{text="›";textSize=28f;gravity=Gravity.CENTER;setTextColor(Color.rgb(15,95,180))},LinearLayout.LayoutParams(dp(28),dp(52)))
        programming.setOnClickListener{programmingDetailDialog(s)}
        root.addView(programming,LinearLayout.LayoutParams(-1,dp(76)).apply{setMargins(0,0,0,dp(12))})

        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        fun actionButton(label:String,accent:Int,bg:Int,click:()->Unit)=Button(this).apply{text=label;setAllCaps(false);textSize=11.5f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(accent);background=liquidInteractiveSurface(bg,18,Color.rgb(205,220,238),1);applyLiquidControlDepth(this);setOnClickListener{click()}}
        actions.addView(actionButton("✎ Rinomina",Color.rgb(15,95,180),Color.rgb(238,246,255)){renameSessionPackDialog(s,dialog)},LinearLayout.LayoutParams(0,dp(46),1f).apply{setMargins(0,0,dp(4),0)})
        actions.addView(actionButton("⏹ Termina",Color.rgb(120,80,25),Color.rgb(255,248,232)){confirmTerminateSessionPack(s,dialog)},LinearLayout.LayoutParams(0,dp(46),1f).apply{setMargins(dp(2),0,dp(2),0)})
        actions.addView(actionButton("🗑 Elimina",Color.rgb(200,45,45),Color.rgb(255,244,244)){confirmDeleteSessionPack(s,dialog)},LinearLayout.LayoutParams(0,dp(46),0.9f).apply{setMargins(dp(4),0,0,0)})
        root.addView(actions,LinearLayout.LayoutParams(-1,dp(50)))
        val backBottom=Button(this).apply{text="‹  Indietro";setAllCaps(false);textSize=12f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(Color.rgb(15,95,180));background=liquidInteractiveSurface(Color.rgb(238,246,255),16,Color.rgb(190,218,248),1);applyLiquidControlDepth(this);setOnClickListener{dialog.dismiss()}}
        root.addView(backBottom,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(10),0,dp(2))})

        val dialogHeader=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;setPadding(dp(10),dp(2),dp(10),dp(2))}
        dialogHeader.addView(TextView(this).apply{text="Gestione pacchetto";textSize=20f;setTypeface(null,android.graphics.Typeface.NORMAL);gravity=Gravity.CENTER;setTextColor(Color.rgb(25,28,32));setSingleLine(true)},LinearLayout.LayoutParams(-1,dp(46)))
        dialog=AlertDialog.Builder(this).setCustomTitle(dialogHeader).setView(scroll).create()
        styleModernCoachDialog(dialog)
        dialog.show()
    }

    private fun customSessionPackUsed(s:SessionPack,type:String,now:LocalDateTime=LocalDateTime.now()):Int{
        return sessionAppointments(s).count{it.type==type && appointmentHasPassed(it,now)}
    }
    private fun customSessionPackBooked(s:SessionPack,type:String):Int{
        return sessionAppointments(s).count{it.type==type}
    }
    private fun customSessionPackRemaining(s:SessionPack,type:String):Int{
        val limit=s.customQuantities[type]?:0
        return (limit-customSessionPackBooked(s,type)).coerceAtLeast(0)
    }
    private fun customSessionPackInfo(s:SessionPack):String{
        return s.customQuantities.entries.sortedBy{it.key}.joinToString("  •  "){(type,q)->"${typeLabel(type)} $q"}
    }

    private fun sessionRatesFor(s:SessionPack):List<Int>{
        val c=s.customRates
        if(c!=null&&c.isNotEmpty()&&c.all{it>0}&&c.sum()==s.cost)return c.toList()
        return listOf(s.cost)
    }

    private fun saveSessionRates(s:SessionPack,rates:List<Int>){s.customRates=rates.toMutableList()}

    private fun SessionPack.paidRateIndex(rates:List<Int>):Int=rates.indices.firstOrNull{paid<rates.take(it+1).sum()}?:rates.size

    private fun registerSessionPayment(s:SessionPack,index:Int,paidNow:Int,sourceDialog:AlertDialog?=null){
        try{
            val rates=sessionRatesFor(s);val due=rates[index];require(paidNow>0);require(s.paid+paidNow<=s.cost)
            val paidBefore=rates.take(index).sum();val already=(s.paid-paidBefore).coerceAtLeast(0);val totalOnRate=already+paidNow
            val newRates=rates.toMutableList();s.paid+=paidNow
            if(totalOnRate<due && index==rates.lastIndex){
                // Keep the original installment schedule until the user confirms
                // creation of the new residual installment.
                saveData();sourceDialog?.dismiss();render();sessionInfoDialog(s)
                val residual=s.cost-s.paid
                if(residual>0)proposeResidualSessionRate(s,index,residual)
                return
            }
            if(totalOnRate>due){
                newRates[index]=totalOnRate
                val remainingCount=newRates.size-index-1
                if(remainingCount>0){
                    val remaining=s.cost-rates.take(index).sum()-totalOnRate;require(remaining>=0)
                    val base=remaining/remainingCount;val extra=remaining%remainingCount
                    for(j in index+1 until newRates.size)newRates[j]=base+if(j-index-1<extra)1 else 0
                } else require(totalOnRate==s.cost-rates.take(index).sum())
            }
            require(newRates.sum()==s.cost);saveSessionRates(s,newRates);saveData();sourceDialog?.dismiss();render();sessionInfoDialog(s)
            Toast.makeText(this,"Pagamento di €$paidNow registrato.",Toast.LENGTH_SHORT).show()
        }catch(_:Exception){Toast.makeText(this,"Importo non valido o superiore al totale residuo.",Toast.LENGTH_LONG).show()}
    }

    private fun confirmSessionPaymentDialog(s:SessionPack,index:Int,amount:Int,parentDialog:AlertDialog?=null){
        if(amount<=0)return
        val rates=sessionRatesFor(s)
        val date=s.start.plusDays(28L*index)
        val (dialog,outer,body)=packActionDialogBase(
            "Conferma pagamento",
            "✓",
            Color.rgb(0,145,112),
            Color.rgb(205,244,233),
            Color.rgb(248,255,252)
        )

        body.addView(dialogBodyText("Confermi il pagamento della rata ${index+1}?"))
        body.addView(dialogInfoCard(
            "€",
            "Importo rata",
            "€$amount",
            Color.rgb(0,145,112),
            Color.rgb(224,248,241)
        ),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,dp(8))})

        body.addView(dialogInfoCard(
            "▣",
            "Rata ${index+1} di ${rates.size}",
            "${date.format(fmt)}",
            Color.rgb(25,100,190),
            Color.rgb(235,244,255)
        ),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(14))})

        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        row.addView(dialogButton("Annulla",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(210,220,232)){dialog.dismiss()},
            LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(5),0)})
        row.addView(dialogButton("✓ Conferma",Color.WHITE,Color.rgb(0,145,112),Color.rgb(0,145,112)){
            dialog.dismiss()
            registerSessionPayment(s,index,amount,parentDialog)
        },LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(5),0,0,0)})
        body.addView(row)

        preparePopupBackdrop(dialog)
        dialog.setOnShowListener{popupBackdropCurrentDialog=dialog;dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28));applyPopupBackdropEffect(dialog);dialog.window?.setDimAmount(0.40f);dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)}
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun sessionPaymentAmountDialog(s:SessionPack,index:Int){
        val rates=sessionRatesFor(s)
        val due=rates[index]
        val paidBefore=rates.take(index).sum()
        val already=(s.paid-paidBefore).coerceAtLeast(0)
        val remaining=(due-already).coerceAtLeast(0)
        val (dialog,outer,body)=packActionDialogBase(
            "Modifica importo pagamento",
            "✎",
            Color.rgb(20,91,165),
            Color.rgb(224,238,255),
            Color.WHITE
        )

        body.addView(dialogBodyText("Rata ${index+1} di ${rates.size} • prevista €$due • da pagare €$remaining"))
        body.addView(dialogInfoCard(
            "ⓘ",
            "Inserisci l'importo da pagare",
            "L'importo previsto è €$due.",
            Color.rgb(25,100,190),
            Color.rgb(235,244,255)
        ),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,dp(12))})

        body.addView(TextView(this).apply{
            text="Nuovo importo"
            textSize=12.5f
            setTypeface(null,android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(82,87,94))
            setPadding(dp(2),0,0,dp(5))
        })

        val amount=modernEditText().apply{
            hint="Importo (€)"
            inputType=2
            setSingleLine(true)
            setText(remaining.toString())
            selectAll()
            textSize=16f
        }
        body.addView(amount,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(14))})

        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        row.addView(dialogButton("Annulla",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(210,220,232)){dialog.dismiss()},
            LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(5),0)})
        row.addView(dialogButton("✓ Conferma",Color.WHITE,Color.rgb(36,112,225),Color.rgb(36,112,225)){
            val value=amount.text.toString().trim().toIntOrNull()
            if(value==null||value<=0||s.paid+value>s.cost){
                Toast.makeText(this,"Importo non valido o superiore al totale residuo.",Toast.LENGTH_LONG).show()
            }else{
                dialog.dismiss()
                confirmSessionPaymentDialog(s,index,value)
            }
        },LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(5),0,0,0)})
        body.addView(row)

        preparePopupBackdrop(dialog)
        dialog.setOnShowListener{
            popupBackdropCurrentDialog=dialog
            dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
            applyPopupBackdropEffect(dialog)
            dialog.window?.setDimAmount(0.40f)
            dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
            amount.clearFocus()
        }
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun proposeResidualSessionRate(s:SessionPack,index:Int,residual:Int){
        if(residual<=0)return
        val next=index+2
        val dialog=buildResidualRateDialog(
            previousRate=index+1,
            dueAmount=sessionRatesFor(s)[index],
            alreadyPaid=(s.paid-sessionRatesFor(s).take(index).sum()).coerceAtLeast(0),
            residual=residual,
            nextRate=next,
            onCreate={
                val current=sessionRatesFor(s).toMutableList()
                val paidBefore=current.take(index).sum()
                val paidOnCurrent=(s.paid-paidBefore).coerceAtLeast(0)
                if(index in current.indices && paidOnCurrent>0 && paidOnCurrent<current[index]){
                    current[index]=paidOnCurrent
                    current.add(residual)
                    if(current.sum()==s.cost){
                        saveSessionRates(s,current);saveData();render();sessionInfoDialog(s)
                        Toast.makeText(this,"${next}ª rata creata: €$residual.",Toast.LENGTH_SHORT).show()
                    }
                }
            }
        )
        dialog.show()
    }

    private fun buildResidualRateDialog(previousRate:Int,dueAmount:Int,alreadyPaid:Int,residual:Int,nextRate:Int,onCreate:()->Unit):Dialog{
        val (dialog,outer,body)=packActionDialogBase(
            "Importo residuo",
            "◷",
            Color.rgb(225,135,0),
            Color.rgb(255,239,205),
            Color.WHITE
        )

        body.addView(dialogBodyText(
            "La rata ${previousRate} è stata pagata solo in parte."
        ))

        val stats=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(16),dp(12),dp(16),dp(12))
            background=roundedSurface(Color.rgb(235,244,255),20)
        }
        fun statRow(label:String,value:String,bold:Boolean=false,accent:Int=Color.rgb(25,55,100)):LinearLayout{
            return LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL
                gravity=Gravity.CENTER_VERTICAL
                addView(TextView(this@MainActivity).apply{
                    text=label;textSize=13.5f;setTextColor(Color.rgb(65,82,105))
                },LinearLayout.LayoutParams(0,-2,1f))
                addView(TextView(this@MainActivity).apply{
                    text=value;textSize=if(bold)17f else 14.5f
                    setTypeface(null,if(bold)android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
                    setTextColor(accent);gravity=Gravity.RIGHT
                })
            }
        }
        stats.addView(statRow("Importo totale rata","€$dueAmount"))
        stats.addView(statRow("Importo già pagato","€$alreadyPaid"),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(7),0,dp(7))})
        val divider=View(this).apply{setBackgroundColor(Color.rgb(205,220,240))}
        stats.addView(divider,LinearLayout.LayoutParams(-1,dp(1)))
        stats.addView(statRow("Importo residuo","€$residual",true,Color.rgb(25,100,190)),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(7),0,0)})
        body.addView(stats,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,dp(12))})

        body.addView(dialogInfoCard(
            "▣",
            "Nuova rata",
            "€$residual",
            Color.rgb(25,100,190),
            Color.rgb(235,244,255)
        ),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})

        body.addView(dialogBodyText(
            "Vuoi creare la ${nextRate}ª rata di €$residual con scadenza tra 28 giorni?"
        ).apply{setPadding(dp(6),0,dp(6),dp(10))})

        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        row.addView(dialogButton(
            "Non ora",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(210,220,232)
        ){dialog.dismiss()},LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(0,0,dp(5),0)})
        row.addView(dialogButton(
            "▣  Crea ${nextRate}ª rata",Color.WHITE,Color.rgb(36,112,225),Color.rgb(36,112,225)
        ){dialog.dismiss();onCreate()},LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(dp(5),0,0,0)})
        body.addView(row)

        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
        return dialog
    }

    private fun confirmTerminateSessionPack(s:SessionPack,source:AlertDialog){
        val future=appointments.filter{it.sessionPackId==s.id&&it.date.isAfter(LocalDate.now())}
        val (dialog,outer,body)=packActionDialogBase("Terminare il pacchetto?","✓",Color.rgb(205,120,0),Color.rgb(255,236,198),Color.rgb(255,252,246))
        body.addView(dialogBodyText("Il pacchetto di ${displaySurnameFirst(s.name)} verrà spostato nello storico e non sarà più considerato attivo."))
        body.addView(dialogInfoCard("CALENDAR_ICON","Appuntamenti futuri","${future.size}",Color.rgb(205,120,0),Color.rgb(255,241,213)),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,dp(10))})
        body.addView(TextView(this).apply{
            text=if(future.isEmpty()) "Non ci sono appuntamenti futuri da gestire." else "Puoi scegliere se mantenere gli appuntamenti futuri oppure eliminarli dal calendario."
            textSize=13.5f;gravity=Gravity.CENTER;setTextColor(Color.rgb(95,78,52));setLineSpacing(0f,1.05f);setPadding(dp(6),0,dp(6),dp(12))
        },LinearLayout.LayoutParams(-1,-2))
        if(future.isNotEmpty()){
            body.addView(dialogButton("Mantieni appuntamenti",Color.WHITE,Color.rgb(235,140,0),Color.rgb(235,140,0)){
                s.active=false;saveData();dialog.dismiss();source.dismiss();render();Toast.makeText(this,"Pacchetto terminato. Appuntamenti mantenuti.",Toast.LENGTH_SHORT).show()
            },LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,0,0,dp(8))})
            body.addView(dialogButton("Elimina futuri",Color.rgb(190,105,0),Color.rgb(255,252,246),Color.rgb(245,190,95)){
                appointments.removeAll{it.sessionPackId==s.id&&it.date.isAfter(LocalDate.now())};s.active=false;saveData();dialog.dismiss();source.dismiss();render();Toast.makeText(this,"Pacchetto terminato e appuntamenti futuri eliminati.",Toast.LENGTH_SHORT).show()
            },LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,0,0,dp(5))})
        } else {
            body.addView(dialogButton("Conferma terminazione",Color.WHITE,Color.rgb(235,140,0),Color.rgb(235,140,0)){
                s.active=false;saveData();dialog.dismiss();source.dismiss();render();Toast.makeText(this,"Pacchetto terminato.",Toast.LENGTH_SHORT).show()
            },LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,0,0,dp(5))})
        }
        body.addView(TextView(this).apply{text="Annulla";textSize=14.5f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(125,75,20));setPadding(0,dp(7),0,dp(2));setOnClickListener{dialog.dismiss()}},LinearLayout.LayoutParams(-1,dp(40)))
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun addTrashItem(kind:String,payload:JSONObject){ trashItems.add(TrashItem(nextTrashId++,kind,LocalDateTime.now(),payload.toString())) }
    private fun packTrashPayload(p:Pack):JSONObject=JSONObject().apply{put("name",p.name);put("start",p.start.toString());put("total",p.total);put("paid",p.paid);put("rateAmounts",JSONArray().apply{ratesFor(p).forEach{put(it)}});put("packageType",p.packageType);put("sessionTotal",p.sessionTotal);put("active",p.active);put("missedSessions",p.missedSessions);put("weeklyWeeks",p.weeklyWeeks);put("weeklyQuantities",JSONObject().apply{p.weeklyQuantities.forEach{(k,v)->put(k,v)}});put("includedAppointmentType",p.includedAppointmentType);put("clientId",p.clientId)}
    private fun sessionPackTrashPayload(s:SessionPack):JSONObject=JSONObject().apply{put("id",s.id);put("name",s.name);put("start",s.start.toString());put("totalSessions",s.totalSessions);put("cost",s.cost);put("paid",s.paid);put("active",s.active);put("rateAmounts",JSONArray().apply{sessionRatesFor(s).forEach{put(it)}});put("customQuantities",JSONObject().apply{s.customQuantities.forEach{(k,v)->put(k,v)}});put("linkedAppointmentIds",JSONArray().apply{appointments.filter{it.sessionPackId==s.id}.forEach{put(it.id)}});put("clientId",s.clientId)}
    private fun appointmentTrashPayload(a:Appointment):JSONObject=JSONObject().apply{put("id",a.id);put("name",a.name);put("date",a.date.toString());put("time",a.time);put("type",a.type);put("seriesId",a.seriesId);put("sessionPackId",a.sessionPackId);put("recovery",a.recovery)}
    private fun purgeExpiredTrash(){ val cutoff=LocalDateTime.now().minusDays(10); trashItems.removeAll{it.deletedAt.isBefore(cutoff)} }

    private fun trashScreen(returnToSettings:Boolean=false,filter:String="ALL"){
        detachSettingsOverlay()
        trashReturnToSettings=returnToSettings
        purgeExpiredTrash();saveData()
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(12),dp(16),dp(12));background=appGlassBackground()}
        val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        header.addView(TextView(this).apply{text="←";textSize=28f;setTextColor(Color.rgb(25,65,120));gravity=Gravity.CENTER;setOnClickListener{if(trashReturnToSettings){trashReturnToSettings=false;settings()}else build()}},LinearLayout.LayoutParams(dp(46),dp(46)))
        header.addView(TextView(this).apply{text="Cestino";textSize=24f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,35,55));gravity=Gravity.CENTER},LinearLayout.LayoutParams(0,dp(46),1f))
        header.addView(TextView(this).apply{text="🗑";textSize=22f;gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(46),dp(46)))
        root.addView(header)
        root.addView(LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(10),dp(12),dp(10));background=roundedSurface(Color.rgb(232,243,255),18,Color.rgb(195,220,248),1)
            addView(TextView(this@MainActivity).apply{text="i";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(25,100,190));background=roundedSurface(Color.WHITE,24)},LinearLayout.LayoutParams(dp(34),dp(34)))
            addView(TextView(this@MainActivity).apply{text="Gli elementi restano nel cestino per 10 giorni, poi vengono eliminati automaticamente.";textSize=13f;setTextColor(Color.rgb(40,75,115));setPadding(dp(10),0,0,0)},LinearLayout.LayoutParams(0,-2,1f))
        },LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(8),0,dp(10))})
        val tabs=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val allCount=trashItems.size;val packCount=trashItems.count{it.kind=="PACK"||it.kind=="SESSION_PACK"};val apCount=trashItems.count{it.kind=="APPOINTMENT"}
        fun tab(label:String,active:Boolean,click:()->Unit)=Button(this).apply{text=label;setAllCaps(false);textSize=11.5f;setTypeface(null,android.graphics.Typeface.BOLD);minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(if(active)Color.WHITE else Color.rgb(55,65,80));background=roundedSurface(if(active)Color.rgb(36,112,225) else Color.WHITE,16,if(active)Color.rgb(36,112,225) else Color.rgb(220,225,232),1);setOnClickListener{click()}}
        tabs.addView(tab("Tutti ($allCount)",filter=="ALL"){trashScreen(trashReturnToSettings,"ALL")},LinearLayout.LayoutParams(0,dp(40),1f).apply{setMargins(0,0,dp(3),0)})
        tabs.addView(tab("Pacchetti ($packCount)",filter=="PACKAGES"){trashScreen(trashReturnToSettings,"PACKAGES")},LinearLayout.LayoutParams(0,dp(40),1f).apply{setMargins(dp(2),0,dp(2),0)})
        tabs.addView(tab("Appuntamenti ($apCount)",filter=="APPOINTMENTS"){trashScreen(trashReturnToSettings,"APPOINTMENTS")},LinearLayout.LayoutParams(0,dp(40),1f).apply{setMargins(dp(3),0,0,0)})
        root.addView(tabs,LinearLayout.LayoutParams(-1,dp(42)))
        val filtered=when(filter){"PACKAGES"->trashItems.filter{it.kind=="PACK"||it.kind=="SESSION_PACK"};"APPOINTMENTS"->trashItems.filter{it.kind=="APPOINTMENT"};else->trashItems}
        val listBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,dp(4),0,dp(10))}
        if(filtered.isEmpty()) listBox.addView(TextView(this).apply{text="🗑\n\nNessun elemento\n\nIn questa sezione non ci sono elementi nel cestino.";textSize=16f;setTextColor(Color.rgb(75,85,100));gravity=Gravity.CENTER;setPadding(dp(20),dp(50),dp(20),dp(50))})
        else filtered.sortedByDescending{it.deletedAt}.forEach{listBox.addView(trashItemView(it),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(7))})}
        val scroll=ScrollView(this).apply{addView(listBox)};root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));prepareEdgeToEdgeRoot(root);setContentView(root)
    }
    private fun trashItemView(item:TrashItem):View{
        val obj=runCatching{JSONObject(item.payload)}.getOrElse{JSONObject()};val isAp=item.kind=="APPOINTMENT";val title=obj.optString("name","Elemento");val subtitle=if(isAp)"Appuntamento • ${obj.optString("date","")} • ${obj.optString("time","")}" else if(item.kind=="SESSION_PACK")"Pacchetto a sedute • ${obj.optInt("totalSessions",0)} sedute • €${obj.optInt("cost",0)}" else "Pacchetto ${obj.optString("packageType","PERSONALIZZATO")} • ${obj.optInt("sessionTotal",0)} sedute • €${obj.optInt("total",0)}";val days=(10-(java.time.Duration.between(item.deletedAt,LocalDateTime.now()).toHours()/24).toInt()).coerceIn(0,10)
        val card=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(10),dp(8),dp(10));background=roundedSurface(Color.WHITE,18,Color.rgb(225,230,237),1);isClickable=true}
        card.addView(TextView(this).apply{text=if(isAp)"▦" else "📦";textSize=22f;gravity=Gravity.CENTER;setTextColor(Color.rgb(30,100,190));background=roundedSurface(Color.rgb(235,244,255),28)},LinearLayout.LayoutParams(dp(48),dp(48)))
        val texts=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),0,dp(8),0)};texts.addView(TextView(this).apply{text=title;textSize=15.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,30,40))});texts.addView(TextView(this).apply{text=subtitle;textSize=12.5f;setTextColor(Color.rgb(80,88,100));setPadding(0,dp(2),0,0)});texts.addView(TextView(this).apply{text="Eliminato ${item.deletedAt.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))}";textSize=11.5f;setTextColor(Color.rgb(120,125,135));setPadding(0,dp(2),0,0)});card.addView(texts,LinearLayout.LayoutParams(0,-2,1f));card.addView(TextView(this).apply{text="$days giorni";textSize=12f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(if(days<=3)Color.rgb(205,55,55) else Color.rgb(30,110,190));gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(62),dp(42)));card.setOnClickListener{trashItemOptions(item)};return card
    }
    private fun trashItemOptions(item:TrashItem){
        val obj=runCatching{JSONObject(item.payload)}.getOrElse{JSONObject()}
        val name=obj.optString("name","Elemento")
        val typeLabel=when(item.kind){"APPOINTMENT"->"Appuntamento";"SESSION_PACK"->"Pacchetto a sedute";else->"Pacchetto 12 settimane"}
        val (d,outer,body)=packActionDialogBase("Elemento nel Cestino",if(item.kind=="APPOINTMENT")"▦" else "📦",Color.rgb(25,100,190),Color.rgb(232,243,255),Color.WHITE)
        body.addView(TextView(this).apply{text=name;textSize=20f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(25,35,55));setPadding(dp(6),0,dp(6),dp(4))})
        body.addView(TextView(this).apply{text=typeLabel;textSize=13.5f;gravity=Gravity.CENTER;setTextColor(Color.rgb(95,105,120));setPadding(0,0,0,dp(10))})
        body.addView(dialogButton("↩  Ripristina",Color.WHITE,Color.rgb(0,150,112),Color.rgb(0,150,112)){restoreTrashItem(item,d)},LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(7))})
        body.addView(dialogButton("🗑  Elimina definitivamente",Color.rgb(205,45,55),Color.rgb(255,244,244),Color.rgb(245,210,214)){confirmPermanentTrashDelete(item,d)},LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(5))})
        body.addView(Button(this).apply{text="Annulla";setAllCaps(false);textSize=14f;setTextColor(Color.rgb(0,125,110));setBackgroundColor(Color.TRANSPARENT);stateListAnimator=null;setOnClickListener{d.dismiss()}},LinearLayout.LayoutParams(-1,dp(44)))
        d.show()
    }
    private fun confirmPermanentTrashDelete(item:TrashItem,source:Dialog?=null){
        source?.dismiss()
        val obj=runCatching{JSONObject(item.payload)}.getOrElse{JSONObject()};val name=obj.optString("name","Elemento")
        val (d,outer,body)=packActionDialogBase("Eliminare definitivamente?","🗑",Color.rgb(205,45,55),Color.rgb(255,225,228),Color.rgb(255,250,250))
        body.addView(dialogBodyText("$name verrà eliminato in modo permanente e non potrà più essere ripristinato."))
        body.addView(dialogInfoCard("!","Attenzione","L'operazione non può essere annullata.",Color.rgb(205,45,55),Color.rgb(255,235,237)),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,dp(12))})
        val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        buttons.addView(dialogButton("Annulla",Color.rgb(65,80,100),Color.WHITE,Color.rgb(215,223,232)){d.dismiss()},LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(0,0,dp(4),0)})
        buttons.addView(dialogButton("🗑  Elimina",Color.WHITE,Color.rgb(205,45,55),Color.rgb(205,45,55)){trashItems.removeAll{it.id==item.id};saveData();d.dismiss();trashScreen(trashReturnToSettings)},LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(dp(4),0,0,0)})
        body.addView(buttons)
        d.show()
    }
    private fun restoreTrashItem(item:TrashItem,source:Dialog?=null){try{val obj=JSONObject(item.payload);when(item.kind){"APPOINTMENT"->appointments.add(Appointment(obj.getLong("id"),obj.getString("name"),LocalDate.parse(obj.getString("date")),obj.getString("time"),normalizedType(obj.optString("type","TYPE1")),obj.optLong("seriesId",0L),obj.optLong("sessionPackId",0L),obj.optBoolean("recovery",false)));"PACK"->packs.add(Pack(obj.getString("name"),LocalDate.parse(obj.getString("start")),obj.getInt("total"),obj.optInt("paid",0),obj.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}},obj.optString("packageType","PERSONALIZZATO"),obj.optInt("sessionTotal",12),obj.optBoolean("active",true),obj.optInt("missedSessions",0),obj.optInt("weeklyWeeks",12),obj.optJSONObject("weeklyQuantities")?.let{jo->mutableMapOf<String,Int>().apply{jo.keys().forEach{key->put(key,jo.optInt(key,0))}}} ?: mutableMapOf(),obj.optString("includedAppointmentType","").ifBlank{null},obj.optLong("clientId",0L)));"SESSION_PACK"->{val restored=SessionPack(obj.getLong("id"),obj.getString("name"),LocalDate.parse(obj.getString("start")),obj.getInt("totalSessions"),obj.getInt("cost"),obj.optInt("paid",0),obj.optBoolean("active",true),obj.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}}, obj.optJSONObject("customQuantities")?.let{jo->mutableMapOf<String,Int>().apply{jo.keys().forEach{key->put(key,jo.optInt(key,0))}}} ?: mutableMapOf(),obj.optLong("clientId",0L));sessionPacks.add(restored);obj.optJSONArray("linkedAppointmentIds")?.let{ja->for(i in 0 until ja.length()){val id=ja.getLong(i);appointments.firstOrNull{it.id==id}?.sessionPackId=restored.id}}}};trashItems.removeAll{it.id==item.id};nextAppointmentId=maxOf(nextAppointmentId,(appointments.maxOfOrNull{it.id}?:0L)+1);nextSessionPackId=maxOf(nextSessionPackId,(sessionPacks.maxOfOrNull{it.id}?:0L)+1);saveData();source?.dismiss();trashScreen(trashReturnToSettings);Toast.makeText(this,"Elemento ripristinato.",Toast.LENGTH_SHORT).show()}catch(_:Exception){Toast.makeText(this,"Impossibile ripristinare l'elemento.",Toast.LENGTH_LONG).show()}}

    private fun confirmDeleteSessionPack(s:SessionPack,source:AlertDialog){
        val (dialog,outer,body)=packActionDialogBase("Eliminare pacchetto?","▣",Color.rgb(215,35,45),Color.rgb(255,215,218),Color.rgb(255,250,250))
        body.addView(dialogBodyText("Stai per spostare nel Cestino il pacchetto di ${displaySurnameFirst(s.name)}."))
        body.addView(dialogInfoCard("!","Cestino • 10 giorni","Sedute, pagamenti e dati del pacchetto verranno conservati per 10 giorni.",Color.rgb(215,35,45),Color.rgb(255,230,232)),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,dp(12))})
        body.addView(TextView(this).apply{text="Gli appuntamenti resteranno nel calendario.";textSize=13.5f;gravity=Gravity.CENTER;setTextColor(Color.rgb(105,65,68));setPadding(dp(6),0,dp(6),dp(14))},LinearLayout.LayoutParams(-1,-2))
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        row.addView(dialogButton("Annulla",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(210,220,232)){dialog.dismiss()},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(4),0)})
        row.addView(dialogButton("Elimina",Color.WHITE,Color.rgb(225,40,50),Color.rgb(225,40,50)){
            addTrashItem("SESSION_PACK",sessionPackTrashPayload(s));sessionPacks.remove(s);appointments.filter{it.sessionPackId==s.id}.forEach{it.sessionPackId=0L};saveData();dialog.dismiss();source.dismiss();render();Toast.makeText(this,"Pacchetto spostato nel Cestino.",Toast.LENGTH_SHORT).show()
        },LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(4),0,0,0)})
        body.addView(row)
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun sessionPaymentInfo(s:SessionPack){ sessionInfoDialog(s) }

    private fun packActionDialogBase(title:String, icon:String, iconColor:Int, iconBg:Int, dialogBg:Int=Color.WHITE): Triple<Dialog,LinearLayout,LinearLayout>{
        val dialog=Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val outer=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(14),dp(12),dp(14),dp(12))
            background=roundedSurface(dialogBg,28)
        }
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val spacer=Space(this)
        top.addView(spacer,LinearLayout.LayoutParams(0,dp(36),1f))
        top.addView(TextView(this).apply{
            text="×";textSize=27f;gravity=Gravity.CENTER;setTextColor(Color.rgb(70,80,95));setPadding(0,0,0,dp(2))
            setOnClickListener{dialog.dismiss()}
        },LinearLayout.LayoutParams(dp(38),dp(36)))
        outer.addView(top)
        val iconView:View=if(icon=="WARNING_TRIANGLE") ImageView(this).apply{
            setImageDrawable(warningTriangleDrawable(iconColor));scaleType=ImageView.ScaleType.CENTER_INSIDE
            background=roundedSurface(iconBg,40)
        } else TextView(this).apply{
            text=icon;textSize=28f;gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(iconColor)
            background=roundedSurface(iconBg,40)
        }
        outer.addView(iconView,LinearLayout.LayoutParams(dp(66),dp(66)).apply{gravity=Gravity.CENTER;setMargins(0,dp(0),0,dp(10))})
        val titleView=TextView(this).apply{
            text=title;textSize=21f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(28,35,48))
        }
        outer.addView(titleView,LinearLayout.LayoutParams(-1,dp(40)).apply{setMargins(dp(8),0,dp(8),dp(2))})
        val body=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(8),0,dp(8),0)}
        outer.addView(body,LinearLayout.LayoutParams(-1,-2))
        dialog.setContentView(outer)
        preparePopupBackdrop(dialog)
        dialog.window?.apply{
            setBackgroundDrawableResource(android.R.color.transparent)
            addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING)
            attributes=attributes.apply{dimAmount=0.40f}
        }
        preparePopupBackdrop(dialog)
        dialog.setOnShowListener{
            popupBackdropCurrentDialog=dialog
            applyPopupBackdropEffect(dialog)
            dialog.window?.apply{
                setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
                attributes=attributes.apply{windowAnimations=0}
            }
            outer.animate().cancel()
            outer.alpha=0f
            outer.scaleX=0.972f
            outer.scaleY=0.972f
            outer.animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(155)
                .setInterpolator(android.view.animation.DecelerateInterpolator(1.5f))
                .withLayer()
                .start()
        }
        return Triple(dialog,outer,body)
    }

    private fun nikiDeleteDialogGlassSurface(): GradientDrawable {
        // Niki UI Glass: piu trasparente e luminoso, senza effetto "bianco latte".
        // Manteniamo esattamente dimensioni e layout del dialog: qui cambiamo solo
        // il rendering della superficie.
        val t = popupBackdropIntensity.coerceIn(0,100) / 100f
        val alphaTop = (118 + 24 * t).roundToInt().coerceIn(118,142)
        val alphaLight = (92 + 20 * t).roundToInt().coerceIn(92,112)
        val alphaMid = (104 + 22 * t).roundToInt().coerceIn(104,126)
        val alphaBottom = (126 + 24 * t).roundToInt().coerceIn(126,150)
        return GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(
                Color.argb(alphaTop, 226, 243, 255),
                Color.argb(alphaLight, 255, 255, 255),
                Color.argb(alphaMid, 238, 248, 255),
                Color.argb(alphaBottom, 207, 232, 251)
            )
        ).apply {
            cornerRadius = dp(28).toFloat()
            setStroke(dp(1), Color.argb(185, 188, 222, 247))
        }
    }

    private fun dialogBodyText(text:String):TextView=TextView(this).apply{
        this.text=text;textSize=15.5f;gravity=Gravity.CENTER;setTextColor(Color.rgb(55,62,75));setLineSpacing(0f,1.08f);setPadding(dp(6),0,dp(6),dp(12))
    }

    private fun dialogInfoCard(icon:String,title:String,value:String?,accent:Int,bg:Int):LinearLayout=LinearLayout(this).apply{
        orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(10),dp(12),dp(10));background=dialogReadableSurface(bg,18,Color.argb(155,175,215,248),1)
        addView(if(icon=="CALENDAR_ICON") ImageView(this@MainActivity).apply{setImageDrawable(calendarIconDrawable(accent));setPadding(dp(11),dp(11),dp(11),dp(11));background=dialogReadableSurface(Color.WHITE,32,Color.argb(90,175,215,248),1)} else TextView(this@MainActivity).apply{text=icon;textSize=22f;gravity=Gravity.CENTER;setTextColor(accent);background=dialogReadableSurface(Color.WHITE,32,Color.argb(90,175,215,248),1)},LinearLayout.LayoutParams(dp(48),dp(48)))
        val txt=LinearLayout(this@MainActivity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),0,0,0)}
        txt.addView(TextView(this@MainActivity).apply{text=title;textSize=13f;setTextColor(Color.rgb(70,78,90))},LinearLayout.LayoutParams(-1,-2))
        if(value!=null) txt.addView(TextView(this@MainActivity).apply{text=value;textSize=24f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(accent);setPadding(0,dp(2),0,0)},LinearLayout.LayoutParams(-1,-2))
        addView(txt,LinearLayout.LayoutParams(0,-2,1f))
    }

    private fun dialogButton(text:String,textColor:Int,bg:Int,stroke:Int,click:()->Unit):Button=Button(this).apply{
        this.text=text;setAllCaps(false);textSize=14.5f;setTypeface(null,android.graphics.Typeface.BOLD);minHeight=0;minimumHeight=0;stateListAnimator=null
        setTextColor(textColor);background=liquidInteractiveSurface(bg,18,stroke,1);applyLiquidControlDepth(this);setPadding(dp(8),0,dp(8),0);setOnClickListener{click()}
    }

    private fun terminatePackDialog(p:Pack){
        val future=appointments.filter{identityKey(it.name)==identityKey(p.name)&&it.date.isAfter(LocalDate.now())}
        val (dialog,outer,body)=packActionDialogBase("Terminare il pacchetto?","✓",Color.rgb(205,120,0),Color.rgb(255,236,198),Color.rgb(255,252,246))
        body.addView(dialogBodyText("Il pacchetto di ${displaySurnameFirst(p.name)} verrà spostato nello storico e non sarà più considerato attivo."))
        body.addView(dialogInfoCard("CALENDAR_ICON","Appuntamenti futuri","${future.size}",Color.rgb(205,120,0),Color.rgb(255,241,213)),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,dp(10))})
        body.addView(TextView(this).apply{
            text=if(future.isEmpty()) "Non ci sono appuntamenti futuri da gestire." else "Puoi scegliere se mantenere gli appuntamenti futuri oppure eliminarli dal calendario."
            textSize=13.5f;gravity=Gravity.CENTER;setTextColor(Color.rgb(95,78,52));setLineSpacing(0f,1.05f);setPadding(dp(6),0,dp(6),dp(12))
        },LinearLayout.LayoutParams(-1,-2))
        if(future.isNotEmpty()){
            body.addView(dialogButton("Mantieni appuntamenti",Color.WHITE,Color.rgb(235,140,0),Color.rgb(235,140,0)){
                p.active=false;saveData();dialog.dismiss();render();Toast.makeText(this,"Pacchetto terminato. Appuntamenti mantenuti.",Toast.LENGTH_SHORT).show()
            },LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,0,0,dp(8))})
            body.addView(dialogButton("Elimina futuri",Color.rgb(190,105,0),Color.rgb(255,252,246),Color.rgb(245,190,95)){
                appointments.removeAll{identityKey(it.name)==identityKey(p.name)&&it.date.isAfter(LocalDate.now())};p.active=false;saveData();dialog.dismiss();render();Toast.makeText(this,"Pacchetto terminato e appuntamenti futuri eliminati.",Toast.LENGTH_SHORT).show()
            },LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,0,0,dp(5))})
        } else {
            body.addView(dialogButton("Conferma terminazione",Color.WHITE,Color.rgb(235,140,0),Color.rgb(235,140,0)){
                p.active=false;saveData();dialog.dismiss();render();Toast.makeText(this,"Pacchetto terminato.",Toast.LENGTH_SHORT).show()
            },LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,0,0,dp(5))})
        }
        body.addView(TextView(this).apply{text="Annulla";textSize=14.5f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(125,75,20));setPadding(0,dp(7),0,dp(2));setOnClickListener{dialog.dismiss()}},LinearLayout.LayoutParams(-1,dp(40)))
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun confirmDeletePack(p:Pack){
        val (dialog,outer,body)=packActionDialogBase("Eliminare pacchetto?","▣",Color.rgb(215,35,45),Color.rgb(255,215,218),Color.rgb(255,250,250))
        body.addView(dialogBodyText("Stai per spostare nel Cestino il pacchetto di ${displaySurnameFirst(p.name)}."))
        body.addView(dialogInfoCard("!","Cestino • 10 giorni","Rate, sedute e dati del pacchetto verranno conservati per 10 giorni.",Color.rgb(215,35,45),Color.rgb(255,230,232)),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,dp(12))})
        body.addView(TextView(this).apply{
            text="Gli appuntamenti resteranno nel calendario."
            textSize=13.5f;gravity=Gravity.CENTER;setTextColor(Color.rgb(105,65,68));setPadding(dp(6),0,dp(6),dp(14))
        },LinearLayout.LayoutParams(-1,-2))
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        row.addView(dialogButton("Annulla",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(210,220,232)){dialog.dismiss()},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(4),0)})
        row.addView(dialogButton("Elimina",Color.WHITE,Color.rgb(225,40,50),Color.rgb(225,40,50)){
            addTrashItem("PACK",packTrashPayload(p));packs.remove(p);saveData();dialog.dismiss();activePackageDialog?.dismiss();activePackageDialog=null;render();Toast.makeText(this,"Pacchetto spostato nel Cestino.",Toast.LENGTH_SHORT).show()
        },LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(4),0,0,0)})
        body.addView(row)
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun editPackDialog(p:Pack){
        val (dialog,outer,body)=packActionDialogBase("Modifica pacchetto","✎",Color.rgb(20,91,165),Color.rgb(224,238,255),Color.WHITE)
        body.addView(dialogBodyText("Modifica i dati del pacchetto di ${displaySurnameFirst(p.name)}."))

        val intro=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(12),dp(9),dp(12),dp(9))
            background=roundedSurface(Color.rgb(247,249,252),18,Color.rgb(225,231,239),1)
        }
        val initials=displaySurnameFirst(p.name).split(" ").filter{it.isNotBlank()}.take(2).joinToString(""){it.first().uppercase()}
        intro.addView(TextView(this).apply{
            text=initials;textSize=17f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER
            setTextColor(Color.rgb(20,70,130));background=roundedSurface(Color.rgb(230,240,252),28)
        },LinearLayout.LayoutParams(dp(50),dp(50)))
        intro.addView(TextView(this).apply{
            text=displaySurnameFirst(p.name);textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(25,28,32));gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),0,0,0)
        },LinearLayout.LayoutParams(0,dp(50),1f))
        body.addView(intro,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(13))})

        fun label(t:String)=TextView(this).apply{
            text=t;textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(82,87,94));setPadding(dp(2),0,0,dp(4))
        }
        val name=modernEditText().apply{
            setSingleLine(true);setText(p.name);setSelection(text.length);textSize=16f;hint="Cognome e Nome"
        }
        body.addView(label("Cliente"))
        body.addView(name,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(10))})

        body.addView(label("Tipo pacchetto"))
        val type=Spinner(this).apply{
            adapter=centeredSpinnerAdapter(listOf("BRONZE • 12 sedute","SILVER • 24 sedute","GOLD • 36 sedute","PERSONALIZZATO"))
            setSelection(when(p.packageType){"BRONZE"->0;"SILVER"->1;"GOLD"->2;else->3})
        }
        body.addView(type,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(10))})

        body.addView(label("Numero sedute"))
        val sessions=modernEditText().apply{
            setSingleLine(true);inputType=2;setText(p.sessionTotal.toString());hint="Numero sedute";textSize=16f
        }
        body.addView(sessions,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(14))})
        fun sync(){sessions.setText(when(type.selectedItemPosition){0->"12";1->"24";2->"36";else->p.sessionTotal.toString()})}
        type.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent:AdapterView<*>?){ }
            override fun onItemSelected(parent:AdapterView<*>?,view:View?,position:Int,id:Long){if(position<3)sync()}
        }

        body.addView(LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
            val cancel=dialogButton("Annulla",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(210,220,232)){dialog.dismiss()}
            val save=dialogButton("▣ Salva",Color.WHITE,Color.rgb(36,112,225),Color.rgb(36,112,225)){
                val newName=normalizeDisplayName(name.text.toString())
                val newTotal=sessions.text.toString().trim().toIntOrNull()
                if(newName.isBlank()||newTotal==null||newTotal<=0){
                    Toast.makeText(this@MainActivity,"Controlla nome e numero sedute.",Toast.LENGTH_LONG).show();return@dialogButton
                }
                val done=sessionsForPack(p,LocalDate.now()).size
                if(newTotal<done){
                    Toast.makeText(this@MainActivity,"Non puoi impostare $newTotal sedute: ne risultano già effettuate $done.",Toast.LENGTH_LONG).show();return@dialogButton
                }
                val oldKey=identityKey(p.name)
                val kind=when(type.selectedItemPosition){0->"BRONZE";1->"SILVER";2->"GOLD";else->"PERSONALIZZATO"}
                p.name=newName;p.packageType=kind;p.sessionTotal=if(kind=="BRONZE")12 else if(kind=="SILVER")24 else if(kind=="GOLD")36 else newTotal
                appointments.filter{identityKey(it.name)==oldKey}.forEach{it.name=newName}
                saveData();dialog.dismiss();render();Toast.makeText(this@MainActivity,"Pacchetto aggiornato.",Toast.LENGTH_SHORT).show()
            }
            addView(cancel,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(4),0)})
            addView(save,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(4),0,0,0)})
        },LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,0,0,dp(2))})

        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun renamePackDialog(p:Pack){
        val (dialog,outer,body)=packActionDialogBase("Rinomina pacchetto","✎",Color.rgb(20,91,165),Color.rgb(224,238,255),Color.WHITE)
        body.addView(dialogBodyText("Modifica il nome del cliente associato al pacchetto."))
        val input=modernEditText().apply{
            setSingleLine(true)
            setText(p.name)
            setSelection(text.length)
            textSize=16f
            hint="Cognome e Nome"
        }
        body.addView(TextView(this).apply{text="Nuovo nome del cliente/pacchetto";textSize=13f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(75,82,92));setPadding(dp(6),0,dp(6),dp(6))},LinearLayout.LayoutParams(-1,dp(28)))
        body.addView(input,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(dp(2),0,dp(2),dp(14))})
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        row.addView(dialogButton("Annulla",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(210,220,232)){dialog.dismiss()},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(4),0)})
        row.addView(dialogButton("✓  Salva",Color.WHITE,Color.rgb(36,112,225),Color.rgb(36,112,225)){
            val newName=normalizeDisplayName(input.text.toString())
            if(newName.isBlank()){input.error="Inserisci un nome";return@dialogButton}
            val oldKey=identityKey(p.name)
            p.name=newName
            appointments.filter{identityKey(it.name)==oldKey}.forEach{it.name=newName}
            saveData();dialog.dismiss()
            activePackageDialog?.dismiss();activePackageDialog=null
            render();packageInfoDialog(p)
            Toast.makeText(this,"Pacchetto rinominato.",Toast.LENGTH_SHORT).show()
        },LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(4),0,0,0)})
        body.addView(row)
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun sessionOptionsDialog(s:SessionPack){
        val used=sessionUsed(s);val booked=sessionBooked(s);val remaining=(s.totalSessions-used).coerceAtLeast(0)
        val actions=arrayOf("Rinomina pacchetto","Termina pacchetto","Elimina pacchetto")
        AlertDialog.Builder(this).setTitle(displaySurnameFirst(s.name)).setMessage("Pacchetto da ${s.totalSessions} sedute • €${s.cost} saldato per intero\nSedute effettuate: $used/${s.totalSessions}\nSedute prenotate: $booked\nSedute rimanenti: $remaining").setItems(actions){_,which->when(which){
            0->{renameSessionPackDialog(s)}
            1->{confirmTerminateSessionPackFromOptions(s)}
            else->{confirmDeleteSessionPackFromOptions(s)}
        }}.setNegativeButton("Chiudi",null).create().also{styleOneUiDialog(it);it.show()}
    }

    private fun confirmTerminateSessionPackFromOptions(s:SessionPack){
        val dialog=AlertDialog.Builder(this).setTitle("Terminare il pacchetto?").setMessage("Il pacchetto verrà spostato nello storico e non sarà più considerato attivo.").setNegativeButton("ANNULLA",null).setPositiveButton("CONFERMA"){_,_->s.active=false;saveData();render();Toast.makeText(this,"Pacchetto terminato.",Toast.LENGTH_SHORT).show()}.create();styleOneUiDialog(dialog);dialog.show()
    }
    private fun confirmDeleteSessionPackFromOptions(s:SessionPack){
        val dialog=AlertDialog.Builder(this).setTitle("Eliminare pacchetto?").setMessage("Stai per eliminare definitivamente il pacchetto di ${displaySurnameFirst(s.name)}. I pagamenti e i dati del pacchetto verranno rimossi, mentre gli appuntamenti resteranno nel calendario.").setNegativeButton("ANNULLA",null).setPositiveButton("ELIMINA"){_,_->addTrashItem("SESSION_PACK",sessionPackTrashPayload(s));sessionPacks.remove(s);appointments.filter{it.sessionPackId==s.id}.forEach{it.sessionPackId=0L};saveData();render();Toast.makeText(this,"Pacchetto spostato nel Cestino.",Toast.LENGTH_SHORT).show()}.create();styleOneUiDialog(dialog);dialog.show()
    }

    private fun renameSessionPackDialog(s:SessionPack,source:AlertDialog?=null){
        val (dialog,outer,body)=packActionDialogBase("Rinomina pacchetto","✎",Color.rgb(20,91,165),Color.rgb(224,238,255),Color.WHITE)
        body.addView(dialogBodyText("Modifica il nome del cliente associato al pacchetto."))
        val input=modernEditText().apply{
            setSingleLine(true)
            setText(s.name)
            setSelection(text.length)
            textSize=16f
            hint="Cognome e Nome"
        }
        body.addView(TextView(this).apply{text="Nuovo nome del cliente/pacchetto";textSize=13f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(75,82,92));setPadding(dp(6),0,dp(6),dp(6))},LinearLayout.LayoutParams(-1,dp(28)))
        body.addView(input,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(dp(2),0,dp(2),dp(14))})
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        row.addView(dialogButton("Annulla",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(210,220,232)){dialog.dismiss()},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(4),0)})
        row.addView(dialogButton("✓  Salva",Color.WHITE,Color.rgb(36,112,225),Color.rgb(36,112,225)){
            val newName=normalizeDisplayName(input.text.toString())
            if(newName.isBlank()){input.error="Inserisci un nome";return@dialogButton}
            val oldKey=identityKey(s.name)
            s.name=newName
            appointments.filter{it.sessionPackId==s.id||identityKey(it.name)==oldKey}.forEach{it.name=newName}
            saveData();dialog.dismiss();source?.dismiss();render()
            if(source!=null) sessionInfoDialog(s)
            Toast.makeText(this,"Pacchetto rinominato.",Toast.LENGTH_SHORT).show()
        },LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(4),0,0,0)})
        body.addView(row)
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun showClientHistory(name:String){
        val oldPacks=packs.filter{!it.active&&identityKey(it.name)==identityKey(name)}
        val oldSessions=sessionPacks.filter{!it.active&&identityKey(it.name)==identityKey(name)}
        if(oldPacks.isEmpty()&&oldSessions.isEmpty()){Toast.makeText(this,"Nessun pacchetto terminato nello storico di $name.",Toast.LENGTH_SHORT).show();return}
        val items=mutableListOf<Pair<String,()->Unit>>()
        oldPacks.forEach{p->items.add("${p.packageType} • ${p.start.format(fmt)} • €${p.total}" to {exportSummary(summaryForPack(p),p.name)})}
        oldSessions.forEach{s->items.add("${s.totalSessions} sedute • ${s.start.format(fmt)} • €${s.cost}" to {exportSummary(summaryForSessionPack(s),s.name)})}
        AlertDialog.Builder(this).setTitle("🗂 Storico • $name").setItems(items.map{it.first}.toTypedArray()){_,which->items[which].second.invoke()}.setNegativeButton("Chiudi",null).show()
    }

    private fun Pack.paidRateIndex(rates:List<Int>):Int=rates.indices.firstOrNull{paid<rates.take(it+1).sum()}?:rates.size

    data class PackStatus(val label:String,val color:Int)
    private fun statusRank(status:PackStatus):Int=when(status.label){"SCADUTA","DA PAGARE"->0;"IN SCADENZA"->1;"IN REGOLA"->2;else->2}
    private fun statusFor(p:Pack,rates:List<Int>,dates:List<LocalDate>):PackStatus{
        val today=LocalDate.now()
        val end=weeklyPackageEnd(p)

        // Logica storica delle rate: la rata successiva influenza lo stato
        // solo a partire dalla sua vera data di scadenza.
        // Prima rata non pagata -> rosso; rata successiva non pagata e
        // arrivata alla data -> giallo; rata pagata -> verde fino alla
        // prossima scadenza. La fine reale del pacchetto resta rossa.
        if(today.isAfter(end)) return PackStatus("SCADUTA",Color.rgb(210,45,45))
        if(p.paid>=p.total) return PackStatus("IN REGOLA",Color.rgb(35,150,70))

        val paidBefore=0
        var paidSoFar=paidBefore
        for(i in rates.indices){
            val installmentAmount=rates[i]
            val installmentPaid=paidSoFar+installmentAmount<=p.paid
            val due=dates.getOrNull(i) ?: p.start.plusWeeks(i.toLong()*4L)
            if(!installmentPaid){
                return if(i==0 || !today.isBefore(due)){
                    if(i==0) PackStatus("DA PAGARE",Color.rgb(210,45,45))
                    else PackStatus("IN SCADENZA",Color.rgb(220,160,20))
                }else{
                    PackStatus("IN REGOLA",Color.rgb(35,150,70))
                }
            }
            paidSoFar+=installmentAmount
        }
        return PackStatus("IN REGOLA",Color.rgb(35,150,70))
    }

    // ---------------- CALENDARIO ----------------
    private fun showCalendarCreateMenu(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(12),dp(18),dp(12))}
        fun option(title:String,subtitle:String,icon:String,action:()->Unit){
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(10),dp(10),dp(10));background=liquidInteractiveSurface(Color.rgb(244,248,252),22,Color.rgb(205,222,239),1);isClickable=true;applyLiquidControlDepth(this)}
            row.addView(TextView(this).apply{text=icon;textSize=22f;gravity=Gravity.CENTER;background=roundedSurface(Color.WHITE,18);setPadding(dp(9),dp(7),dp(9),dp(7))},LinearLayout.LayoutParams(dp(52),dp(52)))
            val texts=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
            texts.addView(TextView(this).apply{text=title;textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(28,38,50))})
            texts.addView(TextView(this).apply{text=subtitle;textSize=12.5f;setTextColor(Color.rgb(88,105,122));setPadding(0,dp(3),0,0)})
            row.addView(texts,LinearLayout.LayoutParams(0,-2,1f));row.addView(TextView(this).apply{text="›";textSize=28f;setTextColor(Color.rgb(120,130,140));gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(28),dp(54)))
            row.setOnClickListener{action()};box.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))})
        }
        option("Nuovo appuntamento","Cliente, pacchetto e tipologia","📅"){showCreateDialogDismissAndRun{appointmentDialog(null)}}
        option("Evento libero","Blocca un periodo senza cliente o pacchetto","✦"){showCreateDialogDismissAndRun{freeEventComposer(calendarWeekStart,null)}}
        val close=Button(this).apply{text="Chiudi";setAllCaps(false);textSize=14f;setTextColor(Color.rgb(20,91,165));background=liquidInteractiveSurface(Color.rgb(238,246,255),20,Color.rgb(202,222,245),1);stateListAnimator=null}
        box.addView(close,LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(10),0,0)})
        val dialog=AlertDialog.Builder(this).setView(box).create();preparePopupBackdrop(dialog);dialog.setOnShowListener{popupBackdropCurrentDialog=dialog;dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28));applyPopupBackdropEffect(dialog);dialog.window?.setDimAmount(0.40f);dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT);animateCalendarDialog(dialog,box)};close.setOnClickListener{dialog.dismiss()};dialog.show()
    }

    private fun showSlotCreationChoice(day:LocalDate,time:String){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(12),dp(18),dp(12))}
        TextView(this).apply{
            text="${day.format(fmt)}  •  $time";textSize=15f;setTypeface(null,android.graphics.Typeface.BOLD);
            setTextColor(Color.rgb(30,65,98));gravity=Gravity.CENTER;setPadding(0,0,0,dp(10))
        }.also{box.addView(it,LinearLayout.LayoutParams(-1,dp(42)))}
        fun option(title:String,subtitle:String,icon:String,action:()->Unit){
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(10),dp(10),dp(10));background=liquidInteractiveSurface(Color.rgb(244,248,252),22,Color.rgb(205,222,239),1);isClickable=true;applyLiquidControlDepth(this)}
            row.addView(TextView(this).apply{text=icon;textSize=22f;gravity=Gravity.CENTER;background=roundedSurface(Color.WHITE,18);setPadding(dp(9),dp(7),dp(9),dp(7))},LinearLayout.LayoutParams(dp(52),dp(52)))
            val texts=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
            texts.addView(TextView(this).apply{text=title;textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(28,38,50))})
            texts.addView(TextView(this).apply{text=subtitle;textSize=12.5f;setTextColor(Color.rgb(88,105,122));setPadding(0,dp(3),0,0)})
            row.addView(texts,LinearLayout.LayoutParams(0,-2,1f));row.addView(TextView(this).apply{text="›";textSize=28f;setTextColor(Color.rgb(120,130,140));gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(28),dp(54)))
            row.setOnClickListener{action()};box.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))})
        }
        option("Appuntamento","Procedi con cliente, pacchetto e tipologia","📅"){showCreateDialogDismissAndRun{appointmentDialogForSlot(day,time)}}
        option("Evento libero","Parti da questo giorno e da questo orario","✦"){showCreateDialogDismissAndRun{freeEventComposer(day,time)}}
        val close=Button(this).apply{text="Chiudi";setAllCaps(false);textSize=14f;setTextColor(Color.rgb(20,91,165));background=liquidInteractiveSurface(Color.rgb(238,246,255),20,Color.rgb(202,222,245),1);stateListAnimator=null}
        box.addView(close,LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(10),0,0)})
        val dialog=AlertDialog.Builder(this).setView(box).create();preparePopupBackdrop(dialog);dialog.setOnShowListener{popupBackdropCurrentDialog=dialog;dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28));applyPopupBackdropEffect(dialog);dialog.window?.setDimAmount(0.40f);dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT);animateCalendarDialog(dialog,box)};close.setOnClickListener{dialog.dismiss()};dialog.show()
    }

    private fun showCreateDialogDismissAndRun(action:()->Unit){
        (popupBackdropCurrentDialog as? Dialog)?.dismiss()
        window.decorView.postDelayed(action,90)
    }

    private fun freeEventComposer(initialDay:LocalDate, initialTime:String?, editingEvent:FreeEvent? = null){
        // Fotografiamo il viewport del calendario prima di aprire l'editor. Alla
        // chiusura useremo questa posizione, invece di lasciare che la nuova
        // composizione del calendario scelga autonomamente una posizione.
        if(currentScreen=="CALENDAR"){
            freeEventReturnScrollX=calendarScrollX.coerceAtLeast(0)
            freeEventReturnScrollY=calendarScrollY.coerceAtLeast(0)
            freeEventReturnWeekStart=calendarWeekStart
            freeEventReturnExpansionDay=calendarEventExpansionDay
        }
        val page=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(12),dp(16),dp(14))}
        val scroll=ScrollView(this).apply{isFillViewport=true;clipToPadding=false;addView(page,ViewGroup.LayoutParams(-1,-2))}
        val hero=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(10),dp(14),dp(10));background=liquidInteractiveSurface(Color.rgb(239,247,255),24,Color.rgb(190,216,242),1);applyLiquidControlDepth(this)}
        hero.addView(TextView(this).apply{text="✦";textSize=25f;gravity=Gravity.CENTER;setTextColor(Color.rgb(20,105,185));background=roundedSurface(Color.WHITE,18);setPadding(dp(11),dp(8),dp(11),dp(8))},LinearLayout.LayoutParams(dp(52),dp(52)))
        val ht=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
        ht.addView(TextView(this).apply{text=if(editingEvent==null)"Evento libero" else "Modifica evento libero";textSize=19f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,55,85))})
        ht.addView(TextView(this).apply{text="Seleziona giorno, orario e colore";textSize=12.5f;setTextColor(Color.rgb(82,104,125));setPadding(0,dp(3),0,0)})
        hero.addView(ht,LinearLayout.LayoutParams(0,-2,1f));page.addView(hero,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})

        val dayScroll=HorizontalScrollView(this).apply{isHorizontalScrollBarEnabled=false;overScrollMode=View.OVER_SCROLL_NEVER}
        val dayRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val dayCards=mutableListOf<TextView>()
        var selectedDay=editingEvent?.date ?: initialDay
        var updateSlots:()->Unit = {}
        fun renderDayCards(){
            dayRow.removeAllViews();dayCards.clear()
            val start=calendarWeekStart
            calendarVisibleDays.forEachIndexed{idx,shown->if(shown){
                val dd=start.plusDays(idx.toLong());val selected=dd==selectedDay
                val card=TextView(this).apply{
                    text="${dayShort(idx)}\n${dd.dayOfMonth}";textSize=if(selected)14f else 12f;gravity=Gravity.CENTER
                    setTypeface(null,if(selected)android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
                    setTextColor(if(selected)Color.rgb(20,82,140) else Color.rgb(80,95,110))
                    background=liquidInteractiveSurface(if(selected)Color.rgb(225,240,255) else Color.rgb(245,247,249),22,if(selected)Color.rgb(151,199,240) else Color.rgb(220,225,230),1)
                    applyLiquidControlDepth(this);setPadding(dp(8),dp(8),dp(8),dp(8));isClickable=true
                }
                val w=if(selected)dp(156) else dp(82);dayCards.add(card)
                dayRow.addView(card,LinearLayout.LayoutParams(w,dp(66)).apply{setMargins(dp(3),0,dp(3),0)})
                card.setOnClickListener{selectedDay=dd;animateDaySelection(dayRow,card,dayCards);renderDayCards();updateSlots()}
            }}
            dayScroll.post{dayScroll.smoothScrollTo((dayCards.indexOfFirst{it.text.toString().contains("${selectedDay.dayOfMonth}")}*dp(88)).coerceAtLeast(0),0)}
        }
        dayScroll.addView(dayRow,ViewGroup.LayoutParams(-2,-2));page.addView(dayScroll,LinearLayout.LayoutParams(-1,dp(74)).apply{setMargins(0,0,0,dp(10))})

        val title=modernEditText().apply{
            hint="Titolo evento"
            setSingleLine(true)
            setText(editingEvent?.title ?: "")
            // Il campo deve poter ricevere il focus indipendentemente dall'ordine
            // con cui l'utente compila l'editor (titolo prima o orario prima).
            isFocusable=true
            isFocusableInTouchMode=true
            isClickable=true
        }
        page.addView(TextView(this).apply{text="Titolo";textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,74,80));setPadding(dp(2),0,0,dp(5))})
        page.addView(title,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(10))})
        val selectedLabel=TextView(this).apply{textSize=13f;setTextColor(Color.rgb(45,75,105));setPadding(dp(12),dp(10),dp(12),dp(10));background=liquidInteractiveSurface(Color.rgb(241,247,253),18,Color.rgb(202,222,242),1);gravity=Gravity.CENTER_VERTICAL}
        page.addView(selectedLabel,LinearLayout.LayoutParams(-1,dp(46)).apply{setMargins(0,0,0,dp(10))})

        val colorLabel=TextView(this).apply{text="Colore evento";textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,74,80));setPadding(dp(2),0,0,dp(5))}
        page.addView(colorLabel)
        val palette=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val colors=listOf(
            "Blu" to Color.rgb(92,120,190),
            "Azzurro" to Color.rgb(50,145,210),
            "Viola" to Color.rgb(135,105,195),
            "Verde" to Color.rgb(65,155,105),
            "Ambra" to Color.rgb(210,150,45),
            "Rosso" to Color.rgb(205,75,75)
        )
        var selectedColor=editingEvent?.color ?: freeEventDefaultColor
        val colorButtons=mutableListOf<TextView>()
        val defaultPreview=TextView(this).apply{text="●";textSize=20f;setTextColor(selectedColor);gravity=Gravity.CENTER;alpha=.72f;isClickable=false}
        fun refreshColorButtons(){
            colorButtons.forEach{b->
                val c=(b.tag as Int);b.alpha=if(c==selectedColor)1f else 0.45f
                b.background=liquidInteractiveSurface(Color.argb(34,Color.red(c),Color.green(c),Color.blue(c)),18,c,if(c==selectedColor)2 else 1)
                b.setTextColor(c)
            }
        }
        colors.forEach{(label,c)->
            val b=TextView(this).apply{
                text="●";textSize=23f;gravity=Gravity.CENTER;tag=c;contentDescription=label;isClickable=true
                setPadding(dp(4),dp(4),dp(4),dp(4));setOnClickListener{selectedColor=c;refreshColorButtons();defaultPreview.setTextColor(selectedColor)}
            }
            colorButtons.add(b);palette.addView(b,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(2),0,dp(2),0)})
        }
        refreshColorButtons()
        page.addView(palette,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(5))})
        val defaultRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val defaultCheck=CheckBox(this).apply{isChecked=false;text="Imposta questo colore come predefinito";textSize=11.5f;setTextColor(Color.rgb(72,88,104));buttonTintList=android.content.res.ColorStateList.valueOf(Color.rgb(70,125,185))}
        defaultCheck.setOnCheckedChangeListener{_,checked->defaultPreview.alpha=if(checked)1f else .72f}
        defaultRow.addView(defaultCheck,LinearLayout.LayoutParams(0,dp(40),1f))
        defaultRow.addView(defaultPreview,LinearLayout.LayoutParams(dp(38),dp(40)))
        page.addView(defaultRow,LinearLayout.LayoutParams(-1,dp(42)).apply{setMargins(0,0,0,dp(8))})

        fun timeValues():List<String>{val out=mutableListOf<String>();var m=7*60;val end=22*60;while(m<=end){out.add(String.format("%02d:%02d",m/60,m%60));m+=freeEventTimeStep};return out}
        val times=timeValues()
        var selectedStartTime=editingEvent?.startTime ?: initialTime ?: times.first()
        var selectedEndTime=editingEvent?.endTime ?: times.getOrNull((times.indexOf(selectedStartTime).takeIf{it>=0}?:0)+1) ?: times.getOrElse(1){times.first()}
        if(selectedStartTime !in times) selectedStartTime=times.first()
        if(selectedEndTime !in times) selectedEndTime=times.getOrNull((times.indexOf(selectedStartTime)+1).coerceAtMost(times.lastIndex)) ?: selectedStartTime

        fun timeField(value:String)=TextView(this).apply{
            text=value;textSize=16f;gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(28,62,95));
            background=liquidInteractiveSurface(Color.rgb(242,248,255),18,Color.rgb(194,216,238),1);isClickable=true;applyLiquidControlDepth(this);
            setPadding(dp(8),0,dp(8),0)
        }
        val startField=timeField(selectedStartTime)
        val endField=timeField(selectedEndTime)
        // I popup secondari non devono MAI poter modificare il viewport dell'editor.
        // Il vecchio approccio correggeva lo scroll dopo che Android lo aveva già
        // spostato, producendo il micro-salto visibile di 2-3 mm. Qui blocchiamo
        // anche l'input dello ScrollView durante tutta la vita del popup secondario.
        var editorScrollFrozen=false
        var frozenEditorScrollY=scroll.scrollY
        var previousOverScrollMode=scroll.overScrollMode
        fun freezeEditorScroll(){
            frozenEditorScrollY=scroll.scrollY
            editorScrollFrozen=true
            previousOverScrollMode=scroll.overScrollMode
            scroll.stopNestedScroll()
            scroll.overScrollMode=View.OVER_SCROLL_NEVER
            // Blocchiamo esclusivamente il movimento verticale del contenitore.
            // NON blocchiamo i discendenti e NON intercettiamo i touch: al rientro
            // dal selettore orario il campo Titolo deve restare immediatamente
            // cliccabile e focalizzabile anche se l'orario è stato scelto per primo.
            scroll.setOnScrollChangeListener{_,_,y,_,_->
                if(editorScrollFrozen && y!=frozenEditorScrollY) scroll.scrollTo(0,frozenEditorScrollY)
            }
            scroll.post{if(editorScrollFrozen)scroll.scrollTo(0,frozenEditorScrollY)}
        }
        fun unfreezeEditorScroll(){
            editorScrollFrozen=false
            scroll.setOnScrollChangeListener(null)
            scroll.overScrollMode=previousOverScrollMode
            scroll.scrollTo(0,frozenEditorScrollY)
            scroll.post{scroll.scrollTo(0,frozenEditorScrollY)}
            // Rimuoviamo eventuale focus residuo dal popup senza impedire ai campi
            // dell'editor di ricevere il prossimo tocco.
            title.isFocusableInTouchMode=true
            title.isClickable=true
        }
        fun showFreeTimePicker(label:String,current:String,values:List<String>,fieldToHide:TextView,onSelected:(String)->Unit){
            // Quando il selettore si apre, nascondiamo visivamente ENTRAMBI i campi
            // orario dell'Evento libero. Lo spazio di entrambi resta invariato, così
            // il layout dell'editor non si sposta e il picker rimane l'unico focus
            // visivo senza sovrapporsi ai valori di Inizio/Fine.
            startField.visibility=View.INVISIBLE
            endField.visibility=View.INVISIBLE
            freezeEditorScroll()
            var selectedIndex=values.indexOf(current).coerceIn(0,(values.size-1).coerceAtLeast(0))
            val picker=AppointmentWheelView(
                this,
                values,
                selectedIndex
            ){index -> selectedIndex=index
            }
            val box=LinearLayout(this).apply{
                orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_HORIZONTAL
                setPadding(dp(20),dp(18),dp(20),dp(8))
                background=liquidInteractiveSurface(Color.argb(238,242,249,255),28,Color.rgb(188,215,240),1)
                elevation=dp(10).toFloat()
            }
            box.addView(TextView(this).apply{text=label;textSize=22f;gravity=Gravity.CENTER;setTextColor(Color.rgb(28,30,33))},LinearLayout.LayoutParams(-1,dp(42)))
            box.addView(TextView(this).apply{text="Intervallo suggerito: ogni $freeEventTimeStep minuti";textSize=11.5f;gravity=Gravity.CENTER;setTextColor(Color.rgb(95,108,122))},LinearLayout.LayoutParams(-1,dp(28)).apply{setMargins(0,0,0,dp(4))})
            // La ruota è una vista autonoma: nessun overlay sopra un NumberPicker,
            // quindi non ci sono duplicazioni del testo. La lente è ottenuta
            // direttamente dal ridisegno non lineare delle righe.
            box.addView(picker,LinearLayout.LayoutParams(dp(190),dp(190)).apply{gravity=Gravity.CENTER})
            val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            fun pickerButton(labelText:String)=TextView(this).apply{text=labelText;textSize=13.5f;gravity=Gravity.CENTER;setTextColor(Color.rgb(0,125,110));setTypeface(null,android.graphics.Typeface.BOLD);isClickable=true;background=liquidInteractiveSurface(Color.argb(70,255,255,255),18,Color.rgb(185,215,225),1);applyLiquidControlDepth(this)}
            val cancelPicker=pickerButton("Annulla")
            val confirmPicker=pickerButton("Conferma")
            buttons.addView(cancelPicker,LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(0,dp(4),dp(5),0)})
            buttons.addView(confirmPicker,LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(dp(5),dp(4),0,0)})
            box.addView(buttons,LinearLayout.LayoutParams(-1,dp(54)))
            val td=AlertDialog.Builder(this).setView(box).create()
            preparePopupBackdrop(td)
            td.setOnShowListener{
                popupBackdropCurrentDialog=td
                td.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                td.window?.setDimAmount(0.40f)
                td.window?.setLayout((resources.displayMetrics.widthPixels*0.88f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT)
                td.window?.decorView?.setBackgroundColor(Color.TRANSPARENT)
                box.alpha=0f;box.scaleX=0.94f;box.scaleY=0.94f;box.translationY=dp(18).toFloat()
                box.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f).setDuration(300L).setInterpolator(android.view.animation.DecelerateInterpolator()).start()
                freezeEditorScroll()
            }
            td.setOnDismissListener{
                // Ripristino entrambi i campi con il loro spazio originale.
                startField.visibility=View.VISIBLE
                endField.visibility=View.VISIBLE
                unfreezeEditorScroll()
                removePopupBackdropDialog(td)
            }
            fun closePicker(){box.animate().alpha(0f).scaleX(0.97f).scaleY(0.97f).translationY(dp(8).toFloat()).setDuration(180L).withEndAction{td.dismiss()}.start()}
            cancelPicker.setOnClickListener{closePicker()}
            confirmPicker.setOnClickListener{onSelected(values[picker.selectedIndex]);closePicker()}
            td.show()
        }
        startField.setOnClickListener{showFreeTimePicker("Ora di inizio",selectedStartTime,times,startField){selectedStartTime=it;startField.text=it;updateSlots()}}
        endField.setOnClickListener{showFreeTimePicker("Ora di fine",selectedEndTime,times,endField){selectedEndTime=it;endField.text=it;updateSlots()}}
        updateSlots={
            selectedLabel.text="${selectedDay.format(fmt)}  •  scegli inizio e fine"
            startField.text=selectedStartTime
            endField.text=selectedEndTime
        }
        renderDayCards();updateSlots()
        val timeRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        fun timeBlock(label:String,field:TextView):LinearLayout{val b=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(2),0,dp(2),0)};b.addView(TextView(this@MainActivity).apply{text=label;textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,74,80));setPadding(0,0,0,dp(5))});b.addView(field,LinearLayout.LayoutParams(-1,dp(50)));return b}
        timeRow.addView(timeBlock("Inizio",startField),LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(0,0,dp(5),0)});timeRow.addView(timeBlock("Fine",endField),LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(dp(5),0,0,0)});page.addView(timeRow,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})
        val hint=TextView(this).apply{text="L'evento non consuma sedute e non genera recuperi.";textSize=12f;setTextColor(Color.rgb(88,105,122));setPadding(dp(12),dp(9),dp(12),dp(9));background=liquidInteractiveSurface(Color.rgb(247,249,251),16,Color.rgb(220,225,230),1)};page.addView(hint,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})

        lateinit var dialog: AlertDialog
        var refreshCalendarAfterDismiss = false
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        if(editingEvent!=null){
            val delete=TextView(this).apply{text="🗑 Elimina";textSize=13f;setTextColor(Color.rgb(190,65,65));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);background=liquidInteractiveSurface(Color.rgb(255,244,244),20,Color.rgb(235,190,190),1);isClickable=true;applyLiquidControlDepth(this)}
            actions.addView(delete,LinearLayout.LayoutParams(0,dp(50),0.9f).apply{setMargins(0,0,dp(5),0)})
            delete.setOnClickListener{
                val (confirm,outer,body)=packActionDialogBase(
                    "Eliminare evento?",
                    "WARNING_TRIANGLE",
                    Color.rgb(205,120,0),
                    Color.rgb(255,236,198),
                    Color.rgb(255,252,246)
                )
                // Solo questa finestra: superficie Niki UI Glass, senza modificare
                // nessun altro dialog dell'app. La struttura e la logica restano identiche.
                outer.background = nikiDeleteDialogGlassSurface()
                outer.elevation = dp(8).toFloat()
                body.addView(dialogBodyText("L'evento verrà rimosso dal calendario."))
                val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                buttons.addView(dialogButton("Annulla",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(210,220,232)){confirm.dismiss()},
                    LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(5),0)})
                buttons.addView(dialogButton("🗑  Elimina",Color.WHITE,Color.rgb(205,45,55),Color.rgb(205,45,55)){
                    // Rimuoviamo l'evento dai dati, ma NON ricostruiamo il calendario
                    // mentre la finestra Glass sta ancora chiudendosi. La pagina resta
                    // fisicamente ferma; il calendario viene ricreato una sola volta
                    // dopo il dismiss completo della finestra di modifica.
                    // L'evento viene rimosso solo dai dati. Non tocchiamo il
                    // viewport del calendario finché entrambe le finestre non sono
                    // state chiuse.
                    // Conserviamo una copia solo per la micro-animazione di uscita.
                    // L'evento viene comunque eliminato subito dai dati persistenti.
                    calendarEventRemovalId = editingEvent.id
                    calendarEventRemovalSnapshot = editingEvent.copy()
                    calendarEventAnimationDay = editingEvent.date
                    calendarEventCollapseAnimate = true
                    calendarEventExpansionAnimate = false
                    // L'evento è stato eliminato: la colonna Evento libero deve
                    // collassare subito. refreshCalendarFreeEventsInPlace() usa
                    // freeEventReturnExpansionDay per ricostruire l'ancoraggio
                    // della vecchia geometria, quindi possiamo togliere lo spazio
                    // senza perdere il giorno/viewport che l'utente stava guardando.
                    calendarEventExpansionDay = null
                    freeEvents.removeAll{it.id==editingEvent.id}
                    saveData()
                    refreshCalendarAfterDismiss = true
                    confirm.dismiss()
                    dialog.dismiss()
                },LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(5),0,0,0)})
                body.addView(buttons,LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(10),0,0)})
                // Congeliamo il viewport dell'editor finché la conferma è aperta.
                scroll.clearFocus()
                scroll.animate().cancel()
                scroll.stopNestedScroll()
                scroll.fling(0)
                scroll.translationY=0f
                page.translationY=0f
                freezeEditorScroll()
                confirm.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING)
                confirm.setOnShowListener{
                    popupBackdropCurrentDialog=confirm
                    confirm.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING)
                    confirm.window?.decorView?.clearFocus()
                    freezeEditorScroll()
                }
                confirm.show()
                // Forziamo la larghezza SOLO dopo show(): su alcuni device il Dialog
                // misura il contenuto a WRAP_CONTENT e ignora la misura impostata
                // durante onShow, producendo la finestra stretta vista nel test.
                confirm.window?.setLayout(
                    (resources.displayMetrics.widthPixels * 0.92f).toInt(),
                    WindowManager.LayoutParams.WRAP_CONTENT
                )
                confirm.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING)
                confirm.window?.decorView?.clearFocus()
                // Non ricatturiamo la posizione dopo show(): quella è proprio la fase
                // in cui Android può tentare il micro-scroll. Manteniamo il valore
                // fotografato prima dell'apertura del popup.
                confirm.setOnDismissListener{removePopupBackdropDialog(confirm);unfreezeEditorScroll()}
            }
        }
        val cancel=TextView(this).apply{text="Annulla";textSize=14f;setTextColor(Color.rgb(20,91,165));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(220,226,234),1);isClickable=true;applyLiquidControlDepth(this)}
        val save=TextView(this).apply{text=if(editingEvent==null)"✓ Crea evento" else "✓ Salva modifiche";textSize=14f;setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);background=liquidInteractiveSurface(Color.rgb(232,243,255),20,Color.rgb(188,211,238),1);isClickable=true;applyLiquidControlDepth(this)}
        actions.addView(cancel,LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(dp(5),0,dp(5),0)})
        actions.addView(save,LinearLayout.LayoutParams(0,dp(50),1f))
        page.addView(actions,LinearLayout.LayoutParams(-1,dp(50)))
        dialog=AlertDialog.Builder(this).setView(scroll).create();preparePopupBackdrop(dialog)
        // Impostiamo ADJUST_NOTHING già prima di mostrare la finestra: il sistema
        // non deve poter fare nemmeno un singolo re-layout del contenuto quando
        // sopra compare il selettore orario o la conferma di eliminazione.
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING)
        dialog.setOnDismissListener{
            removePopupBackdropDialog(dialog)
            if(refreshCalendarAfterDismiss){
                refreshCalendarAfterDismiss=false
                window.decorView.postDelayed({
                    freeEventReturnWeekStart?.let { calendarWeekStart=it }
                    freeEventReturnScrollX?.let { calendarScrollX=it.coerceAtLeast(0) }
                    freeEventReturnScrollY?.let { calendarScrollY=it.coerceAtLeast(0) }
                    // IMPORTANTE: non richiamiamo calendarScreen(). Il calendario
                    // sottostante resta lo stesso View tree; aggiorniamo solo le
                    // colonne coinvolte. In questo modo il dialog non può provocare
                    // il "salto verso l'alto" del contenuto della pagina.
                    refreshCalendarFreeEventsInPlace()
                    freeEventReturnScrollX=null
                    freeEventReturnScrollY=null
                    freeEventReturnWeekStart=null
                    freeEventReturnExpansionDay=null
                    calendarEventAnimationDay=null
                },220L)
            }
        }
        dialog.setOnShowListener{
            popupBackdropCurrentDialog=dialog
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28))
            applyPopupBackdropEffect(dialog)
            dialog.window?.setDimAmount(0.40f)
            // L'editor non deve mai essere riposizionato quando compare un
            // secondo popup (selettore orario/conferma eliminazione).
            dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING)
            dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.94f).toInt(),(resources.displayMetrics.heightPixels*0.84f).toInt())
            dialog.window?.decorView?.minimumHeight=(resources.displayMetrics.heightPixels*0.84f).toInt()
            animateCalendarDialog(dialog,scroll)
            scroll.postDelayed({dayCards.firstOrNull{it.text.toString().contains("${selectedDay.dayOfMonth}")}?.let{animateDaySelection(dayRow,it,dayCards)}},250L)
        }
        cancel.setOnClickListener{dialog.dismiss()}
        save.setOnClickListener{
            val st=selectedStartTime
            val en=selectedEndTime
            if(times.indexOf(en)<=times.indexOf(st)){Toast.makeText(this,"L'orario di fine deve essere successivo all'inizio.",Toast.LENGTH_SHORT).show();return@setOnClickListener}
            val t=title.text.toString().trim().ifBlank{"Evento libero"}
            if(defaultCheck.isChecked) freeEventDefaultColor=selectedColor
            if(editingEvent!=null){
                editingEvent.title=t;editingEvent.date=selectedDay;editingEvent.startTime=st;editingEvent.endTime=en;editingEvent.color=selectedColor
                calendarEventExpansionDay=selectedDay
            }else{
                freeEvents.add(FreeEvent(nextFreeEventId++,t,selectedDay,st,en,selectedColor))
                calendarEventExpansionDay=selectedDay
            }
            // Il calendario viene aggiornato in-place dopo la chiusura del dialog.
            // Questa volta lasciamo attiva la micro-animazione del chip appena creato:
            // niente comparsa istantanea e nessuna ricostruzione visibile della pagina.
            calendarEventExpansionAnimate=true
            calendarEventCollapseAnimate=false
            calendarEventAnimationDay=selectedDay
            calendarEventRemovalId=null
            calendarEventRemovalSnapshot=null
            saveData()
            refreshCalendarAfterDismiss=true
            dialog.dismiss()
        }
        dialog.show()
    }

    /**
     * Aggiorna solo la parte del calendario relativa agli eventi liberi.
     * Il View tree principale non viene ricreato: questo evita il relayout globale
     * che faceva comprimere/spostare il contenuto sotto il dialog.
     */
    private fun refreshCalendarFreeEventsInPlace(){
        if(currentScreen!="CALENDAR") return
        val header=calendarHeaderWeekView ?: return
        val body=calendarBodyWeekView ?: return
        val headerScroll=calendarHeaderScrollView ?: return
        val bodyScroll=calendarBodyScrollView ?: return
        val vertical=calendarVerticalScrollView ?: return
        val visibleDays=mutableListOf<Int>()
        calendarVisibleDays.forEachIndexed{idx,shown->if(shown) visibleDays.add(idx)}
        if(header.childCount!=visibleDays.size || body.childCount!=visibleDays.size) return

        val savedX=freeEventReturnScrollX ?: calendarScrollX
        val savedY=freeEventReturnScrollY ?: calendarScrollY
        val base=(dp((178f*calendarZoom).toInt())).coerceAtLeast(dp(132))
        val extra=dp(calendarEventExpansionDp)
        val transitionDay=calendarEventAnimationDay
        val creation=calendarEventExpansionAnimate && transitionDay!=null
        val removal=calendarEventRemovalId!=null && transitionDay!=null

        // Prima del cambio catturiamo le posizioni attuali. In questo modo la nuova
        // geometria può essere animata senza ricostruire/trascinare artificialmente
        // le colonne: in apertura aumentiamo davvero la larghezza del giorno;
        // in chiusura la riduciamo davvero.
        val oldChildLefts=IntArray(visibleDays.size){pos->body.getChildAt(pos)?.left ?: 0}
        val oldHeaderLefts=IntArray(visibleDays.size){pos->header.getChildAt(pos)?.left ?: 0}

        header.suppressLayout(true)
        body.suppressLayout(true)
        vertical.suppressLayout(true)
        try{
            visibleDays.forEachIndexed{pos,dayIndex->
                val day=calendarWeekStart.plusDays(dayIndex.toLong())
                // Durante la cancellazione teniamo temporaneamente la colonna Evento
                // libera visibile: l'evento può uscire mentre la colonna si richiude.
                val renderExpanded = calendarEventExpansionDay==day || (removal && transitionDay==day)
                val width=base+if(renderExpanded)extra else 0
                header.removeViewAt(pos)
                header.addView(dayHeader(day),pos,LinearLayout.LayoutParams(width,-2))
                body.removeViewAt(pos)
                body.addView(dayColumn(day,false),pos,LinearLayout.LayoutParams(width,-2))
            }
        }finally{
            vertical.suppressLayout(false)
            header.suppressLayout(false)
            body.suppressLayout(false)
        }

        if(creation || removal){
            val transitionIndex=visibleDays.indexOfFirst{calendarWeekStart.plusDays(it.toLong())==transitionDay}
            if(transitionIndex>=0){
                val selectedBody=body.getChildAt(transitionIndex)
                val selectedHeader=header.getChildAt(transitionIndex)
                val targetExpanded=creation
                val fromWidth=if(targetExpanded) base else base+extra
                val toWidth=if(targetExpanded) base+extra else base

                // Il giorno dell'evento resta il punto fermo: non viene tradotto.
                // Si apre/chiude realmente la sua larghezza, così le colonne successive
                // vengono spinte/richiamate dal layout in modo naturale.
                fun animateWidth(view:View?, duration:Long, delay:Long=0L){
                    if(view==null) return
                    val lp=view.layoutParams as? LinearLayout.LayoutParams ?: return
                    lp.width=fromWidth
                    view.layoutParams=lp
                    ValueAnimator.ofInt(fromWidth,toWidth).apply{
                        this.duration=duration
                        this.startDelay=delay
                        interpolator=android.view.animation.PathInterpolator(0.16f,0.82f,0.22f,1f)
                        addUpdateListener{
                            val p=view.layoutParams as LinearLayout.LayoutParams
                            p.width=it.animatedValue as Int
                            view.layoutParams=p
                        }
                        start()
                    }
                }

                animateWidth(selectedHeader,560L)
                animateWidth(selectedBody,560L)

                // Le colonne successive non vengono più traslate con una seconda
                // animazione: il loro movimento nasce direttamente dall'apertura/
                // chiusura della colonna attiva. È esattamente l'effetto desiderato:
                // evento entra + colonne si aprono, evento esce + colonne si chiudono.
                visibleDays.indices.filter{it>transitionIndex}.forEach{pos->
                    body.getChildAt(pos)?.translationX=0f
                    header.getChildAt(pos)?.translationX=0f
                }
            }
        }

        header.post{
            val maxH=(header.width-headerScroll.width).coerceAtLeast(0)
            val maxB=(body.width-bodyScroll.width).coerceAtLeast(0)
            val maxScroll=minOf(maxH,maxB)
            val finalX=savedX.coerceIn(0,maxScroll)
            calendarScrollX=finalX
            headerScroll.scrollTo(finalX,0)
            bodyScroll.scrollTo(finalX,0)
            vertical.scrollTo(0,savedY.coerceAtLeast(0))

            header.post{
                val maxH2=(header.width-headerScroll.width).coerceAtLeast(0)
                val maxB2=(body.width-bodyScroll.width).coerceAtLeast(0)
                val x2=finalX.coerceIn(0,minOf(maxH2,maxB2))
                headerScroll.scrollTo(x2,0)
                bodyScroll.scrollTo(x2,0)
                vertical.scrollTo(0,savedY.coerceAtLeast(0))
                calendarScrollX=x2

                if(creation){
                    header.postDelayed({
                        calendarEventExpansionAnimate=false
                        calendarEventCollapseAnimate=false
                        calendarEventAnimationDay=null
                    },620L)
                }
                if(removal){
                    header.postDelayed({
                        calendarEventRemovalId=null
                        calendarEventRemovalSnapshot=null
                        calendarEventCollapseAnimate=false
                        calendarEventAnimationDay=null
                        refreshCalendarFreeEventsInPlace()
                    },680L)
                }
            }
        }
    }

    private fun dialogDismissAndRefresh(){
        (popupBackdropCurrentDialog as? Dialog)?.dismiss()
        window.decorView.postDelayed({calendarScreen()},90)
    }

    private fun animateDaySelection(row:LinearLayout, selected:View, cards:List<View>){
        cards.forEach{v->val lp=v.layoutParams as? LinearLayout.LayoutParams ?: return@forEach;val target=if(v===selected)dp(156) else dp(82);v.animate().scaleX(if(v===selected)1f else 0.97f).alpha(if(v===selected)1f else 0.82f).setDuration(220).start();if(lp.width!=target){val from=lp.width.coerceAtLeast(1);ValueAnimator.ofInt(from,target).apply{duration=280;addUpdateListener{lp.width=it.animatedValue as Int;v.layoutParams=lp};start()}}}
        row.animate().translationX(dp(8).toFloat()).setDuration(110).withEndAction{row.animate().translationX(0f).setDuration(190).start()}.start()
    }

    private fun calendarScreen(){
        currentScreen = "CALENDAR"
        lastHomeBackAt = 0L
        detachSettingsOverlay()
        trashReturnToSettings=false
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),dp(12),dp(10),dp(8));background=calendarGlassBackground()}

        fun changeCalendarWeekAnimated(direction:Int){
            if (calendarWeekAnimationDirection != 0) return
            calendarWeekAnimationDirection = direction
            root.animate().translationX((-direction * dp(70)).toFloat()).alpha(0f).setDuration(180).withEndAction{
                calendarWeekStart=if(direction<0)calendarWeekStart.minusWeeks(1) else calendarWeekStart.plusWeeks(1)
                calendarAutoFocusOnOpen=false
                calendarSwipeArmed=0
                calendarScrollX=0
                calendarScrollY=0
                calendarScreen()
            }.start()
        }

        fun calendarGlassButton(label:String):Button = Button(this).apply{
            text=label; textSize=13.5f; setAllCaps(false); setTextColor(Color.rgb(35,60,82));
            minHeight=0; minimumHeight=0; setPadding(0,0,0,0); stateListAnimator=null
            background=liquidInteractiveSurface(Color.rgb(238,241,243),18,Color.rgb(188,200,210),1)
            applyLiquidControlDepth(this)
        }

        fun calendarActionButton(key:String):View=when(key){
            "APPT"->Button(this).apply{
                setTextColor(Color.rgb(48,72,92))
                background=liquidInteractiveSurface(Color.rgb(239,242,244),20,Color.rgb(190,202,211),1)
                applyLiquidControlDepth(this)
                stateListAnimator=null
                contentDescription="＋ Appuntamento"
                textSize=15f
                val person=whitePersonDrawable().apply{setBounds(0,0,dp(17),dp(17))}
                val label=android.text.SpannableString("＋  \uFFFC")
                label.setSpan(android.text.style.ImageSpan(person,android.text.style.ImageSpan.ALIGN_CENTER),3,4,android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                text=label
                setOnClickListener{showCalendarCreateMenu()}
            }
            "PREV"->calendarGlassButton("‹").apply{setOnClickListener{changeCalendarWeekAnimated(-1)}}
            "NEXT"->calendarGlassButton("›").apply{setOnClickListener{changeCalendarWeekAnimated(1)}}
            "TODAY"->calendarGlassButton("Oggi").apply{setOnClickListener{calendarWeekStart=LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));calendarAutoFocusOnOpen=true;calendarSwipeArmed=0;calendarScreen()}}
            else->Button(this).apply{
                text="🔎 Cerca"; textSize=15f; setAllCaps(false); setTextColor(Color.rgb(48,72,92));
                minHeight=0; minimumHeight=0; stateListAnimator=null;
                background=liquidInteractiveSurface(Color.rgb(239,242,244),20,Color.rgb(190,202,211),1);
                applyLiquidControlDepth(this); setOnClickListener{calendarSearchScreen()}
            }
        }
        fun addButtonBar(keys:List<String>,top:Boolean){
            if(keys.isEmpty())return
            val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            keys.forEach{key->bar.addView(calendarActionButton(key),LinearLayout.LayoutParams(0,dp(46),1f).apply{setMargins(dp(3),0,dp(3),0)})}
            if(top)root.addView(bar,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(4))})
            else root.addView(bar,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(4),0,0)})
        }
        addButtonBar(calendarTopButtons,true)

        val titleRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val visibleOffsets=mutableListOf<Int>();calendarVisibleDays.forEachIndexed{i,shown->if(shown)visibleOffsets.add(i)};val firstVisibleOffset=visibleOffsets.firstOrNull()?:0;val lastVisibleOffset=visibleOffsets.lastOrNull()?:4;titleRow.addView(TextView(this).apply{text="${calendarWeekStart.plusDays(firstVisibleOffset.toLong()).format(fmt)}  →  ${calendarWeekStart.plusDays(lastVisibleOffset.toLong()).format(fmt)}";textSize=14f;setTextColor(Color.DKGRAY);gravity=Gravity.CENTER;setPadding(0,dp(4),0,dp(8))},LinearLayout.LayoutParams(0,dp(34),1f))
        val zoomLabel=TextView(this).apply{text="${(calendarZoom*100).toInt()}%";textSize=12f;setTextColor(Color.GRAY);gravity=Gravity.CENTER}
        titleRow.addView(buttonStyle("−").apply{setOnClickListener{calendarZoom=(calendarZoom-0.25f).coerceAtLeast(0.75f);calendarAutoFocusOnOpen=false;calendarScreen()}},LinearLayout.LayoutParams(dp(44),dp(34)))
        titleRow.addView(zoomLabel,LinearLayout.LayoutParams(dp(44),dp(34)))
        titleRow.addView(buttonStyle("+").apply{setOnClickListener{calendarZoom=(calendarZoom+0.25f).coerceAtMost(1.75f);calendarAutoFocusOnOpen=false;calendarScreen()}},LinearLayout.LayoutParams(dp(44),dp(34)))
        root.addView(titleRow,LinearLayout.LayoutParams(-1,dp(38)))

        val columnWidth=(dp(178)*calendarZoom).toInt().coerceAtLeast(dp(132))

        // Testata dei giorni fissa: resta sempre visibile mentre le fasce scorrono verticalmente.
        val headerHorizontal=CalendarHorizontalScrollView(this).apply{isFillViewport=false;isHorizontalScrollBarEnabled=false}
        val headerWeek=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        calendarHeaderScrollView=headerHorizontal
        calendarHeaderWeekView=headerWeek
        calendarVisibleDays.forEachIndexed{i,shown->if(shown){
            val day=calendarWeekStart.plusDays(i.toLong())
            val w=if(calendarEventExpansionDay==day) columnWidth+dp(calendarEventExpansionDp) else columnWidth
            headerWeek.addView(dayHeader(day),LinearLayout.LayoutParams(w,-2))
        }}
        headerHorizontal.addView(headerWeek,ViewGroup.LayoutParams(-2,-2))
        root.addView(headerHorizontal,LinearLayout.LayoutParams(-1,(dp(62)*calendarZoom).toInt()))

        val verticalScroll=ScrollView(this).apply{isFillViewport=false}
        val bodyHorizontal=CalendarHorizontalScrollView(this).apply{isFillViewport=false;isHorizontalScrollBarEnabled=true}
        val week=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        calendarVerticalScrollView=verticalScroll
        calendarBodyScrollView=bodyHorizontal
        calendarBodyWeekView=week
        calendarVisibleDays.forEachIndexed{i,shown->if(shown){
            val day=calendarWeekStart.plusDays(i.toLong())
            val w=if(calendarEventExpansionDay==day) columnWidth+dp(calendarEventExpansionDp) else columnWidth
            week.addView(dayColumn(day,false),LinearLayout.LayoutParams(w,-2))
        }}
        bodyHorizontal.addView(week,ViewGroup.LayoutParams(-2,-2))
        verticalScroll.addView(bodyHorizontal,ViewGroup.LayoutParams(-2,-2))

        // La testata e il corpo scorrono orizzontalmente insieme.
        var syncingHeader=false
        var syncingBody=false
        headerHorizontal.setOnScrollChangeListener{_,scrollX,_,_,_->if(!syncingHeader){syncingBody=true;bodyHorizontal.scrollTo(scrollX,0);syncingBody=false};calendarScrollX=scrollX}
        bodyHorizontal.setOnScrollChangeListener{_,scrollX,_,_,_->if(!syncingBody){syncingHeader=true;headerHorizontal.scrollTo(scrollX,0);syncingHeader=false};calendarScrollX=scrollX}
        verticalScroll.setOnScrollChangeListener{_,_,scrollY,_,_->calendarScrollY=scrollY}

        // Cambio settimana con gesto continuo sui bordi.
        // Il controllo viene fatto dalla HorizontalScrollView stessa, così il gesto
        // non viene perso durante l'intercettazione dello scroll nativo.
        val weekChange: (Int) -> Unit = { direction ->
            val currentRoot = root
            currentRoot.animate().translationX((-direction * dp(70)).toFloat()).alpha(0f).setDuration(180).withEndAction {
                calendarWeekStart=if(direction<0)calendarWeekStart.minusWeeks(1) else calendarWeekStart.plusWeeks(1)
                calendarAutoFocusOnOpen=false
                calendarSwipeArmed=0
                calendarScrollX=0
                calendarScrollY=0
                calendarWeekAnimationDirection=direction
                calendarScreen()
            }.start()
        }
        bodyHorizontal.onEdgeWeekChange = weekChange
        headerHorizontal.onEdgeWeekChange = weekChange

        val today=LocalDate.now()
        val currentWeekStart=today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        var initialHorizontalScroll = calendarScrollX.coerceAtLeast(0)
        var initialVerticalScroll = calendarScrollY.coerceAtLeast(0)
        if(calendarAutoFocusOnOpen && calendarWeekStart==currentWeekStart){
            val todayOffset=today.dayOfWeek.value-1
            val visibleBeforeToday=calendarVisibleDays.take(todayOffset).count{it}
            val nowMinutes=LocalTime.now().hour*60+LocalTime.now().minute
            val slotIndex=((nowMinutes-(7*60))/calendarSlotDuration).coerceIn(0,calendarSlotCount()-1)
            val slotHeight=(dp(86)*calendarZoom).toInt()
            initialHorizontalScroll=visibleBeforeToday*columnWidth
            initialVerticalScroll=(slotIndex-2).coerceAtLeast(0)*slotHeight
            // Anche il focus "Oggi" deve applicare la posizione orizzontale dopo
            // il layout. In precedenza veniva calcolata correttamente, ma non
            // trasferita alle HorizontalScrollView: il calendario restava quindi
            // per un frame/alla fine sulla prima coppia (Lunedì/Martedì).
            root.post{
                headerHorizontal.scrollTo(initialHorizontalScroll,0)
                bodyHorizontal.scrollTo(initialHorizontalScroll,0)
                verticalScroll.smoothScrollTo(0,initialVerticalScroll)
            }
        }else{
            // Ripristino post-layout puro: niente translation temporanee del contenuto.
            // La translation precedente poteva essere visibile per un frame durante
            // la ricostruzione, creando proprio lo "scivolamento" segnalato nei test.
            root.post{
                val maxHeader=(headerWeek.width-headerHorizontal.width).coerceAtLeast(0)
                val maxBody=(week.width-bodyHorizontal.width).coerceAtLeast(0)
                val targetX=initialHorizontalScroll.coerceIn(0,minOf(maxHeader,maxBody))
                headerHorizontal.scrollTo(targetX,0)
                bodyHorizontal.scrollTo(targetX,0)
                verticalScroll.scrollTo(0,initialVerticalScroll.coerceAtLeast(0))
                // Un secondo passaggio dopo il layout garantisce che eventuali
                // misure aggiornate dall'evento non possano cambiare il viewport.
                root.post{
                    val maxH2=(headerWeek.width-headerHorizontal.width).coerceAtLeast(0)
                    val maxB2=(week.width-bodyHorizontal.width).coerceAtLeast(0)
                    val x2=initialHorizontalScroll.coerceIn(0,minOf(maxH2,maxB2))
                    headerHorizontal.scrollTo(x2,0)
                    bodyHorizontal.scrollTo(x2,0)
                    verticalScroll.scrollTo(0,initialVerticalScroll.coerceAtLeast(0))
                }
            }
        }
        calendarAutoFocusOnOpen=false
        root.addView(verticalScroll,LinearLayout.LayoutParams(-1,0,1f))
        addButtonBar(calendarBottomButtons,false)
        root.addView(calendarGlassButton("← Torna ai clienti").apply{setTextColor(Color.rgb(48,72,92));setOnClickListener{build()}},LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(4),0,0)})
        prepareEdgeToEdgeRoot(root)
        setContentView(root)
        calendarEventExpansionAnimate=false
        calendarEventCollapseAnimate=false
        calendarEventRemovalId=null
        calendarEventRemovalSnapshot=null
        if(calendarWeekAnimationDirection!=0){
            val direction=calendarWeekAnimationDirection
            calendarWeekAnimationDirection=0
            root.translationX=(direction * dp(70)).toFloat()
            root.alpha=0f
            root.animate().translationX(0f).alpha(1f).setDuration(180).start()
        }
    }

    private fun calendarSearchScreen(){
        currentScreen = "CALENDAR"
        detachSettingsOverlay()
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(14),dp(16),dp(10));background=appGlassBackground()}
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        top.addView(TextView(this).apply{text="🔎 Ricerca appuntamenti";textSize=22f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,dp(52),1f))
        top.addView(buttonStyle("Chiudi").apply{setOnClickListener{calendarScreen()}},LinearLayout.LayoutParams(dp(82),dp(44)))
        root.addView(top)
        searchInput=modernEditText().apply{
            hint="Cerca per nome cliente";textSize=16f;setSingleLine(true);setPadding(dp(14),0,dp(14),0);background=roundedSurface(Color.WHITE,20,Color.rgb(226,229,234),1)
            addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){searchList.removeAllViews();if(s.toString().trim().isNotEmpty())renderSearchResults(s.toString().trim().lowercase())};override fun afterTextChanged(s:Editable?){}})
        }
        root.addView(searchInput,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,dp(8),0,dp(8))})
        searchList=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,dp(4),0,0)}
        val scroll=ScrollView(this).apply{addView(searchList,ViewGroup.LayoutParams(-1,-2))}
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        root.addView(softBlueButtonStyle("← Torna al calendario").apply{setOnClickListener{calendarScreen()}},LinearLayout.LayoutParams(-1,dp(48)))
        prepareEdgeToEdgeRoot(root)
        setContentView(root)
        searchInput.requestFocus()
    }

    private fun dayHeader(day:LocalDate):View{
        val z=calendarZoom
        val today=day==LocalDate.now()
        val expanded=calendarEventExpansionDay==day
        val headerBg=GradientDrawable().apply{
            cornerRadius=(dp(if(expanded)15 else 12)*z)
            setColor(if(expanded)Color.argb(225,229,242,255)else if(today)Color.argb(210,238,242,246)else Color.argb(195,255,255,255))
            setStroke((dpf(if(expanded)1.7f else 1f)*z).toInt(),if(expanded)Color.rgb(102,174,235)else if(today)Color.rgb(184,198,210)else Color.rgb(205,220,235))
        }
        val main=TextView(this).apply{
            text=if(expanded){
                "${day.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, java.util.Locale.ITALIAN).uppercase()}\n${day.dayOfMonth.toString().padStart(2,'0')} ${day.month.getDisplayName(java.time.format.TextStyle.SHORT, java.util.Locale.ITALIAN).uppercase()}"
            }else{
                "${dayShort(day.dayOfWeek.value-1)}\n${day.dayOfMonth.toString().padStart(2,'0')}/${day.monthValue.toString().padStart(2,'0')}"
            }
            textSize=if(expanded)14f*z else 15f*z;gravity=Gravity.CENTER
            setTypeface(null,if(expanded)android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
            setTextColor(if(expanded)Color.rgb(20,91,165) else Color.rgb(45,50,56))
            setPadding(0,(dp(6)*z).toInt(),0,(dp(6)*z).toInt())
            background=headerBg
        }
        // La testata del giorno mantiene sempre la stessa altezza.
        // L'Evento libero allarga solo la colonna orizzontalmente: non deve
        // aumentare l'altezza della testata, altrimenti invade il primo slot
        // del corpo e lascia il piccolo "residuo" visibile sotto il giorno.
        return main.apply{
            layoutParams=LinearLayout.LayoutParams(-1,(dp(58)*z).toInt()).apply{
                setMargins(0,0,0,(dp(4)*z).toInt())
            }
        }
    }

    private fun buildAppointmentFrame(day:LocalDate,z:Float,slotHeight:Int):FrameLayout{
        val frame=FrameLayout(this)
        val totalHeight=calendarSlotCount()*slotHeight
        frame.layoutParams=LinearLayout.LayoutParams(-1,totalHeight)
        for(slot in 0 until calendarSlotCount()){
            val mins=7*60+slot*calendarSlotDuration;val hour=mins/60;val minute=mins%60;val time=String.format("%02d:%02d",hour,minute)
            val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding((dp(5)*z).toInt(),(dp(3)*z).toInt(),(dp(5)*z).toInt(),(dp(3)*z).toInt());background=calendarSlotSurface(z,slot);isClickable=true;clipChildren=true;clipToPadding=true}.also{applyCalendarSlotDepth(it)}
            val items=appointments.filter{it.date==day&&it.time==time}.sortedBy{it.type}
            val maxTotal=calendarRoutines.getOrNull(activeRoutineIndex)?.maxTotal?:3;val countColor=when{items.size>=maxTotal->Color.rgb(205,55,55);items.size==maxTotal-1->Color.rgb(210,145,25);else->Color.GRAY}
            val timeRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            timeRow.addView(TextView(this).apply{text=time;textSize=11f*z;setTextColor(Color.rgb(105,110,118));setTypeface(null,android.graphics.Typeface.BOLD)},LinearLayout.LayoutParams(0,(dp(22)*z).toInt(),1f))
            timeRow.addView(TextView(this).apply{text="${items.size}/${maxTotal}";textSize=9f*z;setTextColor(countColor);gravity=Gravity.CENTER},LinearLayout.LayoutParams((dp(30)*z).toInt(),(dp(22)*z).toInt()))
            box.addView(timeRow)
            if(items.isEmpty()){
                box.addView(TextView(this).apply{text="＋";textSize=18f*z;gravity=Gravity.CENTER;setTextColor(Color.LTGRAY)},LinearLayout.LayoutParams(-1,(dp(42)*z).toInt()))
            }else{
                val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                items.forEachIndexed{index,a->row.addView(appointmentChip(a),LinearLayout.LayoutParams(0,(dp(46)*z).toInt(),1f).apply{if(index>0)setMargins((dp(3)*z).toInt(),0,0,0)})}
                box.addView(row,LinearLayout.LayoutParams(-1,(dp(40)*z).toInt()));box.addView(TextView(this).apply{text="${items.size}/${maxTotal} appuntamenti";textSize=8.5f*z;setTextColor(Color.GRAY);gravity=Gravity.CENTER_VERTICAL;setPadding(0,(dp(1)*z).toInt(),0,0)},LinearLayout.LayoutParams(-1,(dp(10)*z).toInt()))
            }
            box.setOnClickListener{showSlotCreationChoice(day,time)}
            val lp=FrameLayout.LayoutParams(-1,slotHeight);lp.topMargin=slot*slotHeight;frame.addView(box,lp)
        }
        return frame
    }

    private fun buildFreeEventFrame(day:LocalDate,z:Float,slotHeight:Int):FrameLayout{
        val frame=FrameLayout(this)
        val totalHeight=calendarSlotCount()*slotHeight
        frame.layoutParams=LinearLayout.LayoutParams(dp(86),totalHeight)
        // Timeline libera: i normali slot restano invisibili nella colonna Evento libero.
        // Manteniamo solo aree touch trasparenti per aprire rapidamente il compositore.
        for(slot in 0 until calendarSlotCount()){
            val mins=7*60+slot*calendarSlotDuration;val time=String.format("%02d:%02d",mins/60,mins%60)
            val touch=View(this).apply{setBackgroundColor(Color.TRANSPARENT);setOnClickListener{freeEventComposer(day,time)}}
            val lp=FrameLayout.LayoutParams(-1,slotHeight);lp.topMargin=slot*slotHeight;frame.addView(touch,lp)
        }
        // Segni temporali molto discreti: danno struttura allo spazio senza trasformarlo
        // in una seconda griglia a slot fissi.
        var markerMin=7*60
        while(markerMin<=22*60){
            val y=((markerMin-7*60).toFloat()/calendarSlotDuration*slotHeight).toInt()
            val line=View(this).apply{setBackgroundColor(Color.argb(28,80,105,135))}
            val lpLine=FrameLayout.LayoutParams(-1,dp(1));lpLine.topMargin=y;frame.addView(line,lpLine)
            val label=TextView(this).apply{text=String.format("%02d:%02d",markerMin/60,markerMin%60);textSize=7.5f*z;setTextColor(Color.argb(90,65,82,100));gravity=Gravity.CENTER_VERTICAL;setPadding(dp(4),0,0,0)}
            val lpLabel=FrameLayout.LayoutParams(-1,dp(16));lpLabel.topMargin=(y+dp(2)).coerceAtMost(totalHeight-dp(16));frame.addView(label,lpLabel)
            markerMin+=60
        }
        val eventsForDay=freeEvents.filter{it.date==day}.toMutableList()
        calendarEventRemovalSnapshot?.takeIf{it.date==day && it.id==calendarEventRemovalId}?.let{snapshot->eventsForDay.add(snapshot)}
        eventsForDay.forEach{event->
            val st=runCatching{LocalTime.parse(event.startTime,timeFmt)}.getOrNull()?:return@forEach
            val en=runCatching{LocalTime.parse(event.endTime,timeFmt)}.getOrNull()?:return@forEach
            val startMin=st.hour*60+st.minute;val endMin=en.hour*60+en.minute
            val top=((startMin-7*60).coerceAtLeast(0).toFloat()/calendarSlotDuration*slotHeight).toInt()
            val height=((endMin-startMin).coerceAtLeast(1).toFloat()/calendarSlotDuration*slotHeight).toInt().coerceAtLeast(dp(20))
            val chip=LinearLayout(this).apply{
                orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(9),dp(6),dp(9),dp(6));
                background=liquidInteractiveSurface(Color.argb(92,Color.red(event.color),Color.green(event.color),Color.blue(event.color)),14,event.color,2);
                applyLiquidControlDepth(this);isClickable=true;isFocusable=true
                setOnClickListener{freeEventComposer(event.date,event.startTime,event)}
            }
            val eventTitle=TextView(this).apply{
                text="✦  ${event.title}";textSize=10.8f*z;setTextColor(Color.rgb(34,55,82));
                setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;maxLines=2;ellipsize=android.text.TextUtils.TruncateAt.END
            }
            val eventTime=TextView(this).apply{
                text="${event.startTime} – ${event.endTime}";textSize=9.2f*z;setTextColor(Color.rgb(58,73,96));
                gravity=Gravity.CENTER;setPadding(0,dp(2),0,0)
            }
            chip.addView(eventTitle,LinearLayout.LayoutParams(-1,0,1f))
            chip.addView(eventTime,LinearLayout.LayoutParams(-1,-2))
            val lp=FrameLayout.LayoutParams(-1,height);lp.topMargin=top+dp(2);lp.leftMargin=dp(3);lp.rightMargin=dp(3);frame.addView(chip,lp)
            if(calendarEventRemovalId==event.id){
                // Uscita sincronizzata con la chiusura della colonna: il chip si
                // dissolve e si comprime mentre lo spazio dell'evento si richiude.
                chip.alpha=1f;chip.scaleX=1f;chip.scaleY=1f;chip.translationX=0f;chip.translationY=0f
                chip.animate().alpha(0f).scaleX(0.94f).scaleY(0.94f)
                    .setDuration(520L)
                    .setInterpolator(android.view.animation.PathInterpolator(0.32f,0f,0.67f,0f))
                    .start()
            }else if(calendarEventExpansionAnimate){
                // Entrata sincronizzata con l'apertura della colonna: il chip nasce
                // leggermente compresso e prende la sua dimensione mentre la colonna
                // si apre sotto di lui.
                chip.alpha=0f;chip.translationX=0f;chip.translationY=dp(4).toFloat();chip.scaleX=0.92f;chip.scaleY=0.92f;chip.translationZ=dp(2).toFloat()
                chip.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                    .setDuration(520L)
                    .setInterpolator(android.view.animation.PathInterpolator(0.16f,0.82f,0.22f,1f))
                    .withEndAction{chip.translationZ=dp(2).toFloat()}.start()
            }
        }
        return frame
    }

    private fun dayColumn(day:LocalDate, includeHeader:Boolean=true):View{
        val z=calendarZoom
        val expanded=calendarEventExpansionDay==day || (calendarEventRemovalId!=null && calendarEventAnimationDay==day)
        val wrapper=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding((dp(4)*z).toInt(),0,(dp(4)*z).toInt(),(dp(4)*z).toInt())}
        if(includeHeader) wrapper.addView(dayHeader(day))
        val slotHeight=(dp(86)*z).toInt()
        if(expanded){
            val totalHeight=calendarSlotCount()*slotHeight
            val split=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.TOP}
            val appointmentsFrame=buildAppointmentFrame(day,z,slotHeight)
            val eventsFrame=buildFreeEventFrame(day,z,slotHeight)
            // La parte appuntamenti conserva la larghezza della giornata normale.
            // Solo la colonna Evento libero occupa lo spazio aggiunto.
            val baseContentWidth=((dp(178)*z).toInt().coerceAtLeast(dp(132)) - (dp(8)*z).toInt()).coerceAtLeast(dp(80))
            split.addView(appointmentsFrame,LinearLayout.LayoutParams(baseContentWidth,totalHeight))
            split.addView(eventsFrame,LinearLayout.LayoutParams(dp(86),totalHeight).apply{setMargins(dp(6),0,0,0)})
            wrapper.addView(split,LinearLayout.LayoutParams(-1,totalHeight))
        }else{
            wrapper.addView(buildAppointmentFrame(day,z,slotHeight),LinearLayout.LayoutParams(-1,calendarSlotCount()*slotHeight))
        }
        return wrapper
    }

    // Indicatore di attenzione sull'appuntamento:
    // - rosso: pacchetto scaduto oppure rata non pagata con scadenza oggi/passata
    // - giallo: prossima rata non pagata entro 7 giorni
    // - null: nessun avviso
    private fun calendarAppointmentAlertColor(a:Appointment):Int?{
        val key=identityKey(a.name)

        // PACCHETTO A SEDUTE / PERSONALIZZATO:
        // le prime N prenotazioni restano normali; dalla N+1 in poi sono
        // fuori pacchetto. Se il pacchetto non è stato saldato, invece,
        // tutte le prenotazioni comprese vengono marcate in rosso.
        sessionPacks.filter{it.active&&identityKey(it.name)==key}.forEach{s->
            if(s.customQuantities.isNotEmpty()){
                val limit=s.customQuantities[a.type]?:0
                val before=sessionAppointments(s).count{it.id!=a.id && it.type==a.type && (it.date.isBefore(a.date) || (it.date==a.date && it.time<=a.time))}
                if(limit<=0 || before>=limit) return Color.rgb(215,55,55)
            }else{
                val ordered=sessionAppointments(s)
                val index=ordered.indexOfFirst{it.id==a.id}
                if(index>=s.totalSessions) return Color.rgb(215,55,55)
            }
            if(s.paid<s.cost) return Color.rgb(215,55,55)
        }

        // PACCHETTO SETTIMANALE:
        // ogni rata copre 4 settimane. La prima rata non pagata rende rossi
        // tutti gli appuntamenti; dopo il pagamento, la riga gialla parte
        // dalla 5a settimana, poi dalla 9a per la 3a rata.
        val weekly=weeklyPackageForAppointment(a.name,a.date)
        if(weekly!=null){
            val end=weeklyPackageEnd(weekly)
            if(a.date.isAfter(end)) return Color.rgb(215,55,55)
            if(weeklyCustomTypeOverLimit(weekly,a)) return Color.rgb(215,55,55)
            weeklyPaymentAlertColor(weekly,a.date)?.let{return it}
        }
        return null
    }

    private fun weeklyPaymentAlertColor(p:Pack,date:LocalDate):Int?{
        if(p.paid>=p.total) return null
        val rates=ratesFor(p)
        val unpaidIndex=p.paidRateIndex(rates)
        if(unpaidIndex !in rates.indices) return null

        // La prima rata non pagata rende ROSSI tutti gli appuntamenti
        // compresi nel pacchetto. Dalla rata successiva in poi il colore
        // passa al GIALLO a partire dalla settimana coperta da quella rata.
        if(unpaidIndex==0) return Color.rgb(215,55,55)

        val dueDates=dueDates(p)
        val coverageStart=dueDates.getOrNull(unpaidIndex) ?: p.start
        return if(!date.isBefore(coverageStart)) Color.rgb(220,160,20) else null
    }

    private fun sessionPaymentAlertColor(s:SessionPack):Int?{
        // Per i pacchetti a sedute/personalizzati il pagamento è un
        // prerequisito: finché il pacchetto non è completamente saldato,
        // gli appuntamenti compresi mostrano la riga rossa.
        return if(s.paid<s.cost) Color.rgb(215,55,55) else null
    }

    // La segnalazione viene calcolata per la singola prenotazione in
    // calendarAppointmentAlertColor(), così la copertura delle rate può
    // cambiare da settimana a settimana senza colorare erroneamente tutto
    // il calendario del cliente.
    private fun calendarPackageAlertColor(name:String):Int? = null

    private inner class SiliconeStripeDrawable(private val z:Float) : Drawable() {
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val highlight = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val edgeGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val rr = RectF()
        private var accentColor:Int = Color.rgb(215,55,55)
        fun setAccentColor(color:Int){ accentColor=color }

        override fun draw(canvas: Canvas) {
            if (bounds.width() <= 0 || bounds.height() <= 0) return
            val inset = 0.55f.dp()
            rr.set(bounds.left + inset, bounds.top + inset, bounds.right - inset, bounds.bottom - inset)
            val radius = rr.height() * 0.50f

            // Corpo colorato: rosso per la scadenza, giallo per la rata imminente.
            val c = accentColor
            val top = Color.rgb(
                (Color.red(c)+45).coerceAtMost(255),
                (Color.green(c)+45).coerceAtMost(255),
                (Color.blue(c)+45).coerceAtMost(255)
            )
            val mid = Color.rgb(
                (Color.red(c)+12).coerceAtMost(255),
                (Color.green(c)+12).coerceAtMost(255),
                (Color.blue(c)+12).coerceAtMost(255)
            )
            fill.shader = LinearGradient(
                rr.left, rr.top, rr.left, rr.bottom,
                intArrayOf(
                    top,
                    mid,
                    c,
                    Color.rgb((Color.red(c)*0.88f).toInt(),(Color.green(c)*0.88f).toInt(),(Color.blue(c)*0.88f).toInt())
                ),
                floatArrayOf(0f,0.24f,0.68f,1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(rr, radius, radius, fill)

            // Un bordo morbido chiude la forma senza creare una linea separata.
            edgeGlow.strokeWidth = (0.70f * z).dp().coerceAtLeast(0.7f)
            edgeGlow.color = Color.argb(115,Color.red(c),Color.green(c),Color.blue(c))
            canvas.drawRoundRect(rr, radius, radius, edgeGlow)

            // Riflesso principale: una sola luce continua, perfettamente orizzontale.
            // Parte dentro la curva sinistra e arriva dentro la curva destra, senza
            // interrompersi prima delle estremità.
            val y = rr.top + rr.height() * 0.28f
            val left = rr.left + rr.height() * 0.34f
            val right = rr.right - rr.height() * 0.34f
            highlight.strokeWidth = (0.82f * z).dp().coerceAtLeast(0.8f)
            highlight.shader = LinearGradient(
                left, y, right, y,
                intArrayOf(
                    Color.argb(105,255,255,255),
                    Color.argb(195,255,255,255),
                    Color.argb(195,255,255,255),
                    Color.argb(105,255,255,255)
                ),
                floatArrayOf(0f,0.13f,0.87f,1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawLine(left, y, right, y, highlight)

            // Micro-riflesso inferiore: molto tenue, segue la stessa geometria e
            // completa la sensazione di silicone senza aumentare lo spessore percepito.
            val low = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeCap = Paint.Cap.ROUND
                strokeWidth = (0.45f * z).dp().coerceAtLeast(0.5f)
                color = Color.argb(78,142,18,30)
            }
            val lowY = rr.bottom - rr.height() * 0.22f
            canvas.drawLine(left + rr.height()*0.10f, lowY, right - rr.height()*0.10f, lowY, low)
        }

        private fun Float.dp():Float = this * resources.displayMetrics.density
        override fun setAlpha(alpha:Int) {}
        override fun setColorFilter(colorFilter:android.graphics.ColorFilter?) {}
        override fun getOpacity():Int = android.graphics.PixelFormat.TRANSLUCENT
    }


    /**
     * Liquid Glass dedicato agli slot appuntamento: colore dell'appuntamento
     * presente su tutta la superficie, ma sempre traslucido, con riflessi lucidi
     * e bordi morbidi. È volutamente separato dagli altri stili del calendario.
     */
    private inner class LiquidAppointmentGlassDrawable(
        private val z:Float,
        private val accent:Int
    ) : Drawable() {
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val gloss = Paint(Paint.ANTI_ALIAS_FLAG)
        private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val inner = RectF()

        override fun draw(canvas:Canvas) {
            if(bounds.width()<=0 || bounds.height()<=0) return
            val r=RectF(bounds)
            val radius=(r.height()*0.30f).coerceAtLeast(dp(7).toFloat())
            val rr=RectF(r.left+dpf(0.6f),r.top+dpf(0.6f),r.right-dpf(0.6f),r.bottom-dpf(0.6f))

            val ar=Color.red(accent); val ag=Color.green(accent); val ab=Color.blue(accent)
            // Colore su tutta la lastra, ma con trasparenza sufficiente a lasciare
            // la sensazione di vetro e a non diventare una card piena e opaca.
            fill.shader=LinearGradient(
                rr.left,rr.top,rr.right,rr.bottom,
                intArrayOf(
                    Color.argb(118, minOf(255,ar+42), minOf(255,ag+42), minOf(255,ab+42)),
                    Color.argb(150, ar,ag,ab),
                    Color.argb(118, maxOf(0,ar-10), maxOf(0,ag-10), maxOf(0,ab-10)),
                    Color.argb(92, minOf(255,ar+20), minOf(255,ag+20), minOf(255,ab+20))
                ),
                floatArrayOf(0f,0.34f,0.72f,1f),Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(rr,radius,radius,fill)

            // Grande riflesso diagonale: dà l'effetto "passata di polish" senza
            // coprire il colore dell'appuntamento.
            val shine=Path().apply{
                moveTo(rr.left+rr.width()*0.03f,rr.top+rr.height()*0.18f)
                quadTo(rr.left+rr.width()*0.36f,rr.top-rr.height()*0.02f,rr.left+rr.width()*0.72f,rr.top+rr.height()*0.06f)
                quadTo(rr.left+rr.width()*0.47f,rr.top+rr.height()*0.24f,rr.left+rr.width()*0.03f,rr.top+rr.height()*0.18f)
                close()
            }
            gloss.shader=LinearGradient(rr.left,rr.top,rr.right,rr.bottom,
                Color.argb(92,255,255,255),Color.argb(18,255,255,255),Shader.TileMode.CLAMP)
            canvas.drawPath(shine,gloss)

            // Barra di luce superiore continua, come vetro appena lucidato.
            gloss.shader=null
            gloss.style=Paint.Style.STROKE
            gloss.strokeCap=Paint.Cap.ROUND
            gloss.strokeWidth=(1.35f*z).dp()
            gloss.color=Color.argb(128,255,255,255)
            val top=Path().apply{
                moveTo(rr.left+rr.width()*0.10f,rr.top+dpf(1.2f))
                quadTo(rr.left+rr.width()*0.50f,rr.top-dpf(0.2f),rr.right-rr.width()*0.10f,rr.top+dpf(1.2f))
            }
            canvas.drawPath(top,gloss)

            // Bordo interno molto leggero: niente contorno duro.
            edge.strokeWidth=(0.9f*z).dp()
            edge.color=Color.argb(112,255,255,255)
            canvas.drawRoundRect(rr,radius,radius,edge)
            inner.set(rr.left+dp(2),rr.top+dp(2),rr.right-dp(2),rr.bottom-dp(2))
            edge.strokeWidth=(0.55f*z).dp()
            edge.color=Color.argb(62,255,255,255)
            canvas.drawRoundRect(inner,(radius-dpf(1.5f)).coerceAtLeast(1f),(radius-dpf(1.5f)).coerceAtLeast(1f),edge)

            // Riflesso inferiore freddo e quasi impercettibile: mantiene la scia
            // trasparente invece di far sembrare lo slot semplicemente colorato.
            gloss.style=Paint.Style.STROKE
            gloss.strokeWidth=(0.8f*z).dp()
            gloss.color=Color.argb(48,235,248,255)
            val bottom=Path().apply{
                moveTo(rr.left+rr.width()*0.14f,rr.bottom-dpf(1.1f))
                quadTo(rr.left+rr.width()*0.50f,rr.bottom+dpf(0.2f),rr.right-rr.width()*0.14f,rr.bottom-dpf(1.1f))
            }
            canvas.drawPath(bottom,gloss)
        }

        private fun Float.dp():Float=this*resources.displayMetrics.density
        override fun setAlpha(alpha:Int) {}
        override fun setColorFilter(colorFilter:android.graphics.ColorFilter?) {}
        override fun getOpacity():Int=android.graphics.PixelFormat.TRANSLUCENT
    }

    /**
     * Dieci materiali/forme realmente distinti per gli slot appuntamento.
     * Lo stile 10 è il Liquid Glass attuale e resta il predefinito.
     * Gli altri nove cambiano struttura, sagoma, contrasto e linguaggio materico,
     * non solo il riflesso.
     */
    private inner class AppointmentSlotStyleDrawable(
        private val style:Int,
        private val z:Float,
        private val accent:Int
    ) : Drawable() {
        private val fill=Paint(Paint.ANTI_ALIAS_FLAG)
        private val edge=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeCap=Paint.Cap.ROUND}
        private val shine=Paint(Paint.ANTI_ALIAS_FLAG)
        private val path=Path()
        private val rr=RectF()
        override fun draw(canvas:Canvas){
            if(bounds.width()<=0||bounds.height()<=0)return
            val d=resources.displayMetrics.density
            fun dp(v:Float)=v*d
            val w=bounds.width().toFloat();val h=bounds.height().toFloat()
            val ar=Color.red(accent);val ag=Color.green(accent);val ab=Color.blue(accent)
            val light=Color.rgb(minOf(255,ar+48),minOf(255,ag+48),minOf(255,ab+48))
            val deep=Color.rgb(maxOf(0,ar-35),maxOf(0,ag-35),maxOf(0,ab-35))
            rr.set(bounds.left+dp(.8f),bounds.top+dp(.8f),bounds.right-dp(.8f),bounds.bottom-dp(.8f))
            when(style){
                1->{ // Capsule: forma completamente organica
                    val rad=h*.50f
                    fill.shader=LinearGradient(rr.left,rr.top,rr.right,rr.bottom,intArrayOf(Color.argb(175,light.red(),light.green(),light.blue()),Color.argb(150,ar,ag,ab),Color.argb(175,light.red(),light.green(),light.blue())),null,Shader.TileMode.CLAMP)
                    canvas.drawRoundRect(rr,rad,rad,fill)
                    edge.strokeWidth=dp(1.1f);edge.color=Color.argb(150,255,255,255);canvas.drawRoundRect(rr,rad,rad,edge)
                }
                2->{ // Tag: angoli smussati asimmetrici
                    path.reset();val cut=dp(7f)
                    path.moveTo(rr.left+cut,rr.top);path.lineTo(rr.right-dp(5f),rr.top);path.lineTo(rr.right,rr.top+cut);path.lineTo(rr.right,rr.bottom-cut);path.lineTo(rr.right-dp(5f),rr.bottom);path.lineTo(rr.left+cut,rr.bottom);path.lineTo(rr.left,rr.bottom-cut);path.lineTo(rr.left,rr.top+cut);path.close()
                    fill.shader=LinearGradient(rr.left,rr.top,rr.left,rr.bottom,intArrayOf(Color.argb(145,light.red(),light.green(),light.blue()),Color.argb(150,ar,ag,ab),Color.argb(105,deep.red(),deep.green(),deep.blue())),null,Shader.TileMode.CLAMP);canvas.drawPath(path,fill)
                    edge.strokeWidth=dp(1.2f);edge.color=Color.argb(175,255,255,255);canvas.drawPath(path,edge)
                }
                3->{ // Seghettato/faceted: profilo a diamante morbido
                    path.reset();val c=dp(6f)
                    path.moveTo(rr.left+c,rr.top);path.lineTo(rr.right-c,rr.top);path.lineTo(rr.right,rr.top+c);path.lineTo(rr.right,rr.bottom-c);path.lineTo(rr.right-c,rr.bottom);path.lineTo(rr.left+c,rr.bottom);path.lineTo(rr.left,rr.bottom-c);path.lineTo(rr.left,rr.top+c);path.close()
                    fill.shader=LinearGradient(rr.left,rr.top,rr.right,rr.bottom,intArrayOf(Color.argb(115,255,255,255),Color.argb(155,ar,ag,ab),Color.argb(115,deep.red(),deep.green(),deep.blue()),Color.argb(135,light.red(),light.green(),light.blue())),null,Shader.TileMode.CLAMP);canvas.drawPath(path,fill)
                    edge.strokeWidth=dp(1.35f);edge.color=Color.argb(165,255,255,255);canvas.drawPath(path,edge)
                }
                4->{ // Ribbon: fascia superiore separata dal corpo
                    val rad=dp(5f)
                    fill.shader=LinearGradient(rr.left,rr.top,rr.left,rr.bottom,intArrayOf(Color.argb(145,light.red(),light.green(),light.blue()),Color.argb(120,ar,ag,ab),Color.argb(155,deep.red(),deep.green(),deep.blue())),null,Shader.TileMode.CLAMP);canvas.drawRoundRect(rr,rad,rad,fill)
                    shine.style=Paint.Style.FILL;shine.shader=LinearGradient(rr.left,rr.top,rr.right,rr.top,Color.argb(205,255,255,255),Color.argb(35,255,255,255),Shader.TileMode.CLAMP);canvas.drawRoundRect(RectF(rr.left,rr.top,rr.right,rr.top+h*.22f),rad,rad,shine)
                    edge.strokeWidth=dp(1f);edge.color=Color.argb(150,255,255,255);canvas.drawRoundRect(rr,rad,rad,edge)
                }
                5->{ // Dark Glass: nero profondo + volume + vernice/lacca + riflesso vetro.
                    val rad=dp(8f)
                    // Ombra interna/scurimento ai bordi: fa percepire una superficie incavata e spessa.
                    fill.shader=LinearGradient(rr.left,rr.top,rr.right,rr.bottom,intArrayOf(
                        Color.rgb(5,7,10),Color.rgb(25,31,40),Color.rgb(48,55,66),Color.rgb(20,25,33),Color.rgb(4,6,9)
                    ),floatArrayOf(0f,.22f,.48f,.72f,1f),Shader.TileMode.CLAMP)
                    canvas.drawRoundRect(rr,rad,rad,fill)
                    // Volume: alone interno morbido e riflesso della vernice.
                    shine.style=Paint.Style.STROKE;shine.strokeCap=Paint.Cap.ROUND
                    shine.strokeWidth=dp(3.2f);shine.color=Color.argb(105,0,0,0)
                    canvas.drawRoundRect(RectF(rr.left+dp(1.4f),rr.top+dp(1.4f),rr.right-dp(1.4f),rr.bottom-dp(1.4f)),dp(7f),dp(7f),shine)
                    shine.style=Paint.Style.FILL
                    shine.shader=LinearGradient(rr.left,rr.top,rr.right,rr.top,
                        intArrayOf(Color.argb(0,255,255,255),Color.argb(125,255,255,255),Color.argb(35,255,255,255),Color.argb(0,255,255,255)),
                        floatArrayOf(0f,.28f,.52f,1f),Shader.TileMode.CLAMP)
                    canvas.drawRoundRect(RectF(rr.left+dp(5f),rr.top+dp(1.8f),rr.right-dp(5f),rr.top+h*.24f),dp(7f),dp(7f),shine)
                    // Grande riflesso diagonale, volutamente morbido: effetto lacca/vetro lucido.
                    shine.shader=LinearGradient(rr.left+rr.width()*.12f,rr.top,rr.left+rr.width()*.48f,rr.bottom,
                        intArrayOf(Color.argb(0,255,255,255),Color.argb(82,255,255,255),Color.argb(0,255,255,255)),floatArrayOf(0f,.5f,1f),Shader.TileMode.CLAMP)
                    path.reset();path.moveTo(rr.left+dp(10f),rr.top);path.lineTo(rr.left+rr.width()*.31f,rr.top);path.lineTo(rr.left+rr.width()*.58f,rr.bottom);path.lineTo(rr.left+dp(29f),rr.bottom);path.close();canvas.drawPath(path,shine)
                    shine.shader=null
                    // Bordo luminoso colorato molto sottile: il colore dell'appuntamento resta riconoscibile.
                    shine.style=Paint.Style.STROKE;shine.strokeWidth=dp(5f);shine.color=Color.argb(40,ar,ag,ab)
                    canvas.drawLine(rr.left+dp(2.7f),rr.top+dp(8f),rr.left+dp(2.7f),rr.bottom-dp(8f),shine)
                    canvas.drawLine(rr.right-dp(2.7f),rr.top+dp(8f),rr.right-dp(2.7f),rr.bottom-dp(8f),shine)
                    shine.strokeWidth=dp(1.15f);shine.color=Color.argb(245,light.red(),light.green(),light.blue())
                    canvas.drawLine(rr.left+dp(2.7f),rr.top+dp(8f),rr.left+dp(2.7f),rr.bottom-dp(8f),shine)
                    canvas.drawLine(rr.right-dp(2.7f),rr.top+dp(8f),rr.right-dp(2.7f),rr.bottom-dp(8f),shine)
                    // Bordo superiore a specchio.
                    shine.strokeWidth=dp(.9f);shine.color=Color.argb(190,255,255,255)
                    canvas.drawLine(rr.left+dp(10f),rr.top+dp(2.5f),rr.right-dp(10f),rr.top+dp(2.5f),shine)
                    edge.strokeWidth=dp(1f);edge.color=Color.argb(205,120,132,148);canvas.drawRoundRect(rr,rad,rad,edge)
                }
                6->{ // Neon outline: centro quasi trasparente, energia tutta sul bordo
                    fill.shader=LinearGradient(rr.left,rr.top,rr.right,rr.bottom,intArrayOf(Color.argb(42,255,255,255),Color.argb(62,ar,ag,ab),Color.argb(32,255,255,255)),null,Shader.TileMode.CLAMP);canvas.drawRoundRect(rr,dp(10f),dp(10f),fill)
                    edge.strokeWidth=dp(3f);edge.color=Color.argb(58,ar,ag,ab);canvas.drawRoundRect(rr,dp(10f),dp(10f),edge)
                    edge.strokeWidth=dp(1.2f);edge.color=Color.argb(220,light.red(),light.green(),light.blue());canvas.drawRoundRect(rr,dp(10f),dp(10f),edge)
                }
                7->{ // Chrome: cromo scuro/argento lucido, profondo, non bianco-piatto.
                    val rad=dp(6f)
                    // Alternanza molto contrastata di nero, acciaio e bianco: riflesso da metallo a specchio.
                    fill.shader=LinearGradient(rr.left,rr.top,rr.right,rr.bottom,
                        intArrayOf(Color.rgb(4,6,8),Color.rgb(52,58,65),Color.rgb(225,229,233),Color.rgb(78,84,91),Color.rgb(245,247,249),Color.rgb(25,29,33),Color.rgb(150,156,163),Color.rgb(8,10,12)),
                        floatArrayOf(0f,.16f,.30f,.43f,.56f,.70f,.86f,1f),Shader.TileMode.CLAMP)
                    canvas.drawRoundRect(rr,rad,rad,fill)
                    // Volume interno: bordo scuro + highlight esterno, come una superficie verniciata.
                    edge.strokeWidth=dp(2.8f);edge.color=Color.argb(105,0,0,0);canvas.drawRoundRect(RectF(rr.left+dp(1f),rr.top+dp(1f),rr.right-dp(1f),rr.bottom-dp(1f)),dp(5f),dp(5f),edge)
                    edge.strokeWidth=dp(.85f);edge.color=Color.argb(235,255,255,255);canvas.drawRoundRect(RectF(rr.left+dp(1.8f),rr.top+dp(1.8f),rr.right-dp(1.8f),rr.bottom-dp(1.8f)),dp(4.5f),dp(4.5f),edge)
                    // Riflesso largo tipo lacca.
                    shine.style=Paint.Style.FILL
                    shine.shader=LinearGradient(rr.left+rr.width()*.08f,rr.top,rr.left+rr.width()*.34f,rr.bottom,
                        intArrayOf(Color.argb(8,255,255,255),Color.argb(220,255,255,255),Color.argb(8,255,255,255)),floatArrayOf(0f,.5f,1f),Shader.TileMode.CLAMP)
                    path.reset();path.moveTo(rr.left+rr.width()*.12f,rr.top);path.lineTo(rr.left+rr.width()*.27f,rr.top);path.lineTo(rr.left+rr.width()*.48f,rr.bottom);path.lineTo(rr.left+rr.width()*.33f,rr.bottom);path.close();canvas.drawPath(path,shine)
                    // Riflesso secondario scuro: evita l'effetto alluminio chiaro e crea profondità.
                    shine.shader=LinearGradient(rr.left+rr.width()*.60f,rr.top,rr.left+rr.width()*.86f,rr.bottom,
                        intArrayOf(Color.argb(0,0,0,0),Color.argb(185,0,0,0),Color.argb(15,0,0,0)),floatArrayOf(0f,.5f,1f),Shader.TileMode.CLAMP)
                    path.reset();path.moveTo(rr.left+rr.width()*.61f,rr.top);path.lineTo(rr.left+rr.width()*.74f,rr.top);path.lineTo(rr.left+rr.width()*.90f,rr.bottom);path.lineTo(rr.left+rr.width()*.77f,rr.bottom);path.close();canvas.drawPath(path,shine)
                    // Highlight orizzontale superiore, come una lampada riflessa sul cromo.
                    shine.shader=LinearGradient(rr.left,rr.top,rr.right,rr.top,Color.argb(220,255,255,255),Color.argb(25,255,255,255),Shader.TileMode.CLAMP)
                    canvas.drawRoundRect(RectF(rr.left+dp(7f),rr.top+dp(2f),rr.right-dp(7f),rr.top+h*.17f),dp(5f),dp(5f),shine)
                    shine.shader=null
                    // Neon laterale sottile: stesso linguaggio del Dark Glass, senza colorare il cromo.
                    shine.style=Paint.Style.STROKE;shine.strokeCap=Paint.Cap.ROUND
                    shine.strokeWidth=dp(4.5f);shine.color=Color.argb(42,ar,ag,ab)
                    canvas.drawLine(rr.left+dp(2.8f),rr.top+dp(7f),rr.left+dp(2.8f),rr.bottom-dp(7f),shine)
                    canvas.drawLine(rr.right-dp(2.8f),rr.top+dp(7f),rr.right-dp(2.8f),rr.bottom-dp(7f),shine)
                    shine.strokeWidth=dp(1f);shine.color=Color.argb(235,light.red(),light.green(),light.blue())
                    canvas.drawLine(rr.left+dp(2.8f),rr.top+dp(8f),rr.left+dp(2.8f),rr.bottom-dp(8f),shine)
                    canvas.drawLine(rr.right-dp(2.8f),rr.top+dp(8f),rr.right-dp(2.8f),rr.bottom-dp(8f),shine)
                }
                8->{ // Crystal: doppio pannello diagonale
                    path.reset();path.moveTo(rr.left+dp(6f),rr.top);path.lineTo(rr.right,rr.top);path.lineTo(rr.right-dp(6f),rr.bottom);path.lineTo(rr.left,rr.bottom);path.close()
                    fill.shader=LinearGradient(rr.left,rr.top,rr.right,rr.bottom,intArrayOf(Color.argb(135,light.red(),light.green(),light.blue()),Color.argb(115,ar,ag,ab),Color.argb(100,255,255,255)),null,Shader.TileMode.CLAMP);canvas.drawPath(path,fill)
                    shine.style=Paint.Style.STROKE;shine.strokeWidth=dp(1f);shine.color=Color.argb(150,255,255,255);canvas.drawLine(rr.left+dp(8f),rr.bottom-dp(1.5f),rr.right-dp(8f),rr.top+dp(1.5f),shine)
                    edge.strokeWidth=dp(1.1f);edge.color=Color.argb(175,255,255,255);canvas.drawPath(path,edge)
                }
                9->{ // Soft slab: rettangolo quasi piatto con angolo laterale marcato
                    fill.shader=LinearGradient(rr.left,rr.top,rr.left,rr.bottom,intArrayOf(Color.argb(165,245,248,251),Color.argb(125,ar,ag,ab),Color.argb(150,225,232,239)),null,Shader.TileMode.CLAMP);canvas.drawRoundRect(rr,dp(3f),dp(3f),fill)
                    shine.style=Paint.Style.FILL;shine.shader=LinearGradient(rr.left,rr.top,rr.left,rr.bottom,Color.argb(95,255,255,255),Color.TRANSPARENT,Shader.TileMode.CLAMP);canvas.drawRect(rr.left,rr.top,rr.right,rr.top+h*.28f,shine)
                    edge.strokeWidth=dp(1f);edge.color=Color.argb(135,155,165,178);canvas.drawRoundRect(rr,dp(3f),dp(3f),edge)
                }
            }
            fill.shader=null;shine.shader=null
        }
        private fun Int.red()=Color.red(this);private fun Int.green()=Color.green(this);private fun Int.blue()=Color.blue(this)
        private fun Float.dp():Float=this*resources.displayMetrics.density
        override fun setAlpha(alpha:Int){};override fun setColorFilter(colorFilter:android.graphics.ColorFilter?){};override fun getOpacity():Int=android.graphics.PixelFormat.TRANSLUCENT
    }

    private inner class WhatsAppIconDrawable(private val tint:Int) : Drawable() {
        private val p=Paint(Paint.ANTI_ALIAS_FLAG)
        override fun draw(canvas:Canvas){
            val r=RectF(bounds.left+dpf(2f),bounds.top+dpf(2f),bounds.right-dpf(2f),bounds.bottom-dpf(2f))
            p.style=Paint.Style.STROKE;p.strokeWidth=dpf(1.8f);p.strokeCap=Paint.Cap.ROUND;p.strokeJoin=Paint.Join.ROUND;p.color=tint
            canvas.drawCircle(r.centerX(),r.centerY(),r.width()*0.34f,p)
            val tail=Path().apply{moveTo(r.left+r.width()*0.32f,r.bottom-r.height()*0.20f);lineTo(r.left+r.width()*0.16f,r.bottom-r.height()*0.08f);lineTo(r.left+r.width()*0.38f,r.bottom-r.height()*0.12f)}
            canvas.drawPath(tail,p)
            val bubble=Path().apply{moveTo(r.centerX()-dpf(4f),r.centerY()-dpf(1f));quadTo(r.centerX()-dpf(1f),r.centerY()+dpf(2f),r.centerX()+dpf(3f),r.centerY()+dpf(3f))}
            canvas.drawPath(bubble,p)
        }
        private fun dpf(v:Float)=v*resources.displayMetrics.density
        override fun setAlpha(alpha:Int){};override fun setColorFilter(colorFilter:android.graphics.ColorFilter?){};override fun getOpacity()=android.graphics.PixelFormat.TRANSLUCENT
    }

    private inner class DialogLineIconDrawable(private val kind:Int, private val tint:Int) : Drawable() {
        private val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeCap=Paint.Cap.ROUND;strokeJoin=Paint.Join.ROUND;strokeWidth=dpf(2.2f);color=tint}
        override fun draw(canvas:Canvas){
            val b=bounds
            val cx=b.exactCenterX(); val cy=b.exactCenterY(); val w=b.width().toFloat(); val h=b.height().toFloat()
            when(kind){
                1->{ // Lucchetto
                    val body=RectF(cx-w*.28f,cy-h*.02f,cx+w*.28f,cy+h*.30f)
                    canvas.drawRoundRect(body,dpf(3.5f),dpf(3.5f),paint)
                    val shackle=RectF(cx-w*.20f,cy-h*.30f,cx+w*.20f,cy+h*.10f)
                    canvas.drawArc(shackle,180f,-180f,false,paint)
                    paint.style=Paint.Style.FILL
                    canvas.drawCircle(cx,cy+h*.10f,dpf(1.6f),paint)
                    paint.style=Paint.Style.STROKE
                }
                4->{ // Copia
                    val back=RectF(cx-w*.24f,cy-h*.20f,cx+w*.20f,cy+h*.28f)
                    val front=RectF(cx-w*.05f,cy-h*.30f,cx+w*.32f,cy+h*.18f)
                    canvas.drawRoundRect(back,dpf(2.5f),dpf(2.5f),paint)
                    canvas.drawRoundRect(front,dpf(2.5f),dpf(2.5f),paint)
                }
                2->{ // Calendario + matita
                    val cal=RectF(cx-w*.34f,cy-h*.28f,cx+w*.30f,cy+h*.31f)
                    canvas.drawRoundRect(cal,dpf(3f),dpf(3f),paint)
                    canvas.drawLine(cal.left,cy-h*.08f,cal.right,cy-h*.08f,paint)
                    canvas.drawLine(cx-w*.20f,cal.top,cx-w*.20f,cal.top+dp(5),paint)
                    canvas.drawLine(cx+w*.12f,cal.top,cx+w*.12f,cal.top+dp(5),paint)
                    val path=Path();path.moveTo(cx+w*.02f,cy+h*.28f);path.lineTo(cx+w*.39f,cy-h*.09f);path.lineTo(cx+w*.48f,cy+h*.00f);path.lineTo(cx+w*.11f,cy+h*.37f);path.close();canvas.drawPath(path,paint)
                }
                else->{ // Cestino
                    val bin=RectF(cx-w*.25f,cy-h*.15f,cx+w*.25f,cy+h*.33f)
                    canvas.drawRoundRect(bin,dpf(2f),dpf(2f),paint)
                    canvas.drawLine(bin.left-dp(2),bin.top,bin.right+dp(2),bin.top,paint)
                    canvas.drawLine(cx-w*.13f,bin.top-dp(4),cx+w*.13f,bin.top-dp(4),paint)
                    canvas.drawLine(cx-w*.10f,bin.top+dp(7),cx-w*.10f,bin.bottom-dp(5),paint)
                    canvas.drawLine(cx,bin.top+dp(7),cx,bin.bottom-dp(5),paint)
                    canvas.drawLine(cx+w*.10f,bin.top+dp(7),cx+w*.10f,bin.bottom-dp(5),paint)
                }
            }
        }
        override fun setAlpha(alpha:Int){paint.alpha=alpha}
        override fun setColorFilter(colorFilter:android.graphics.ColorFilter?){paint.colorFilter=colorFilter}
        override fun getOpacity():Int=android.graphics.PixelFormat.TRANSLUCENT
    }

    private fun appointmentSlotSurface(accent:Int):Drawable = if(appointmentSlotStyle==10) liquidAppointmentSurface(accent) else AppointmentSlotStyleDrawable(appointmentSlotStyle,calendarZoom,accent)

    private fun liquidAppointmentSurface(accent:Int):Drawable =
        LiquidAppointmentGlassDrawable(calendarZoom,accent)

    private fun LinearLayout.setTextViewIcon(icon:Drawable, label:String, size:Float, color:Int){
        addView(ImageView(this@MainActivity).apply{setImageDrawable(icon);scaleType=ImageView.ScaleType.CENTER},LinearLayout.LayoutParams(dp(28),dp(28)).apply{setMargins(0,0,dp(10),0)})
        addView(TextView(this@MainActivity).apply{text=label;textSize=size;setTextColor(color);setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(-2,-1))
    }

    private fun appointmentChip(a:Appointment):View{
        val accent=typeColor(a.type)
        val bg=typeBgForColor(accent)
        val chip=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding((dp(3)*calendarZoom).toInt(),(dp(2)*calendarZoom).toInt(),(dp(3)*calendarZoom).toInt(),(dp(2)*calendarZoom).toInt());background=appointmentSlotSurface(accent);isClickable=true;clipToOutline=true}
        val packageAlertColor=calendarAppointmentAlertColor(a) ?: calendarPackageAlertColor(a.name)
        if(packageAlertColor!=null){
            // Indicatore scadenza/attenzione: resta perfettamente orizzontale, più corto del chip,
            // con estremità arrotondate e una sfumatura luminosa per ricordare una
            // piccola striscia di materiale liquido spremuto sulla superficie.
            val stripe=SiliconeStripeDrawable(calendarZoom).apply{setAccentColor(packageAlertColor)}
            chip.addView(TextView(this).apply{
                background=stripe
                elevation=dpf(2.2f)
            },LinearLayout.LayoutParams(-1,(dp(6)*calendarZoom).toInt()).apply{
                // Abbassiamo appena la striscia: ora non tocca più il bordo superiore
                // della card e può leggere meglio come piccolo cordoncino di silicone.
                setMargins((dp(10)*calendarZoom).toInt(),(dp(2)*calendarZoom).toInt(),(dp(10)*calendarZoom).toInt(),(dp(1)*calendarZoom).toInt())
            })
        }
        chip.addView(TextView(this).apply{text=displaySurnameFirst(a.name);textSize=9.5f*calendarZoom;setTextColor(if(appointmentSlotStyle==5) Color.argb(235,255,255,255) else Color.argb(225,22,29,36));gravity=Gravity.CENTER;translationY=dpf(1.8f);maxLines=2;ellipsize=android.text.TextUtils.TruncateAt.END;setTypeface(null,android.graphics.Typeface.BOLD);setShadowLayer(dpf(0.8f),0f,dpf(0.6f),Color.argb(55,255,255,255))},LinearLayout.LayoutParams(-1,(dp(if(packageAlertColor!=null) 33 else 42)*calendarZoom).toInt()))
        chip.setOnClickListener{appointmentActions(a)}
        return chip}

    private fun registerDeletedRegularAppointment(a:Appointment){
        if(!a.recovery && !isStudioClosed(a.date)){regularPackFor(a.name,a.date)?.let{it.missedSessions++}}
    }

    private fun appointmentActions(a:Appointment){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(6),dp(18),dp(10))}
        box.addView(TextView(this).apply{text=displaySurnameFirst(a.name);textSize=23f;setTextColor(Color.rgb(24,27,31));setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setPadding(0,dp(4),0,dp(2))},LinearLayout.LayoutParams(-1,dp(42)))
        box.addView(TextView(this).apply{text="${a.date.format(fmt)} • ${a.time} • ${calendarSlotDuration} min";textSize=13.5f;setTextColor(Color.rgb(92,96,102));gravity=Gravity.CENTER;setPadding(0,0,0,dp(6))},LinearLayout.LayoutParams(-1,dp(30)))
        if(isStudioClosed(a.date)){
            val closed=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(8),dp(14),dp(8));background=liquidInteractiveSurface(Color.rgb(224,240,255),18,Color.rgb(176,214,248),1);elevation=dp(2).toFloat()}
            val iconBox=FrameLayout(this).apply{background=liquidInteractiveSurface(Color.rgb(235,247,255),14,Color.rgb(195,225,249),1);elevation=dpf(1.5f)}
            iconBox.addView(ImageView(this).apply{setImageDrawable(DialogLineIconDrawable(1,Color.rgb(25,105,205)));scaleType=ImageView.ScaleType.CENTER},FrameLayout.LayoutParams(dp(42),dp(42)))
            closed.addView(iconBox,LinearLayout.LayoutParams(dp(48),dp(48)).apply{setMargins(0,0,dp(10),0)})
            val copy=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL}
            copy.addView(TextView(this).apply{text="Studio chiuso";textSize=15f;setTextColor(Color.rgb(18,55,91));setTypeface(null,android.graphics.Typeface.BOLD)},LinearLayout.LayoutParams(-1,dp(23)))
            copy.addView(TextView(this).apply{text="Questo appuntamento non viene conteggiato nel pacchetto.";textSize=12.5f;setTextColor(Color.rgb(61,78,96));maxLines=2},LinearLayout.LayoutParams(-1,-2))
            closed.addView(copy,LinearLayout.LayoutParams(0,-2,1f))
            box.addView(closed,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(9))})
        }
        val edit=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;setPadding(dp(14),0,dp(14),0);setTextViewIcon(DialogLineIconDrawable(2,Color.rgb(35,104,195)),"Modifica / sposta",15f,Color.rgb(35,91,145));background=liquidInteractiveSurface(Color.rgb(232,243,255),20,Color.rgb(188,211,238),1);isClickable=true;applyLiquidControlDepth(this)}
        val del=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;setPadding(dp(14),0,dp(14),0);setTextViewIcon(DialogLineIconDrawable(3,Color.rgb(205,45,55)),"Elimina appuntamento",15f,Color.rgb(195,55,55));background=liquidInteractiveSurface(Color.rgb(255,232,235),20,Color.rgb(244,195,201),1);isClickable=true;applyLiquidControlDepth(this)}
        val cancel=TextView(this).apply{text="Annulla";textSize=14f;setTextColor(Color.rgb(0,125,110));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);background=liquidInteractiveSurface(Color.rgb(248,250,253),18,Color.rgb(218,225,232),1);isClickable=true;applyLiquidControlDepth(this)}
        box.addView(edit,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,0,0,dp(7))})
        box.addView(del,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,0,0,dp(7))})
        box.addView(cancel,LinearLayout.LayoutParams(-1,dp(46)))
        val dialog=AlertDialog.Builder(this).setView(box).create();styleModernCoachDialog(dialog)
        preparePopupBackdrop(dialog)
        dialog.setOnShowListener{popupBackdropCurrentDialog=dialog;dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28));applyPopupBackdropEffect(dialog);dialog.window?.setDimAmount(0.40f);dialog.window?.let{w->w.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT)};animateCalendarDialog(dialog,box);edit.setOnClickListener{dialog.dismiss();appointmentDialog(a)};del.setOnClickListener{
            dialog.dismiss()
            if(a.seriesId!=0L){
                val series=appointments.filter{it.seriesId==a.seriesId}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
                val seriesCount=series.size
                val selectedIndex=series.indexOfFirst{it.id==a.id}
                val laterCount=if(selectedIndex>=0) series.size-selectedIndex else 0
                val (seqDialog,outer,body)=packActionDialogBase("Elimina appuntamento","🗑",Color.rgb(205,45,55),Color.rgb(255,225,228),Color.WHITE)
                body.addView(dialogBodyText("Questo appuntamento fa parte di una programmazione di $seriesCount appuntamenti.\n\nScegli cosa vuoi eliminare."))
                fun seqButton(label:String, sub:String?=null, bg:Int=Color.rgb(246,248,250), fg:Int=Color.rgb(25,28,32)):Button=dialogButton(if(sub.isNullOrBlank())label else "$label\n$sub",fg,bg,if(bg==Color.rgb(246,248,250)) Color.rgb(220,225,232) else bg){}
                val one=seqButton("Solo questo appuntamento")
                val subsequent=seqButton("Questo e tutti i successivi","Elimina $laterCount appuntamenti da questo in poi")
                val all=seqButton("Tutta la sequenza","Elimina tutti i $seriesCount appuntamenti",Color.rgb(255,244,244),Color.rgb(195,55,55))
                body.addView(one,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(7))})
                body.addView(subsequent,LinearLayout.LayoutParams(-1,dp(58)).apply{setMargins(0,0,0,dp(7))})
                body.addView(all,LinearLayout.LayoutParams(-1,dp(58)).apply{setMargins(0,0,0,dp(5))})
                body.addView(dialogButton("Annulla",Color.rgb(0,125,110),Color.rgb(248,250,253),Color.rgb(218,225,232)){seqDialog.dismiss()},LinearLayout.LayoutParams(-1,dp(44)))
                one.setOnClickListener{registerDeletedRegularAppointment(a);addTrashItem("APPOINTMENT",appointmentTrashPayload(a));appointments.remove(a);saveData();seqDialog.dismiss();calendarScreen()}
                subsequent.setOnClickListener{
                    if(selectedIndex>=0){val toRemove=appointments.filter{it.seriesId==a.seriesId && (it.date.isAfter(a.date) || (it.date==a.date && it.time>=a.time))};toRemove.forEach{registerDeletedRegularAppointment(it);addTrashItem("APPOINTMENT",appointmentTrashPayload(it))};appointments.removeAll{it.id in toRemove.map{r->r.id}.toSet()}}
                    saveData();seqDialog.dismiss();calendarScreen()
                }
                all.setOnClickListener{val toRemove=appointments.filter{it.seriesId==a.seriesId};toRemove.forEach{registerDeletedRegularAppointment(it);addTrashItem("APPOINTMENT",appointmentTrashPayload(it))};appointments.removeAll{it.id in toRemove.map{r->r.id}.toSet()};saveData();seqDialog.dismiss();calendarScreen()}
                seqDialog.show()
            }else{
                val (confirmDialog,outer,body)=packActionDialogBase("Elimina appuntamento?","🗑",Color.rgb(205,45,55),Color.rgb(255,225,228),Color.WHITE)
                body.addView(dialogBodyText("Vuoi eliminare l'appuntamento di ${displaySurnameFirst(a.name)} del ${a.date.format(fmt)} alle ${a.time}?"))
                val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                buttons.addView(dialogButton("Annulla",Color.rgb(65,80,100),Color.WHITE,Color.rgb(215,223,232)){confirmDialog.dismiss()},LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(0,0,dp(4),0)})
                buttons.addView(dialogButton("🗑  Elimina",Color.WHITE,Color.rgb(205,45,55),Color.rgb(205,45,55)){registerDeletedRegularAppointment(a);addTrashItem("APPOINTMENT",appointmentTrashPayload(a));appointments.remove(a);saveData();confirmDialog.dismiss();calendarScreen()},LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(dp(4),0,0,0)})
                body.addView(buttons)
                confirmDialog.show()
            }
        };cancel.setOnClickListener{dialog.dismiss()}}
        dialog.show()
    }

    private fun animateCalendarDialog(dialog: AlertDialog, content: View){
        dialog.window?.apply{
            // Disattiva l'animazione di finestra Android: evitiamo di sommare due
            // animazioni (sistema + Niki UI) mentre il calendario continua a essere renderizzato sotto.
            attributes = attributes.apply{windowAnimations = 0}
        }
        content.alpha = 0f
        content.scaleX = 0.985f
        content.scaleY = 0.985f
        content.translationY = dp(8).toFloat()
        content.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .translationY(0f)
            .setDuration(170)
            .setInterpolator(android.view.animation.DecelerateInterpolator())
            .start()
    }

    private fun animateSettingsPageIn(dialog: AlertDialog, content: View){
        val shouldAnimate=settingsTransitionPending
        settingsTransitionPending=false
        dialog.window?.apply{
            attributes=attributes.apply{windowAnimations=0}
        }
        if(!shouldAnimate)return
        content.animate().cancel()
        content.alpha=0f
        content.translationX=dp(34).toFloat()
        content.scaleX=0.985f
        content.scaleY=0.985f
        content.animate().alpha(1f).translationX(0f).scaleX(1f).scaleY(1f)
            .setDuration(210)
            .setInterpolator(android.view.animation.DecelerateInterpolator(1.15f))
            .withLayer().start()
    }

    private fun styleFullPageCoachDialog(dialog:AlertDialog){
        preparePopupBackdrop(dialog)
        dialog.setOnShowListener{
            popupBackdropCurrentDialog=dialog
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28))
            applyPopupBackdropEffect(dialog)
            dialog.window?.setDimAmount(0.40f)
            dialog.window?.let{w->
                val metrics=resources.displayMetrics
                w.setLayout((metrics.widthPixels*0.92f).toInt(),(metrics.heightPixels*0.82f).toInt())
                w.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
                // La finestra resta ferma, mentre la pagina interna è realmente scrollabile
                // anche quando il contenuto, a tastiera chiusa, sarebbe più corto del viewport.
                fun prepareScroll(v:View){
                    if(v is ScrollView){
                        v.isFillViewport=true
                        v.clipToPadding=false
                        v.setPadding(0,dp(76),0,dp(76))
                        val child=v.getChildAt(0)
                        if(child!=null){
                            v.post{
                                val extra=dp(152)
                                child.minimumHeight=maxOf(child.measuredHeight,v.height+extra)
                            }
                        }
                    }
                    if(v is ViewGroup){
                        for(i in 0 until v.childCount) prepareScroll(v.getChildAt(i))
                    }
                }
                w.decorView.post{prepareScroll(w.decorView)}
            }
        }
    }

    private fun styleModernCoachDialog(dialog:AlertDialog){
        preparePopupBackdrop(dialog)
        dialog.setOnShowListener{
            popupBackdropCurrentDialog=dialog
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28))
            applyPopupBackdropEffect(dialog)
            dialog.window?.setDimAmount(0.40f)
            dialog.window?.let{w->
                val metrics=resources.displayMetrics
                w.setLayout((metrics.widthPixels*0.92f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT)
                w.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
            }
            dialog.findViewById<TextView>(resources.getIdentifier("alertTitle","id","android"))?.apply{
                textSize=22f
                gravity=Gravity.CENTER
                textAlignment=View.TEXT_ALIGNMENT_CENTER
                setTextColor(Color.rgb(28,30,33))
                setTypeface(null,android.graphics.Typeface.NORMAL)
                layoutParams = (layoutParams ?: ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT)).apply {
                    width = ViewGroup.LayoutParams.MATCH_PARENT
                    gravity = Gravity.CENTER
                }
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.apply{setTextColor(Color.rgb(0,125,110));setAllCaps(false);stateListAnimator=null}
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.apply{setTextColor(Color.rgb(0,125,110));setAllCaps(false);stateListAnimator=null}
        }
    }

    private fun styleSettingsPageWindow(dialog:AlertDialog){
        dialog.window?.apply{
            // Settings uses a full-screen window, but NOT edge-to-edge into
            // the status bar. The status bar stays opaque white with dark
            // icons so Android/Samsung system icons never collide with the
            // Settings title or become unreadable on the light background.
            setBackgroundDrawable(roundedSurface(Color.WHITE,0))
            setDimAmount(0f)
            if(android.os.Build.VERSION.SDK_INT >= 30){
                setDecorFitsSystemWindows(true)
            }
            clearFlags(android.view.WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            if(android.os.Build.VERSION.SDK_INT >= 21){
                clearFlags(android.view.WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION)
            }
            addFlags(android.view.WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            statusBarColor=Color.WHITE
            navigationBarColor=Color.WHITE
            if(android.os.Build.VERSION.SDK_INT >= 28){
                navigationBarDividerColor=Color.WHITE
            }
            val metrics=resources.displayMetrics
            setLayout(metrics.widthPixels,metrics.heightPixels)
        }
    }

    private fun styleSettingsPageDialog(dialog:AlertDialog, returnToSettings:Boolean){
        var backHandled=false
        dialog.setOnKeyListener{_,keyCode,event->
            if(keyCode==android.view.KeyEvent.KEYCODE_BACK && event.action==android.view.KeyEvent.ACTION_UP){
                if(backHandled)return@setOnKeyListener true
                backHandled=true
                val content=dialog.window?.decorView
                if(content!=null){
                    content.animate().cancel()
                    content.animate().translationX(dp(34).toFloat()).alpha(0f)
                        .setDuration(170)
                        .setInterpolator(android.view.animation.DecelerateInterpolator(1.15f))
                        .withLayer()
                        .withEndAction{dialog.dismiss();if(returnToSettings)window.decorView.post{settings()}}
                        .start()
                }else{
                    dialog.dismiss()
                    if(returnToSettings)window.decorView.post{settings()}
                }
                true
            }else false
        }
        dialog.setOnCancelListener{
            removePopupBackdropDialog(dialog)
            if(!backHandled && returnToSettings){
                backHandled=true
                window.decorView.post{settings()}
            }
        }
    }

    private fun styleOneUiDialog(dialog:AlertDialog){
        preparePopupBackdrop(dialog)
        dialog.setOnShowListener{
            popupBackdropCurrentDialog=dialog
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28))
            applyPopupBackdropEffect(dialog)
            dialog.window?.setDimAmount(0.38f)
            dialog.findViewById<TextView>(resources.getIdentifier("alertTitle","id","android"))?.apply{
                textSize=22f
                gravity=Gravity.CENTER
                textAlignment=View.TEXT_ALIGNMENT_CENTER
                setTextColor(Color.rgb(28,30,33))
                setTypeface(null,android.graphics.Typeface.NORMAL)
                setPadding(0,dp(2),0,dp(2))
                layoutParams = (layoutParams ?: ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT)).apply {
                    width = ViewGroup.LayoutParams.MATCH_PARENT
                    gravity = Gravity.CENTER
                }
            }
            dialog.findViewById<TextView>(android.R.id.message)?.apply{
                textSize=16f
                setTextColor(Color.rgb(55,58,63))
                setLineSpacing(0f,1.05f)
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.apply{setTextColor(Color.rgb(0,125,110));setAllCaps(false);stateListAnimator=null;minHeight=0;minimumHeight=0}
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.apply{setTextColor(Color.rgb(0,125,110));setAllCaps(false);stateListAnimator=null;minHeight=0;minimumHeight=0}
        }
    }

    private fun appointmentDialog(existing:Appointment?, forcedDay:LocalDate?=null, forcedTime:String?=null){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(4),dp(14),0)}
        val name=AutoCompleteTextView(this).apply{hint="Cognome e Nome";setText(existing?.name?:"");setSingleLine(true);setAdapter(clientNameAutoCompleteAdapter((packs.map{it.name}+sessionPacks.map{it.name}).distinct()))}
        val date=modernEditText().apply{hint="Data (gg/mm/aaaa)";inputType=2;setText((existing?.date?:forcedDay?:calendarWeekStart).format(fmt))};setupDateInput(date)
        val time=Spinner(this).also{installNikiAppointmentTimePicker(it)}
        val type=Spinner(this);type.adapter=centeredSpinnerAdapter(appointmentTypes.map{it.name});type.setSelection(existing?.let{typeIndex(it.type)}?:0)
        var seriesEdit: Button? = null
        if(existing!=null && existing.seriesId!=0L){
            seriesEdit=Button(this).apply{
                text="↻  Modifica ripetizione";setAllCaps(false);textSize=15f;gravity=Gravity.CENTER_VERTICAL;setTextColor(Color.rgb(25,92,170))
                setTypeface(null,android.graphics.Typeface.BOLD)
                background=liquidInteractiveSurface(Color.rgb(232,242,255),20,Color.rgb(168,207,247),1);applyLiquidControlDepth(this);stateListAnimator=null
                setPadding(dp(14),0,dp(10),0)
            }
        }
        var recovery: CheckBox? = null

        // Mantieni aggiornata la fascia oraria disponibile anche nella nuova UI compatta.
        fun refreshTimeSlots(){
            val selectedType=typeIdAt(type.selectedItemPosition)
            val selectedDate=runCatching{parseDate(date.text.toString())}.getOrNull()?: (existing?.date?:forcedDay?:calendarWeekStart)
            val slots=availableTimeSlots(selectedDate,selectedType,existing)
            val values=if(slots.isEmpty()) listOf("NESSUNA FASCIA DISPONIBILE") else slots
            time.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,values)
            val wanted=existing?.time?:forcedTime
            if(wanted!=null){val idx=values.indexOf(wanted);if(idx>=0)time.setSelection(idx)}
        }

        fun refreshRecoveryOption(){
            if(existing!=null || recovery==null) return
            val selectedDate=runCatching{parseDate(date.text.toString())}.getOrNull() ?: LocalDate.now()
            val possiblePack=regularPackFor(name.text.toString(),selectedDate)
            val pending=possiblePack?.let{recoveriesForPack(it)} ?: 0
            recovery!!.isChecked=false
            recovery!!.isEnabled=pending>0
            recovery!!.visibility=if(pending>0)View.VISIBLE else View.GONE
            if(pending>0){
                val breakdown=possiblePack?.let{recoveryBreakdownLabel(it)}.orEmpty()
                recovery!!.text=if(breakdown.isNotBlank()) "↩ Recuperi disponibili: $breakdown" else "↩ Recupero seduta persa ($pending disponibile/i)"
            }
        }

        if(existing==null){
            // Creazione appuntamento: UI compatta e moderna. La logica di calendario/ripetizione resta invariata.
            val page=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(14),dp(18),dp(12))}
            val scroll=ScrollView(this).apply{isFillViewport=true;clipToPadding=false;setPadding(0,0,0,dp(24))}
            scroll.addView(page,ViewGroup.LayoutParams(-1,-2))

            val header=LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
                setPadding(dp(14),dp(10),dp(14),dp(10))
                background=roundedSurface(Color.rgb(238,246,255),22,Color.rgb(200,222,246),1)
            }
            val icon=ImageView(this).apply{
                setImageDrawable(calendarIconDrawable(Color.rgb(20,91,165)))
                scaleType=ImageView.ScaleType.CENTER_INSIDE
                background=roundedSurface(Color.WHITE,18)
                setPadding(dp(10),dp(10),dp(10),dp(10))
            }
            header.addView(icon,LinearLayout.LayoutParams(dp(50),dp(50)))
            val headerText=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),0,0,0)}
            headerText.addView(TextView(this).apply{
                text="Nuovo appuntamento";textSize=18f;setTextColor(Color.rgb(25,55,85));setTypeface(null,android.graphics.Typeface.BOLD)
            })
            headerText.addView(TextView(this).apply{
                text="Aggiungi un nuovo appuntamento al calendario";textSize=12.5f;setTextColor(Color.rgb(82,104,125));setPadding(0,dp(3),0,0)
            })
            header.addView(headerText,LinearLayout.LayoutParams(0,-2,1f))
            page.addView(header,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})

            fun modernSpinner(spinner:Spinner){
                spinner.background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(220,226,234),1)
                applyLiquidControlDepth(spinner)
                spinner.setPadding(dp(14),0,dp(10),0)
            }
            name.background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(220,226,234),1)
            applyLiquidControlDepth(name)
            name.setPadding(dp(14),0,dp(14),0)
            name.textSize=16f
            name.setTextColor(Color.rgb(35,38,42))
            name.setHintTextColor(Color.rgb(135,140,147))
            styleClientNameSuggestions(name)
            name.isFocusable=true;name.isFocusableInTouchMode=true
            modernSpinner(time);modernSpinner(type)
            val fields=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
            fields.addView(TextView(this).apply{text="Cognome e Nome";textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,74,80));setPadding(dp(2),0,0,dp(5))})
            fields.addView(name,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(6))})
            val packageAvailabilityBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(9),dp(12),dp(9));background=liquidInteractiveSurface(Color.rgb(241,247,253),18,Color.rgb(202,222,242),1);visibility=View.GONE;applyLiquidControlDepth(this)}
            val packageAvailabilityTitle=TextView(this).apply{text="📦  Disponibilità pacchetto";textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,75,115));setPadding(0,0,0,dp(5))}
            val packageAvailability=TextView(this).apply{textSize=12.5f;setTextColor(Color.rgb(65,95,125));setLineSpacing(0f,1.05f)}
            packageAvailabilityBox.addView(packageAvailability)
            fields.addView(packageAvailabilityBox,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})
            fun refreshPackageAvailability(){
                val key=identityKey(name.text.toString());val sp=sessionPacks.filter{it.active&&identityKey(it.name)==key}.maxByOrNull{it.start}
                val selectedDate=runCatching{parseDate(date.text.toString())}.getOrNull()?:LocalDate.now()
                // Tutti i pacchetti a programmazione settimanale (Bronze/Silver/Gold
                // e settimanale personalizzato) devono mostrare sempre la quota
                // prevista per la settimana corrente, anche quando non è ancora
                // stato programmato nessun appuntamento. I recuperi restano
                // separati e non sostituiscono mai le disponibilità normali.
                val wp=regularPackFor(name.text.toString(),selectedDate)
                if(sp!=null&&sp.customQuantities.isNotEmpty()){
                    val lines=sp.customQuantities.entries.sortedBy{typeLabel(it.key)}.joinToString("\n"){(id,_)->"${typeLabel(id)}   ${customSessionPackRemaining(sp,id)} disponibili"}
                    packageAvailability.text=lines;packageAvailabilityBox.visibility=View.VISIBLE
                }else if(wp!=null&&(wp.weeklyQuantities.isNotEmpty() || wp.includedAppointmentType!=null)){
                    val types=if(wp.packageType=="WEEKLY_CUSTOM") wp.weeklyQuantities.keys.toList() else listOfNotNull(wp.includedAppointmentType)
                    val availableLines=types.sortedBy{typeLabel(it)}.map{"${typeLabel(it)}   ${weeklyRemainingThisWeek(wp,selectedDate,it)} disponibili"}
                    val recoveryLines=recoveryBreakdownForPack(wp).map{"${it.second} ${typeLabel(it.first)}"}
                    val text=buildString{
                        append("Disponibili questa settimana\n")
                        append(availableLines.joinToString("\n"))
                        if(recoveryLines.isNotEmpty()){
                            append("\n\nRecuperi disponibili\n")
                            append(recoveryLines.joinToString("\n"))
                        }
                    }
                    packageAvailability.text=text;packageAvailabilityBox.visibility=View.VISIBLE
                }else packageAvailabilityBox.visibility=View.GONE
            }
            fun applyPackageTypePreselection(){
                val selectedDate=runCatching{parseDate(date.text.toString())}.getOrNull()?:LocalDate.now()
                val standard=standardPackFor(name.text.toString(),selectedDate)
                val includedStandard=standard?.includedAppointmentType
                if(includedStandard!=null&&includedStandard.isNotBlank()){
                    val idx=appointmentTypes.indexOfFirst{it.id==includedStandard}
                    if(idx>=0){type.setSelection(idx);return}
                }
                val sp=sessionPacks.filter{it.active&&identityKey(it.name)==identityKey(name.text.toString())}.maxByOrNull{it.start}
                if(sp!=null&&sp.customQuantities.size==1){
                    val onlyType=sp.customQuantities.keys.first()
                    val idx=appointmentTypes.indexOfFirst{it.id==onlyType}
                    if(idx>=0)type.setSelection(idx)
                }
            }
            name.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){applyPackageTypePreselection();refreshPackageAvailability()};override fun afterTextChanged(s:Editable?){} })
            date.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){applyPackageTypePreselection();refreshPackageAvailability()};override fun afterTextChanged(s:Editable?){} })
            type.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener{override fun onNothingSelected(parent:android.widget.AdapterView<*>?){};override fun onItemSelected(parent:android.widget.AdapterView<*>?,view:View?,position:Int,id:Long){refreshPackageAvailability()}}
            fields.addView(TextView(this).apply{text="Data";textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,74,80));setPadding(dp(2),0,0,dp(5))})
            fields.addView(date,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(10))})
            fields.addView(TextView(this).apply{text="Fascia oraria disponibile";textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,74,80));setPadding(dp(2),0,0,dp(5))})
            fields.addView(time,LinearLayout.LayoutParams(dp(110),dp(50)).apply{gravity=Gravity.CENTER;setMargins(0,0,0,dp(10))})
            fields.addView(TextView(this).apply{text="Tipo appuntamento";textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,74,80));setPadding(dp(2),0,0,dp(5))})
            fields.addView(type,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(10))})
            page.addView(fields)
            recovery=CheckBox(this).apply{
                text="↩ Recupero seduta persa";textSize=13.5f;setTextColor(Color.rgb(55,58,63));setPadding(0,0,0,0);visibility=View.GONE
            }
            page.addView(recovery,LinearLayout.LayoutParams(-1,dp(44)).apply{setMargins(dp(2),0,0,dp(2))})

            val repeat=CheckBox(this).apply{
                text="Ripeti ogni settimana";textSize=14f;setTextColor(Color.rgb(35,38,42));setPadding(0,0,0,0)
            }
            val repeatRow=LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
                setPadding(dp(12),dp(7),dp(10),dp(7))
                background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(220,226,234),1)
                applyLiquidControlDepth(this)
                addView(repeat,LinearLayout.LayoutParams(0,dp(48),1f))
            }
            page.addView(repeatRow,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})

            // Quando si apre il selettore del tipo, nascondiamo solo visivamente
            // la riga "Ripeti ogni settimana" per evitare che il popup la copra.
            // Lo stato del checkbox e l'eventuale pannello dei giorni restano invariati.
            installNikiTypeDropdown(
                type,
                centerOnSpinner = true,
                replaceAnchor = true,
                onPopupShown = { repeatRow.visibility = View.INVISIBLE },
                onPopupDismissed = { repeatRow.visibility = View.VISIBLE }
            )

            val repeatPanel=LinearLayout(this).apply{
                orientation=LinearLayout.VERTICAL;visibility=View.GONE
                setPadding(dp(12),dp(10),dp(12),dp(10))
                background=roundedSurface(Color.rgb(238,246,255),20,Color.rgb(205,225,247),1)
            }
            repeatPanel.addView(TextView(this).apply{
                text="Seleziona giorni e orari";textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,75,125));setPadding(0,0,0,dp(7))
            })
            val days=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
            // La ripetizione segue gli stessi giorni attivi del calendario: se la settimana
            // è impostata lunedì-venerdì, sabato e domenica non vengono proprio proposti.
            val activeDayIndexes=(0..6).filter{calendarVisibleDays.getOrElse(it){false}}
            val fallbackDay=(forcedDay?:calendarWeekStart).dayOfWeek.value-1
            val defaultDay=if(fallbackDay in activeDayIndexes)fallbackDay else activeDayIndexes.firstOrNull()?:fallbackDay
            val checks=(0..6).map{i->CheckBox(this).apply{text=dayShort(i);isChecked=i==defaultDay&&i in activeDayIndexes;setPadding(0,0,0,0);visibility=if(i in activeDayIndexes)View.VISIBLE else View.GONE}}
            val dayTimes=mutableMapOf<Int,Spinner>()
            val dayRows=mutableMapOf<Int,LinearLayout>()
            fun datesForWeekday(dayIndex:Int,start:LocalDate,end:LocalDate):List<LocalDate>{
                val out=mutableListOf<LocalDate>();var d=start
                while(!d.isAfter(end)){if(d.dayOfWeek.value-1==dayIndex)out.add(d);d=d.plusDays(1)}
                return out
            }
            fun slotsForWeekday(dayIndex:Int,start:LocalDate,end:LocalDate,selectedType:String):List<String>{
                val dates=datesForWeekday(dayIndex,start,end);if(dates.isEmpty())return emptyList()
                val first=availableTimeSlots(dates.first(),selectedType,existing)
                return first.filter{slot->dates.all{d->canAdd(d,slot,selectedType,if(existing?.date==d)existing else null)}}
            }
            val end=modernEditText().apply{hint="Fine ripetizione (gg/mm/aaaa)";inputType=2;setText(calendarWeekStart.plusWeeks(12).format(fmt));visibility=View.GONE};setupDateInput(end)
            repeatPanel.addView(days)
            repeatPanel.addView(end,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(8),0,0)})
            page.addView(repeatPanel,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})
            checks.forEachIndexed{idx,c->
                if(idx !in activeDayIndexes)return@forEachIndexed
                val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                row.addView(c,LinearLayout.LayoutParams(0,dp(48),1f))
                val spinner=Spinner(this).also{
                    installNikiTimeDropdown(
                        it,
                        true,
                        onPopupShown = {
                            // Quando la rotella è aperta, nascondiamo SOLO visivamente
                            // gli orari dei giorni selezionati. Le righe restano ferme e
                            // occupano esattamente lo stesso spazio: così la rotella non
                            // crea doppie letture, ma la finestra non si muove.
                            checks.forEachIndexed { dayIndex, check ->
                                if (!check.isChecked) return@forEachIndexed
                                dayTimes[dayIndex]?.animate()
                                    ?.alpha(0.035f)
                                    ?.scaleX(0.985f)
                                    ?.scaleY(0.985f)
                                    ?.setDuration(120L)
                                    ?.setInterpolator(android.view.animation.DecelerateInterpolator())
                                    ?.start()
                            }
                        },
                        onPopupDismissed = {
                            // Ricomparsa morbida degli orari, senza modificare la posizione
                            // delle righe né il layout del pannello.
                            checks.forEachIndexed { dayIndex, check ->
                                if (!check.isChecked) return@forEachIndexed
                                dayTimes[dayIndex]?.animate()
                                    ?.alpha(1f)
                                    ?.scaleX(1f)
                                    ?.scaleY(1f)
                                    ?.setDuration(180L)
                                    ?.setInterpolator(android.view.animation.DecelerateInterpolator())
                                    ?.start()
                            }
                        }
                    )
                };modernSpinner(spinner);dayTimes[idx]=spinner
                row.addView(spinner,LinearLayout.LayoutParams(dp(110),dp(46)).apply{gravity=Gravity.CENTER_VERTICAL})
                dayRows[idx]=row;days.addView(row)
            }
            if(activeDayIndexes.isEmpty()){
                days.addView(TextView(this).apply{text="Nessun giorno attivo nel calendario.";textSize=13f;setTextColor(Color.rgb(115,120,126));setPadding(0,dp(6),0,dp(8))})
            }
            fun refreshDayTimeRows(){
                val startDate=runCatching{parseDate(date.text.toString())}.getOrNull()?:calendarWeekStart
                val endDate=runCatching{parseDate(end.text.toString())}.getOrNull()?:startDate
                val selectedType=typeIdAt(type.selectedItemPosition)
                checks.forEachIndexed{idx,c->
                    val row=dayRows[idx]?:return@forEachIndexed;val spinner=dayTimes[idx]?:return@forEachIndexed
                    // I sette giorni restano sempre visibili: solo l'orario viene mostrato
                    // quando il relativo giorno è selezionato.
                    row.visibility=View.VISIBLE
                    spinner.visibility=if(c.isChecked)View.VISIBLE else View.INVISIBLE
                    spinner.isEnabled=c.isChecked
                    if(!c.isChecked)return@forEachIndexed
                    val values=slotsForWeekday(idx,startDate,endDate,selectedType);val shown=if(values.isEmpty())listOf("NESSUNA FASCIA DISPONIBILE") else values
                    spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,shown)
                    val preferred=if(idx==((forcedDay?:calendarWeekStart).dayOfWeek.value-1))time.selectedItem?.toString()else null
                    if(preferred!=null){val pi=shown.indexOf(preferred);if(pi>=0)spinner.setSelection(pi)}
                    spinner.isEnabled=values.isNotEmpty()
                }
            }
            // Listener collegati dopo la dichiarazione della funzione locale: evita riferimenti non risolti in Kotlin.
            checks.forEach{c->c.setOnCheckedChangeListener{_,_->refreshDayTimeRows()}}
            type.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{
                override fun onNothingSelected(parent:AdapterView<*>?){ }
                override fun onItemSelected(parent:AdapterView<*>?,view:View?,position:Int,id:Long){
                    refreshTimeSlots()
                    if(repeat.isChecked) refreshDayTimeRows()
                }
            }
            var dialogRef:AlertDialog?=null
            repeat.setOnCheckedChangeListener{_,checked->
                repeatPanel.visibility=if(checked)View.VISIBLE else View.GONE
                end.visibility=if(checked)View.VISIBLE else View.GONE
                time.visibility=if(checked)View.GONE else View.VISIBLE
                recovery?.visibility=if(checked)View.GONE else if(recovery?.isEnabled==true)View.VISIBLE else View.GONE
                refreshDayTimeRows()
                dialogRef?.window?.let{w->
                    val target=if(checked)ViewGroup.LayoutParams.WRAP_CONTENT else ViewGroup.LayoutParams.WRAP_CONTENT
                    w.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),target)
                }
                if(checked){
                    repeatPanel.alpha=0f
                    repeatPanel.translationY=-dp(10).toFloat()
                    repeatPanel.animate().alpha(1f).translationY(0f).setDuration(180).start()
                    // Dopo l'espansione porta automaticamente la nuova sezione in vista,
                    // lasciando comunque lo ScrollView libero di muoversi in entrambe le direzioni.
                    scroll.postDelayed({
                        val target=(repeatPanel.top-dp(12)).coerceAtLeast(0)
                        scroll.smoothScrollTo(0,target)
                    },220)
                } else {
                    scroll.post{scroll.smoothScrollTo(0,0)}
                }
            }
            date.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){refreshTimeSlots();if(repeat.isChecked)refreshDayTimeRows();refreshRecoveryOption()};override fun afterTextChanged(s:Editable?){}})
            name.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){refreshRecoveryOption();refreshPackageAvailability()};override fun afterTextChanged(s:Editable?){}})
            applyPackageTypePreselection()
            refreshPackageAvailability()
            end.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){if(repeat.isChecked)refreshDayTimeRows()};override fun afterTextChanged(s:Editable?){}})

            val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            val cancel=TextView(this).apply{text="Annulla";textSize=14f;setTextColor(Color.rgb(20,91,165));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(220,226,234),1);isClickable=true;applyLiquidControlDepth(this)}
            val save=TextView(this).apply{text="✓ Salva";textSize=14f;setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);background=liquidInteractiveSurface(Color.rgb(232,243,255),20,Color.rgb(188,211,238),1);isClickable=true;applyLiquidControlDepth(this)}
            actions.addView(cancel,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(6),0)})
            actions.addView(save,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(6),0,0,0)})
            page.addView(actions,LinearLayout.LayoutParams(-1,dp(48)))
            page.setPadding(dp(18),dp(14),dp(18),dp(24))

            listOf<View>(name,date,end).forEach{field->field.setOnFocusChangeListener{_,hasFocus->if(hasFocus)scroll.post{scroll.smoothScrollTo(0,(field.top-dp(24)).coerceAtLeast(0))}}}
            val dialog=AlertDialog.Builder(this).setView(scroll).create()
            preparePopupBackdrop(dialog)
            dialog.setOnShowListener{
                popupBackdropCurrentDialog=dialog
                dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28))
                applyPopupBackdropEffect(dialog);dialog.window?.setDimAmount(0.40f)
                dialog.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
                dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT)
                animateCalendarDialog(dialog,scroll)
                name.clearFocus();date.clearFocus();end.clearFocus()
            }
            cancel.setOnClickListener{dialog.dismiss()}
            save.setOnClickListener{
                val selectedDayTimes=dayTimes.filterKeys{it in activeDayIndexes && checks[it].isChecked}.mapValues{it.value.selectedItem?.toString() ?: ""}
                createAppointments(name.text.toString().trim(),date.text.toString(),time.selectedItem?.toString() ?: "",typeIdAt(type.selectedItemPosition),repeat.isChecked,checks,end.text.toString(),recovery?.isChecked==true,dayTimes=selectedDayTimes)
                dialog.dismiss()
            }
            dialogRef=dialog
            dialog.show()
            refreshTimeSlots()
            refreshRecoveryOption()
            refreshDayTimeRows()
        }else{
            val page=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(14),dp(18),dp(18))}
            val scroll=ScrollView(this).apply{isFillViewport=true;clipToPadding=false;setPadding(0,0,0,dp(8));addView(page,ViewGroup.LayoutParams(-1,-2))}

            val top=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_HORIZONTAL}
            val icon=TextView(this).apply{
                text="✎";textSize=24f;gravity=Gravity.CENTER;setTextColor(Color.rgb(25,105,190))
                background=roundedSurface(Color.rgb(225,239,255),50);setPadding(dp(12),dp(10),dp(12),dp(10))
            }
            top.addView(icon,LinearLayout.LayoutParams(dp(64),dp(64)).apply{gravity=Gravity.CENTER})
            top.addView(TextView(this).apply{text="Modifica appuntamento";textSize=22f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(24,35,50));gravity=Gravity.CENTER;setPadding(0,dp(10),0,dp(2))},LinearLayout.LayoutParams(-1,dp(38)))
            top.addView(TextView(this).apply{text="Modifica i dati dell'appuntamento";textSize=13.5f;setTextColor(Color.rgb(88,98,110));gravity=Gravity.CENTER;setPadding(0,0,0,dp(12))},LinearLayout.LayoutParams(-1,dp(30)))
            page.addView(top)

            fun label(t:String)=TextView(this).apply{text=t;textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,78,88));setPadding(dp(2),0,0,dp(5))}
            fun modernAuto(v:AutoCompleteTextView){v.background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(220,226,234),1);applyLiquidControlDepth(v);v.setPadding(dp(14),0,dp(14),0);v.textSize=16f;v.setTextColor(Color.rgb(35,38,42));v.setHintTextColor(Color.rgb(135,140,147))}
            fun modernSpinner(v:Spinner){v.background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(220,226,234),1);applyLiquidControlDepth(v);v.setPadding(dp(12),0,dp(10),0)}
            modernAuto(name)
            styleClientNameSuggestions(name)
            // date è un EditText: manteniamo il campo moderno separato.
            date.background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(220,226,234),1);applyLiquidControlDepth(date);date.setPadding(dp(14),0,dp(14),0);date.textSize=16f
            modernSpinner(time);modernSpinner(type);installNikiTypeDropdown(type)
            val fields=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(2),0,dp(2),0)}
            fields.addView(label("Cognome e Nome"));fields.addView(name,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(10))})
            fields.addView(label("Data"));fields.addView(date,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(10))})
            fields.addView(label("Fascia oraria"));fields.addView(time,LinearLayout.LayoutParams(dp(110),dp(50)).apply{gravity=Gravity.CENTER;setMargins(0,0,0,dp(10))})
            fields.addView(label("Tipo appuntamento"));fields.addView(type,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(8))})
            page.addView(fields)
            if(seriesEdit!=null){
                page.addView(seriesEdit,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(6),0,dp(8))})
            }
            val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            val cancel=TextView(this).apply{text="Annulla";textSize=14f;setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(218,225,234),1);isClickable=true;applyLiquidControlDepth(this)}
            val save=TextView(this).apply{text="✓ Salva";textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;background=liquidInteractiveSurface(Color.rgb(232,243,255),20,Color.rgb(188,211,238),1);isClickable=true;applyLiquidControlDepth(this)}
            actions.addView(cancel,LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(0,0,dp(5),0)});actions.addView(save,LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(dp(5),0,0,0)})
            page.addView(actions,LinearLayout.LayoutParams(-1,dp(50)))
            listOf<View>(name,date).forEach{field->field.setOnFocusChangeListener{_,hasFocus->if(hasFocus)scroll.post{scroll.smoothScrollTo(0,(field.top-dp(20)).coerceAtLeast(0))}}}
            // La schermata di modifica usa esattamente la stessa struttura Glass
            // della schermata "Nuovo appuntamento": una sola superficie sulla finestra,
            // senza un secondo pannello Glass interno che crea una doppia fascia in basso.
            val dialog=AlertDialog.Builder(this).setView(scroll).create()
            preparePopupBackdrop(dialog)
            dialog.setOnShowListener{
                popupBackdropCurrentDialog=dialog
                dialog.window?.apply{
                    setBackgroundDrawable(roundedSurface(Color.WHITE,28))
                    setDimAmount(0.40f)
                    setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT)
                    setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
                }
                applyPopupBackdropEffect(dialog)
                animateCalendarDialog(dialog,scroll)
            }
            cancel.setOnClickListener{dialog.dismiss()}
            save.setOnClickListener{updateAppointment(existing,name.text.toString().trim(),date.text.toString(),time.selectedItem?.toString() ?: "",typeIdAt(type.selectedItemPosition));dialog.dismiss()}
            dialog.show();refreshTimeSlots();seriesEdit?.setOnClickListener{dialog.dismiss();editSeriesProgramming(existing!!)}
        }
    }

    private fun editSeriesProgramming(anchor:Appointment){
        val seriesId=anchor.seriesId
        if(seriesId==0L)return
        val series=appointments.filter{it.seriesId==seriesId}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        if(series.isEmpty())return
        val future=series.filter{!it.date.isBefore(anchor.date)}
        if(future.isEmpty())return
        val endDate=series.maxOf{it.date}

        val page=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(18),dp(10),dp(18),dp(12))
        }
        val scroll=ScrollView(this).apply{
            isFillViewport=true
            clipToPadding=false
            setPadding(0,0,0,dp(18))
            addView(page,ViewGroup.LayoutParams(-1,-2))
        }

        // Header Niki UI: icona grafica + titolo + contesto, senza emoji.
        val header=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(12),dp(10),dp(12),dp(12))
            background=liquidInteractiveSurface(Color.rgb(238,246,255),22,Color.rgb(194,220,247),1)
        }
        val icon=TextView(this).apply{
            text="↻";textSize=30f;gravity=Gravity.CENTER
            setTextColor(Color.rgb(25,92,170))
            background=liquidInteractiveSurface(Color.rgb(222,237,255),20)
        }
        header.addView(icon,LinearLayout.LayoutParams(dp(56),dp(56)))
        val headerText=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
        headerText.addView(TextView(this).apply{
            text="Modifica ripetizione";textSize=19f;setTextColor(Color.rgb(24,38,58));setTypeface(null,android.graphics.Typeface.BOLD)
        })
        headerText.addView(TextView(this).apply{
            text="Modifica da ${anchor.date.format(fmt)} in poi";textSize=13f;setTextColor(Color.rgb(82,104,125));setPadding(0,dp(3),0,0)
        })
        header.addView(headerText,LinearLayout.LayoutParams(0,-2,1f))
        page.addView(header,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})

        page.addView(TextView(this).apply{
            text="Scegli i giorni e gli orari della nuova programmazione";textSize=14f;setTextColor(Color.rgb(55,64,76));setPadding(dp(2),0,dp(2),dp(10))
        })

        val type=Spinner(this).apply{adapter=centeredSpinnerAdapter(appointmentTypes.map{it.name});setSelection(typeIndex(anchor.type));installNikiTypeDropdown(this);background=liquidInteractiveSurface(Color.rgb(248,249,251),18,Color.rgb(220,226,234),1);setPadding(dp(14),0,dp(10),0)}
        page.addView(TextView(this).apply{text="Tipo appuntamento";textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,74,80));setPadding(dp(2),0,0,dp(5))})
        page.addView(type,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(12))})

        val days=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        page.addView(TextView(this).apply{text="Giorni";textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,74,80));setPadding(dp(2),0,0,dp(6))})

        val checks=(0..6).map{i->CheckBox(this).apply{
            text=dayShort(i);textSize=15f;setTextColor(Color.rgb(35,38,42));setPadding(0,0,0,0);isChecked=future.any{it.date.dayOfWeek.value-1==i}
        }}
        val dayTimes=mutableMapOf<Int,Spinner>()
        val rows=mutableMapOf<Int,LinearLayout>()

        fun datesForDay(dayIndex:Int):List<LocalDate>{
            val out=mutableListOf<LocalDate>();var d=anchor.date
            while(!d.isAfter(endDate)){if(d.dayOfWeek.value-1==dayIndex)out.add(d);d=d.plusDays(1)}
            return out
        }
        fun availableSeriesSlots(dayIndex:Int,selectedType:String):List<String>{
            val dates=datesForDay(dayIndex)
            if(dates.isEmpty())return emptyList()
            val first=availableTimeSlotsAfterSeriesRemoval(dates.first(),selectedType,seriesId)
            return first.filter{slot->dates.all{d->canAddAfterSeriesRemoval(d,slot,selectedType,seriesId)}}
        }
        fun refresh(){
            val selectedType=typeIdAt(type.selectedItemPosition)
            checks.forEachIndexed{idx,c->
                val spinner=dayTimes[idx] ?: return@forEachIndexed
                val row=rows[idx] ?: return@forEachIndexed
                row.alpha=if(c.isChecked)1f else 0.72f
                spinner.visibility=if(c.isChecked)View.VISIBLE else View.INVISIBLE
                if(!c.isChecked)return@forEachIndexed
                val values=availableSeriesSlots(idx,selectedType)
                val shown=if(values.isEmpty())listOf("NESSUNA FASCIA DISPONIBILE") else values
                spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,shown)
                val preferred=future.firstOrNull{it.date.dayOfWeek.value-1==idx}?.time
                if(preferred!=null){val pi=shown.indexOf(preferred);if(pi>=0)spinner.setSelection(pi)}
                spinner.isEnabled=values.isNotEmpty()
            }
        }

        checks.forEachIndexed{idx,c->
            val row=LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
                setPadding(dp(12),dp(2),dp(8),dp(2))
                background=liquidInteractiveSurface(Color.rgb(248,249,251),18,Color.rgb(220,226,234),1)
            }
            row.addView(c,LinearLayout.LayoutParams(0,dp(50),1f))
            val spinner=Spinner(this).also{
                installNikiTimeDropdown(it, true)
                it.background=liquidInteractiveSurface(Color.rgb(248,249,251),16,Color.rgb(220,226,234),1)
                it.setPadding(dp(10),0,dp(6),0)
            }
            dayTimes[idx]=spinner
            row.addView(spinner,LinearLayout.LayoutParams(dp(110),dp(46)).apply{gravity=Gravity.CENTER_VERTICAL})
            rows[idx]=row
            days.addView(row,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,0,0,dp(6))})
            c.setOnCheckedChangeListener{_,_->refresh()}
        }
        page.addView(days,LinearLayout.LayoutParams(-1,-2))

        val endCard=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(12),dp(10),dp(12),dp(10))
            background=liquidInteractiveSurface(Color.rgb(232,243,255),18,Color.rgb(192,220,248),1)
        }
        endCard.addView(TextView(this).apply{text="▣";textSize=22f;setTextColor(Color.rgb(25,92,170));gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(38),dp(38)))
        endCard.addView(TextView(this).apply{
            text="Fine programmazione: ${endDate.format(fmt)}\nVerranno aggiornati gli appuntamenti futuri selezionati.";textSize=13f;setTextColor(Color.rgb(55,74,96));setLineSpacing(0f,1.05f);setPadding(dp(8),0,0,0)
        },LinearLayout.LayoutParams(0,-2,1f))
        page.addView(endCard,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(8),0,dp(12))})

        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val cancel=TextView(this).apply{
            text="Annulla";textSize=14f;setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);isClickable=true
            background=liquidInteractiveSurface(Color.rgb(248,249,251),18,Color.rgb(188,211,238),1)
        }
        val save=TextView(this).apply{
            text="✓ Salva";textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;isClickable=true
            background=liquidInteractiveSurface(Color.rgb(232,243,255),18,Color.rgb(188,211,238),1);applyLiquidControlDepth(this)
        }
        actions.addView(cancel,LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(0,0,dp(5),0)})
        actions.addView(save,LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(dp(5),0,0,0)})
        page.addView(actions,LinearLayout.LayoutParams(-1,dp(50)))

        type.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent:AdapterView<*>?){ }
            override fun onItemSelected(parent:AdapterView<*>?,view:View?,position:Int,id:Long){refresh()}
        }
        val dialog=AlertDialog.Builder(this).setView(scroll).create()
        styleFullPageCoachDialog(dialog)
        cancel.setOnClickListener{dialog.dismiss()}
        save.setOnClickListener{
            val selected=checks.mapIndexedNotNull{idx,c->if(c.isChecked)idx else null}
            if(selected.isEmpty()){Toast.makeText(this,"Seleziona almeno un giorno.",Toast.LENGTH_LONG).show();return@setOnClickListener}
            val selectedType=typeIdAt(type.selectedItemPosition)
            val times=selected.associateWith{idx->dayTimes[idx]?.selectedItem?.toString()?.takeUnless{it=="NESSUNA FASCIA DISPONIBILE"}}
            if(times.values.any{it==null}){Toast.makeText(this,"Scegli un orario disponibile per ogni giorno selezionato.",Toast.LENGTH_LONG).show();return@setOnClickListener}
            applySeriesProgrammingFrom(anchor,selected,times.mapValues{it.value!!},selectedType,endDate)
            dialog.dismiss()
        }
        dialog.show()
        animateSeriesProgrammingIn(dialog,scroll)
        refresh()
    }

    private fun animateSeriesProgrammingIn(dialog: AlertDialog, content: View){
        dialog.window?.attributes = dialog.window?.attributes?.apply{windowAnimations=0}
        content.animate().cancel()
        content.alpha=0f
        content.translationX=dp(34).toFloat()
        content.scaleX=0.985f
        content.scaleY=0.985f
        content.animate().alpha(1f).translationX(0f).scaleX(1f).scaleY(1f)
            .setDuration(210)
            .setInterpolator(android.view.animation.DecelerateInterpolator(1.15f))
            .withLayer().start()
    }

    private fun availableTimeSlotsAfterSeriesRemoval(date:LocalDate,type:String,seriesId:Long):List<String>{
        return (0 until calendarSlotCount()).map{slot -> val mins=7*60+slot*calendarSlotDuration; String.format("%02d:%02d",mins/60,mins%60)}.filter{slot->canAddAfterSeriesRemoval(date,slot,type,seriesId)}
    }

    private fun canAddAfterSeriesRemoval(date:LocalDate,time:String,type:String,seriesId:Long):Boolean{
        val r=calendarRoutines.getOrNull(activeRoutineIndex)?:CalendarRoutine("Personalizzata",3,MutableList(appointmentTypes.size){3})
        val items=appointments.filter{it.date==date&&it.time==time&&it.seriesId!=seriesId}
        if(items.size>=r.maxTotal)return false
        val idx=typeIndex(type);if(items.count{typeIndex(it.type)==idx}>=(r.maxByType.getOrNull(idx)?:r.maxTotal))return false
        return true
    }

    private fun applySeriesProgrammingFrom(anchor:Appointment,selectedDays:List<Int>,dayTimes:Map<Int,String>,type:String,endDate:LocalDate){
        val seriesId=anchor.seriesId
        val future=appointments.filter{it.seriesId==seriesId&&!it.date.isBefore(anchor.date)}
        if(future.isEmpty())return
        val sessionPackId=future.firstOrNull{it.sessionPackId!=0L}?.sessionPackId ?: anchor.sessionPackId
        val futureIds=future.map{it.id}.toSet()
        appointments.removeAll{it.id in futureIds}
        var d=anchor.date;var created=0;var skipped=0
        val linked=sessionPackId.takeIf{it!=0L}?.let{id->sessionPacks.firstOrNull{it.id==id}}
        while(!d.isAfter(endDate)){
            val idx=d.dayOfWeek.value-1
            if(idx in selectedDays){
                val t=dayTimes[idx]!!
                val capacityOk=canAdd(d,t,type)
                if(capacityOk){appointments.add(Appointment(nextAppointmentId++,anchor.name,d,t,type,seriesId,sessionPackId,anchor.recovery));created++}else skipped++
            }
            d=d.plusDays(1)
        }
        saveData();calendarScreen()
        if(skipped>0)Toast.makeText(this,"$skipped appuntamenti non inseriti perché la fascia o il pacchetto non erano disponibili.",Toast.LENGTH_LONG).show()
    }

    private fun closureAppointmentsConfirmDialog(affected:List<Appointment>, onPositive:()->Unit){
        val dialog=Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val glass = popupBackdropEffect != "NONE"
        val outerBg = if(glass) dialogReadableSurface(Color.rgb(246,250,255),28,Color.rgb(188,218,246),1)
                      else roundedSurface(Color.WHITE,28,Color.rgb(218,225,232),1)
        val cardBg = if(glass) dialogReadableSurface(Color.rgb(250,252,255),20,Color.rgb(210,226,243),1)
                     else roundedSurface(Color.rgb(248,250,253),20,Color.rgb(224,229,235),1)

        val outer=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(14),dp(10),dp(14),dp(12))
            background=outerBg
            clipToPadding=false
        }

        // Header fisso: non entra nell'area scrollabile.
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        top.addView(Space(this),LinearLayout.LayoutParams(0,dp(38),1f))
        top.addView(TextView(this).apply{
            text="×";textSize=28f;gravity=Gravity.CENTER;setTextColor(Color.rgb(65,78,96));
            setOnClickListener{dialog.dismiss()}
        },LinearLayout.LayoutParams(dp(42),dp(38)))
        outer.addView(top)

        val iconView=TextView(this).apply{
            text="!";textSize=30f;gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(225,150,20));background=roundedSurface(Color.rgb(255,247,226),40)
        }
        outer.addView(iconView,LinearLayout.LayoutParams(dp(68),dp(68)).apply{gravity=Gravity.CENTER;setMargins(0,0,0,dp(10))})

        outer.addView(TextView(this).apply{
            text="Appuntamenti durante la chiusura";textSize=21f;setTypeface(null,android.graphics.Typeface.BOLD)
            gravity=Gravity.CENTER;setTextColor(Color.rgb(24,35,52));setLineSpacing(0f,0.98f)
        },LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(8),0,dp(8),dp(4))})

        val info=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(12));background=cardBg
        }
        val warningLine=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
        }
        warningLine.addView(TextView(this).apply{
            text="!";textSize=22f;gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(225,150,20))
            background=roundedSurface(Color.rgb(255,247,226),30)
        },LinearLayout.LayoutParams(dp(46),dp(46)))
        warningLine.addView(TextView(this).apply{
            text="Hai ${affected.size} appuntamento/i nelle settimane che stai impostando come chiusura."
            textSize=14.5f;setTextColor(Color.rgb(45,63,84));setLineSpacing(0f,1.08f);setPadding(dp(10),0,dp(2),0)
        },LinearLayout.LayoutParams(0,-2,1f))
        info.addView(warningLine,LinearLayout.LayoutParams(-1,-2))
        info.addView(View(this).apply{setBackgroundColor(Color.argb(45,70,100,130))},LinearLayout.LayoutParams(-1,dp(1)).apply{setMargins(0,dp(10),0,dp(10))})
        info.addView(TextView(this).apply{
            text="Gli appuntamenti resteranno nel calendario, ma non consumeranno sedute dei pacchetti perché lo studio risulterà chiuso."
            textSize=13.5f;setTextColor(Color.rgb(55,70,90));setLineSpacing(0f,1.05f);setPadding(dp(2),0,dp(2),0)
        },LinearLayout.LayoutParams(-1,-2))
        outer.addView(info,LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(4),0,dp(4),dp(10))})

        val sectionTitle=TextView(this).apply{
            text="Appuntamenti interessati (${affected.size})";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);
            setTextColor(Color.rgb(28,42,61));gravity=Gravity.CENTER;setIncludeFontPadding(false)
        }
        outer.addView(sectionTitle,LinearLayout.LayoutParams(-1,dp(42)).apply{setMargins(dp(4),0,dp(4),dp(4))})

        // Solo questo contenitore scorre. Header, messaggio informativo e pulsanti restano fissi.
        val listScroll=ScrollView(this).apply{
            isFillViewport=false;overScrollMode=View.OVER_SCROLL_IF_CONTENT_SCROLLS;clipToPadding=false
            setPadding(0,0,0,dp(2))
        }
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(4),0,dp(4),dp(4))}
        affected.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time}.thenBy{it.name.lowercase()}).forEach{a->
            val row=LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),dp(8),dp(10),dp(8));background=cardBg
            }
            val dateBox=LinearLayout(this).apply{
                orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(5),dp(3),dp(5),dp(3));
                background=roundedSurface(if(glass)Color.rgb(232,242,255)else Color.rgb(239,245,251),15)
            }
            dateBox.addView(TextView(this@MainActivity).apply{
                text=a.date.dayOfMonth.toString().padStart(2,'0');textSize=18f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(30,76,125))
            },LinearLayout.LayoutParams(dp(52),dp(24)))
            dateBox.addView(TextView(this@MainActivity).apply{
                text=a.date.format(DateTimeFormatter.ofPattern("MMM",java.util.Locale.ITALIAN)).uppercase();textSize=9.5f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(45,91,139))
            },LinearLayout.LayoutParams(dp(52),dp(16)))
            row.addView(dateBox,LinearLayout.LayoutParams(dp(58),dp(54)))
            row.addView(LinearLayout(this@MainActivity).apply{
                orientation=LinearLayout.VERTICAL;setPadding(dp(10),0,dp(4),0)
                addView(TextView(this@MainActivity).apply{
                    text=displaySurnameFirst(a.name);textSize=14.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(27,39,57));setSingleLine(true)
                },LinearLayout.LayoutParams(-1,-2))
                addView(TextView(this@MainActivity).apply{
                    text="${a.date.format(fmt)} · ${a.time}";textSize=12.5f;setTextColor(Color.rgb(76,91,110));setPadding(0,dp(2),0,0)
                },LinearLayout.LayoutParams(-1,-2))
            },LinearLayout.LayoutParams(0,-2,1f))
            row.addView(TextView(this).apply{
                text="›";textSize=27f;gravity=Gravity.CENTER;setTextColor(Color.rgb(66,88,116))
            },LinearLayout.LayoutParams(dp(28),dp(50)))
            list.addView(row,LinearLayout.LayoutParams(-1,dp(68)).apply{setMargins(0,0,0,dp(7))})
        }
        listScroll.addView(list,ViewGroup.LayoutParams(-1,-2))
        outer.addView(listScroll,LinearLayout.LayoutParams(-1,0,1f).apply{setMargins(0,0,0,dp(8))})

        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val cancel=dialogButton("Annulla",Color.rgb(45,60,80),Color.rgb(248,250,253),Color.rgb(218,225,232)){dialog.dismiss()}
        val confirm=dialogButton("Conferma chiusura",Color.WHITE,Color.rgb(30,112,230),Color.rgb(30,112,230)){dialog.dismiss();onPositive()}
        actions.addView(cancel,LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(0,0,dp(5),0)})
        actions.addView(confirm,LinearLayout.LayoutParams(0,dp(50),1.12f).apply{setMargins(dp(5),0,0,0)})
        outer.addView(actions,LinearLayout.LayoutParams(-1,dp(50)))

        dialog.setContentView(outer)
        preparePopupBackdrop(dialog)
        dialog.window?.apply{
            setBackgroundDrawableResource(android.R.color.transparent)
            addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            attributes=attributes.apply{dimAmount=0.40f;windowAnimations=0}
        }
        dialog.setOnShowListener{
            popupBackdropCurrentDialog=dialog
            applyPopupBackdropEffect(dialog)
            dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),(resources.displayMetrics.heightPixels*0.88f).toInt())
            outer.alpha=0f;outer.scaleX=0.975f;outer.scaleY=0.975f
            outer.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(160).setInterpolator(android.view.animation.DecelerateInterpolator(1.5f)).withLayer().start()
        }
        dialog.setOnDismissListener{removePopupBackdropDialog(dialog)}
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),(resources.displayMetrics.heightPixels*0.88f).toInt())
    }

    private fun warningTriangleDrawable(accent:Int = Color.rgb(235,145,0)): Drawable = object : Drawable() {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun draw(canvas: Canvas) {
            val b=bounds; val cx=b.exactCenterX(); val cy=b.exactCenterY(); val w=b.width()*0.58f; val h=b.height()*0.62f
            val path=Path().apply{
                moveTo(cx, cy-h*0.56f)
                lineTo(cx+w*0.52f, cy+h*0.50f)
                quadTo(cx+w*0.58f,cy+h*0.62f,cx+w*0.40f,cy+h*0.62f)
                lineTo(cx-w*0.40f, cy+h*0.62f)
                quadTo(cx-w*0.58f,cy+h*0.62f,cx-w*0.52f,cy+h*0.50f)
                close()
            }
            paint.style=Paint.Style.FILL;paint.color=Color.argb(210,255,190,55);canvas.drawPath(path,paint)
            paint.style=Paint.Style.STROKE;paint.strokeWidth=dp(2).toFloat();paint.color=Color.argb(235,Color.red(accent),Color.green(accent),Color.blue(accent));canvas.drawPath(path,paint)
            paint.style=Paint.Style.FILL;paint.color=Color.WHITE
            canvas.drawRoundRect(cx-dp(2).toFloat(),cy-dp(10).toFloat(),cx+dp(2).toFloat(),cy+dp(3).toFloat(),dp(2).toFloat(),dp(2).toFloat(),paint)
            canvas.drawCircle(cx,cy+dp(9).toFloat(),dp(2).toFloat(),paint)
        }
        override fun setAlpha(alpha:Int) { paint.alpha=alpha }
        override fun setColorFilter(colorFilter:android.graphics.ColorFilter?) { paint.colorFilter=colorFilter }
        override fun getOpacity():Int=android.graphics.PixelFormat.TRANSLUCENT
        override fun getIntrinsicWidth():Int=dp(42)
        override fun getIntrinsicHeight():Int=dp(42)
    }

    private fun nikiConfirmDialog(title:String,message:String,positiveText:String,positiveColor:Int=Color.rgb(30,112,230),icon:String="⚠️",onPositive:()->Unit){
        val triangle=icon=="WARNING_TRIANGLE"
        val actualIcon=if(triangle) "WARNING_TRIANGLE" else icon
        val isOrange=positiveColor==Color.rgb(235,145,0)
        val (dialog,outer,body)=packActionDialogBase(title,actualIcon,positiveColor,if(triangle)Color.rgb(255,246,224) else if(positiveColor==Color.rgb(205,55,55))Color.rgb(255,235,235) else Color.rgb(232,242,255),Color.WHITE)
        body.addView(dialogBodyText(message))
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        row.addView(dialogButton("Annulla",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(218,225,232)){dialog.dismiss()},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(4),0)})
        val positiveBg=if(isOrange) Color.argb(175,235,145,0) else positiveColor
        val positiveStroke=if(isOrange) Color.argb(205,235,145,0) else positiveColor
        row.addView(dialogButton(positiveText,Color.WHITE,positiveBg,positiveStroke){dialog.dismiss();onPositive()},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(4),0,0,0)})
        body.addView(row)
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun dayShort(i:Int)=arrayOf("Lunedì","Martedì","Mercoledì","Giovedì","Venerdì","Sabato","Domenica")[i]
    private fun createAppointments(name:String,dateText:String,timeText:String,type:String,repeat:Boolean,checks:List<CheckBox>,endText:String,recovery:Boolean=false,allowWarnings:Boolean=false,dayTimes:Map<Int,String>?=null){
        try{
            val cleanName=normalizeDisplayName(name);require(cleanName.isNotEmpty());val start=parseDate(dateText);val time=normalizeTime(timeText);val linked=if(recovery)null else activeSessionPackFor(cleanName)
            if(recovery){
                val rp=regularPackFor(cleanName,start) ?: throw IllegalArgumentException("Nessun recupero disponibile")
                if(repeat || recoveriesForPack(rp)<=0) throw IllegalArgumentException("Nessun recupero disponibile")
            }
            if(!allowWarnings){
                val standardPack=standardPackFor(cleanName,start)
                val includedType=standardPack?.includedAppointmentType
                if(includedType!=null && includedType.isNotBlank() && includedType!=type){
                    val includedName=typeLabel(includedType)
                    val selectedName=typeLabel(type)
                    nikiConfirmDialog(
                        "Tipo non incluso nel pacchetto",
                        "Il pacchetto ${standardPack.packageType} comprende il tipo $includedName. Hai selezionato $selectedName, che è fuori pacchetto. Vuoi comunque creare l'appuntamento?",
                        "Crea comunque",
                        Color.rgb(235,145,0),
                        "WARNING_TRIANGLE"
                    ){createAppointments(cleanName,dateText,timeText,type,repeat,checks,endText,recovery,true,dayTimes)}
                    return
                }
                val customSession=activeSessionPackFor(cleanName)
                if(customSession!=null&&customSession.customQuantities.isNotEmpty()){
                    val limit=customSession.customQuantities[type]?:0
                    val remaining=customSessionPackRemaining(customSession,type)
                    val selectedName=typeLabel(type)
                    if(limit<=0){
                        nikiConfirmDialog(
                            "Tipologia non prevista nel pacchetto",
                            "$selectedName non è inclusa nel pacchetto a sedute di ${customSession.name}. Vuoi comunque creare l'appuntamento?",
                            "Crea comunque",
                            Color.rgb(235,145,0),
                            "WARNING_TRIANGLE"
                        ){createAppointments(cleanName,dateText,timeText,type,repeat,checks,endText,recovery,true,dayTimes)}
                        return
                    }
                    if(remaining<=0){
                        nikiConfirmDialog(
                            "Sedute esaurite",
                            "Le sedute $selectedName previste dal pacchetto sono esaurite. Vuoi comunque creare l'appuntamento?",
                            "Crea comunque",
                            Color.rgb(235,145,0),
                            "WARNING_TRIANGLE"
                        ){createAppointments(cleanName,dateText,timeText,type,repeat,checks,endText,recovery,true,dayTimes)}
                        return
                    }
                }else if(customSession!=null&&customSession.customQuantities.isEmpty()){
                    // Vecchio pacchetto a sedute: se tutte le sedute sono già
                    // prenotate, avvisa solo alla prima eccedenza. Premendo
                    // "Crea comunque" l'avviso viene sospeso per 30 minuti,
                    // esclusivamente per questo pacchetto.
                    val nowMillis=System.currentTimeMillis()
                    val suppressedUntil=sessionPackWarningSuppressedUntil[customSession.id]?:0L
                    val booked=sessionBooked(customSession)
                    if(booked>=customSession.totalSessions && nowMillis>=suppressedUntil){
                        val extra=if(repeat) "Gli appuntamenti successivi saranno comunque creati e segnati come fuori pacchetto." else "Questo appuntamento sarà segnato come fuori pacchetto e a pagamento."
                        nikiConfirmDialog(
                            "Sedute del pacchetto esaurite",
                            "Hai già programmato ${customSession.totalSessions} sedute per il pacchetto di ${customSession.name}. $extra Vuoi comunque creare l'appuntamento?",
                            "Crea comunque",
                            Color.rgb(235,145,0),
                            "WARNING_TRIANGLE"
                        ){
                            sessionPackWarningSuppressedUntil[customSession.id]=System.currentTimeMillis()+30L*60L*1000L
                            createAppointments(cleanName,dateText,timeText,type,repeat,checks,endText,recovery,true,dayTimes)
                        }
                        return
                    }
                }
                val weeklyPackForWarning=regularPackFor(cleanName,start)
                if(weeklyPackForWarning!=null){
                    val weeklyWarning=if(repeat){
                        val end=runCatching{parseDate(endText)}.getOrNull()?:start
                        val selectedDays=checks.mapIndexedNotNull{idx,c->if(c.isChecked)idx+1 else null}.toSet()
                        weeklyRepeatQuotaWarning(weeklyPackForWarning,start,end,selectedDays,type,dayTimes)
                    }else weeklyQuotaWarning(weeklyPackForWarning,start,type)
                    if(weeklyWarning!=null){
                        val title=if(weeklyWarning.contains("non è prevista"))"Tipologia non prevista nel pacchetto" else "Quota settimanale esaurita"
                        nikiConfirmDialog(title,weeklyWarning,"Crea comunque",Color.rgb(235,145,0),"WARNING_TRIANGLE"){
                            createAppointments(cleanName,dateText,timeText,type,repeat,checks,endText,recovery,true,dayTimes)
                        }
                        return
                    }
                }
                val duplicateDates=if(repeat){
                    val end=runCatching{parseDate(endText)}.getOrNull()?:start
                    val selected=checks.mapIndexedNotNull{idx,c->if(c.isChecked)idx+1 else null}.toSet()
                    appointments.filter{identityKey(it.name)==identityKey(cleanName)&&selected.contains(it.date.dayOfWeek.value)&&!it.date.isBefore(start)&&!it.date.isAfter(end)}.map{it.date}.distinct().sorted()
                }else appointments.filter{identityKey(it.name)==identityKey(cleanName)&&it.date==start}.map{it.date}
                if(duplicateDates.isNotEmpty()){
                    val first=appointments.filter{identityKey(it.name)==identityKey(cleanName)&&duplicateDates.contains(it.date)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time}).first()
                    nikiConfirmDialog("Appuntamento già presente",if(repeat)"$cleanName ha già appuntamenti in ${duplicateDates.size} giorno/i della ripetizione. Primo trovato: ${first.date.format(fmt)} alle ${first.time}. Vuoi comunque crearli?" else "$cleanName ha già un appuntamento il ${first.date.format(fmt)} alle ${first.time}. Vuoi comunque creare un altro appuntamento oggi?","Crea comunque",Color.rgb(235,145,0),"WARNING_TRIANGLE"){createAppointments(cleanName,dateText,timeText,type,repeat,checks,endText,recovery,true,dayTimes)}
                    return
                }
            }
            if(!repeat){
                if(!canAdd(start,time,type))throw IllegalArgumentException("Fascia piena")
                appointments.add(Appointment(nextAppointmentId++,cleanName,start,time,type,0L,linked?.id?:0L,recovery));saveData();calendarScreen();return
            }
            val end=parseDate(endText);require(!end.isBefore(start));val selected=checks.mapIndexedNotNull{idx,c->if(c.isChecked)idx+1 else null};require(selected.isNotEmpty())
            val weeklyPack=packs.filter{it.active&&it.packageType=="WEEKLY_CUSTOM"&&identityKey(it.name)==identityKey(cleanName)&&!start.isBefore(it.start)&&!start.isAfter(weeklyPackageEnd(it))}.maxByOrNull{it.start}
            val series=nextAppointmentId;var d=start;var count=0;var sessionAdded=0
            // Prenotazioni della ripetizione riservate settimana per settimana.
            // È importante usare la settimana del pacchetto e non la singola data:
            // con Lun+Mer+Ven e quota 3 devono essere create tutte e tre.
            val plannedByWeekAndType=mutableMapOf<Pair<LocalDate,String>,Int>()
            while(!d.isAfter(end)){
                if(selected.contains(d.dayOfWeek.value)){
                    val dayTime=dayTimes?.get(d.dayOfWeek.value-1)?.let{normalizeTime(it)} ?: time
                    val weekStart=weeklyPack?.let{weeklyWeekStart(it,d)}
                    // La quota del pacchetto NON deve impedire di programmare un appuntamento.
                    // Se la settimana ha già raggiunto la quantità inclusa, l'appuntamento
                    // viene comunque creato e sarà poi marcato come FUORI PACCHETTO (rosso).
                    // In questo modo una sequenza Lun/Mer/Ven viene inserita per intero anche
                    // quando esistono già altre prenotazioni nella stessa settimana.
                    if(canAdd(d,dayTime,type)){
                        appointments.add(Appointment(nextAppointmentId++,cleanName,d,dayTime,type,series,linked?.id?:0L,recovery));sessionAdded++
                        if(weekStart!=null){val k=weekStart to type;plannedByWeekAndType[k]=(plannedByWeekAndType[k]?:0)+1}
                    }else count++
                }
                d=d.plusDays(1)
            }
            saveData();calendarScreen();if(count>0)Toast.makeText(this,"$count ripetizioni non inserite perché la fascia o la disponibilità del pacchetto non erano sufficienti.",Toast.LENGTH_LONG).show()
        }catch(e:Exception){Toast.makeText(this,if(e.message=="Fascia piena")"Fascia non disponibile: massimo 3 persone e massimo 2 allenamenti." else "Controlla cliente, data, ora e ripetizione.",Toast.LENGTH_LONG).show()}
    }

    private fun calendarSlotCount():Int = ((22*60-7*60) / calendarSlotDuration).coerceAtLeast(1)

    private fun normalizeTime(value:String):String{val clean=value.trim();val parts=clean.split(":");require(parts.size==2);val h=parts[0].toInt();val m=parts[1].toInt();require(h in 7..21&&m in 0..59);require((h*60+m-7*60)%calendarSlotDuration==0);return String.format("%02d:%02d",h,m)}
    private fun updateAppointment(a:Appointment,name:String,dateText:String,timeText:String,type:String){
        try{
            val cleanName=normalizeDisplayName(name);require(cleanName.isNotEmpty());val date=parseDate(dateText);val time=normalizeTime(timeText)
            val duplicate=appointments.firstOrNull{it!==a&&it.date==date&&identityKey(it.name)==identityKey(cleanName)}
            if(duplicate!=null){
                nikiConfirmDialog("Appuntamento già presente","$cleanName ha già un appuntamento il ${date.format(fmt)} alle ${duplicate.time}. Vuoi comunque spostare/modificare questo appuntamento?","Continua"){updateAppointmentConfirmed(a,cleanName,date,time,type)};return
            }
            updateAppointmentConfirmed(a,cleanName,date,time,type)
        }catch(_:Exception){Toast.makeText(this,"Controlla i dati dell'appuntamento.",Toast.LENGTH_LONG).show()}
    }

    private fun updateAppointmentConfirmed(a:Appointment,name:String,date:LocalDate,time:String,type:String){
        if(!canAdd(date,time,type,a)){Toast.makeText(this,"Questa fascia non è disponibile.",Toast.LENGTH_LONG).show();return}
        var linked=if(a.sessionPackId!=0L)sessionPacks.firstOrNull{it.id==a.sessionPackId} else null
        if(linked==null)linked=activeSessionPackFor(name)
        if(linked!=null&&a.sessionPackId!=linked.id){
            val bookedWithoutThis=sessionBooked(linked)-if(a.sessionPackId==linked.id) 1 else 0
            if(bookedWithoutThis>=linked.totalSessions){Toast.makeText(this,"Il pacchetto sedute è già completo.",Toast.LENGTH_LONG).show();return}
            a.sessionPackId=linked.id
        }
        a.name=name;a.date=date;a.time=time;a.type=type;saveData();calendarScreen()
    }

    private fun appointmentDialogForSlot(day:LocalDate,time:String){appointmentDialog(null,day,time)}

    private fun availableTimeSlots(date:LocalDate,type:String,ignore:Appointment?=null):List<String>{
        return (0 until calendarSlotCount()).map{slot->
            val mins=7*60+slot*calendarSlotDuration
            String.format("%02d:%02d",mins/60,mins%60)
        }.filter{slot->canAdd(date,slot,type,ignore)}
    }

    private fun canAdd(date:LocalDate,time:String,type:String,ignore:Appointment?=null):Boolean{
        val r=calendarRoutines.getOrNull(activeRoutineIndex)?:CalendarRoutine("Personalizzata",3,MutableList(appointmentTypes.size){3})
        val items=appointments.filter{it.date==date&&it.time==time&&it!==ignore}
        if(items.size>=r.maxTotal)return false
        val idx=typeIndex(type);if(items.count{typeIndex(it.type)==idx}>=(r.maxByType.getOrNull(idx)?:r.maxTotal))return false
        return true
    }

}
