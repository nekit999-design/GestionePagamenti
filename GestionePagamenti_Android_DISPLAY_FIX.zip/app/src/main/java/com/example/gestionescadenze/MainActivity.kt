package com.example.gestionescadenze

import android.app.*
import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Color
import android.net.Uri
import android.provider.MediaStore
import android.content.ContentValues
import android.provider.Settings
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.graphics.drawable.GradientDrawable
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import android.text.Editable
import android.text.TextWatcher
import java.io.BufferedReader
import java.io.InputStreamReader
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters

private data class Pack(var name: String, val start: LocalDate, val total: Int, var paid: Int = 0, var customRates: MutableList<Int>? = null, var packageType: String = "PERSONALIZZATO", var sessionTotal: Int = 12, var active: Boolean = true, var missedSessions: Int = 0)
private data class SessionPack(
    val id: Long,
    var name: String,
    val start: LocalDate,
    val totalSessions: Int,
    val cost: Int,
    var paid: Int = 0,
    var active: Boolean = true,
    var customRates: MutableList<Int>? = null
)
private data class AppointmentType(var id:String, var name:String, var color:Int, var duration:Int = 45)
private data class CalendarRoutine(var name:String, var maxTotal:Int, var maxByType:MutableList<Int>)

private data class Appointment(
    val id: Long,
    var name: String,
    var date: LocalDate,
    var time: String,
    var type: String,
    var seriesId: Long = 0L,
    var sessionPackId: Long = 0L,
    var recovery: Boolean = false
) {
    val duration: Int get() = if (type == "TYPE2") 30 else 45
}

class MainActivity : Activity() {
    private val fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy")
    private val timeFmt = DateTimeFormatter.ofPattern("HH:mm")
    private val packs = mutableListOf<Pack>()
    private val sessionPacks = mutableListOf<SessionPack>()
    private val appointments = mutableListOf<Appointment>()
    private var ferieStart: LocalDate? = null
    private var ferieEnd: LocalDate? = null
    private lateinit var list: LinearLayout
    private var dashboardEnabled = false
    private lateinit var searchInput: EditText
    private lateinit var searchList: LinearLayout
    private var calendarWeekStart: LocalDate = LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    private var nextAppointmentId = 1L
    private var nextSessionPackId = 1L
    private var calendarZoom = 1.0f
    private var calendarVisibleDays = booleanArrayOf(true,true,true,true,true,false,false)
    private val appointmentTypes = mutableListOf(
        AppointmentType("TYPE1","ALLENAMENTO",Color.rgb(45,135,210),45),
        AppointmentType("TYPE2","MEZZ'ORA",Color.rgb(215,55,55),30)
    )
    private val calendarRoutines = mutableListOf(
        CalendarRoutine("Standard",3,mutableListOf(2,3)),
        CalendarRoutine("Light",2,mutableListOf(1,2)),
        CalendarRoutine("Full",4,mutableListOf(3,4))
    )
    private var activeRoutineIndex = 0
    private var surnameFirstDisplay = true
    private var pendingSummaryText = ""
    private val expandedClients = mutableSetOf<String>()
    private var activePackageDialog: AlertDialog? = null

    companion object {
        private const val REQ_EXPORT = 1001
        private const val REQ_IMPORT = 1002
        private const val REQ_SUMMARY = 1003
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        if (android.os.Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(true)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        loadData()
        maybeAutoBackup()
        build()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun centeredSpinnerAdapter(items: List<String>): ArrayAdapter<String> =
        object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            init { setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent)
                (v as? TextView)?.gravity = Gravity.CENTER
                return v
            }
            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getDropDownView(position, convertView, parent)
                (v as? TextView)?.gravity = Gravity.CENTER
                return v
            }
        }
    private fun typeBgForColor(c:Int):Int = Color.rgb((Color.red(c)+255)/2,(Color.green(c)+255)/2,(Color.blue(c)+255)/2)
    private fun ensureAppointmentTypes(){
        if(appointmentTypes.isEmpty()){
            appointmentTypes.add(AppointmentType("TYPE1","ALLENAMENTO",Color.rgb(45,135,210),45))
            appointmentTypes.add(AppointmentType("TYPE2","MEZZ'ORA",Color.rgb(215,55,55),30))
        }else if(appointmentTypes.none{it.id=="TYPE1"}){
            appointmentTypes.add(0,AppointmentType("TYPE1","ALLENAMENTO",Color.rgb(45,135,210),45))
        }
    }
    private fun normalizedType(type:String):String = when(type){"ALLENAMENTO"->"TYPE1";"MEZZ'ORA"->"TYPE2";else->type}
    private fun typeIndex(type:String):Int {
        ensureAppointmentTypes()
        val id=normalizedType(type)
        val found=appointmentTypes.indexOfFirst{it.id==id}
        if(found>=0)return found
        val legacy=when(id){"TYPE1"->0;"TYPE2"->1;else->-1}
        return if(legacy>=0&&legacy<appointmentTypes.size)legacy else 0
    }
    private fun typeLabel(type:String):String { ensureAppointmentTypes(); return appointmentTypes.getOrNull(typeIndex(type))?.name ?: appointmentTypes.first().name }
    private fun typeColor(type:String):Int { ensureAppointmentTypes(); return appointmentTypes.getOrNull(typeIndex(type))?.color ?: appointmentTypes.first().color }
    private fun typeDuration(type:String):Int { ensureAppointmentTypes(); return appointmentTypes.getOrNull(typeIndex(type))?.duration ?: 45 }
    private fun typeIdAt(index:Int):String { ensureAppointmentTypes(); return appointmentTypes.getOrNull(index)?.id ?: appointmentTypes.first().id }

    private fun roundedSurface(color:Int, radius:Int=16, strokeColor:Int=Color.TRANSPARENT, strokeWidth:Int=0): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius=dp(radius).toFloat(); if(strokeWidth>0) setStroke(dp(strokeWidth),strokeColor) }


    private fun modernEditText(): EditText = EditText(this).apply {
        textSize = 16f
        setSingleLine(true)
        setTextColor(Color.rgb(30,33,38))
        setHintTextColor(Color.rgb(130,135,142))
        setPadding(dp(14),0,dp(14),0)
        background = roundedSurface(Color.rgb(247,248,250),16,Color.rgb(222,226,232),1)
        stateListAnimator = null
    }

    private fun paymentButtonStyle(): Button = Button(this).apply {
        text = "PAGA"
        setAllCaps(false)
        textSize = 13.5f
        minWidth = 0; minimumWidth = 0
        minHeight = 0; minimumHeight = 0
        setPadding(0,0,0,0)
        setTextColor(Color.rgb(20,91,165))
        background = roundedSurface(Color.rgb(238,246,255),14,Color.rgb(190,218,248),1)
        stateListAnimator = null
    }

    private fun menuIconButtonStyle(): Button = Button(this).apply {
        text = "⋮"
        textSize = 18f
        minWidth = 0; minimumWidth = 0
        minHeight = 0; minimumHeight = 0
        setPadding(0,0,0,dp(1))
        setTextColor(Color.rgb(55,58,63))
        background = roundedSurface(Color.rgb(246,248,250),13,Color.rgb(225,229,234),1)
        stateListAnimator = null
    }

    private fun editIconButtonStyle(): Button = Button(this).apply {
        text = "✎"
        setAllCaps(false)
        textSize = 15f
        minWidth = 0; minimumWidth = 0
        minHeight = 0; minimumHeight = 0
        setPadding(0,0,0,dp(1))
        setTextColor(Color.rgb(20,91,165))
        background = roundedSurface(Color.rgb(246,249,253),14,Color.rgb(205,220,238),1)
        stateListAnimator = null
    }

    private fun buttonStyle(textValue: String): Button = Button(this).apply {
        text = textValue; textSize = 13.5f; setTextColor(Color.rgb(35,38,42)); gravity = Gravity.CENTER; setPadding(0,0,0,0)
        minHeight = 0; minimumHeight = 0; setAllCaps(false); stateListAnimator = null
        background = roundedSurface(Color.rgb(241,243,246),16,Color.rgb(226,229,234),1)
    }

    private fun primaryButtonStyle(textValue: String): Button = Button(this).apply {
        text = textValue; textSize = 13.5f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0,0,0,0)
        minHeight = 0; minimumHeight = 0; setAllCaps(false); stateListAnimator = null
        background = roundedSurface(Color.rgb(20,112,232),16,Color.rgb(20,112,232),1)
    }

    private fun softBlueButtonStyle(textValue: String): Button = Button(this).apply {
        text = textValue; textSize = 13.5f; setTextColor(Color.rgb(30,83,145)); gravity = Gravity.CENTER; setPadding(0,0,0,0)
        minHeight = 0; minimumHeight = 0; setAllCaps(false); stateListAnimator = null
        background = roundedSurface(Color.rgb(235,244,255),16,Color.rgb(205,224,248),1)
    }

    private fun build() {
        // Quando si rientra nella schermata Clienti, la ricerca del Calendario
        // non deve rimanere attiva e nascondere i pacchetti.
        if(::searchInput.isInitialized) searchInput.setText("")
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(14),dp(16),dp(10)); setBackgroundColor(Color.rgb(247,248,250)) }
        val titleRow = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        val brand=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        brand.addView(TextView(this).apply{text="➤";textSize=31f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(20,91,165));gravity=Gravity.CENTER;rotation=-18f},LinearLayout.LayoutParams(dp(42),dp(52)))
        val brandText=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL}
        val brandName=TextView(this).apply{
            text=android.text.SpannableStringBuilder().apply{append("Coach");setSpan(android.text.style.ForegroundColorSpan(Color.rgb(25,62,112)),0,5,android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);append("Flow");setSpan(android.text.style.ForegroundColorSpan(Color.rgb(20,128,235)),5,9,android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)}
            textSize=29f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER_VERTICAL;setIncludeFontPadding(false)
        }
        brandText.addView(brandName,LinearLayout.LayoutParams(-1,dp(36)))
        brandText.addView(TextView(this).apply{text="ALLENA  •  ORGANIZZA  •  CRESCI";textSize=7.5f;setTextColor(Color.rgb(115,125,140));letterSpacing=0.18f;gravity=Gravity.CENTER_VERTICAL;setIncludeFontPadding(false)},LinearLayout.LayoutParams(-1,dp(16)))
        brand.addView(brandText,LinearLayout.LayoutParams(0,dp(54),1f))
        titleRow.addView(brand,LinearLayout.LayoutParams(0,dp(56),1f))
        val dashButton = Button(this).apply {
            text=if(dashboardEnabled) "DASH  ●" else "DASH  ○"; textSize=12.5f; setTextColor(Color.rgb(70,74,80)); gravity=Gravity.CENTER; minHeight=0; minimumHeight=0; setPadding(dp(8),0,dp(8),0); setAllCaps(false); stateListAnimator=null
            background=roundedSurface(if(dashboardEnabled) Color.rgb(235,241,248) else Color.rgb(248,249,250),18,Color.rgb(220,223,227),1)
            setOnClickListener { dashboardEnabled=!dashboardEnabled; saveData(); updateDashboardButton(this); render() }
        }
        titleRow.addView(dashButton,LinearLayout.LayoutParams(dp(78),dp(42)).apply{setMargins(dp(6),0,dp(4),0)})
        val moreButton=Button(this).apply{
            text="⋯"; textSize=22f; setTextColor(Color.rgb(55,58,63)); gravity=Gravity.CENTER
            minHeight=0; minimumHeight=0; setPadding(0,0,0,dp(4)); setAllCaps(false); stateListAnimator=null
            background=roundedSurface(Color.rgb(248,249,251),18,Color.rgb(220,223,227),1)
            setOnClickListener{mainMoreMenu()}
        }
        titleRow.addView(moreButton,LinearLayout.LayoutParams(dp(48),dp(42)))
        root.addView(titleRow,LinearLayout.LayoutParams(-1,dp(56)))
        root.addView(TextView(this).apply { text="Clienti  •  Pacchetti  •  Calendario  •  Pagamenti"; textSize=15f; setTextColor(Color.rgb(92,95,101)); setPadding(dp(2),0,0,dp(5)) },LinearLayout.LayoutParams(-1,dp(34)))
        val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val add=primaryButtonStyle("＋ Nuovo").apply{setOnClickListener{newPackageMenu()}}
        val ferie=buttonStyle("Chiusura ferie").apply{setOnClickListener{settings()}}
        val cal=primaryButtonStyle("📅 Calendario").apply{setOnClickListener{calendarScreen()}}
        buttons.addView(add,LinearLayout.LayoutParams(0,dp(58),1f).apply{setMargins(0,0,dp(4),0)}); buttons.addView(ferie,LinearLayout.LayoutParams(0,dp(58),1f).apply{setMargins(dp(2),0,dp(2),0)}); buttons.addView(cal,LinearLayout.LayoutParams(0,dp(58),1f).apply{setMargins(dp(4),0,0,0)}); root.addView(buttons,LinearLayout.LayoutParams(-1,dp(60)))
        root.addView(TextView(this).apply{textSize=13f;setTextColor(Color.DKGRAY);setPadding(0,dp(4),0,dp(4));gravity=Gravity.CENTER_VERTICAL;text=closureText()},LinearLayout.LayoutParams(-1,dp(34)))
        list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,dp(12),0,0)}
        val scroll=ScrollView(this).apply{addView(list,ViewGroup.LayoutParams(-1,-2))}; root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root); render()
    }

    private fun updateDashboardButton(button:Button){button.text=if(dashboardEnabled)"DASH  ●" else "DASH  ○";button.background=roundedSurface(if(dashboardEnabled)Color.rgb(235,241,248)else Color.rgb(248,249,250),18,Color.rgb(220,223,227),1)}

    private fun mainMoreMenu(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(4),dp(18),dp(8))}
        fun option(title:String,subtitle:String,icon:String,action:()->Unit){
            val row=LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL
                gravity=Gravity.CENTER_VERTICAL
                setPadding(dp(14),dp(12),dp(12),dp(12))
                background=roundedSurface(Color.rgb(246,248,250),20,Color.rgb(228,231,235),1)
                isClickable=true
                isFocusable=true
            }
            row.addView(TextView(this).apply{
                text=icon;textSize=22f;gravity=Gravity.CENTER
                setBackground(roundedSurface(Color.WHITE,16))
                setPadding(dp(8),dp(6),dp(8),dp(6))
            },LinearLayout.LayoutParams(dp(50),dp(50)))
            val texts=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
            texts.addView(TextView(this@MainActivity).apply{
                text=title;textSize=16f;setTextColor(Color.rgb(25,28,32))
                setTypeface(null,android.graphics.Typeface.BOLD)
            })
            texts.addView(TextView(this@MainActivity).apply{
                text=subtitle;textSize=12.5f;setTextColor(Color.rgb(100,104,110))
                setPadding(0,dp(3),0,0)
            })
            row.addView(texts,LinearLayout.LayoutParams(0,-2,1f))
            row.addView(TextView(this@MainActivity).apply{
                text="›";textSize=28f;setTextColor(Color.rgb(120,124,130));gravity=Gravity.CENTER
            },LinearLayout.LayoutParams(dp(28),dp(50)))
            row.setOnClickListener{action()}
            box.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))})
        }
        option("Backup e dati","Automatico • Esporta • Importa","☁"){backupMenu()}
        option("Impostazioni","Preferenze e gestione dell'app","⚙"){settings()}
        val close=Button(this).apply{
            text="Chiudi";setAllCaps(false);textSize=14f;setTextColor(Color.rgb(0,125,110))
            setBackgroundColor(Color.TRANSPARENT);stateListAnimator=null
        }
        box.addView(close,LinearLayout.LayoutParams(-1,dp(46)).apply{setMargins(0,dp(4),0,0)})
        val dialog=AlertDialog.Builder(this).setTitle("Altre opzioni").setView(box).create()
        dialog.setOnShowListener{
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28))
            dialog.window?.setDimAmount(0.42f)
            close.setOnClickListener{dialog.dismiss()}
        }
        dialog.show()
    }

    private fun newPackageMenu(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(8),dp(18),dp(12))}
        box.addView(TextView(this).apply{
            text="Crea nuovo pacchetto"
            textSize=22f
            setTextColor(Color.rgb(28,30,33))
            gravity=Gravity.CENTER
            setTypeface(null,android.graphics.Typeface.NORMAL)
            setPadding(0,0,0,dp(2))
        },LinearLayout.LayoutParams(-1,dp(34)))
        box.addView(TextView(this).apply{
            text="Scegli il tipo di pacchetto da creare"
            textSize=14f
            setTextColor(Color.rgb(95,100,108))
            gravity=Gravity.CENTER
            setPadding(0,0,0,dp(8))
        },LinearLayout.LayoutParams(-1,dp(28)))
        fun option(title:String,subtitle:String,icon:String,action:()->Unit){
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(12),dp(12),dp(12));background=roundedSurface(Color.rgb(246,248,250),20,Color.rgb(228,231,235),1);isClickable=true;isFocusable=true}
            val ico=TextView(this).apply{text=icon;textSize=23f;gravity=Gravity.CENTER;setBackground(roundedSurface(Color.WHITE,16));setPadding(dp(8),dp(6),dp(8),dp(6))}
            row.addView(ico,LinearLayout.LayoutParams(dp(50),dp(50)))
            val texts=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
            texts.addView(TextView(this).apply{text=title;textSize=16f;setTextColor(Color.rgb(25,28,32));setTypeface(null,android.graphics.Typeface.BOLD)})
            texts.addView(TextView(this).apply{text=subtitle;textSize=12.5f;setTextColor(Color.rgb(100,104,110));setPadding(0,dp(3),0,0)})
            row.addView(texts,LinearLayout.LayoutParams(0,-2,1f))
            row.addView(TextView(this).apply{text="›";textSize=28f;setTextColor(Color.rgb(120,124,130));gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(28),dp(50)))
            row.setOnClickListener{action()}
            box.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))})
        }
        option("Pacchetto 12 settimane","3 rate • Bronze / Silver / Gold","📦"){newPack()}
        option("Pacchetto sedute","Numero sedute e costo personalizzabili","🏋️"){newSessionPack()}
        val close=Button(this).apply{
            text="Chiudi";setAllCaps(false);textSize=14f;setTextColor(Color.rgb(20,91,165));
            minHeight=0;minimumHeight=0;stateListAnimator=null;
            background=roundedSurface(Color.rgb(248,249,251),18,Color.rgb(220,226,234),1)
        }
        box.addView(close,LinearLayout.LayoutParams(-1,dp(46)).apply{setMargins(0,dp(6),0,0)})
        val dialog=AlertDialog.Builder(this).setView(box).create()
        styleOneUiDialog(dialog)
        dialog.setOnShowListener{ 
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28))
            dialog.window?.setDimAmount(0.42f)
            close.setOnClickListener{dialog.dismiss()}
        }
        dialog.show()
    }

    private fun newSessionPack(){
        val page=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(8),dp(18),dp(12))}
        val scroll=ScrollView(this).apply{isFillViewport=true;clipToPadding=false}
        scroll.addView(page,ViewGroup.LayoutParams(-1,-2))
        // Il titolo e\"Nuovo pacchetto sedute\" non viene ripetuto: la card introduttiva identifica gia il tipo di pacchetto.
        val intro=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(12));background=roundedSurface(Color.rgb(239,247,255),20,Color.rgb(205,224,248),1)}
        intro.addView(TextView(this).apply{text="🏋️";textSize=22f;gravity=Gravity.CENTER;setBackground(roundedSurface(Color.WHITE,16));setPadding(dp(8),dp(6),dp(8),dp(6))},LinearLayout.LayoutParams(dp(50),dp(50)))
        val introText=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
        introText.addView(TextView(this@MainActivity).apply{text="Pacchetto a sedute";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,55,85))})
        introText.addView(TextView(this@MainActivity).apply{text="Pagamento unico • consumo sincronizzato con il calendario";textSize=12.5f;setTextColor(Color.rgb(75,100,125));setPadding(0,dp(3),0,0)})
        intro.addView(introText,LinearLayout.LayoutParams(0,-2,1f));page.addView(intro,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(16))})
        fun field(title:String,hint:String,inputTypeValue:Int=0):EditText{
            page.addView(TextView(this).apply{text=title;textSize=13f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(82,87,94));setPadding(dp(2),0,0,dp(4))})
            return modernEditText().apply{this.hint=hint;inputType=if(inputTypeValue==0) android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS else inputTypeValue;setSingleLine(true);textSize=16f;setPadding(dp(14),0,dp(14),0)}
        }
        val name=field("Cliente","Cognome e Nome").apply{
            isFocusable=true
            isFocusableInTouchMode=true
            isClickable=true
            showSoftInputOnFocus=true
            setOnTouchListener { v, event ->
                if(event.action == android.view.MotionEvent.ACTION_DOWN){
                    v.requestFocusFromTouch()
                }
                false
            }
        }
        page.addView(name,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(12))})
        val date=field("Data di inizio","Data (gg/mm/aaaa)",2);setupDateInput(date);date.setText(LocalDate.now().format(fmt))
        page.addView(date,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(12))})
        val sessions=field("Sedute disponibili","Numero sedute",2)
        page.addView(sessions,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(12))})
        val cost=field("Importo del pacchetto","Costo totale (€)",2)
        page.addView(cost,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(16))})
        val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val cancel=TextView(this).apply{text="ANNULLA";textSize=14f;setTextColor(Color.rgb(0,125,110));gravity=Gravity.CENTER;isClickable=true}
        val create=TextView(this).apply{text="CREA PACCHETTO";textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(0,125,110));gravity=Gravity.CENTER;isClickable=true}
        buttons.addView(cancel,LinearLayout.LayoutParams(0,dp(48),1f));buttons.addView(create,LinearLayout.LayoutParams(0,dp(48),1.25f))
        page.addView(buttons,LinearLayout.LayoutParams(-1,dp(52)))
        val dialog=AlertDialog.Builder(this).setView(scroll).create()
        styleFullPageCoachDialog(dialog)
        // Il focus iniziale resta sulla pagina: il primo tocco sul nome deve
        // dare subito focus al campo e aprire la tastiera.
        scroll.isFocusableInTouchMode=true
        scroll.requestFocus()
        dialog.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        cancel.setOnClickListener{dialog.dismiss()}
        create.setOnClickListener{
            try{val n=normalizeDisplayName(name.text.toString());val d=parseDate(date.text.toString());val total=sessions.text.toString().trim().toInt();val c=cost.text.toString().trim().toInt();require(n.isNotEmpty()&&total>0&&c>0)
                sessionPacks.add(SessionPack(nextSessionPackId++,n,d,total,c,0,true));saveData();render();dialog.dismiss()
            }catch(_:Exception){Toast.makeText(this,"Controlla nome, data, numero sedute e costo.",Toast.LENGTH_LONG).show()}
        }
        listOf<View>(name,date,sessions,cost).forEach{field->
            field.setOnFocusChangeListener{view,hasFocus->
                if(hasFocus){
                    scroll.post{scroll.smoothScrollTo(0,(field.top-dp(24)).coerceAtLeast(0))}
                }
            }
        }
        dialog.show()
        dialog.window?.decorView?.post{ name.clearFocus(); scroll.requestFocus(); val imm=getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager; imm.hideSoftInputFromWindow(name.windowToken,0) }
    }

    private fun normalizeDisplayName(value:String):String{
        return value.trim().split(Regex("\\s+")).filter{it.isNotBlank()}.joinToString(" "){word->
            word.lowercase().replaceFirstChar{if(it.isLowerCase())it.titlecase() else it.toString()}
        }
    }

    private fun identityKey(value:String):String{
        return value.trim().lowercase().split(Regex("\\s+")).filter{it.isNotBlank()}.sorted().joinToString(" ")
    }

    private fun newPack(){
        val page=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(8),dp(18),dp(12))}
        val scroll=ScrollView(this).apply{isFillViewport=true;clipToPadding=false}
        scroll.addView(page,ViewGroup.LayoutParams(-1,-2))
        // Il titolo e\"Nuovo pacchetto 12 settimane\" non viene ripetuto: la card introduttiva identifica gia il tipo di pacchetto.
        val intro=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(12));background=roundedSurface(Color.rgb(239,247,255),20,Color.rgb(205,224,248),1)}
        intro.addView(TextView(this).apply{text="📦";textSize=22f;gravity=Gravity.CENTER;setBackground(roundedSurface(Color.WHITE,16));setPadding(dp(8),dp(6),dp(8),dp(6))},LinearLayout.LayoutParams(dp(50),dp(50)))
        val it=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
        it.addView(TextView(this@MainActivity).apply{text="Pacchetto 12 settimane";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,55,85))})
        it.addView(TextView(this@MainActivity).apply{text="Bronze • Silver • Gold • programmazione dal calendario";textSize=12.5f;setTextColor(Color.rgb(75,100,125));setPadding(0,dp(3),0,0)})
        intro.addView(it,LinearLayout.LayoutParams(0,-2,1f));page.addView(intro,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(16))})
        fun label(t:String)=TextView(this).apply{text=t;textSize=13f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(82,87,94));setPadding(dp(2),0,0,dp(4))}
        val name=modernEditText().apply{hint="Cognome e Nome";setSingleLine(true);textSize=16f}
        val date=modernEditText().apply{hint="Data di inizio (gg/mm/aaaa)";inputType=2;setSingleLine(true);textSize=16f};setupDateInput(date);date.setText(LocalDate.now().format(fmt))
        val type=Spinner(this).apply{adapter=centeredSpinnerAdapter(listOf("BRONZE • 12 sedute","SILVER • 24 sedute","GOLD • 36 sedute"))}
        val cost=modernEditText().apply{hint="Costo totale (€)";inputType=2;setSingleLine(true);textSize=16f}
        page.addView(label("Cliente"));page.addView(name,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(12))})
        page.addView(label("Data di inizio"));page.addView(date,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(12))})
        page.addView(label("Tipo pacchetto"));page.addView(type,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(12))})
        page.addView(label("Costo totale"));page.addView(cost,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(16))})
        val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val cancel=TextView(this).apply{text="ANNULLA";textSize=14f;setTextColor(Color.rgb(0,125,110));gravity=Gravity.CENTER;isClickable=true}
        val create=TextView(this).apply{text="CREA PACCHETTO";textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(0,125,110));gravity=Gravity.CENTER;isClickable=true}
        buttons.addView(cancel,LinearLayout.LayoutParams(0,dp(48),1f));buttons.addView(create,LinearLayout.LayoutParams(0,dp(48),1.25f));page.addView(buttons,LinearLayout.LayoutParams(-1,dp(52)))
        val dialog=AlertDialog.Builder(this).setView(scroll).create();styleFullPageCoachDialog(dialog)
        scroll.isFocusableInTouchMode=true
        scroll.requestFocus()
        dialog.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        cancel.setOnClickListener{dialog.dismiss()}
        create.setOnClickListener{try{val n=normalizeDisplayName(name.text.toString());val d=parseDate(date.text.toString());val c=cost.text.toString().trim().toInt();require(n.isNotEmpty()&&c>0);val kind=when(type.selectedItemPosition){0->"BRONZE";1->"SILVER";else->"GOLD"};packs.add(Pack(n,d,c,0,null,kind,when(kind){"BRONZE"->12;"SILVER"->24;else->36},true));saveData();render();dialog.dismiss()}catch(_:Exception){Toast.makeText(this,"Controlla nome, data, tipo e costo.",Toast.LENGTH_LONG).show()}}
        listOf<View>(name,date,cost).forEach{field->field.setOnFocusChangeListener{_,hasFocus->if(hasFocus)scroll.post{scroll.smoothScrollTo(0,(field.top-dp(24)).coerceAtLeast(0))}}}
        dialog.show()
        dialog.window?.decorView?.post{ name.clearFocus(); scroll.requestFocus(); val imm=getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager; imm.hideSoftInputFromWindow(name.windowToken,0) }
    }

    private fun setupDateInput(edit:EditText){edit.addTextChangedListener(object:TextWatcher{private var editing=false;override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){};override fun afterTextChanged(s:Editable?){if(editing||s==null)return;val digits=s.toString().filter{it.isDigit()}.take(8);val formatted=buildString{digits.forEachIndexed{i,c->if(i==2||i==4)append('/');append(c)}};if(formatted!=s.toString()){editing=true;edit.setText(formatted);edit.setSelection(formatted.length);editing=false}}})}
    private fun parseDate(value:String):LocalDate=LocalDate.parse(value.trim(),fmt)

    private fun settings(){
        val scroll=ScrollView(this).apply{isFillViewport=true}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(4),dp(18),dp(8))}
        fun section(title:String,subtitle:String){
            box.addView(TextView(this).apply{text=title;textSize=19f;setTextColor(Color.rgb(24,27,31));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(0,dp(10),0,dp(3))})
            box.addView(TextView(this).apply{text=subtitle;textSize=13.5f;setTextColor(Color.rgb(92,96,102));setPadding(0,0,0,dp(8))})
        }
        section("Chiusura ferie","Le scadenze che cadono nella chiusura vengono spostate al giorno successivo alla riapertura.")
        val s=modernEditText().apply{hint="Data inizio • gg/mm/aaaa";inputType=2;setSingleLine(true);setText(ferieStart?.format(fmt) ?: "")};setupDateInput(s)
        val e=modernEditText().apply{hint="Data fine • gg/mm/aaaa";inputType=2;setSingleLine(true);setText(ferieEnd?.format(fmt) ?: "")};setupDateInput(e)
        box.addView(s,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,0,0,dp(6))})
        box.addView(e,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,0,0,dp(14))})

        section("Giorni visualizzati nel calendario","Scegli quali giorni della settimana mostrare. La scelta viene salvata.")
        val dayChecks=(0..6).map{i->CheckBox(this).apply{text=dayShort(i);textSize=15f;isChecked=calendarVisibleDays[i];setPadding(0,0,0,0)}}
        dayChecks.forEach{cb->box.addView(cb,LinearLayout.LayoutParams(-1,dp(42)))}

        section("Preferenze visualizzazione","Scegli come mostrare i nomi dei clienti in tutta l'app. Il dato salvato non viene modificato.")
        val nameOrder=RadioGroup(this).apply{orientation=RadioGroup.VERTICAL}
        val surnameFirst=RadioButton(this).apply{text="Cognome Nome";textSize=15f;isChecked=surnameFirstDisplay}
        val firstNameFirst=RadioButton(this).apply{text="Nome Cognome";textSize=15f;isChecked=!surnameFirstDisplay}
        nameOrder.addView(surnameFirst,RadioGroup.LayoutParams(-1,dp(44)))
        nameOrder.addView(firstNameFirst,RadioGroup.LayoutParams(-1,dp(44)))
        box.addView(nameOrder)

        section("Tipi di appuntamento","Personalizza il nome e il colore. I primi 2 tipi sono già configurati.")
        val typeRows=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val typeNameFields=mutableListOf<EditText>()
        val workingTypes=appointmentTypes.map{it.copy()}.toMutableList()
        var baselineFerieStart=ferieStart
        var baselineFerieEnd=ferieEnd
        var baselineVisibleDays=calendarVisibleDays.toList()
        var baselineSurnameFirst=surnameFirstDisplay
        var baselineTypes=appointmentTypes.map{it.copy()}
        var baselineTotal=(calendarRoutines.getOrNull(activeRoutineIndex)?.maxTotal ?: 3).coerceIn(1,10)
        var baselineLimits=(calendarRoutines.getOrNull(activeRoutineIndex)?.maxByType ?: MutableList(baselineTypes.size){baselineTotal}).toList()
        fun colorHex(c:Int)=String.format("#%06X",0xFFFFFF and c)
        var rerenderLimits: (() -> Unit)? = null
        fun renderTypeRows(){
            // Prima di ridisegnare le righe conserviamo i nomi già digitati.
            // Altrimenti premendo "+ Nome appuntamento" i campi precedenti venivano ricreati
            // con il valore iniziale (es. "Nuovo appuntamento").
            if(typeNameFields.size==workingTypes.size){
                typeNameFields.forEachIndexed{i,field->
                    val typed=field.text.toString().trim()
                    if(typed.isNotEmpty()) workingTypes[i].name=typed
                }
            }
            typeRows.removeAllViews();typeNameFields.clear()
            workingTypes.forEachIndexed{idx,t->
                val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                val name=modernEditText().apply{setSingleLine(true);setText(t.name);hint="Nome appuntamento ${idx+1}";gravity=Gravity.CENTER};typeNameFields.add(name)
                row.addView(name,LinearLayout.LayoutParams(0,dp(54),1f))
                val colorBtn=Button(this).apply{setAllCaps(false);text="✏️ Colore";textSize=12f;gravity=Gravity.CENTER;setTextColor(t.color);background=roundedSurface(typeBgForColor(t.color),14);stateListAnimator=null}
                colorBtn.setOnClickListener{
                    val palette=listOf(
                        "Blu" to Color.rgb(45,135,210), "Azzurro" to Color.rgb(55,170,205), "Celeste" to Color.rgb(95,180,235), "Blu scuro" to Color.rgb(35,75,145), "Turchese" to Color.rgb(20,155,145), "Verde" to Color.rgb(40,160,90),
                        "Verde chiaro" to Color.rgb(100,185,85), "Lime" to Color.rgb(165,195,45), "Giallo" to Color.rgb(235,190,35), "Arancione" to Color.rgb(235,140,35), "Corallo" to Color.rgb(235,105,80), "Rosso" to Color.rgb(215,55,55),
                        "Rosa" to Color.rgb(220,90,145), "Fucsia" to Color.rgb(195,55,150), "Viola" to Color.rgb(125,80,190), "Lilla" to Color.rgb(160,115,210), "Indaco" to Color.rgb(75,70,170), "Marrone" to Color.rgb(145,95,60),
                        "Beige" to Color.rgb(205,170,120), "Grigio" to Color.rgb(100,105,112), "Grigio chiaro" to Color.rgb(155,160,165), "Antracite" to Color.rgb(55,60,65), "Nero" to Color.rgb(25,25,28), "Bianco" to Color.rgb(245,245,245)
                    )
                    val paletteGrid=GridLayout(this).apply{
                        columnCount=4
                        rowCount=(palette.size+3)/4
                        setPadding(dp(12),dp(8),dp(12),dp(8))
                    }
                    val colorDialog=AlertDialog.Builder(this).setTitle("Scegli il colore").setView(paletteGrid).setNegativeButton("Annulla",null).create()
                    palette.forEach{pair->
                        val swatch=TextView(this).apply{
                            text=""
                            gravity=Gravity.CENTER
                            setBackground(GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(pair.second);setStroke(dp(2),Color.WHITE)})
                            isClickable=true
                            isFocusable=true
                            contentDescription=pair.first
                            elevation=dp(2).toFloat()
                        }
                        swatch.setOnClickListener{
                            t.color=pair.second
                            colorBtn.setTextColor(pair.second)
                            colorBtn.background=roundedSurface(typeBgForColor(pair.second),14)
                            colorBtn.contentDescription="Colore: ${pair.first}"
                            colorDialog.dismiss()
                        }
                        paletteGrid.addView(swatch,GridLayout.LayoutParams().apply{
                            width=dp(48);height=dp(48);setMargins(dp(8),dp(8),dp(8),dp(8))
                        })
                    }
                    styleOneUiDialog(colorDialog);colorDialog.show()
                }
                row.addView(colorBtn,LinearLayout.LayoutParams(dp(142),dp(48)).apply{setMargins(dp(6),0,0,0)})
                val removeBtn=Button(this).apply{
                    text="✕";setAllCaps(false);textSize=18f;setTextColor(Color.rgb(105,110,116));setBackgroundColor(Color.TRANSPARENT);stateListAnimator=null
                    contentDescription="Elimina ${t.name}"
                }
                removeBtn.setOnClickListener{
                    if(workingTypes.size<=1){Toast.makeText(this,"Deve rimanere almeno un tipo di appuntamento.",Toast.LENGTH_SHORT).show()}
                    else {
                        val typeId=t.id
                        val used=appointments.any{normalizedType(it.type)==typeId}
                        if(used){
                            Toast.makeText(this,"Questo tipo è già usato nel calendario e non può essere eliminato.",Toast.LENGTH_LONG).show()
                        }else{
                            workingTypes.removeAt(idx)
                            renderTypeRows()
                            rerenderLimits?.invoke()
                        }
                    }
                }
                row.addView(removeBtn,LinearLayout.LayoutParams(dp(42),dp(48)).apply{setMargins(dp(2),0,0,0)})
                typeRows.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(3),0,dp(3))})
            }
        }
        renderTypeRows();box.addView(typeRows)
        val addType=softBlueButtonStyle("＋ Nome appuntamento")
        box.addView(addType,LinearLayout.LayoutParams(-1,dp(46)).apply{setMargins(0,dp(7),0,dp(8))})
        addType.setOnClickListener{val n=workingTypes.size+1;workingTypes.add(AppointmentType("TYPE$n","Nuovo appuntamento",Color.rgb(90,105,120),45));renderTypeRows();rerenderLimits?.invoke()}

        section("Capienza calendario","Imposta quanti appuntamenti possono essere presenti nella stessa fascia.")
        val sourceRoutine=calendarRoutines.getOrNull(activeRoutineIndex)
        val workingRoutine=(sourceRoutine?.let{CalendarRoutine(it.name,it.maxTotal,it.maxByType.toMutableList())} ?: CalendarRoutine("Personalizzata",3,MutableList(workingTypes.size){3}))
        while(workingRoutine.maxByType.size<workingTypes.size)workingRoutine.maxByType.add(workingRoutine.maxTotal)
        val maxTotal=Spinner(this).apply{adapter=centeredSpinnerAdapter((1..10).map{it.toString()});setSelection((workingRoutine.maxTotal.coerceIn(1,10))-1)}
        box.addView(TextView(this).apply{text="Appuntamenti massimi per fascia";textSize=14f;setTextColor(Color.GRAY);gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(-1,dp(30)).apply{setMargins(0,dp(4),0,0)})
        box.addView(maxTotal,LinearLayout.LayoutParams(-1,dp(50)))
        val limitsBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val limitSpinners=mutableListOf<Spinner>()
        fun renderLimits(){
            limitsBox.removeAllViews();limitSpinners.clear()
            val total=maxTotal.selectedItemPosition+1
            workingTypes.forEachIndexed{idx,t->
                val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                val label=TextView(this).apply{text=t.name;textSize=15f;setTextColor(Color.DKGRAY);gravity=Gravity.CENTER_VERTICAL}
                row.addView(label,LinearLayout.LayoutParams(0,dp(50),1f))
                val sp=Spinner(this).apply{
                    adapter=centeredSpinnerAdapter((0..total).map{it.toString()})
                    val value=(workingRoutine.maxByType.getOrNull(idx)?:total).coerceIn(0,total)
                    setSelection(value)
                }
                limitSpinners.add(sp)
                row.addView(sp,LinearLayout.LayoutParams(dp(105),dp(50)).apply{setMargins(dp(8),0,0,0)})
                limitsBox.addView(row,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,dp(3),0,dp(3))})
            }
        }
        rerenderLimits={renderLimits()}
        maxTotal.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent:AdapterView<*>?){ }
            override fun onItemSelected(parent:AdapterView<*>?,view:View?,position:Int,id:Long){renderLimits()}
        }
        box.addView(limitsBox);renderLimits()
        val saveRoutine=buttonStyle("Salva capienza")
        box.addView(saveRoutine,LinearLayout.LayoutParams(-1,dp(46)).apply{setMargins(0,dp(7),0,dp(4))})
        saveRoutine.setOnClickListener{
            val total=maxTotal.selectedItemPosition+1
            workingRoutine.name="Personalizzata"
            workingRoutine.maxTotal=total
            workingRoutine.maxByType.clear()
            limitSpinners.forEach{workingRoutine.maxByType.add(it.selectedItemPosition.coerceAtMost(total))}
            renderLimits()
            Toast.makeText(this,"Capienza aggiornata. Premi Salva per confermare.",Toast.LENGTH_SHORT).show()
        }

        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(10),0,0)}
        val clear=Button(this).apply{text="Cancella ferie";setAllCaps(false);textSize=13.5f;setTextColor(Color.rgb(205,55,55));setBackgroundColor(Color.TRANSPARENT);stateListAnimator=null}
        val close=Button(this).apply{text="Chiudi";setAllCaps(false);textSize=13.5f;setTextColor(Color.rgb(0,125,110));setBackgroundColor(Color.TRANSPARENT);stateListAnimator=null}
        val save=Button(this).apply{text="Salva";setAllCaps(false);textSize=13.5f;setTextColor(Color.WHITE);background=roundedSurface(Color.rgb(0,125,110),18);stateListAnimator=null}
        actions.addView(clear,LinearLayout.LayoutParams(0,dp(46),1f));actions.addView(close,LinearLayout.LayoutParams(0,dp(46),1f));actions.addView(save,LinearLayout.LayoutParams(dp(86),dp(44)));box.addView(actions)
        scroll.addView(box,ViewGroup.LayoutParams(-1,-2))
        val dialog=AlertDialog.Builder(this).setView(scroll).create();styleOneUiDialog(dialog)
        fun hasUnsavedChanges():Boolean{
            val st=s.text.toString().trim();val et=e.text.toString().trim()
            val ferieChanged=st != (baselineFerieStart?.format(fmt) ?: "") || et != (baselineFerieEnd?.format(fmt) ?: "")
            val daysChanged=dayChecks.map{it.isChecked} != baselineVisibleDays
            val nameOrderChanged=surnameFirst.isChecked != baselineSurnameFirst
            val currentTypes=workingTypes.mapIndexed { i, t ->
                val nn=typeNameFields.getOrNull(i)?.text?.toString()?.trim().orEmpty()
                t.copy(name=nn.ifEmpty { t.name })
            }
            val typesChanged=currentTypes.size != baselineTypes.size || currentTypes.zip(baselineTypes).any{(a,b)->a.id!=b.id||a.name!=b.name||a.color!=b.color||a.duration!=b.duration}
            val totalChanged=maxTotal.selectedItemPosition+1 != baselineTotal
            val limitsNow=limitSpinners.map{it.selectedItemPosition}
            val limitsChanged=limitsNow.size!=baselineLimits.size || limitsNow!=baselineLimits.map{v->v.coerceIn(0,baselineTotal)}
            return ferieChanged||daysChanged||nameOrderChanged||typesChanged||totalChanged||limitsChanged
        }
        dialog.setOnShowListener{
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28));dialog.window?.setDimAmount(0.42f)
            clear.setOnClickListener{
                s.setText("");e.setText("")
            }
            close.setOnClickListener{
                if(hasUnsavedChanges()){
                    AlertDialog.Builder(this).setTitle("Modifiche non salvate").setMessage("Hai apportato delle modifiche che non sono state salvate. Vuoi uscire senza salvare?").setNegativeButton("Continua modifica",null).setPositiveButton("Esci senza salvare"){_,_->dialog.dismiss()}.show()
                }else dialog.dismiss()
            }
            save.setOnClickListener{try{
                val st=s.text.toString().trim();val et=e.text.toString().trim()
                if(st.isEmpty()&&et.isEmpty()){ferieStart=null;ferieEnd=null}else{val sd=parseDate(st);val ed=parseDate(et);require(!ed.isBefore(sd));ferieStart=sd;ferieEnd=ed}
                require(dayChecks.any{it.isChecked})
                dayChecks.forEachIndexed{i,cb->calendarVisibleDays[i]=cb.isChecked}
                surnameFirstDisplay=surnameFirst.isChecked
                val savedTypes=workingTypes.mapIndexed{i,t ->
                    val nn=typeNameFields.getOrNull(i)?.text?.toString()?.trim().orEmpty()
                    t.copy(name=nn.ifEmpty{t.name})
                }
                require(savedTypes.isNotEmpty())
                appointmentTypes.clear();appointmentTypes.addAll(savedTypes)
                calendarRoutines.forEach{while(it.maxByType.size<appointmentTypes.size)it.maxByType.add(it.maxTotal)}
                val total=maxTotal.selectedItemPosition+1
                workingRoutine.name="Personalizzata";workingRoutine.maxTotal=total;workingRoutine.maxByType.clear()
                limitSpinners.forEach{workingRoutine.maxByType.add(it.selectedItemPosition.coerceAtMost(total))}
                if(calendarRoutines.isEmpty())calendarRoutines.add(workingRoutine) else calendarRoutines[activeRoutineIndex]=workingRoutine
                saveData()
                baselineFerieStart=ferieStart;baselineFerieEnd=ferieEnd
                baselineVisibleDays=calendarVisibleDays.toList()
                baselineSurnameFirst=surnameFirstDisplay
                baselineTypes=appointmentTypes.map{it.copy()}
                baselineTotal=workingRoutine.maxTotal
                baselineLimits=workingRoutine.maxByType.toList()
                Toast.makeText(this,"Impostazioni salvate.",Toast.LENGTH_SHORT).show()
            }catch(_:Exception){Toast.makeText(this,"Inserisci dati validi e seleziona almeno un giorno del calendario.",Toast.LENGTH_LONG).show()}}
        }
        dialog.show()
    }
    private fun backupMenu(){
        val last=getSharedPreferences("gestione_pagamenti",MODE_PRIVATE).getString("autoBackupDate","")
        val lastText=if(last.isNullOrBlank())"Nessun backup automatico ancora"else"Ultimo backup automatico: $last"
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(4),dp(18),dp(8))}
        fun option(title:String,subtitle:String,icon:String,action:()->Unit){
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(12),dp(12),dp(12));background=roundedSurface(Color.rgb(246,248,250),20,Color.rgb(228,231,235),1);isClickable=true;isFocusable=true}
            row.addView(TextView(this).apply{text=icon;textSize=22f;gravity=Gravity.CENTER;setBackground(roundedSurface(Color.WHITE,16));setPadding(dp(8),dp(6),dp(8),dp(6))},LinearLayout.LayoutParams(dp(50),dp(50)))
            val texts=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
            texts.addView(TextView(this@MainActivity).apply{text=title;textSize=16f;setTextColor(Color.rgb(25,28,32));setTypeface(null,android.graphics.Typeface.BOLD)})
            texts.addView(TextView(this@MainActivity).apply{text=subtitle;textSize=12.5f;setTextColor(Color.rgb(100,104,110));setPadding(0,dp(3),0,0)})
            row.addView(texts,LinearLayout.LayoutParams(0,-2,1f))
            row.addView(TextView(this@MainActivity).apply{text="›";textSize=28f;setTextColor(Color.rgb(120,124,130));gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(28),dp(50)))
            row.setOnClickListener{action()}
            box.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))})
        }
        option("Backup automatico","Attivo • 1 copia automatica al giorno, separata dal manuale","☁"){maybeAutoBackup();Toast.makeText(this,"$lastText",Toast.LENGTH_LONG).show()}
        option("Esporta backup manuale","Salva una copia completa dove preferisci","↑"){exportData()}
        option("Importa backup manuale","Ripristina una copia precedentemente salvata","↓"){importData()}
        option("Ripristina backup automatico",lastText,"↺"){restoreAutoBackup()}
        val close=Button(this).apply{text="Chiudi";setAllCaps(false);textSize=14f;setTextColor(Color.rgb(0,125,110));setBackgroundColor(Color.TRANSPARENT);stateListAnimator=null}
        box.addView(close,LinearLayout.LayoutParams(-1,dp(46)).apply{setMargins(0,dp(4),0,0)})
        val dialog=AlertDialog.Builder(this).setTitle("Backup e dati").setView(box).create()
        dialog.setOnShowListener{dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28));dialog.window?.setDimAmount(0.42f);close.setOnClickListener{dialog.dismiss()}}
        dialog.show()
    }
    private fun exportData(){startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/json";putExtra(Intent.EXTRA_TITLE,"GestionePagamenti_backup.json")},REQ_EXPORT)}
    private fun importData(){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/json"},REQ_IMPORT)}
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK)return;val uri=data?.data?:return;if(requestCode==REQ_EXPORT)writeBackup(uri)else if(requestCode==REQ_IMPORT)readBackup(uri)else if(requestCode==REQ_SUMMARY)writeSummary(uri)}

    private fun backupJson():JSONObject{
        val root=JSONObject();root.put("format","GestionePagamenti");root.put("version",5);root.put("exportedAt",LocalDateTime.now().toString());root.put("ferieStart",ferieStart?.toString()?:JSONObject.NULL);root.put("ferieEnd",ferieEnd?.toString()?:JSONObject.NULL);root.put("dashboardEnabled",dashboardEnabled);root.put("surnameFirstDisplay",surnameFirstDisplay);root.put("calendarVisibleDays",JSONArray().apply{calendarVisibleDays.forEach{put(it)}});root.put("appointmentTypes",JSONArray().apply{appointmentTypes.forEach{t->put(JSONObject().apply{put("id",t.id);put("name",t.name);put("color",t.color);put("duration",t.duration)})}});root.put("activeRoutineIndex",activeRoutineIndex);root.put("calendarRoutines",JSONArray().apply{calendarRoutines.forEach{r->put(JSONObject().apply{put("name",r.name);put("maxTotal",r.maxTotal);put("maxByType",JSONArray().apply{r.maxByType.forEach{put(it)}})})}})
        val array=JSONArray();packs.forEach{p->val rates=ratesFor(p);val dates=dueDates(p);array.put(JSONObject().apply{put("name",p.name);put("start",p.start.toString());put("total",p.total);put("paid",p.paid);put("dueDates",JSONArray().apply{dates.forEach{put(it.toString())}});put("rateAmounts",JSONArray().apply{rates.forEach{put(it)}});put("packageType",p.packageType);put("sessionTotal",p.sessionTotal);put("active",p.active);put("missedSessions",p.missedSessions)})};root.put("packs",array)
        root.put("sessionPacks",JSONArray().apply{sessionPacks.forEach{s->put(JSONObject().apply{put("id",s.id);put("name",s.name);put("start",s.start.toString());put("totalSessions",s.totalSessions);put("cost",s.cost);put("paid",s.paid);put("active",s.active);put("rateAmounts",JSONArray().apply{sessionRatesFor(s).forEach{put(it)}})})}})
        root.put("appointments",JSONArray().apply{appointments.forEach{a->put(JSONObject().apply{put("id",a.id);put("name",a.name);put("date",a.date.toString());put("time",a.time);put("type",a.type);put("seriesId",a.seriesId);put("sessionPackId",a.sessionPackId);put("recovery",a.recovery)})}});return root
    }

    private fun loadCalendarConfig(root:JSONObject){
        appointmentTypes.clear();root.optJSONArray("appointmentTypes")?.let{ta->for(i in 0 until ta.length()){val t=ta.getJSONObject(i);appointmentTypes.add(AppointmentType(t.optString("id","TYPE${i+1}"),t.optString("name",if(i==0)"ALLENAMENTO" else if(i==1)"MEZZ'ORA" else "Tipo ${i+1}"),t.optInt("color",if(i==0)Color.rgb(45,135,210) else Color.rgb(215,55,55)),t.optInt("duration",if(i==1)30 else 45)))}};if(appointmentTypes.isEmpty()){appointmentTypes.add(AppointmentType("TYPE1","ALLENAMENTO",Color.rgb(45,135,210),45));appointmentTypes.add(AppointmentType("TYPE2","MEZZ'ORA",Color.rgb(215,55,55),30))}
        calendarRoutines.clear();root.optJSONArray("calendarRoutines")?.let{ra->for(i in 0 until ra.length()){val r=ra.getJSONObject(i);val limits=mutableListOf<Int>();r.optJSONArray("maxByType")?.let{ja->for(j in 0 until ja.length())limits.add(ja.optInt(j,3))};if(limits.isEmpty()){limits.add(2);limits.add(3)};while(limits.size<appointmentTypes.size)limits.add(r.optInt("maxTotal",3));calendarRoutines.add(CalendarRoutine(r.optString("name","Routine ${i+1}"),r.optInt("maxTotal",3),limits))}};if(calendarRoutines.isEmpty())calendarRoutines.add(CalendarRoutine("Personalizzata",3,MutableList(appointmentTypes.size){if(it==0)2 else 3}));activeRoutineIndex=root.optInt("activeRoutineIndex",0).coerceIn(0,calendarRoutines.lastIndex)
    }
    private fun writeSummary(uri:Uri){try{contentResolver.openOutputStream(uri)?.use{it.write(pendingSummaryText.toByteArray(Charsets.UTF_8))};Toast.makeText(this,"Riepilogo esportato.",Toast.LENGTH_LONG).show()}catch(_:Exception){Toast.makeText(this,"Impossibile esportare il riepilogo.",Toast.LENGTH_LONG).show()}}

    private fun regularPackFor(name:String, date:LocalDate):Pack? = packs.filter {
        it.active && identityKey(it.name)==identityKey(name) && !date.isBefore(it.start) && !date.isAfter(it.start.plusWeeks(12).minusDays(1))
    }.maxByOrNull { it.start }

    private fun recoveryUsedForPack(p:Pack):Int = 0

    private fun recoveriesForPack(p:Pack):Int {
        val end=p.start.plusWeeks(12).minusDays(1)
        val target=when(p.packageType){
            "GOLD"->3
            "SILVER"->2
            "BRONZE"->1
            else->0
        }
        if(target<=0)return 0
        val inWindow=appointments.filter{
            identityKey(it.name)==identityKey(p.name) &&
            !it.date.isBefore(p.start) && !it.date.isAfter(end)
        }
        if(inWindow.isEmpty())return 0
        var deficit=0
        var surplus=0
        for(week in 0 until 12){
            val ws=p.start.plusWeeks(week.toLong())
            val we=ws.plusDays(6)
            val count=inWindow.count{!it.date.isBefore(ws)&&!it.date.isAfter(we)}
            if(count==0)continue
            if(count<target) deficit += target-count
            else if(count>target) surplus += count-target
        }
        return (deficit-surplus).coerceAtLeast(0)
    }

    private fun sessionsForPack(p:Pack,until:LocalDate=LocalDate.now()):List<Appointment>{
        val end=p.start.plusWeeks(12).minusDays(1)
        return appointments.filter{identityKey(it.name)==identityKey(p.name)&&!it.date.isBefore(p.start)&&!it.date.isAfter(until)&&!it.date.isAfter(end)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
    }

    private fun sessionsForSessionPack(s:SessionPack,until:LocalDate=LocalDate.now()):List<Appointment>{
        return sessionAppointments(s).filter{!it.date.isAfter(until)&&!it.date.isBefore(s.start)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
    }

    private fun summaryForPack(p: Pack): String {
        val today = LocalDate.now()
        val packageEnd = p.start.plusWeeks(12).minusDays(1)
        val done = sessionsForPack(p, today)
        val expected = p.sessionTotal
        val recoveryDue = recoveriesForPack(p)
        val scheduledInWindow = appointments.count {
            identityKey(it.name)==identityKey(p.name) &&
            !it.date.isBefore(p.start) && !it.date.isAfter(packageEnd)
        }
        val remaining = (expected - scheduledInWindow).coerceAtLeast(0)
        val futurePackage = appointments.filter {
            identityKey(it.name) == identityKey(p.name) &&
            it.date.isAfter(today) && !it.date.isAfter(packageEnd) && !it.date.isBefore(p.start)
        }.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        val usedRecoveries = appointments.filter {
            it.recovery && identityKey(it.name)==identityKey(p.name) &&
            !it.date.isBefore(p.start) && !it.date.isAfter(packageEnd)
        }.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        return buildString {
            appendLine("📊 RIEPILOGO PROGRAMMAZIONE")
            appendLine()
            appendLine("Cliente: ${displaySurnameFirst(p.name)}")
            appendLine("Pacchetto: ${p.packageType} • $expected sedute • 12 settimane")
            appendLine("Periodo: ${p.start.format(fmt)} → ${packageEnd.format(fmt)}")
            appendLine()
            appendLine("SITUAZIONE")
            appendLine("• Sedute effettuate: ${done.size}")
            appendLine("• Sedute rimaste: $remaining")
            appendLine("• Recuperi disponibili: $recoveryDue")
            appendLine()
            appendLine("SEDUTE EFFETTUATE")
            if (done.isEmpty()) appendLine("Nessuna seduta effettuata.")
            done.forEachIndexed { index, a ->
                appendLine("${index + 1}. ${a.date.format(fmt)} • ${a.time} • ${typeLabel(a.type)}")
            }
            appendLine()
            appendLine("RECUPERI")
            if (usedRecoveries.isEmpty()) appendLine("Nessun recupero utilizzato.")
            usedRecoveries.forEachIndexed { index, a ->
                appendLine("${index + 1}. ${a.date.format(fmt)} • ${a.time} • RECUPERO • ${typeLabel(a.type)}")
            }
            appendLine("Disponibili: $recoveryDue")
            appendLine()
            appendLine("PROSSIMI APPUNTAMENTI")
            if (futurePackage.isEmpty()) appendLine("Nessun appuntamento futuro nel pacchetto.")
            futurePackage.forEachIndexed { index, a ->
                appendLine("${index + 1}. ${a.date.format(fmt)} • ${a.time} • ${typeLabel(a.type)}")
            }
        }
    }

    private fun summaryForSessionPack(s: SessionPack): String {
        val today = LocalDate.now()
        val done = sessionsForSessionPack(s, today)
        val futurePackage = sessionAppointments(s).filter { it.date.isAfter(today) }
            .sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        val annualFuture = appointments.filter {
            identityKey(it.name)==identityKey(s.name) && it.date.isAfter(today) && it.sessionPackId != s.id
        }.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        return buildString {
            appendLine("📋 PROGRAMMAZIONE ${displaySurnameFirst(s.name).uppercase()}")
            appendLine("Pacchetto • ${s.totalSessions} sedute")
            appendLine("Periodo pacchetto: ${s.start.format(fmt)} → aperto fino a esaurimento sedute")
            appendLine()
            appendLine("📊 SITUAZIONE")
            appendLine("• Sedute previste: ${s.totalSessions}")
            appendLine("• Sedute effettuate: ${done.size}")
            appendLine("• Sedute prenotate nel pacchetto: ${futurePackage.size}")
            appendLine("• Sedute rimanenti: ${(s.totalSessions-done.size).coerceAtLeast(0)}")
            appendLine()
            appendLine("🗓 PROGRAMMAZIONE DEL PACCHETTO")
            if(futurePackage.isEmpty()) appendLine("Nessun appuntamento futuro nel pacchetto.")
            futurePackage.forEachIndexed{index,a->
                val type=typeLabel(a.type)
                appendLine("${index+1}. ${a.date.format(fmt)} • ${a.time} • $type")
            }
            if(annualFuture.isNotEmpty()){
                appendLine()
                appendLine("📅 PROGRAMMAZIONE SUCCESSIVA")
                appendLine("Gli appuntamenti successivi restano nel calendario e verranno considerati per il prossimo pacchetto.")
                annualFuture.forEachIndexed{index,a->
                    val type=typeLabel(a.type)
                    appendLine("${index+1}. ${a.date.format(fmt)} • ${a.time} • $type")
                }
            }
        }
    }

    private fun copySummaryToClipboard(text:String,name:String){
        pendingSummaryText=text
        val clipboard=getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Riepilogo $name",text))
        val preview=TextView(this).apply{this.text=text;textSize=14f;setTextColor(Color.rgb(35,35,35));setPadding(dp(16),dp(8),dp(16),dp(8))}
        val dialog=AlertDialog.Builder(this).setTitle("📊 Riepilogo pronto per WhatsApp").setMessage("Il riepilogo è già stato copiato negli appunti. Puoi incollarlo direttamente su WhatsApp.").setView(ScrollView(this).apply{addView(preview)}).setPositiveButton("COPIA DI NUOVO"){_,_->
            clipboard.setPrimaryClip(ClipData.newPlainText("Riepilogo $name",text))
            Toast.makeText(this,"Riepilogo copiato negli appunti.",Toast.LENGTH_SHORT).show()
        }.setNegativeButton("CHIUDI",null).create()
        styleOneUiDialog(dialog)
        dialog.show()
    }

    private fun exportSummary(text:String,name:String){copySummaryToClipboard(text,name)}

    private fun maybeAutoBackup(){
        val prefs=getSharedPreferences("gestione_pagamenti",MODE_PRIVATE)
        val today=LocalDate.now().format(fmt)
        if(prefs.getString("autoBackupDate","")==today)return
        if(writeAutoBackup())prefs.edit().putString("autoBackupDate",today).apply()
    }

    private fun writeAutoBackup():Boolean{
        return try{
            val json=backupJson().toString(2).toByteArray(Charsets.UTF_8)
            val day=LocalDate.now().toString()
            val fileName="GestionePagamenti_auto_${day}.json"
            if(android.os.Build.VERSION.SDK_INT>=29){
                val resolver=contentResolver
                val projection=arrayOf(MediaStore.Downloads._ID)
                val selection="${MediaStore.Downloads.DISPLAY_NAME}=? AND ${MediaStore.Downloads.RELATIVE_PATH}=?"
                val args=arrayOf(fileName,"Download/GestionePagamenti/Backup automatici/")
                var uri:Uri?=null
                resolver.query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,projection,selection,args,null)?.use{c->if(c.moveToFirst())uri=Uri.withAppendedPath(MediaStore.Downloads.EXTERNAL_CONTENT_URI,c.getLong(0).toString())}
                val target=uri ?: resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,ContentValues().apply{
                    put(MediaStore.Downloads.DISPLAY_NAME,fileName)
                    put(MediaStore.Downloads.MIME_TYPE,"application/json")
                    put(MediaStore.Downloads.RELATIVE_PATH,"Download/GestionePagamenti/Backup automatici/")
                })
                target!=null && resolver.openOutputStream(target,"wt")?.use{it.write(json);true}==true
            }else{
                val dir=java.io.File(filesDir,"auto_backup");if(!dir.exists())dir.mkdirs()
                java.io.File(dir,fileName).writeBytes(json);true
            }
        }catch(_:Exception){false}
    }

    private fun restoreAutoBackup(){
        try{
            val text=if(android.os.Build.VERSION.SDK_INT>=29){
                val resolver=contentResolver
                val projection=arrayOf(MediaStore.Downloads._ID,MediaStore.Downloads.DISPLAY_NAME)
                val selection="${MediaStore.Downloads.DISPLAY_NAME} LIKE ? AND ${MediaStore.Downloads.RELATIVE_PATH}=?"
                val args=arrayOf("GestionePagamenti_auto_%.json","Download/GestionePagamenti/Backup automatici/")
                var uri:Uri?=null;var latestName=""
                resolver.query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,projection,selection,args,"${MediaStore.Downloads.DISPLAY_NAME} DESC")?.use{c->if(c.moveToFirst()){latestName=c.getString(1);uri=Uri.withAppendedPath(MediaStore.Downloads.EXTERNAL_CONTENT_URI,c.getLong(0).toString())}}
                uri?.let{resolver.openInputStream(it)?.use{ins->BufferedReader(InputStreamReader(ins,Charsets.UTF_8)).readText()}}
            }else{
                val dir=java.io.File(filesDir,"auto_backup")
                dir.listFiles()?.sortedByDescending{it.name}?.firstOrNull()?.takeIf{it.exists()}?.readText()
            } ?: throw Exception()
            val root=JSONObject(text);require(root.optString("format")=="GestionePagamenti")
            AlertDialog.Builder(this).setTitle("Ripristinare backup automatico?").setMessage("Il backup automatico sostituirà i dati attualmente presenti nell'app.\n\nBackup del: ${root.optString("exportedAt", "data non disponibile")}").setNegativeButton("ANNULLA",null).setPositiveButton("RIPRISTINA"){_,_->restoreFromJson(root)}.show()
        }catch(_:Exception){Toast.makeText(this,"Nessun backup automatico disponibile.",Toast.LENGTH_LONG).show()}
    }

    private fun restoreFromJson(root:JSONObject){
        try{
            val newPacks=mutableListOf<Pack>();val array=root.getJSONArray("packs");for(i in 0 until array.length()){val o=array.getJSONObject(i);newPacks.add(Pack(o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("total"),o.optInt("paid",0),o.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}},o.optString("packageType","PERSONALIZZATO"),o.optInt("sessionTotal",12),o.optBoolean("active",true),o.optInt("missedSessions",0)))}
            val newSessionPacks=mutableListOf<SessionPack>();val sp=root.optJSONArray("sessionPacks");if(sp!=null)for(i in 0 until sp.length()){val o=sp.getJSONObject(i);newSessionPacks.add(SessionPack(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("totalSessions"),o.getInt("cost"),o.optInt("paid",o.optInt("cost",0)),o.optBoolean("active",true),o.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}}))}
            val newAppointments=mutableListOf<Appointment>();val ap=root.optJSONArray("appointments");if(ap!=null)for(i in 0 until ap.length()){val o=ap.getJSONObject(i);newAppointments.add(Appointment(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("date")),o.getString("time"),normalizedType(o.optString("type","TYPE1")),o.optLong("seriesId",0L),o.optLong("sessionPackId",0L),o.optBoolean("recovery",false)))}
            packs.clear();packs.addAll(newPacks);sessionPacks.clear();sessionPacks.addAll(newSessionPacks);appointments.clear();appointments.addAll(newAppointments);nextAppointmentId=(appointments.maxOfOrNull{it.id}?:0L)+1;nextSessionPackId=(sessionPacks.maxOfOrNull{it.id}?:0L)+1
            ferieStart=if(root.isNull("ferieStart"))null else LocalDate.parse(root.getString("ferieStart"));ferieEnd=if(root.isNull("ferieEnd"))null else LocalDate.parse(root.getString("ferieEnd"));dashboardEnabled=root.optBoolean("dashboardEnabled",false);surnameFirstDisplay=root.optBoolean("surnameFirstDisplay",true);loadCalendarConfig(root);calendarVisibleDays=booleanArrayOf(true,true,true,true,true,false,false);root.optJSONArray("calendarVisibleDays")?.let{ja->if(ja.length()==7)calendarVisibleDays=BooleanArray(7){i->ja.optBoolean(i,i<5)}}
            saveData();build();Toast.makeText(this,"Backup automatico ripristinato.",Toast.LENGTH_LONG).show()
        }catch(_:Exception){Toast.makeText(this,"Backup automatico non valido.",Toast.LENGTH_LONG).show()}
    }

    private fun writeBackup(uri:Uri){try{contentResolver.openOutputStream(uri)?.use{it.write(backupJson().toString(2).toByteArray(Charsets.UTF_8))};Toast.makeText(this,"Backup esportato correttamente.",Toast.LENGTH_LONG).show()}catch(_:Exception){Toast.makeText(this,"Impossibile esportare il backup.",Toast.LENGTH_LONG).show()}}
    private fun readBackup(uri:Uri){try{val text=contentResolver.openInputStream(uri)?.use{BufferedReader(InputStreamReader(it,Charsets.UTF_8)).readText()}?:throw Exception();val root=JSONObject(text);require(root.optString("format")=="GestionePagamenti");val newPacks=mutableListOf<Pack>();val array=root.getJSONArray("packs");for(i in 0 until array.length()){val o=array.getJSONObject(i);newPacks.add(Pack(o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("total"),o.optInt("paid",0), o.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}}, o.optString("packageType","PERSONALIZZATO"), o.optInt("sessionTotal",when(o.optString("packageType","PERSONALIZZATO")){"BRONZE"->12;"SILVER"->24;"GOLD"->36;else->12}), o.optBoolean("active",true), o.optInt("missedSessions",0)))};ferieStart=if(root.isNull("ferieStart"))null else LocalDate.parse(root.getString("ferieStart"));ferieEnd=if(root.isNull("ferieEnd"))null else LocalDate.parse(root.getString("ferieEnd"));dashboardEnabled=root.optBoolean("dashboardEnabled",false);surnameFirstDisplay=root.optBoolean("surnameFirstDisplay",true);loadCalendarConfig(root);calendarVisibleDays=booleanArrayOf(true,true,true,true,true,false,false);root.optJSONArray("calendarVisibleDays")?.let{ja->if(ja.length()==7)calendarVisibleDays=BooleanArray(7){i->ja.optBoolean(i,i<5)}};val newSessionPacks=mutableListOf<SessionPack>();val sp=root.optJSONArray("sessionPacks");if(sp!=null)for(i in 0 until sp.length()){val o=sp.getJSONObject(i);newSessionPacks.add(SessionPack(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("totalSessions"),o.getInt("cost"),o.optInt("paid",o.optInt("cost",0)),o.optBoolean("active",true),o.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}}))};val newAppointments=mutableListOf<Appointment>();val ap=root.optJSONArray("appointments");if(ap!=null)for(i in 0 until ap.length()){val o=ap.getJSONObject(i);newAppointments.add(Appointment(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("date")),o.getString("time"),normalizedType(o.optString("type","TYPE1")),o.optLong("seriesId",0L),o.optLong("sessionPackId",0L),o.optBoolean("recovery",false)))};packs.clear();packs.addAll(newPacks);sessionPacks.clear();sessionPacks.addAll(newSessionPacks);appointments.clear();appointments.addAll(newAppointments);nextAppointmentId=(appointments.maxOfOrNull{it.id}?:0L)+1;nextSessionPackId=(sessionPacks.maxOfOrNull{it.id}?:0L)+1;saveData();build();Toast.makeText(this,"Backup importato: dati, ferie, pagamenti e appuntamenti ripristinati.",Toast.LENGTH_LONG).show()}catch(_:Exception){Toast.makeText(this,"Backup non valido o non leggibile.",Toast.LENGTH_LONG).show()}}

    private fun saveData(){
        val prefs=getSharedPreferences("gestione_pagamenti",MODE_PRIVATE);val array=JSONArray();packs.forEach{p->array.put(JSONObject().apply{put("name",p.name);put("start",p.start.toString());put("total",p.total);put("paid",p.paid);put("rateAmounts",JSONArray().apply{ratesFor(p).forEach{put(it)}});put("packageType",p.packageType);put("sessionTotal",p.sessionTotal);put("active",p.active);put("missedSessions",p.missedSessions)})};val sp=JSONArray();sessionPacks.forEach{s->sp.put(JSONObject().apply{put("id",s.id);put("name",s.name);put("start",s.start.toString());put("totalSessions",s.totalSessions);put("cost",s.cost);put("paid",s.paid);put("active",s.active);put("rateAmounts",JSONArray().apply{sessionRatesFor(s).forEach{put(it)}})})};val ap=JSONArray();appointments.forEach{a->ap.put(JSONObject().apply{put("id",a.id);put("name",a.name);put("date",a.date.toString());put("time",a.time);put("type",a.type);put("seriesId",a.seriesId);put("sessionPackId",a.sessionPackId);put("recovery",a.recovery)})};prefs.edit().putString("packs",array.toString()).putString("sessionPacks",sp.toString()).putString("appointments",ap.toString()).putString("ferieStart",ferieStart?.toString()).putString("ferieEnd",ferieEnd?.toString()).putBoolean("dashboardEnabled",dashboardEnabled).putBoolean("surnameFirstDisplay",surnameFirstDisplay).putString("calendarVisibleDays",calendarVisibleDays.joinToString(","){if(it)"1" else "0"}).putString("appointmentTypes",JSONArray().apply{appointmentTypes.forEach{t->put(JSONObject().apply{put("id",t.id);put("name",t.name);put("color",t.color);put("duration",t.duration)})}}.toString()).putInt("activeRoutineIndex",activeRoutineIndex).putString("calendarRoutines",JSONArray().apply{calendarRoutines.forEach{r->put(JSONObject().apply{put("name",r.name);put("maxTotal",r.maxTotal);put("maxByType",JSONArray().apply{r.maxByType.forEach{put(it)}})})}}.toString()).putLong("nextAppointmentId",nextAppointmentId).putLong("nextSessionPackId",nextSessionPackId).apply();maybeAutoBackup()
    }
    private fun loadData(){
        val prefs=getSharedPreferences("gestione_pagamenti",MODE_PRIVATE);packs.clear();sessionPacks.clear();appointments.clear();val saved=prefs.getString("packs",null);if(!saved.isNullOrEmpty())try{val array=JSONArray(saved);for(i in 0 until array.length()){val o=array.getJSONObject(i);packs.add(Pack(o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("total"),o.optInt("paid",0), o.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}}, o.optString("packageType","PERSONALIZZATO"), o.optInt("sessionTotal",when(o.optString("packageType","PERSONALIZZATO")){"BRONZE"->12;"SILVER"->24;"GOLD"->36;else->12}), o.optBoolean("active",true), o.optInt("missedSessions",0)))}}catch(_:Exception){packs.clear()};val ap=prefs.getString("appointments",null);if(!ap.isNullOrEmpty())try{val array=JSONArray(ap);for(i in 0 until array.length()){val o=array.getJSONObject(i);appointments.add(Appointment(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("date")),o.getString("time"),normalizedType(o.optString("type","TYPE1")),o.optLong("seriesId",0L),o.optLong("sessionPackId",0L),o.optBoolean("recovery",false)))}}catch(_:Exception){appointments.clear()};val savedSp=prefs.getString("sessionPacks",null);if(!savedSp.isNullOrEmpty())try{val array=JSONArray(savedSp);for(i in 0 until array.length()){val o=array.getJSONObject(i);sessionPacks.add(SessionPack(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("totalSessions"),o.getInt("cost"),o.optInt("paid",o.optInt("cost",0)),o.optBoolean("active",true),o.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}}))}}catch(_:Exception){sessionPacks.clear()};nextAppointmentId=maxOf(prefs.getLong("nextAppointmentId",1L),(appointments.maxOfOrNull{it.id}?:0L)+1);nextSessionPackId=maxOf(prefs.getLong("nextSessionPackId",1L),(sessionPacks.maxOfOrNull{it.id}?:0L)+1)
        appointments.filter{it.sessionPackId==0L}.forEach{a->activeSessionPackFor(a.name)?.let{sp->a.sessionPackId=sp.id}}
        ferieStart=prefs.getString("ferieStart",null)?.let{runCatching{LocalDate.parse(it)}.getOrNull()};ferieEnd=prefs.getString("ferieEnd",null)?.let{runCatching{LocalDate.parse(it)}.getOrNull()};dashboardEnabled=prefs.getBoolean("dashboardEnabled",false);surnameFirstDisplay=prefs.getBoolean("surnameFirstDisplay",true);val savedDays=prefs.getString("calendarVisibleDays",null);calendarVisibleDays=if(!savedDays.isNullOrBlank()){val parts=savedDays.split(",");if(parts.size==7)BooleanArray(7){i->parts[i]=="1"}else booleanArrayOf(true,true,true,true,true,false,false)}else booleanArrayOf(true,true,true,true,true,false,false);appointmentTypes.clear();prefs.getString("appointmentTypes",null)?.let{runCatching{val a=JSONArray(it);for(i in 0 until a.length()){val t=a.getJSONObject(i);appointmentTypes.add(AppointmentType(t.optString("id","TYPE${i+1}"),t.optString("name",if(i==0)"ALLENAMENTO" else if(i==1)"MEZZ'ORA" else "Tipo ${i+1}"),t.optInt("color",if(i==0)Color.rgb(45,135,210) else Color.rgb(215,55,55)),t.optInt("duration",if(i==1)30 else 45)))}}};if(appointmentTypes.isEmpty()){appointmentTypes.add(AppointmentType("TYPE1","ALLENAMENTO",Color.rgb(45,135,210),45));appointmentTypes.add(AppointmentType("TYPE2","MEZZ'ORA",Color.rgb(215,55,55),30))};activeRoutineIndex=prefs.getInt("activeRoutineIndex",0);prefs.getString("calendarRoutines",null)?.let{runCatching{val a=JSONArray(it);calendarRoutines.clear();for(i in 0 until a.length()){val r=a.getJSONObject(i);val limits=mutableListOf<Int>();r.optJSONArray("maxByType")?.let{ja->for(j in 0 until ja.length())limits.add(ja.optInt(j,3))};if(limits.isEmpty()){limits.add(2);limits.add(3)};while(limits.size<appointmentTypes.size)limits.add(r.optInt("maxTotal",3));calendarRoutines.add(CalendarRoutine(r.optString("name","Routine ${i+1}"),r.optInt("maxTotal",3),limits))}}};if(calendarRoutines.isEmpty())calendarRoutines.add(CalendarRoutine("Personalizzata",3,MutableList(appointmentTypes.size){if(it==0)2 else 3}));ensureAppointmentTypes();calendarRoutines.forEach{while(it.maxByType.size<appointmentTypes.size)it.maxByType.add(it.maxTotal)};activeRoutineIndex=activeRoutineIndex.coerceIn(0,calendarRoutines.lastIndex)
    }

    private fun ratesFor(p:Pack):List<Int>{
        val c=p.customRates
        if(c!=null&&c.size>=3&&c.all{it>0}&&c.sum()==p.total)return c.toList()
        val r1=p.total/3;return listOf(r1,r1,p.total-r1*2)
    }

    private fun saveRates(p:Pack,rates:List<Int>){p.customRates=rates.toMutableList()}

    private fun registerPayment(p:Pack,index:Int,paidNow:Int){
        try{
            val rates=ratesFor(p)
            val due=rates[index]
            require(paidNow>0)
            require(p.paid+paidNow<=p.total)

            val paidBeforeCurrent=rates.take(index).sum()
            val alreadyPaidOnCurrent=(p.paid-paidBeforeCurrent).coerceAtLeast(0)
            val totalPaidOnCurrent=alreadyPaidOnCurrent+paidNow
            val newRates=rates.toMutableList()

            p.paid+=paidNow

            // Se il cliente paga più della rata prevista, la rata corrente
            // diventa pari a quanto effettivamente versato e il residuo viene
            // redistribuito sulle rate successive.
            if(totalPaidOnCurrent>due){
                newRates[index]=totalPaidOnCurrent
                val remainingCount=newRates.size-index-1
                if(remainingCount>0){
                    val remaining=p.total-rates.take(index).sum()-totalPaidOnCurrent
                    require(remaining>=0)
                    val base=remaining/remainingCount
                    val extra=remaining%remainingCount
                    for(j in index+1 until newRates.size){
                        newRates[j]=base+if(j-index-1<extra)1 else 0
                    }
                } else require(totalPaidOnCurrent==p.total-rates.take(index).sum())
            }

            require(newRates.sum()==p.total)
            saveRates(p,newRates)
            expandedClients.add(identityKey(p.name))
            saveData()
            // Aggiorna immediatamente anche la scheda Gestione pacchetto già aperta.
            // Prima veniva aggiornata solo dopo averla chiusa e riaperta.
            activePackageDialog?.dismiss()
            activePackageDialog = null
            render()
            packageInfoDialog(p)
            val residual=p.total-p.paid
            if(index==rates.lastIndex && residual>0 && totalPaidOnCurrent<due){
                Toast.makeText(this,"Pagamento registrato. Rimangono €$residual da pagare.",Toast.LENGTH_LONG).show()
                proposeResidualRate(p,index,residual)
            } else if(totalPaidOnCurrent>due) Toast.makeText(this,"Pagamento registrato: rate successive ricalcolate automaticamente.",Toast.LENGTH_LONG).show()
            else Toast.makeText(this,"Pagamento di €$paidNow registrato.",Toast.LENGTH_SHORT).show()
        }catch(_:Exception){
            Toast.makeText(this,"Importo non valido o superiore al totale residuo.",Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmPaymentDialog(p:Pack,index:Int,amount:Int){
        val rates=ratesFor(p)
        val root=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(20),dp(16),dp(20),dp(16))
            background=roundedSurface(Color.WHITE,28)
        }
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        top.addView(Space(this),LinearLayout.LayoutParams(0,dp(36),1f))
        top.addView(TextView(this).apply{
            text="×";textSize=28f;gravity=Gravity.CENTER;setTextColor(Color.rgb(70,82,105))
            background=roundedSurface(Color.rgb(246,248,252),18)
        },LinearLayout.LayoutParams(dp(36),dp(36)))
        root.addView(top)
        val icon=TextView(this).apply{
            text="✓";textSize=24f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER
            setTextColor(Color.rgb(0,125,110));background=roundedSurface(Color.rgb(221,248,239),32)
        }
        root.addView(icon,LinearLayout.LayoutParams(dp(64),dp(64)).apply{gravity=Gravity.CENTER;setMargins(0,dp(2),0,dp(12))})
        root.addView(TextView(this).apply{
            text="Conferma pagamento";textSize=21f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER
            setTextColor(Color.rgb(25,32,45))
        },LinearLayout.LayoutParams(-1,-2))
        root.addView(TextView(this).apply{
            text="Confermi il pagamento della rata ${index+1}?";textSize=15.5f;gravity=Gravity.CENTER
            setTextColor(Color.rgb(70,82,105));setPadding(dp(8),dp(7),dp(8),dp(14))
        },LinearLayout.LayoutParams(-1,-2))
        val info=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(12))
            background=roundedSurface(Color.rgb(232,249,242),18,Color.rgb(203,236,222),1)
        }
        val money=TextView(this).apply{text="€";textSize=22f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(0,125,110));background=roundedSurface(Color.rgb(208,244,229),22)}
        info.addView(money,LinearLayout.LayoutParams(dp(50),dp(50)))
        val details=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
        details.addView(TextView(this).apply{text="Importo rata";textSize=12.5f;setTextColor(Color.rgb(55,90,80))})
        details.addView(TextView(this).apply{text="€$amount";textSize=22f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(0,125,110));setPadding(0,dp(2),0,dp(3))})
        details.addView(TextView(this).apply{text="Rata ${index+1} di ${rates.size}  •  ${dueDates(p)[index]}";textSize=12.5f;setTextColor(Color.rgb(65,92,85))})
        info.addView(details,LinearLayout.LayoutParams(0,-2,1f))
        root.addView(info,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(16))})
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val cancel=Button(this).apply{text="Annulla";setAllCaps(false);textSize=14f;setTextColor(Color.rgb(35,65,110));background=roundedSurface(Color.rgb(244,247,252),18,Color.rgb(203,218,239),1);minHeight=0;minimumHeight=0;minWidth=0;minimumWidth=0;stateListAnimator=null}
        val confirm=Button(this).apply{text="✓  Conferma";setAllCaps(false);textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.WHITE);background=roundedSurface(Color.rgb(0,145,125),18);minHeight=0;minimumHeight=0;minWidth=0;minimumWidth=0;stateListAnimator=null}
        actions.addView(cancel,LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(0,0,dp(6),0)})
        actions.addView(confirm,LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(dp(6),0,0,0)})
        root.addView(actions)
        val dialog=AlertDialog.Builder(this).setView(root).create()
        dialog.setOnShowListener{
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.TRANSPARENT,28));dialog.window?.setDimAmount(0.42f)
            dialog.window?.let{w->w.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT)}
        }
        top.getChildAt(1).setOnClickListener{dialog.dismiss()};cancel.setOnClickListener{dialog.dismiss()};confirm.setOnClickListener{dialog.dismiss();registerPayment(p,index,amount)}
        dialog.show()
    }

    private fun proposeResidualRate(p:Pack,index:Int,residual:Int){
        if(residual<=0 || index!=ratesFor(p).lastIndex)return
        val dialog=AlertDialog.Builder(this)
            .setTitle("Importo residuo")
            .setMessage("La terza rata è stata pagata solo in parte.\n\nRestano €$residual da pagare per completare il pacchetto da €${p.total}.\n\nVuoi creare una 4ª rata di €$residual con scadenza tra 28 giorni?")
            .setNegativeButton("NON ORA",null)
            .setPositiveButton("CREA 4ª RATA"){_,_->
                val current=ratesFor(p).toMutableList()
                val paidOnLast=(p.paid-current.dropLast(1).sum()).coerceAtLeast(0)
                if(paidOnLast>0 && paidOnLast<current.last()){
                    current[current.lastIndex]=paidOnLast
                    current.add(residual)
                    saveRates(p,current)
                    saveData()
                    activePackageDialog?.dismiss();activePackageDialog=null
                    render();packageInfoDialog(p)
                    Toast.makeText(this,"4ª rata creata: €$residual.",Toast.LENGTH_SHORT).show()
                }
            }
            .create()
        styleOneUiDialog(dialog);dialog.show()
    }

    private fun addRateDialog(p:Pack){
        val rates=ratesFor(p)
        val lastIndex=rates.lastIndex
        val paidBeforeLast=rates.dropLast(1).sum()
        val paidOnLast=(p.paid-paidBeforeLast).coerceAtLeast(0)
        val residual=(p.total-p.paid).coerceAtLeast(0)
        if(rates.size>=12){Toast.makeText(this,"Numero massimo di rate raggiunto.",Toast.LENGTH_SHORT).show();return}
        if(residual<=0){Toast.makeText(this,"Il pacchetto è già completamente pagato.",Toast.LENGTH_SHORT).show();return}
        if(lastIndex<0 || paidOnLast<=0 || paidOnLast>=rates[lastIndex]){
            Toast.makeText(this,"La 4ª rata viene proposta automaticamente quando l'ultima rata viene pagata solo in parte.",Toast.LENGTH_LONG).show()
            return
        }
        val dialog=AlertDialog.Builder(this)
            .setTitle("Aggiungi 4ª rata")
            .setMessage("Restano €$residual da pagare. Vuoi trasformare il residuo in una 4ª rata con scadenza tra 28 giorni?")
            .setNegativeButton("ANNULLA",null)
            .setPositiveButton("CREA 4ª RATA"){_,_->
                val newRates=rates.toMutableList()
                newRates[lastIndex]=paidOnLast
                newRates.add(residual)
                saveRates(p,newRates)
                saveData()
                activePackageDialog?.dismiss();activePackageDialog=null
                render();packageInfoDialog(p)
                Toast.makeText(this,"4ª rata creata: €$residual.",Toast.LENGTH_SHORT).show()
            }
            .create()
        styleOneUiDialog(dialog);dialog.show()
    }

    private fun paymentAmountDialog(p:Pack,index:Int){
        val rates=ratesFor(p)
        val due=rates[index]
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(8),dp(16),0)}
        box.addView(TextView(this).apply{this.text="Rata ${index+1} • prevista €$due";textSize=15f;setTextColor(Color.DKGRAY);setPadding(0,0,0,dp(8))})
        val amount=modernEditText().apply{hint="Importo effettivamente pagato (€)";inputType=2;setSingleLine(true);setText(due.toString());selectAll()}
        box.addView(amount)
        AlertDialog.Builder(this)
            .setTitle("Modifica importo pagamento")
            .setView(box)
            .setNegativeButton("ANNULLA",null)
            .setPositiveButton("CONFERMA PAGAMENTO"){_,_->
                val value=amount.text.toString().trim().toIntOrNull()
                if(value==null||value<=0||p.paid+value>p.total){
                    Toast.makeText(this,"Importo non valido o superiore al totale residuo.",Toast.LENGTH_LONG).show()
                }else{
                    registerPayment(p,index,value)
                }
            }.create().also{styleOneUiDialog(it);it.show()}
    }

    private fun paymentOptionsDialog(p:Pack,index:Int){
        val rates=ratesFor(p)
        val root=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(16),dp(20),dp(16));background=roundedSurface(Color.WHITE,28)
        }
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        top.addView(Space(this),LinearLayout.LayoutParams(0,dp(36),1f))
        top.addView(TextView(this).apply{text="×";textSize=28f;gravity=Gravity.CENTER;setTextColor(Color.rgb(70,82,105));background=roundedSurface(Color.rgb(246,248,252),18)},LinearLayout.LayoutParams(dp(36),dp(36)))
        root.addView(top)
        val icon=TextView(this).apply{text="✎";textSize=24f;gravity=Gravity.CENTER;setTextColor(Color.rgb(20,91,165));background=roundedSurface(Color.rgb(222,237,255),32)}
        root.addView(icon,LinearLayout.LayoutParams(dp(64),dp(64)).apply{gravity=Gravity.CENTER;setMargins(0,dp(2),0,dp(12))})
        root.addView(TextView(this).apply{text="Opzioni pagamento";textSize=21f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(25,32,45))},LinearLayout.LayoutParams(-1,-2))
        root.addView(TextView(this).apply{text="Rata ${index+1} di ${rates.size} • €${rates[index]}";textSize=15.5f;gravity=Gravity.CENTER;setTextColor(Color.rgb(70,82,105));setPadding(dp(8),dp(7),dp(8),dp(14))},LinearLayout.LayoutParams(-1,-2))
        val editRow=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(10),dp(10),dp(10));background=roundedSurface(Color.rgb(235,244,255),18,Color.rgb(205,224,248),1)
        }
        editRow.addView(TextView(this).apply{text="✎";textSize=21f;gravity=Gravity.CENTER;setTextColor(Color.rgb(20,91,165));background=roundedSurface(Color.rgb(216,234,255),20)},LinearLayout.LayoutParams(dp(46),dp(46)))
        val et=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,dp(6),0)}
        et.addView(TextView(this).apply{text="Modifica importo da pagare";textSize=15f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,70,125))})
        et.addView(TextView(this).apply{text="Puoi modificare l'importo di questa rata.";textSize=12.5f;setTextColor(Color.rgb(70,100,130));setPadding(0,dp(3),0,0)})
        editRow.addView(et,LinearLayout.LayoutParams(0,-2,1f))
        editRow.addView(TextView(this).apply{text="›";textSize=28f;gravity=Gravity.CENTER;setTextColor(Color.rgb(20,91,165))},LinearLayout.LayoutParams(dp(28),dp(50)))
        root.addView(editRow,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})
        val cancel=Button(this).apply{text="Annulla";setAllCaps(false);textSize=14f;setTextColor(Color.rgb(20,91,165));background=roundedSurface(Color.rgb(248,249,251),18,Color.rgb(205,220,238),1);minHeight=0;minimumHeight=0;stateListAnimator=null}
        root.addView(cancel,LinearLayout.LayoutParams(-1,dp(50)))
        val dialog=AlertDialog.Builder(this).setView(root).create()
        dialog.setOnShowListener{dialog.window?.setBackgroundDrawable(roundedSurface(Color.TRANSPARENT,28));dialog.window?.setDimAmount(0.42f);dialog.window?.let{w->w.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT)}}
        top.getChildAt(1).setOnClickListener{dialog.dismiss()};cancel.setOnClickListener{dialog.dismiss()};editRow.setOnClickListener{dialog.dismiss();paymentAmountDialog(p,index)}
        dialog.show()
    }

    private fun editRateDialog(p:Pack,index:Int){
        val rates=ratesFor(p);val firstUnpaid=p.paidRateIndex(rates);if(index<firstUnpaid){Toast.makeText(this,"Questa rata è già pagata.",Toast.LENGTH_SHORT).show();return}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(8),dp(16),0)}
        val amount=modernEditText().apply{hint="Nuovo importo rata";inputType=2;setSingleLine(true);setText(rates[index].toString())};box.addView(amount)
        val laterCount=rates.size-index-1
        AlertDialog.Builder(this).setTitle("Modifica rata ${index+1}").setMessage(if(laterCount>0)"Modifica questa rata: le rate successive verranno ricalcolate automaticamente per mantenere invariato il totale di €${p.total}." else "Essendo l'ultima rata, l'importo viene calcolato sul residuo del pacchetto.").setView(box).setNegativeButton("Annulla",null).setPositiveButton("SALVA"){_,_->
            try{
                val newAmount=amount.text.toString().trim().toInt();require(newAmount>0)
                val paidBefore=rates.take(index).sum();val alreadyOnRate=p.paid-paidBefore;require(newAmount>=alreadyOnRate)
                val remainingAfter=p.total-paidBefore-newAmount;require(remainingAfter>=0)
                val newRates=rates.toMutableList();newRates[index]=newAmount
                if(laterCount>0){val base=remainingAfter/laterCount;val extra=remainingAfter%laterCount;for(j in index+1 until newRates.size)newRates[j]=base+if(j-index-1<extra)1 else 0}else require(remainingAfter==0)
                require(newRates.sum()==p.total);saveRates(p,newRates);saveData();render()
            }catch(_:Exception){Toast.makeText(this,"Importo non valido: controlla il residuo del pacchetto.",Toast.LENGTH_LONG).show()}
        }.create().also{styleOneUiDialog(it);it.show()}
    }
    private fun dueDates(p:Pack):List<LocalDate>{val count=ratesFor(p).size;val out=mutableListOf<LocalDate>();var d=p.start;repeat(count){out.add(d);d=advance(d,28)};return out}
    private fun advance(d0:LocalDate,days:Int):LocalDate{var d=d0.plusDays(days.toLong());val fs=ferieStart;val fe=ferieEnd;if(fs!=null&&fe!=null&&!fe.isBefore(fs)&&!d.isBefore(fs)&&!d.isAfter(fe))d=fe.plusDays(1);return d}
    private fun closureText():String{val fs=ferieStart;val fe=ferieEnd;return if(fs!=null&&fe!=null)"🏖 Chiusura ferie: ${fs.format(fmt)} → ${fe.format(fmt)}" else "Nessuna chiusura ferie impostata"}

    private fun displaySurnameFirst(name:String):String{
        val clean=name.trim()
        if(!surnameFirstDisplay)return clean.split(Regex("\\s+")).filter{it.isNotBlank()}.let{parts->if(parts.size<=1)clean else parts.drop(1).joinToString(" ")+" "+parts.first()}
        return clean
    }


    private fun render(){
        list.removeAllViews()
        val query=if(::searchInput.isInitialized)searchInput.text.toString().trim().lowercase() else ""
        if(query.isNotEmpty()){
            renderSearchResults(query)
            return
        }
        val filtered=packs.filter{it.active}.sortedWith(compareBy<Pack>{statusRank(statusFor(it,ratesFor(it),dueDates(it)))}.thenBy{it.start}.thenBy{it.name.lowercase()})
        val filteredSessions=sessionPacks.filter{it.active&&(query.isEmpty()||it.name.lowercase().contains(query))}.sortedWith(compareBy<SessionPack>{statusRank(sessionStatus(it))}.thenBy{it.start}.thenBy{it.name.lowercase()})
        if(dashboardEnabled){renderDashboard(filtered,filteredSessions)}else{
            if(filtered.isEmpty()&&filteredSessions.isEmpty()){
                list.addView(TextView(this).apply{text=if(packs.isEmpty()&&sessionPacks.isEmpty())"Nessun pacchetto inserito." else "Nessun cliente trovato.";textSize=18f;setTextColor(Color.DKGRAY);setPadding(0,dp(12),0,dp(12))})
                return
            }
            val unified=mutableListOf<Pair<Int,Any>>()
            filtered.forEach{unified.add(statusRank(statusFor(it,ratesFor(it),dueDates(it))) to it)}
            filteredSessions.forEach{unified.add(statusRank(sessionStatus(it)) to it)}
            unified.sortedWith(compareBy<Pair<Int,Any>>{it.first}.thenBy{item->when(val value=item.second){is Pack->value.start;is SessionPack->value.start;else->LocalDate.MAX}}).forEach{item->when(val value=item.second){is Pack->card(value);is SessionPack->sessionCard(value)}}
        }
    }

    private fun renderSearchResults(query:String){
        val target=if(::searchList.isInitialized)searchList else list
        target.removeAllViews()
        val matchingNames=(packs.filter{it.name.lowercase().contains(query)}.map{it.name}+sessionPacks.filter{it.name.lowercase().contains(query)}.map{it.name}+appointments.filter{it.name.lowercase().contains(query)}.map{it.name}).distinctBy{identityKey(it)}.sortedBy{it.lowercase()}
        val matchingAppointments=appointments.filter{it.name.lowercase().contains(query)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        if(matchingNames.isEmpty()&&matchingAppointments.isEmpty()){
            target.addView(TextView(this).apply{text="Nessun risultato";textSize=17f;setTextColor(Color.DKGRAY);setPadding(dp(8),dp(16),dp(8),dp(16))})
            return
        }
        if(matchingNames.isNotEmpty()){
            target.addView(TextView(this).apply{text="CLIENTI";textSize=12f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(100,104,110));setPadding(dp(6),dp(4),dp(6),dp(6))})
            matchingNames.forEach{name->
                val key=identityKey(name)
                val regular=packs.firstOrNull{it.active&&identityKey(it.name)==key}
                val session=sessionPacks.firstOrNull{it.active&&identityKey(it.name)==key}
                val statusColor=when{regular!=null->statusFor(regular,ratesFor(regular),dueDates(regular)).color;session!=null->sessionStatus(session).color;else->Color.GRAY}
                val future=appointments.filter{identityKey(it.name)==key&&it.date.isAfter(LocalDate.now())}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
                val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;background=roundedSurface(Color.WHITE,18,Color.rgb(228,231,235),1);setPadding(dp(14),dp(10),dp(10),dp(10))}
                val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                top.addView(TextView(this).apply{text=displaySurnameFirst(name);textSize=17f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(24,27,31));gravity=Gravity.CENTER_VERTICAL;maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END},LinearLayout.LayoutParams(0,dp(44),1f))
                top.addView(TextView(this).apply{text=if(future.isNotEmpty())"${future.size} appuntamenti" else "Nessun futuro";textSize=12.5f;setTextColor(Color.rgb(90,94,100));gravity=Gravity.CENTER},LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,dp(44)))
                top.addView(TextView(this).apply{text="●";textSize=18f;setTextColor(statusColor);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(28),dp(44)))
                row.addView(top)
                val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(6),0,0)}
                val program=Button(this).apply{text="📋 Programmazione";setAllCaps(false);textSize=12.5f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(Color.rgb(20,95,150));background=roundedSurface(Color.rgb(240,247,253),15,Color.rgb(190,220,248),1);setOnClickListener{copyProgrammingToClipboard(name)}}
                actions.addView(program,LinearLayout.LayoutParams(0,dp(42),1f).apply{setMargins(0,0,dp(5),0)})
                val packageButton=Button(this).apply{text="📦 Pacchetto";setAllCaps(false);textSize=12.5f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(Color.rgb(65,70,185));background=roundedSurface(Color.rgb(246,246,255),15,Color.rgb(214,214,246),1);setOnClickListener{openPackageFromSearch(name)}}
                actions.addView(packageButton,LinearLayout.LayoutParams(0,dp(42),0.82f).apply{setMargins(0,0,dp(5),0)})
                val open=Button(this).apply{text="Apri";setAllCaps(false);textSize=12.5f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(Color.rgb(0,125,110));background=roundedSurface(Color.rgb(244,249,248),15,Color.rgb(190,225,216),1);setOnClickListener{showSearchClientAppointments(name)}}
                actions.addView(open,LinearLayout.LayoutParams(dp(72),dp(42)))
                row.addView(actions)
                row.setOnClickListener{showSearchClientAppointments(name)}
                target.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})
            }
        }
        if(matchingAppointments.isNotEmpty()){
            target.addView(TextView(this).apply{text="APPUNTAMENTI";textSize=12f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(100,104,110));setPadding(dp(6),dp(10),dp(6),dp(6))})
            matchingAppointments.forEach{a->
                val accent=typeColor(a.type)
                val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;background=roundedSurface(Color.WHITE,16,Color.rgb(228,231,235),1);setPadding(dp(12),dp(8),dp(12),dp(8))}
                row.addView(TextView(this).apply{text=displaySurnameFirst(a.name);textSize=15f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(30,32,36));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,dp(52),1f))
                row.addView(TextView(this).apply{text="${a.date.format(fmt)}\n${a.time} • ${typeLabel(a.type)}";textSize=11.5f;setTextColor(accent);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(118),dp(52)))
                row.setOnClickListener{appointmentActions(a)}
                target.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(6))})
            }
        }
    }

    private fun openPackageFromSearch(name:String){
        val key=identityKey(name)
        val regular=packs.firstOrNull{it.active&&identityKey(it.name)==key}
        val session=sessionPacks.firstOrNull{it.active&&identityKey(it.name)==key}
        when{
            regular!=null&&session==null -> packageInfoDialog(regular)
            session!=null&&regular==null -> sessionInfoDialog(session)
            regular!=null&&session!=null -> {
                val choices=arrayOf("📦 ${regular.packageType} • 12 settimane","🎯 Pacchetto sedute • ${session.totalSessions} sedute")
                AlertDialog.Builder(this).setTitle(displaySurnameFirst(name)).setItems(choices){_,which->
                    if(which==0) packageInfoDialog(regular) else sessionInfoDialog(session)
                }.setNegativeButton("ANNULLA",null).create().also{styleOneUiDialog(it);it.show()}
            }
            else -> Toast.makeText(this,"Nessun pacchetto attivo per ${displaySurnameFirst(name)}.",Toast.LENGTH_SHORT).show()
        }
    }

    private fun showSearchClientAppointments(name:String){
        val key=identityKey(name)
        val all=appointments.filter{identityKey(it.name)==key}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        val future=all.filter{it.date.isAfter(LocalDate.now())}
        if(future.isEmpty()){
            Toast.makeText(this,"Nessun appuntamento futuro per ${displaySurnameFirst(name)}.",Toast.LENGTH_SHORT).show()
            return
        }
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(4),dp(16),dp(6))}
        box.addView(TextView(this).apply{text="${future.size} appuntamenti futuri";textSize=13f;setTextColor(Color.rgb(100,104,110));setPadding(0,0,0,dp(8))})
        future.forEach{a->
            val accent=typeColor(a.type)
            box.addView(TextView(this).apply{text="${a.date.format(fmt)} • ${a.time} • ${typeLabel(a.type)}";textSize=14.5f;setTextColor(accent);setPadding(0,dp(5),0,dp(5))})
        }
        val dialog=AlertDialog.Builder(this).setTitle(displaySurnameFirst(name)).setView(box).setNegativeButton("CHIUDI",null).setPositiveButton("📋 COPIA PROGRAMMAZIONE"){_,_->copyProgrammingToClipboard(name)}.create()
        styleOneUiDialog(dialog);dialog.show()
    }

    private fun programmingAppointments(name:String, choice:Int):List<Appointment>{
        val today=LocalDate.now()
        val all=appointments.filter{identityKey(it.name)==identityKey(name)&&it.date.isAfter(today)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        return when(choice){
            0 -> all.take(10)
            1 -> all.take(30)
            2 -> {
                val pack=packs.filter{it.active&&identityKey(it.name)==identityKey(name)}.maxByOrNull{it.start}
                val session=sessionPacks.filter{it.active&&identityKey(it.name)==identityKey(name)}.maxByOrNull{it.start}
                when {
                    pack!=null -> all.filter{!it.date.isAfter(pack.start.plusWeeks(12).minusDays(1))&& !it.date.isBefore(pack.start)}
                    session!=null -> all.filter{it.sessionPackId==session.id}
                    else -> all
                }
            }
            else -> all
        }
    }

    private fun programmingText(name:String, choice:Int):String{
        val selected=programmingAppointments(name,choice)
        if(selected.isEmpty()) return "Nessun appuntamento futuro disponibile."
        val title=when(choice){0->"PROSSIMI 10 APPUNTAMENTI";1->"PROSSIMI 30 APPUNTAMENTI";2->"PROGRAMMAZIONE PACCHETTO";else->"PROGRAMMAZIONE ANNUALE"}
        return buildString{
            appendLine("📋 $title")
            appendLine("Cliente: ${displaySurnameFirst(name)}")
            appendLine()
            selected.forEachIndexed{index,a->
                val type=typeLabel(a.type)
                appendLine("${index+1}. ${a.date.format(fmt)} • ${a.time} • $type")
            }
        }
    }

    private fun programmingOptionsDialog(name:String){
        val options=arrayOf("Prossimi 10 appuntamenti","Prossimi 30 appuntamenti","Tutto il pacchetto","Tutta la programmazione annuale")
        val dialog=AlertDialog.Builder(this)
            .setTitle("📋 Copia programmazione")
            .setItems(options){_,which->
                val text=programmingText(name,which)
                if(text.startsWith("Nessun appuntamento")) Toast.makeText(this,text,Toast.LENGTH_SHORT).show()
                else copyProgrammingTextToClipboard(text,name)
            }
            .setNegativeButton("ANNULLA",null)
            .create()
        styleOneUiDialog(dialog);dialog.show()
    }

    private fun copyProgrammingTextToClipboard(text:String,name:String){
        val clipboard=getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Programmazione $name",text))
        val preview=TextView(this).apply{this.text=text;textSize=14f;setTextColor(Color.rgb(35,35,35));setPadding(dp(16),dp(8),dp(16),dp(8))}
        val dialog=AlertDialog.Builder(this).setTitle("📋 Programmazione pronta").setMessage("La programmazione è già stata copiata negli appunti. Puoi incollarla direttamente su WhatsApp.").setView(ScrollView(this).apply{addView(preview)}).setNegativeButton("CHIUDI",null).setPositiveButton("COPIA DI NUOVO"){_,_->clipboard.setPrimaryClip(ClipData.newPlainText("Programmazione $name",text));Toast.makeText(this,"Programmazione copiata.",Toast.LENGTH_SHORT).show()}.create()
        styleOneUiDialog(dialog);dialog.show()
    }

    private fun copyProgrammingToClipboard(name:String){ programmingOptionsDialog(name) }

    private fun renderDashboard(items:List<Pack>,sessionItems:List<SessionPack>){
        val today=LocalDate.now()
        val activeClients=(items.map{identityKey(it.name)}+sessionItems.map{identityKey(it.name)}).distinct().size
        val todayAppointments=appointments.count{it.date==today}
        val toCollect=packs.filter{it.active}.fold(0){acc,p -> acc + (p.total-p.paid).coerceAtLeast(0)}
        val stats=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(0,0,0,dp(10))}
        fun stat(value:String,label:String):View=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(6),dp(8),dp(6),dp(8));background=roundedSurface(Color.WHITE,16,Color.rgb(230,232,236),1)
            addView(TextView(this@MainActivity).apply{text=value;textSize=19f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(28,31,35));gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,dp(28)))
            addView(TextView(this@MainActivity).apply{text=label;textSize=10.5f;setTextColor(Color.rgb(105,108,114));gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,dp(22))) }
        stats.addView(stat(activeClients.toString(),"CLIENTI ATTIVI"),LinearLayout.LayoutParams(0,dp(58),1f).apply{setMargins(0,0,dp(4),0)})
        stats.addView(stat(todayAppointments.toString(),"SEDUTE OGGI"),LinearLayout.LayoutParams(0,dp(58),1f).apply{setMargins(dp(2),0,dp(2),0)})
        stats.addView(stat("€$toCollect","DA INCASSARE"),LinearLayout.LayoutParams(0,dp(58),1f).apply{setMargins(dp(4),0,0,0)})
        list.addView(stats)
        val groups=listOf(
            Triple("SCADUTI",Color.rgb(210,45,45),items.filter{statusFor(it,ratesFor(it),dueDates(it)).label=="SCADUTA"}),
            Triple("IN SCADENZA",Color.rgb(220,160,20),items.filter{statusFor(it,ratesFor(it),dueDates(it)).label=="IN SCADENZA"}),
            Triple("IN REGOLA",Color.rgb(35,150,70),items.filter{statusFor(it,ratesFor(it),dueDates(it)).label=="IN REGOLA"})
        )
        val sessionGroups=listOf(
            Triple("SCADUTI",Color.rgb(210,45,45),sessionItems.filter{sessionStatus(it).label=="SCADUTA"}),
            Triple("IN SCADENZA",Color.rgb(220,160,20),sessionItems.filter{sessionStatus(it).label=="IN SCADENZA"}),
            Triple("IN REGOLA",Color.rgb(35,150,70),sessionItems.filter{sessionStatus(it).label=="IN REGOLA"})
        )
        groups.indices.forEach{idx->
            val clients=groups[idx].third
            val sessions=sessionGroups[idx].third
            if(clients.isEmpty()&&sessions.isEmpty())return@forEach
            val label=groups[idx].first;val color=groups[idx].second
            val section=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;background=roundedSurface(Color.WHITE,18,Color.rgb(232,234,238),1)}
            val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;isClickable=true;isFocusable=true;setPadding(dp(12),dp(4),dp(12),dp(4))}
            header.addView(TextView(this).apply{text="●";textSize=18f;setTextColor(color);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(28),dp(48)))
            val totalCount=clients.size+sessions.size
            header.addView(TextView(this).apply{text="$label ($totalCount)";textSize=17f;setTextColor(Color.rgb(35,35,35));gravity=Gravity.CENTER_VERTICAL;setPadding(dp(8),0,0,0)},LinearLayout.LayoutParams(0,dp(48),1f))
            val arrow=TextView(this).apply{text="▾";textSize=20f;setTextColor(Color.DKGRAY);gravity=Gravity.CENTER}
            header.addView(arrow,LinearLayout.LayoutParams(dp(36),dp(48)));section.addView(header)
            val sectionHasExpandedClient = clients.any{expandedClients.contains(identityKey(it.name))} || sessions.any{expandedClients.contains(identityKey(it.name))}
            val clientsBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=if(sectionHasExpandedClient)View.VISIBLE else View.GONE;setPadding(dp(8),0,dp(8),dp(4))}
            clients.forEach{card(it,clientsBox)};sessions.forEach{sessionCard(it,clientsBox)}
            section.addView(clientsBox)
            arrow.text=if(sectionHasExpandedClient)"▴" else "▾"
            header.setOnClickListener{val open=clientsBox.visibility!=View.VISIBLE;clientsBox.visibility=if(open)View.VISIBLE else View.GONE;arrow.text=if(open)"▴" else "▾"}
            list.addView(section,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})
        }
    }

    private fun card(p:Pack,parent:ViewGroup=list){
        val rates=ratesFor(p);val dates=dueDates(p);val status=statusFor(p,rates,dates)
        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(4),dp(10),dp(4));background=roundedSurface(Color.WHITE,18,Color.rgb(231,233,237),1)}
        val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;isClickable=true;isFocusable=true;setPadding(dp(2),0,0,0)}
        val nameView=TextView(this).apply{text=displaySurnameFirst(p.name);textSize=17.5f;setTextColor(Color.rgb(20,20,20));gravity=Gravity.CENTER_VERTICAL;maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END}
        header.addView(nameView,LinearLayout.LayoutParams(0,dp(48),1f))
        val menu=menuIconButtonStyle().apply{setOnClickListener{packageInfoDialog(p)}}
        header.addView(menu,LinearLayout.LayoutParams(dp(38),dp(40)).apply{setMargins(dp(6),0,dp(6),0)})
        header.addView(TextView(this).apply{text="●";textSize=18f;setTextColor(status.color);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(26),dp(44)))
        card.addView(header)

        val isExpanded=expandedClients.contains(identityKey(p.name))
        val details=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=if(isExpanded)View.VISIBLE else View.GONE;setPadding(dp(2),dp(4),dp(2),dp(2))}
        details.addView(TextView(this).apply{text="${p.packageType} • ${p.sessionTotal} sedute • Partenza: ${p.start.format(fmt)}    Totale: €${p.total}";textSize=14f;setTextColor(Color.DKGRAY);setPadding(0,dp(2),0,dp(8))})
        for(i in rates.indices){
            val isPaid=p.paid>=rates.take(i+1).sum();val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
            val suffix = if(isPaid) " ✓ pagata" else if(i==p.paidRateIndex(rates)) " • parziale €${p.paid-rates.take(i).sum()}" else ""
            row.addView(TextView(this).apply{this.text="Rata ${i+1}: €${rates[i]} • ${dates[i].format(fmt)}$suffix";textSize=15f;setTextColor(Color.rgb(30,30,30));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,dp(48),1f))
            if(!isPaid){
                if(i==p.paidRateIndex(rates)) row.addView(paymentButtonStyle().apply{setOnClickListener{
                    val alreadyPaidOnCurrent=(p.paid-rates.take(i).sum()).coerceAtLeast(0)
                    val remainingToPay=(rates[i]-alreadyPaidOnCurrent).coerceAtLeast(0)
                    if(remainingToPay>0) confirmPaymentDialog(p,i,remainingToPay)
                }},LinearLayout.LayoutParams(dp(72),dp(40)))
                row.addView(editIconButtonStyle().apply{setOnClickListener{paymentOptionsDialog(p,i)}},LinearLayout.LayoutParams(dp(44),dp(40)))
            }
            details.addView(row)
        }
        card.addView(details)
        header.setOnClickListener{val open=details.visibility!=View.VISIBLE;details.visibility=if(open)View.VISIBLE else View.GONE;if(open)expandedClients.add(identityKey(p.name)) else expandedClients.remove(identityKey(p.name))}
        parent.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})
    }

    private fun programmingDetailDialog(s:SessionPack){
        val now=LocalDateTime.now()
        val done=sessionsForSessionPack(s,LocalDate.now())
        val doneCount=done.size
        val future=appointments.filter{it.sessionPackId==s.id && it.date.isAfter(LocalDate.now())}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        val futureCount=future.size
        val remaining=(s.totalSessions-sessionBooked(s)).coerceAtLeast(0)
        val text=summaryForSessionPack(s)
        showProgrammingDetail(
            title="Programmazione",
            name=s.name,
            subtitle="Pacchetto a sedute • ${s.totalSessions} sedute",
            stats=listOf("$doneCount" to "EFFETTUATE","$remaining" to "RIMASTE","$futureCount" to "PRENOTATE"),
            sections=buildList{
                add("Sedute effettuate" to done.map{"${it.date.format(fmt)}  •  ${it.time}  •  ${typeLabel(it.type)}"})
                add("Prossimi appuntamenti" to future.map{"${it.date.format(fmt)}  •  ${it.time}  •  ${typeLabel(it.type)}"})
            },
            shareText=text
        )
    }

    private fun programmingDetailDialog(p:Pack){
        val today=LocalDate.now()
        val end=p.start.plusWeeks(12).minusDays(1)
        val done=sessionsForPack(p,today)
        val future=appointments.filter{identityKey(it.name)==identityKey(p.name)&&it.date.isAfter(today)&&!it.date.isAfter(end)&&!it.date.isBefore(p.start)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        val scheduled=appointments.count{identityKey(it.name)==identityKey(p.name)&&!it.date.isBefore(p.start)&&!it.date.isAfter(end)}
        val remaining=(p.sessionTotal-scheduled).coerceAtLeast(0)
        val recoveries=recoveriesForPack(p)
        val usedRecoveries=appointments.filter{it.recovery&&identityKey(it.name)==identityKey(p.name)&&!it.date.isBefore(p.start)&&!it.date.isAfter(end)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        val text=summaryForPack(p)
        showProgrammingDetail(
            title="Programmazione",
            name=p.name,
            subtitle="${p.packageType} • ${p.sessionTotal} sedute • 12 settimane",
            stats=listOf("${done.size}" to "EFFETTUATE","$remaining" to "RIMASTE","$recoveries" to "RECUPERI"),
            sections=buildList{
                add("Sedute effettuate" to done.map{"${it.date.format(fmt)}  •  ${it.time}  •  ${typeLabel(it.type)}"})
                add("Recuperi" to if(usedRecoveries.isEmpty()) listOf("$recoveries recuperi disponibili") else usedRecoveries.map{"${it.date.format(fmt)}  •  ${it.time}  •  RECUPERO • ${typeLabel(it.type)}"} + if(recoveries>0) listOf("$recoveries recuperi disponibili") else emptyList())
                add("Prossimi appuntamenti" to future.map{"${it.date.format(fmt)}  •  ${it.time}  •  ${typeLabel(it.type)}"})
            },
            shareText=text
        )
    }

    private fun showProgrammingDetail(title:String,name:String,subtitle:String,stats:List<Pair<String,String>>,sections:List<Pair<String,List<String>>>,shareText:String){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),0,dp(14),dp(10))}
        val scroll=ScrollView(this).apply{isFillViewport=true;addView(root)}
        val head=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(14),dp(12),dp(14),dp(10));background=roundedSurface(Color.rgb(247,249,252),20,Color.rgb(228,232,238),1)}
        val initials=displaySurnameFirst(name).split(" ").filter{it.isNotBlank()}.take(2).joinToString(""){it.first().uppercase()}
        head.addView(TextView(this).apply{text=initials;textSize=18f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(20,70,130));background=roundedSurface(Color.rgb(230,240,252),28)},LinearLayout.LayoutParams(dp(54),dp(54)))
        head.addView(TextView(this).apply{text=displaySurnameFirst(name);textSize=20f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(25,28,32));setPadding(0,dp(7),0,0)},LinearLayout.LayoutParams(-1,dp(34)))
        head.addView(TextView(this).apply{text=subtitle;textSize=13f;gravity=Gravity.CENTER;setTextColor(Color.rgb(85,90,98))},LinearLayout.LayoutParams(-1,dp(24)))
        root.addView(head,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(8),0,dp(10))})

        val statRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        stats.forEachIndexed{index,(value,label)->
            val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(3),dp(8),dp(3),dp(8));background=roundedSurface(Color.WHITE,16,Color.rgb(230,233,238),1)}
            card.addView(TextView(this).apply{text=value;textSize=17f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(25,30,38))},LinearLayout.LayoutParams(-1,dp(27)))
            card.addView(TextView(this).apply{text=label;textSize=9.5f;gravity=Gravity.CENTER;setTextColor(Color.rgb(85,90,98));maxLines=2},LinearLayout.LayoutParams(-1,dp(30)))
            statRow.addView(card,LinearLayout.LayoutParams(0,dp(74),1f).apply{setMargins(if(index==0)0 else dp(2),0,if(index==stats.lastIndex)0 else dp(2),0)})
        }
        root.addView(statRow)

        sections.forEach{(heading,items)->
            val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(10),dp(14),dp(10));background=roundedSurface(Color.WHITE,18,Color.rgb(230,233,238),1)}
            card.addView(TextView(this).apply{text=heading;textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32))},LinearLayout.LayoutParams(-1,dp(30)))
            if(items.isEmpty()) card.addView(TextView(this).apply{text="Nessuna informazione";textSize=13f;setTextColor(Color.rgb(100,104,110));setPadding(0,dp(3),0,dp(3))})
            else items.forEach{item->card.addView(TextView(this).apply{text=item;textSize=13f;setTextColor(Color.rgb(55,59,65));setPadding(0,dp(4),0,dp(4))})}
            root.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(8),0,0)})
        }
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(10),0,dp(2))}
        val copy=Button(this).apply{text="📋 Copia testo";setAllCaps(false);textSize=12f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(Color.rgb(15,95,180));background=roundedSurface(Color.rgb(238,246,255),16,Color.rgb(190,218,248),1);setOnClickListener{val cb=getSystemService(CLIPBOARD_SERVICE) as ClipboardManager;cb.setPrimaryClip(ClipData.newPlainText("Programmazione $name",shareText));Toast.makeText(this@MainActivity,"Testo copiato. Puoi incollarlo su WhatsApp.",Toast.LENGTH_SHORT).show()}}
        val wa=Button(this).apply{text="WhatsApp";setAllCaps(false);textSize=12f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(Color.WHITE);background=roundedSurface(Color.rgb(25,155,100),16,Color.rgb(25,155,100),1);setOnClickListener{val intent=Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,shareText)};try{intent.setPackage("com.whatsapp");startActivity(intent)}catch(_:Exception){startActivity(Intent.createChooser(intent,"Invia programmazione"))}}}
        actions.addView(copy,LinearLayout.LayoutParams(0,dp(46),1f).apply{setMargins(0,0,dp(4),0)})
        actions.addView(wa,LinearLayout.LayoutParams(0,dp(46),1f).apply{setMargins(dp(4),0,0,0)})
        root.addView(actions)
        val dialog=AlertDialog.Builder(this).setTitle(title).setView(scroll).setNegativeButton("CHIUDI",null).create()
        styleOneUiDialog(dialog);dialog.show()
    }

    private fun packageInfoDialog(p:Pack){
        val rates=ratesFor(p)
        val dates=dueDates(p)
        val status=statusFor(p,rates,dates)
        val expected=p.sessionTotal
        val done=sessionsForPack(p,LocalDate.now()).size
        val recoveries=recoveriesForPack(p)
        val scheduled=appointments.count {
            identityKey(it.name)==identityKey(p.name) &&
            !it.date.isBefore(p.start) && !it.date.isAfter(p.start.plusWeeks(12).minusDays(1))
        }
        val remaining=(expected-scheduled).coerceAtLeast(0)

        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),0,dp(14),dp(10))}
        val scroll=ScrollView(this).apply{isFillViewport=true;addView(root)}

        val client=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(10),dp(8),dp(10));background=roundedSurface(Color.rgb(247,249,252),20,Color.rgb(228,232,238),1)}
        val initials=displaySurnameFirst(p.name).split(" ").filter{it.isNotBlank()}.take(2).joinToString(""){it.first().uppercase()}
        client.addView(TextView(this).apply{text=initials;textSize=18f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(20,70,130));background=roundedSurface(Color.rgb(230,240,252),28);},LinearLayout.LayoutParams(dp(52),dp(52)))
        val clientText=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
        clientText.addView(TextView(this@MainActivity).apply{text=displaySurnameFirst(p.name);textSize=18f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32))})
        clientText.addView(TextView(this@MainActivity).apply{text="●  ${status.label}";textSize=13f;setTextColor(status.color);setPadding(0,dp(3),0,0)})
        client.addView(clientText,LinearLayout.LayoutParams(0,-2,1f))
        root.addView(client,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(8),0,dp(10))})

        val stats=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        fun stat(value:String,label:String):View=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(4),dp(7),dp(4),dp(7));background=roundedSurface(Color.WHITE,16,Color.rgb(230,233,238),1)
            addView(TextView(this@MainActivity).apply{text=value;textSize=17f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,30,38));gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,dp(27)))
            addView(TextView(this@MainActivity).apply{text=label;textSize=9.5f;setTextColor(Color.rgb(85,90,98));gravity=Gravity.CENTER;maxLines=2},LinearLayout.LayoutParams(-1,dp(30))) }
        stats.addView(stat("$expected","SEDUTE TOTALI"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(0,0,dp(4),0)})
        stats.addView(stat("$remaining","SEDUTE RIMASTE"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(dp(2),0,dp(2),0)})
        stats.addView(stat("$recoveries","RECUPERI"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(dp(2),0,dp(2),0)})
        stats.addView(stat("€${p.total}","TOTALE PACCHETTO"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(dp(4),0,0,0)})
        root.addView(stats)

        val info=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(8),dp(14),dp(8));background=roundedSurface(Color.WHITE,18,Color.rgb(230,233,238),1)}
        fun infoRow(label:String,value:String){val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(7),0,dp(7))};r.addView(TextView(this@MainActivity).apply{text=label;textSize=13f;setTextColor(Color.rgb(85,90,98))},LinearLayout.LayoutParams(0,dp(34),1f));r.addView(TextView(this@MainActivity).apply{text=value;textSize=13.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,40,48));gravity=Gravity.CENTER_VERTICAL});info.addView(r)}
        infoRow("Tipo pacchetto",p.packageType.replace("PERSONALIZZATO","Personalizzato"))
        infoRow("Data di inizio",p.start.format(fmt))
        infoRow("Importo totale","€${p.total}")
        infoRow("Pagato","€${p.paid}")
        infoRow("Stato","${status.label}")
        root.addView(info,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(10),0,dp(14))})

        val rateTitle=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        rateTitle.addView(TextView(this).apply{text="Rate di pagamento";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32))},LinearLayout.LayoutParams(0,dp(42),1f))
        rateTitle.addView(Button(this).apply{text="+ Aggiungi rata";setAllCaps(false);textSize=11.5f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(Color.rgb(15,95,180));background=roundedSurface(Color.rgb(235,244,255),16,Color.rgb(190,218,248),1);setOnClickListener{addRateDialog(p)}},LinearLayout.LayoutParams(dp(122),dp(38)))
        root.addView(rateTitle)
        for(i in rates.indices){
            val isPaid=p.paid>=rates.take(i+1).sum()
            val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),dp(5),dp(6),dp(5));background=roundedSurface(Color.WHITE,16,Color.rgb(230,233,238),1)}
            r.addView(TextView(this).apply{text="${i+1}";textSize=13f;gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);background=roundedSurface(Color.rgb(242,245,249),22);setTextColor(Color.rgb(40,45,52))},LinearLayout.LayoutParams(dp(34),dp(40)))
            r.addView(TextView(this).apply{this.text="€${rates[i]}\n${dates[i].format(fmt)}${if(isPaid)" • ✓ Pagata" else ""}";textSize=13.5f;setTextColor(Color.rgb(35,40,48));setPadding(dp(10),0,0,0)},LinearLayout.LayoutParams(0,dp(52),1f))
            if(!isPaid&&i==p.paidRateIndex(rates)) r.addView(paymentButtonStyle().apply{setOnClickListener{val already=(p.paid-rates.take(i).sum()).coerceAtLeast(0);val amount=(rates[i]-already).coerceAtLeast(0);if(amount>0) confirmPaymentDialog(p,i,amount)}},LinearLayout.LayoutParams(dp(68),dp(40)))
            r.addView(editIconButtonStyle().apply{setOnClickListener{paymentOptionsDialog(p,i)}},LinearLayout.LayoutParams(dp(40),dp(40)).apply{setMargins(dp(5),0,0,0)})
            root.addView(r,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(4),0,dp(4))})
        }

        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(12),0,dp(4))}
        fun actionButton(label:String,accent:Int,bg:Int,click:()->Unit)=Button(this).apply{text=label;setAllCaps(false);textSize=11.5f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(accent);background=roundedSurface(bg,16,Color.rgb(205,220,238),1);setOnClickListener{click()}}
        actions.addView(actionButton("✓ Segna tutto pagato",Color.rgb(15,95,180),Color.rgb(238,246,255)){
            val remainingToPay=(p.total-p.paid).coerceAtLeast(0)
            if(remainingToPay<=0){
                Toast.makeText(this@MainActivity,"Tutte le rate risultano già pagate.",Toast.LENGTH_SHORT).show()
                return@actionButton
            }
            val (paymentDialog,outer,body)=packActionDialogBase("Conferma pagamento","✓",Color.rgb(0,145,112),Color.rgb(205,244,233),Color.rgb(248,255,252))
            body.addView(dialogBodyText("Vuoi segnare come pagate tutte le rate del pacchetto?"))
            body.addView(dialogInfoCard("≋","Importo ancora da pagare","€$remainingToPay",Color.rgb(0,145,112),Color.rgb(224,248,241)),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,dp(10))})
            body.addView(LinearLayout(this@MainActivity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),dp(9),dp(10),dp(9));background=roundedSurface(Color.rgb(224,248,241),18)
                addView(TextView(this@MainActivity).apply{text="i";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(0,145,112));background=roundedSurface(Color.WHITE,24)},LinearLayout.LayoutParams(dp(34),dp(34)))
                addView(TextView(this@MainActivity).apply{text="Tutte le rate del pacchetto verranno segnate come pagate.";textSize=13.5f;setTextColor(Color.rgb(45,70,65));setPadding(dp(10),0,0,0)},LinearLayout.LayoutParams(0,dp(34),1f))
            },LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(14))})
            val row=LinearLayout(this@MainActivity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            row.addView(dialogButton("Annulla",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(210,220,232)){paymentDialog.dismiss()},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(4),0)})
            row.addView(dialogButton("Conferma",Color.WHITE,Color.rgb(0,145,112),Color.rgb(0,145,112)){
                p.paid=p.total;saveData();paymentDialog.dismiss();activePackageDialog?.dismiss();activePackageDialog=null;render();packageInfoDialog(p);Toast.makeText(this@MainActivity,"Tutte le rate sono state segnate come pagate.",Toast.LENGTH_SHORT).show()
            },LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(4),0,0,0)})
            body.addView(row)
            paymentDialog.show()
            paymentDialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
        },LinearLayout.LayoutParams(0,dp(46),1f).apply{setMargins(0,0,dp(4),0)})
        actions.addView(actionButton("✎ Modifica",Color.rgb(20,91,165),Color.rgb(238,246,255)){editPackDialog(p)},LinearLayout.LayoutParams(0,dp(46),0.7f).apply{setMargins(dp(2),0,dp(2),0)})
        actions.addView(actionButton("⏹ Termina",Color.rgb(120,80,25),Color.rgb(255,248,232)){terminatePackDialog(p)},LinearLayout.LayoutParams(0,dp(46),0.7f).apply{setMargins(dp(2),0,dp(2),0)})
        actions.addView(actionButton("🗑 Elimina",Color.rgb(200,45,45),Color.rgb(255,244,244)){confirmDeletePack(p)},LinearLayout.LayoutParams(0,dp(46),0.7f).apply{setMargins(dp(4),0,0,0)})
        root.addView(actions)
        root.addView(Button(this).apply{text="🗂 Storico cliente";setAllCaps(false);textSize=13f;setTextColor(Color.rgb(65,70,78));background=roundedSurface(Color.rgb(246,248,250),16,Color.rgb(228,231,235),1);stateListAnimator=null;setOnClickListener{showClientHistory(p.name)}},LinearLayout.LayoutParams(-1,dp(44)).apply{setMargins(0,dp(4),0,dp(2))})
        val programming=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(9),dp(10),dp(9));background=roundedSurface(Color.rgb(238,246,255),18,Color.rgb(190,218,248),1);isClickable=true;isFocusable=true}
        val programText=LinearLayout(this@MainActivity).apply{orientation=LinearLayout.VERTICAL}
        programText.addView(TextView(this@MainActivity).apply{text="Programmazione";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32))},LinearLayout.LayoutParams(-1,dp(29)))
        programText.addView(TextView(this@MainActivity).apply{text="${scheduled} appuntamenti prenotati • ${done} effettuati • ${remaining} sedute disponibili";textSize=13f;setTextColor(Color.rgb(85,90,98))},LinearLayout.LayoutParams(-1,dp(30)))
        programming.addView(programText,LinearLayout.LayoutParams(0,dp(60),1f))
        programming.addView(TextView(this).apply{text="›";textSize=24f;gravity=Gravity.CENTER;setTextColor(Color.rgb(15,95,180))},LinearLayout.LayoutParams(dp(30),dp(52)))
        programming.setOnClickListener{programmingDetailDialog(p)}
        root.addView(programming,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(8),0,dp(4))})

        activePackageDialog?.dismiss()
        val dialog=AlertDialog.Builder(this).setTitle("Gestione pacchetto").setView(scroll).setNegativeButton("CHIUDI",null).create()
        activePackageDialog=dialog
        styleOneUiDialog(dialog)
        dialog.setOnDismissListener{if(activePackageDialog===dialog) activePackageDialog=null}
        dialog.show()
    }

    private fun appointmentHasPassed(a:Appointment,now:LocalDateTime=LocalDateTime.now()):Boolean{
        val t=runCatching{LocalTime.parse(a.time,timeFmt)}.getOrNull()?:LocalTime.MIDNIGHT
        return LocalDateTime.of(a.date,t).isBefore(now)
    }

    private fun sessionAppointments(s:SessionPack):List<Appointment>{
        val key=identityKey(s.name)
        return appointments.filter{
            (it.sessionPackId==s.id || (it.sessionPackId==0L && identityKey(it.name)==key)) &&
            !it.date.isBefore(s.start)
        }.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
    }

    private fun sessionBooked(s:SessionPack):Int=sessionAppointments(s).size
    private fun sessionUsed(s:SessionPack,now:LocalDateTime=LocalDateTime.now()):Int=sessionAppointments(s).count{appointmentHasPassed(it,now)}
    private fun sessionStatus(s:SessionPack):PackStatus{
        val booked=sessionBooked(s)
        val remaining=(s.totalSessions-booked).coerceAtLeast(0)
        return when{
            remaining<=0->PackStatus("SCADUTA",Color.rgb(210,45,45))
            s.paid<s.cost->PackStatus("DA PAGARE",Color.rgb(210,45,45))
            remaining<=2->PackStatus("IN SCADENZA",Color.rgb(220,160,20))
            else->PackStatus("IN REGOLA",Color.rgb(35,150,70))
        }
    }
    private fun activeSessionPackFor(name:String):SessionPack?=sessionPacks.filter{it.active&&identityKey(it.name)==identityKey(name)&&sessionBooked(it)<it.totalSessions}.maxByOrNull{it.start}

    private fun sessionCard(s:SessionPack,parent:ViewGroup=list){
        val used=sessionUsed(s);val booked=sessionBooked(s);val remaining=(s.totalSessions-booked).coerceAtLeast(0);val status=sessionStatus(s)
        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(4),dp(10),dp(4));background=roundedSurface(Color.WHITE,18,Color.rgb(231,233,237),1)}
        val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;isClickable=true;isFocusable=true;setPadding(dp(2),0,0,0)}
        val name=TextView(this).apply{text=displaySurnameFirst(s.name);textSize=17.5f;setTextColor(Color.rgb(20,20,20));gravity=Gravity.CENTER_VERTICAL;maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END}
        header.addView(name,LinearLayout.LayoutParams(0,dp(48),1f))
        header.addView(TextView(this).apply{text="$remaining rimaste";textSize=13f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(status.color);gravity=Gravity.CENTER_VERTICAL;maxLines=1},LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,dp(44)))
        val menu=menuIconButtonStyle().apply{setOnClickListener{sessionInfoDialog(s)}}
        header.addView(menu,LinearLayout.LayoutParams(dp(38),dp(40)).apply{setMargins(dp(6),0,dp(6),0)})
        header.addView(TextView(this).apply{text="●";textSize=18f;setTextColor(status.color);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(26),dp(44)))
        card.addView(header)

        val details=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE;setPadding(dp(4),dp(4),0,dp(2))}
        details.addView(TextView(this).apply{text="Pacchetto sedute • €${s.cost} • $used effettuate • $booked prenotate";textSize=14f;setTextColor(Color.rgb(75,78,84));setPadding(0,0,0,dp(4))})
        val dates=appointments.filter{it.sessionPackId==s.id}.sortedBy{it.date}.joinToString(" • " ){it.date.format(fmt)}
        if(dates.isNotEmpty())details.addView(TextView(this).apply{text="Date: $dates";textSize=12.5f;setTextColor(Color.DKGRAY);setPadding(0,0,0,dp(5))})
        details.addView(TextView(this).apply{
            text="ALTRE INFORMAZIONI"
            textSize=12.5f
            setTypeface(null,android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(20,91,165))
            gravity=Gravity.CENTER
            isClickable=true
            isFocusable=true
            background=roundedSurface(Color.rgb(238,246,255),16,Color.rgb(190,218,248),1)
            setOnClickListener{sessionOptionsDialog(s)}
        },LinearLayout.LayoutParams(-1,dp(40)).apply{setMargins(0,dp(2),0,dp(2))})
        card.addView(details)
        header.setOnClickListener{val open=details.visibility!=View.VISIBLE;details.visibility=if(open)View.VISIBLE else View.GONE;if(open)expandedClients.add(identityKey(s.name)) else expandedClients.remove(identityKey(s.name))}
        parent.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})
    }

    private fun sessionInfoDialog(s:SessionPack){
        lateinit var dialog: AlertDialog
        val now=LocalDateTime.now()
        val used=sessionUsed(s,now)
        val booked=sessionBooked(s)
        val remaining=(s.totalSessions-booked).coerceAtLeast(0)
        val status=sessionStatus(s)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),0,dp(16),dp(10))}
        val scroll=ScrollView(this).apply{isFillViewport=true;addView(root)}

        val client=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(14),dp(14),dp(14),dp(12));background=roundedSurface(Color.rgb(247,249,252),20,Color.rgb(228,232,238),1)}
        val initials=displaySurnameFirst(s.name).split(" ").filter{it.isNotBlank()}.take(2).joinToString(""){it.first().uppercase()}
        client.addView(TextView(this).apply{text=initials;textSize=19f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(20,70,130));background=roundedSurface(Color.rgb(230,240,252),30)},LinearLayout.LayoutParams(dp(58),dp(58)))
        client.addView(TextView(this).apply{text=displaySurnameFirst(s.name);textSize=21f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32));gravity=Gravity.CENTER;setPadding(0,dp(8),0,0)},LinearLayout.LayoutParams(-1,dp(36)))
        client.addView(TextView(this).apply{text="●  ${status.label}";textSize=13.5f;setTextColor(status.color);gravity=Gravity.CENTER;setPadding(0,dp(2),0,0)},LinearLayout.LayoutParams(-1,dp(24)))
        root.addView(client,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(8),0,dp(12))})

        val stats=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        fun stat(value:String,label:String):View=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(3),dp(8),dp(3),dp(8));background=roundedSurface(Color.WHITE,16,Color.rgb(230,233,238),1)
            addView(TextView(this@MainActivity).apply{text=value;textSize=17f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,30,38));gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,dp(27)))
            addView(TextView(this@MainActivity).apply{text=label;textSize=9.5f;setTextColor(Color.rgb(85,90,98));gravity=Gravity.CENTER;maxLines=2},LinearLayout.LayoutParams(-1,dp(30)))}
        stats.addView(stat("${s.totalSessions}","SEDUTE TOTALI"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(0,0,dp(4),0)})
        stats.addView(stat("$remaining","SEDUTE RIMASTE"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(dp(2),0,dp(2),0)})
        stats.addView(stat("$used","EFFETTUATE"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(dp(2),0,dp(2),0)})
        stats.addView(stat("€${s.cost}","TOTALE PACCHETTO"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(dp(4),0,0,0)})
        root.addView(stats)

        val info=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(9),dp(14),dp(9));background=roundedSurface(Color.WHITE,18,Color.rgb(230,233,238),1)}
        fun infoRow(label:String,value:String){val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(7),0,dp(7))};r.addView(TextView(this@MainActivity).apply{text=label;textSize=13f;setTextColor(Color.rgb(85,90,98))},LinearLayout.LayoutParams(0,dp(34),1f));r.addView(TextView(this@MainActivity).apply{text=value;textSize=13.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,40,48));gravity=Gravity.CENTER_VERTICAL}) ;info.addView(r)}
        infoRow("Tipo pacchetto","PACCHETTO A SEDUTE")
        infoRow("Data di inizio",s.start.format(fmt))
        infoRow("Numero sedute","${s.totalSessions}")
        infoRow("Importo totale","€${s.cost}")
        infoRow("Pagamento",if(s.paid>=s.cost)"Saldato per intero" else "Da pagare • €${s.cost-s.paid}")
        infoRow("Stato",status.label)
        root.addView(info,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(12),0,dp(14))})

        val rates=sessionRatesFor(s)
        val paymentBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        rates.forEachIndexed{index,due->
            val paidBefore=rates.take(index).sum()
            val alreadyOnRate=(s.paid-paidBefore).coerceAtLeast(0)
            val isPaid=s.paid>=rates.take(index+1).sum()
            val remainingOnRate=(due-alreadyOnRate).coerceAtLeast(0)
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(7),dp(8),dp(7));background=roundedSurface(Color.WHITE,18,Color.rgb(230,233,238),1)}
            row.addView(TextView(this).apply{text=if(isPaid)"✓" else "€";textSize=17f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(if(isPaid)Color.rgb(20,150,95) else Color.rgb(210,45,45));background=roundedSurface(if(isPaid)Color.rgb(232,248,240) else Color.rgb(255,240,240),22)},LinearLayout.LayoutParams(dp(42),dp(42)))
            val date=s.start.plusDays((28L*index)); row.addView(TextView(this).apply{text="Rata ${index+1}  •  €$due\n${date.format(fmt)}  •  ${if(isPaid)"Pagata" else if(alreadyOnRate>0)"Parziale • €$alreadyOnRate pagati" else "Da pagare • €$remainingOnRate"}";textSize=14f;setTextColor(Color.rgb(35,40,48));setPadding(dp(12),0,dp(4),0)},LinearLayout.LayoutParams(0,dp(54),1f))
            if(!isPaid && index==s.paidRateIndex(rates)){
                row.addView(paymentButtonStyle().apply{setOnClickListener{confirmSessionPaymentDialog(s,index,remainingOnRate)}},LinearLayout.LayoutParams(dp(68),dp(40)))
                row.addView(editIconButtonStyle().apply{setOnClickListener{sessionPaymentAmountDialog(s,index)}},LinearLayout.LayoutParams(dp(40),dp(40)).apply{setMargins(dp(4),0,0,0)})
            } else if(!isPaid){
                row.addView(TextView(this).apply{text=""},LinearLayout.LayoutParams(dp(118),dp(40)))
            }
            paymentBox.addView(row,LinearLayout.LayoutParams(-1,dp(70)).apply{setMargins(0,0,0,dp(6))})
        }
        root.addView(TextView(this).apply{text="Pagamento";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32))},LinearLayout.LayoutParams(-1,dp(34)).apply{setMargins(0,0,0,dp(3))})
        root.addView(paymentBox,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})

        val programming=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(10),dp(14),dp(10));background=roundedSurface(Color.rgb(238,246,255),18,Color.rgb(190,218,248),1);isClickable=true;isFocusable=true}
        programming.addView(TextView(this).apply{text="Programmazione";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32))},LinearLayout.LayoutParams(-1,dp(30)))
        programming.addView(TextView(this).apply{text="$booked appuntamenti prenotati • $used effettuati • $remaining sedute disponibili";textSize=13f;setTextColor(Color.rgb(85,90,98));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,dp(34),1f))
        programming.addView(TextView(this).apply{text="›";textSize=24f;gravity=Gravity.CENTER;setTextColor(Color.rgb(15,95,180))},LinearLayout.LayoutParams(dp(30),dp(34)))
        programming.setOnClickListener{programmingDetailDialog(s)}
        root.addView(programming,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})

        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        fun actionButton(label:String,accent:Int,bg:Int,click:()->Unit)=Button(this).apply{text=label;setAllCaps(false);textSize=11.5f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(accent);background=roundedSurface(bg,16,Color.rgb(205,220,238),1);setOnClickListener{click()}}
        actions.addView(actionButton("✎ Rinomina",Color.rgb(15,95,180),Color.rgb(238,246,255)){dialog.dismiss();renameSessionPackDialog(s)},LinearLayout.LayoutParams(0,dp(46),1f).apply{setMargins(0,0,dp(4),0)})
        actions.addView(actionButton("⏹ Termina",Color.rgb(120,80,25),Color.rgb(255,248,232)){confirmTerminateSessionPack(s,dialog)},LinearLayout.LayoutParams(0,dp(46),1f).apply{setMargins(dp(2),0,dp(2),0)})
        actions.addView(actionButton("🗑 Elimina",Color.rgb(200,45,45),Color.rgb(255,244,244)){confirmDeleteSessionPack(s,dialog)},LinearLayout.LayoutParams(0,dp(46),0.9f).apply{setMargins(dp(4),0,0,0)})
        root.addView(actions,LinearLayout.LayoutParams(-1,dp(50)))

        dialog=AlertDialog.Builder(this).setTitle("Gestione pacchetto").setView(scroll).setNegativeButton("CHIUDI",null).create()
        styleModernCoachDialog(dialog)
        dialog.show()
    }

    private fun sessionRatesFor(s:SessionPack):List<Int>{
        val c=s.customRates
        if(c!=null&&c.isNotEmpty()&&c.all{it>0}&&c.sum()==s.cost)return c.toList()
        return listOf(s.cost)
    }

    private fun saveSessionRates(s:SessionPack,rates:List<Int>){s.customRates=rates.toMutableList()}

    private fun SessionPack.paidRateIndex(rates:List<Int>):Int=rates.indices.firstOrNull{paid<rates.take(it+1).sum()}?:rates.size

    private fun registerSessionPayment(s:SessionPack,index:Int,paidNow:Int,sourceDialog:AlertDialog?=null){
        try{
            val rates=sessionRatesFor(s);val due=rates[index];require(paidNow>0);require(s.paid+paidNow<=s.cost)
            val paidBefore=rates.take(index).sum();val already=(s.paid-paidBefore).coerceAtLeast(0);val totalOnRate=already+paidNow
            val newRates=rates.toMutableList();s.paid+=paidNow
            if(totalOnRate<due && index==rates.lastIndex){
                // Keep the original installment schedule until the user confirms
                // creation of the new residual installment.
                saveData();sourceDialog?.dismiss();render();sessionInfoDialog(s)
                val residual=s.cost-s.paid
                if(residual>0)proposeResidualSessionRate(s,index,residual)
                return
            }
            if(totalOnRate>due){
                newRates[index]=totalOnRate
                val remainingCount=newRates.size-index-1
                if(remainingCount>0){
                    val remaining=s.cost-rates.take(index).sum()-totalOnRate;require(remaining>=0)
                    val base=remaining/remainingCount;val extra=remaining%remainingCount
                    for(j in index+1 until newRates.size)newRates[j]=base+if(j-index-1<extra)1 else 0
                } else require(totalOnRate==s.cost-rates.take(index).sum())
            }
            require(newRates.sum()==s.cost);saveSessionRates(s,newRates);saveData();sourceDialog?.dismiss();render();sessionInfoDialog(s)
            Toast.makeText(this,"Pagamento di €$paidNow registrato.",Toast.LENGTH_SHORT).show()
        }catch(_:Exception){Toast.makeText(this,"Importo non valido o superiore al totale residuo.",Toast.LENGTH_LONG).show()}
    }

    private fun confirmSessionPaymentDialog(s:SessionPack,index:Int,amount:Int){
        if(amount<=0)return
        val dialog=AlertDialog.Builder(this).setTitle("Conferma pagamento").setMessage("Confermi il pagamento della rata ${index+1} di €$amount?").setNegativeButton("ANNULLA",null).setPositiveButton("CONFERMA"){_,_->registerSessionPayment(s,index,amount)}.create()
        styleOneUiDialog(dialog);dialog.show()
    }

    private fun sessionPaymentAmountDialog(s:SessionPack,index:Int){
        val rates=sessionRatesFor(s);val due=rates[index];val paidBefore=rates.take(index).sum();val already=(s.paid-paidBefore).coerceAtLeast(0);val remaining=(due-already).coerceAtLeast(0)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(8),dp(16),0)}
        box.addView(TextView(this).apply{text="Rata ${index+1} • prevista €$due • da pagare €$remaining";textSize=15f;setTextColor(Color.DKGRAY);setPadding(0,0,0,dp(8))})
        val amount=modernEditText().apply{hint="Importo effettivamente pagato (€)";inputType=2;setSingleLine(true);setText(remaining.toString());selectAll()};box.addView(amount)
        val dialog=AlertDialog.Builder(this).setTitle("Modifica importo pagamento").setView(box).setNegativeButton("ANNULLA",null).setPositiveButton("CONFERMA PAGAMENTO",null).create()
        styleOneUiDialog(dialog);dialog.setOnShowListener{dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{val value=amount.text.toString().trim().toIntOrNull();if(value==null||value<=0||s.paid+value>s.cost){Toast.makeText(this,"Importo non valido o superiore al totale residuo.",Toast.LENGTH_LONG).show()}else{dialog.dismiss();confirmSessionPaymentDialog(s,index,value)}}};dialog.show()
    }

    private fun proposeResidualSessionRate(s:SessionPack,index:Int,residual:Int){
        if(residual<=0)return
        val next=index+2
        val dialog=AlertDialog.Builder(this)
            .setTitle("Importo residuo")
            .setMessage("La rata ${index+1} è stata pagata solo in parte.\n\nRestano €$residual da pagare per completare il pacchetto da €${s.cost}.\n\nVuoi creare la ${next}ª rata di €$residual con scadenza tra 28 giorni?")
            .setNegativeButton("NON ORA",null)
            .setPositiveButton("CREA ${next}ª RATA"){_,_->
                val current=sessionRatesFor(s).toMutableList()
                val paidBefore=current.take(index).sum()
                val paidOnCurrent=(s.paid-paidBefore).coerceAtLeast(0)
                if(index in current.indices && paidOnCurrent>0 && paidOnCurrent<current[index]){
                    current[index]=paidOnCurrent
                    current.add(residual)
                    if(current.sum()==s.cost){
                        saveSessionRates(s,current);saveData();render();sessionInfoDialog(s)
                        Toast.makeText(this,"${next}ª rata creata: €$residual.",Toast.LENGTH_SHORT).show()
                    }
                }
            }.create()
        styleOneUiDialog(dialog);dialog.show()
    }

    private fun confirmTerminateSessionPack(s:SessionPack,source:AlertDialog){
        val future=appointments.filter{it.sessionPackId==s.id&&it.date.isAfter(LocalDate.now())}
        val dialog=AlertDialog.Builder(this).setTitle("Terminare il pacchetto?").setMessage("Il pacchetto di ${displaySurnameFirst(s.name)} verrà spostato nello storico e non sarà più considerato attivo.\n\nSono presenti ${future.size} appuntamenti futuri nel calendario.").setNegativeButton("ANNULLA",null).setPositiveButton("CONFERMA"){_,_->s.active=false;saveData();source.dismiss();render();Toast.makeText(this,"Pacchetto terminato.",Toast.LENGTH_SHORT).show()}.create()
        styleOneUiDialog(dialog);dialog.show()
    }

    private fun confirmDeleteSessionPack(s:SessionPack,source:AlertDialog){
        val dialog=AlertDialog.Builder(this).setTitle("Eliminare pacchetto?").setMessage("Stai per eliminare definitivamente il pacchetto di ${displaySurnameFirst(s.name)}.\n\nLe sedute, i pagamenti e i dati del pacchetto verranno rimossi. Gli appuntamenti resteranno nel calendario.").setNegativeButton("ANNULLA",null).setPositiveButton("ELIMINA"){_,_->sessionPacks.remove(s);appointments.filter{it.sessionPackId==s.id}.forEach{it.sessionPackId=0L};saveData();source.dismiss();render();Toast.makeText(this,"Pacchetto eliminato.",Toast.LENGTH_SHORT).show()}.create()
        styleOneUiDialog(dialog);dialog.show()
    }

    private fun sessionPaymentInfo(s:SessionPack){ sessionInfoDialog(s) }

    private fun packActionDialogBase(title:String, icon:String, iconColor:Int, iconBg:Int, dialogBg:Int=Color.WHITE): Triple<Dialog,LinearLayout,LinearLayout>{
        val dialog=Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val outer=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(14),dp(12),dp(14),dp(12))
            background=roundedSurface(dialogBg,28)
        }
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val spacer=Space(this)
        top.addView(spacer,LinearLayout.LayoutParams(0,dp(36),1f))
        top.addView(TextView(this).apply{
            text="×";textSize=27f;gravity=Gravity.CENTER;setTextColor(Color.rgb(70,80,95));setPadding(0,0,0,dp(2))
            setOnClickListener{dialog.dismiss()}
        },LinearLayout.LayoutParams(dp(38),dp(36)))
        outer.addView(top)
        val iconView=TextView(this).apply{
            text=icon;textSize=28f;gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(iconColor)
            background=roundedSurface(iconBg,40)
        }
        outer.addView(iconView,LinearLayout.LayoutParams(dp(66),dp(66)).apply{gravity=Gravity.CENTER;setMargins(0,dp(0),0,dp(10))})
        val titleView=TextView(this).apply{
            text=title;textSize=21f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(28,35,48))
        }
        outer.addView(titleView,LinearLayout.LayoutParams(-1,dp(40)).apply{setMargins(dp(8),0,dp(8),dp(2))})
        val body=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(8),0,dp(8),0)}
        outer.addView(body,LinearLayout.LayoutParams(-1,-2))
        dialog.setContentView(outer)
        dialog.window?.apply{
            setBackgroundDrawableResource(android.R.color.transparent)
            addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            attributes=attributes.apply{dimAmount=0.40f}
        }
        dialog.setOnShowListener{
            dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
        }
        return Triple(dialog,outer,body)
    }

    private fun dialogBodyText(text:String):TextView=TextView(this).apply{
        this.text=text;textSize=15.5f;gravity=Gravity.CENTER;setTextColor(Color.rgb(55,62,75));setLineSpacing(0f,1.08f);setPadding(dp(6),0,dp(6),dp(12))
    }

    private fun dialogInfoCard(icon:String,title:String,value:String?,accent:Int,bg:Int):LinearLayout=LinearLayout(this).apply{
        orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(10),dp(12),dp(10));background=roundedSurface(bg,18)
        addView(TextView(this@MainActivity).apply{text=icon;textSize=22f;gravity=Gravity.CENTER;setTextColor(accent);background=roundedSurface(Color.WHITE,32);},LinearLayout.LayoutParams(dp(48),dp(48)))
        val txt=LinearLayout(this@MainActivity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),0,0,0)}
        txt.addView(TextView(this@MainActivity).apply{text=title;textSize=13f;setTextColor(Color.rgb(70,78,90))},LinearLayout.LayoutParams(-1,-2))
        if(value!=null) txt.addView(TextView(this@MainActivity).apply{text=value;textSize=24f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(accent);setPadding(0,dp(2),0,0)},LinearLayout.LayoutParams(-1,-2))
        addView(txt,LinearLayout.LayoutParams(0,-2,1f))
    }

    private fun dialogButton(text:String,textColor:Int,bg:Int,stroke:Int,click:()->Unit):Button=Button(this).apply{
        this.text=text;setAllCaps(false);textSize=14.5f;setTypeface(null,android.graphics.Typeface.BOLD);minHeight=0;minimumHeight=0;stateListAnimator=null
        setTextColor(textColor);background=roundedSurface(bg,18,stroke,1);setPadding(dp(8),0,dp(8),0);setOnClickListener{click()}
    }

    private fun terminatePackDialog(p:Pack){
        val future=appointments.filter{identityKey(it.name)==identityKey(p.name)&&it.date.isAfter(LocalDate.now())}
        val (dialog,outer,body)=packActionDialogBase("Terminare il pacchetto?","□",Color.rgb(225,130,0),Color.rgb(255,235,195),Color.rgb(255,252,246))
        body.addView(dialogBodyText("Il pacchetto verrà spostato nello storico e non sarà più considerato attivo."))
        body.addView(dialogInfoCard("▣","Sono presenti ${future.size} appuntamenti futuri nel calendario.","Puoi mantenerli oppure eliminarli.",Color.rgb(205,120,0),Color.rgb(255,241,213)),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,dp(12))})
        body.addView(dialogButton("Mantieni appuntamenti",Color.WHITE,Color.rgb(235,140,0),Color.rgb(235,140,0)){
            p.active=false;saveData();dialog.dismiss();render();Toast.makeText(this,"Pacchetto terminato. Appuntamenti mantenuti.",Toast.LENGTH_SHORT).show()
        },LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,0,0,dp(8))})
        body.addView(dialogButton("Elimina futuri",Color.rgb(205,120,0),Color.rgb(255,252,246),Color.rgb(245,190,95)){
            appointments.removeAll{identityKey(it.name)==identityKey(p.name)&&it.date.isAfter(LocalDate.now())};p.active=false;saveData();dialog.dismiss();render();Toast.makeText(this,"Pacchetto terminato e appuntamenti futuri eliminati.",Toast.LENGTH_SHORT).show()
        },LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,0,0,dp(4))})
        body.addView(TextView(this).apply{text="Annulla";textSize=14.5f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(125,75,20));setPadding(0,dp(8),0,dp(2));setOnClickListener{dialog.dismiss()}},LinearLayout.LayoutParams(-1,dp(42)))
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun confirmDeletePack(p:Pack){
        val (dialog,outer,body)=packActionDialogBase("Eliminare pacchetto?","▣",Color.rgb(220,35,45),Color.rgb(255,205,210),Color.rgb(255,248,248))
        body.addView(dialogBodyText("Stai per eliminare definitivamente il pacchetto di ${displaySurnameFirst(p.name)}."))
        body.addView(dialogInfoCard("!","Le rate e i dati del pacchetto verranno rimossi.","Gli appuntamenti del cliente resteranno nel calendario.",Color.rgb(215,35,45),Color.rgb(255,222,225)),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,dp(16))})
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        row.addView(dialogButton("Annulla",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(210,220,232)){dialog.dismiss()},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(4),0)})
        row.addView(dialogButton("Elimina",Color.WHITE,Color.rgb(225,40,50),Color.rgb(225,40,50)){
            packs.remove(p);saveData();dialog.dismiss();render();Toast.makeText(this,"Pacchetto eliminato.",Toast.LENGTH_SHORT).show()
        },LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(4),0,0,0)})
        body.addView(row)
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun editPackDialog(p:Pack){
        val (dialog,outer,body)=packActionDialogBase("Modifica pacchetto","✎",Color.rgb(20,91,165),Color.rgb(224,238,255),Color.WHITE)
        body.addView(dialogBodyText("Modifica i dati del pacchetto di ${displaySurnameFirst(p.name)}."))

        val intro=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(12),dp(9),dp(12),dp(9))
            background=roundedSurface(Color.rgb(247,249,252),18,Color.rgb(225,231,239),1)
        }
        val initials=displaySurnameFirst(p.name).split(" ").filter{it.isNotBlank()}.take(2).joinToString(""){it.first().uppercase()}
        intro.addView(TextView(this).apply{
            text=initials;textSize=17f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER
            setTextColor(Color.rgb(20,70,130));background=roundedSurface(Color.rgb(230,240,252),28)
        },LinearLayout.LayoutParams(dp(50),dp(50)))
        intro.addView(TextView(this).apply{
            text=displaySurnameFirst(p.name);textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(25,28,32));gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),0,0,0)
        },LinearLayout.LayoutParams(0,dp(50),1f))
        body.addView(intro,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(13))})

        fun label(t:String)=TextView(this).apply{
            text=t;textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(82,87,94));setPadding(dp(2),0,0,dp(4))
        }
        val name=modernEditText().apply{
            setSingleLine(true);setText(p.name);setSelection(text.length);textSize=16f;hint="Cognome e Nome"
        }
        body.addView(label("Cliente"))
        body.addView(name,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(10))})

        body.addView(label("Tipo pacchetto"))
        val type=Spinner(this).apply{
            adapter=centeredSpinnerAdapter(listOf("BRONZE • 12 sedute","SILVER • 24 sedute","GOLD • 36 sedute","PERSONALIZZATO"))
            setSelection(when(p.packageType){"BRONZE"->0;"SILVER"->1;"GOLD"->2;else->3})
        }
        body.addView(type,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(10))})

        body.addView(label("Numero sedute"))
        val sessions=modernEditText().apply{
            setSingleLine(true);inputType=2;setText(p.sessionTotal.toString());hint="Numero sedute";textSize=16f
        }
        body.addView(sessions,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(14))})
        fun sync(){sessions.setText(when(type.selectedItemPosition){0->"12";1->"24";2->"36";else->p.sessionTotal.toString()})}
        type.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent:AdapterView<*>?){ }
            override fun onItemSelected(parent:AdapterView<*>?,view:View?,position:Int,id:Long){if(position<3)sync()}
        }

        body.addView(LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
            val cancel=dialogButton("Annulla",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(210,220,232)){dialog.dismiss()}
            val save=dialogButton("▣ Salva",Color.WHITE,Color.rgb(36,112,225),Color.rgb(36,112,225)){
                val newName=normalizeDisplayName(name.text.toString())
                val newTotal=sessions.text.toString().trim().toIntOrNull()
                if(newName.isBlank()||newTotal==null||newTotal<=0){
                    Toast.makeText(this@MainActivity,"Controlla nome e numero sedute.",Toast.LENGTH_LONG).show();return@dialogButton
                }
                val done=sessionsForPack(p,LocalDate.now()).size
                if(newTotal<done){
                    Toast.makeText(this@MainActivity,"Non puoi impostare $newTotal sedute: ne risultano già effettuate $done.",Toast.LENGTH_LONG).show();return@dialogButton
                }
                val oldKey=identityKey(p.name)
                val kind=when(type.selectedItemPosition){0->"BRONZE";1->"SILVER";2->"GOLD";else->"PERSONALIZZATO"}
                p.name=newName;p.packageType=kind;p.sessionTotal=if(kind=="BRONZE")12 else if(kind=="SILVER")24 else if(kind=="GOLD")36 else newTotal
                appointments.filter{identityKey(it.name)==oldKey}.forEach{it.name=newName}
                saveData();dialog.dismiss();render();Toast.makeText(this@MainActivity,"Pacchetto aggiornato.",Toast.LENGTH_SHORT).show()
            }
            addView(cancel,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(4),0)})
            addView(save,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(4),0,0,0)})
        },LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,0,0,dp(2))})

        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun renamePackDialog(p:Pack){
        val input=modernEditText().apply{
            setSingleLine(true)
            setText(p.name)
            setSelection(text.length)
            textSize=16f
            hint="Cognome e Nome"
        }
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(22),dp(6),dp(22),0)}
        box.addView(TextView(this).apply{text="Nuovo nome del cliente/pacchetto";textSize=13f;setTextColor(Color.rgb(95,99,105));setPadding(0,0,0,dp(6))})
        box.addView(input,LinearLayout.LayoutParams(-1,dp(54)))
        val dialog=AlertDialog.Builder(this).setTitle("Rinomina pacchetto").setView(box).setPositiveButton("SALVA",null).setNegativeButton("ANNULLA",null).create()
        styleOneUiDialog(dialog)
        dialog.setOnShowListener{
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{
                val newName=normalizeDisplayName(input.text.toString())
                if(newName.isBlank()){input.error="Inserisci un nome";return@setOnClickListener}
                val oldKey=identityKey(p.name)
                p.name=newName
                appointments.filter{identityKey(it.name)==oldKey}.forEach{it.name=newName}
                saveData();render();dialog.dismiss();Toast.makeText(this,"Pacchetto rinominato.",Toast.LENGTH_SHORT).show()
            }
        }
        dialog.show()
    }

    private fun sessionOptionsDialog(s:SessionPack){
        val used=sessionUsed(s);val booked=sessionBooked(s);val remaining=(s.totalSessions-booked).coerceAtLeast(0)
        val actions=arrayOf("Rinomina pacchetto","Termina pacchetto","Elimina pacchetto")
        AlertDialog.Builder(this).setTitle(displaySurnameFirst(s.name)).setMessage("Pacchetto da ${s.totalSessions} sedute • €${s.cost} saldato per intero\nSedute effettuate: $used/${s.totalSessions}\nSedute prenotate: $booked\nSedute rimanenti: $remaining").setItems(actions){_,which->when(which){
            0->{renameSessionPackDialog(s)}
            1->{confirmTerminateSessionPackFromOptions(s)}
            else->{confirmDeleteSessionPackFromOptions(s)}
        }}.setNegativeButton("Chiudi",null).create().also{styleOneUiDialog(it);it.show()}
    }

    private fun confirmTerminateSessionPackFromOptions(s:SessionPack){
        val dialog=AlertDialog.Builder(this).setTitle("Terminare il pacchetto?").setMessage("Il pacchetto verrà spostato nello storico e non sarà più considerato attivo.").setNegativeButton("ANNULLA",null).setPositiveButton("CONFERMA"){_,_->s.active=false;saveData();render();Toast.makeText(this,"Pacchetto terminato.",Toast.LENGTH_SHORT).show()}.create();styleOneUiDialog(dialog);dialog.show()
    }
    private fun confirmDeleteSessionPackFromOptions(s:SessionPack){
        val dialog=AlertDialog.Builder(this).setTitle("Eliminare pacchetto?").setMessage("Stai per eliminare definitivamente il pacchetto di ${displaySurnameFirst(s.name)}. I pagamenti e i dati del pacchetto verranno rimossi, mentre gli appuntamenti resteranno nel calendario.").setNegativeButton("ANNULLA",null).setPositiveButton("ELIMINA"){_,_->sessionPacks.remove(s);appointments.filter{it.sessionPackId==s.id}.forEach{it.sessionPackId=0L};saveData();render();Toast.makeText(this,"Pacchetto eliminato.",Toast.LENGTH_SHORT).show()}.create();styleOneUiDialog(dialog);dialog.show()
    }

    private fun renameSessionPackDialog(s:SessionPack){
        val input=modernEditText().apply{
            setSingleLine(true)
            setText(s.name)
            setSelection(text.length)
            textSize=16f
            hint="Cognome e Nome"
        }
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(22),dp(6),dp(22),0)}
        box.addView(TextView(this).apply{text="Nuovo nome del cliente/pacchetto";textSize=13f;setTextColor(Color.rgb(95,99,105));setPadding(0,0,0,dp(6))})
        box.addView(input,LinearLayout.LayoutParams(-1,dp(54)))
        val dialog=AlertDialog.Builder(this).setTitle("Rinomina pacchetto").setView(box).setPositiveButton("SALVA",null).setNegativeButton("ANNULLA",null).create()
        dialog.setOnShowListener{
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{
                val newName=normalizeDisplayName(input.text.toString())
                if(newName.isBlank()){input.error="Inserisci un nome";return@setOnClickListener}
                val oldKey=identityKey(s.name)
                s.name=newName
                appointments.filter{it.sessionPackId==s.id}.forEach{it.name=newName}
                saveData();render();dialog.dismiss();Toast.makeText(this,"Pacchetto rinominato.",Toast.LENGTH_SHORT).show()
            }
        }
        styleOneUiDialog(dialog)
        dialog.show()
    }

    private fun showClientHistory(name:String){
        val oldPacks=packs.filter{!it.active&&identityKey(it.name)==identityKey(name)}
        val oldSessions=sessionPacks.filter{!it.active&&identityKey(it.name)==identityKey(name)}
        if(oldPacks.isEmpty()&&oldSessions.isEmpty()){Toast.makeText(this,"Nessun pacchetto terminato nello storico di $name.",Toast.LENGTH_SHORT).show();return}
        val items=mutableListOf<Pair<String,()->Unit>>()
        oldPacks.forEach{p->items.add("${p.packageType} • ${p.start.format(fmt)} • €${p.total}" to {exportSummary(summaryForPack(p),p.name)})}
        oldSessions.forEach{s->items.add("${s.totalSessions} sedute • ${s.start.format(fmt)} • €${s.cost}" to {exportSummary(summaryForSessionPack(s),s.name)})}
        AlertDialog.Builder(this).setTitle("🗂 Storico • $name").setItems(items.map{it.first}.toTypedArray()){_,which->items[which].second.invoke()}.setNegativeButton("Chiudi",null).show()
    }

    private fun Pack.paidRateIndex(rates:List<Int>):Int=rates.indices.firstOrNull{paid<rates.take(it+1).sum()}?:rates.size

    private data class PackStatus(val label:String,val color:Int)
    private fun statusRank(status:PackStatus):Int=when(status.label){"SCADUTA"->0;"IN SCADENZA"->1;else->2}
    private fun statusFor(p:Pack,rates:List<Int>,dates:List<LocalDate>):PackStatus{if(p.paid>=p.total)return PackStatus("IN REGOLA",Color.rgb(35,150,70));val nextIndex=rates.indices.firstOrNull{p.paid<rates.take(it+1).sum()}?:rates.lastIndex;val due=dates[nextIndex];val today=LocalDate.now();return when{due.isBefore(today)->PackStatus("SCADUTA",Color.rgb(210,45,45));!due.isAfter(today.plusDays(7))->PackStatus("IN SCADENZA",Color.rgb(220,160,20));else->PackStatus("IN REGOLA",Color.rgb(35,150,70))}}

    // ---------------- CALENDARIO ----------------
    private fun calendarScreen(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),dp(12),dp(10),dp(8));setBackgroundColor(Color.rgb(247,248,250))}
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        top.addView(buttonStyle("‹").apply{setOnClickListener{calendarWeekStart=calendarWeekStart.minusWeeks(1);calendarScreen()}},LinearLayout.LayoutParams(dp(52),dp(48)))
        top.addView(TextView(this).apply{text="Settimana ${calendarWeekStart.format(fmt)}";textSize=17f;gravity=Gravity.CENTER;setTextColor(Color.rgb(30,30,30))},LinearLayout.LayoutParams(0,dp(48),1f))
        top.addView(buttonStyle("›").apply{setOnClickListener{calendarWeekStart=calendarWeekStart.plusWeeks(1);calendarScreen()}},LinearLayout.LayoutParams(dp(52),dp(48)))
        root.addView(top)
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        actions.addView(primaryButtonStyle("＋ Appuntamento").apply{setOnClickListener{appointmentDialog(null)}},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(3),0)})
        actions.addView(buttonStyle("Oggi").apply{setOnClickListener{calendarWeekStart=LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));calendarScreen()}},LinearLayout.LayoutParams(0,dp(48),0.55f).apply{setMargins(dp(3),0,dp(3),0)})
        actions.addView(primaryButtonStyle("🔎 Cerca").apply{setOnClickListener{calendarSearchScreen()}},LinearLayout.LayoutParams(0,dp(48),0.72f).apply{setMargins(dp(3),0,0,0)})
        root.addView(actions,LinearLayout.LayoutParams(-1,dp(52)))
        val titleRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val visibleOffsets=mutableListOf<Int>();calendarVisibleDays.forEachIndexed{i,shown->if(shown)visibleOffsets.add(i)};val firstVisibleOffset=visibleOffsets.firstOrNull()?:0;val lastVisibleOffset=visibleOffsets.lastOrNull()?:4;titleRow.addView(TextView(this).apply{text="${calendarWeekStart.plusDays(firstVisibleOffset.toLong()).format(fmt)}  →  ${calendarWeekStart.plusDays(lastVisibleOffset.toLong()).format(fmt)}";textSize=14f;setTextColor(Color.DKGRAY);gravity=Gravity.CENTER;setPadding(0,dp(4),0,dp(8))},LinearLayout.LayoutParams(0,dp(34),1f))
        val zoomLabel=TextView(this).apply{text="${(calendarZoom*100).toInt()}%";textSize=12f;setTextColor(Color.GRAY);gravity=Gravity.CENTER}
        titleRow.addView(buttonStyle("−").apply{setOnClickListener{calendarZoom=(calendarZoom-0.25f).coerceAtLeast(0.75f);calendarScreen()}},LinearLayout.LayoutParams(dp(44),dp(34)))
        titleRow.addView(zoomLabel,LinearLayout.LayoutParams(dp(44),dp(34)))
        titleRow.addView(buttonStyle("+").apply{setOnClickListener{calendarZoom=(calendarZoom+0.25f).coerceAtMost(1.75f);calendarScreen()}},LinearLayout.LayoutParams(dp(44),dp(34)))
        root.addView(titleRow,LinearLayout.LayoutParams(-1,dp(38)))

        val columnWidth=(dp(178)*calendarZoom).toInt().coerceAtLeast(dp(132))

        // Testata dei giorni fissa: resta sempre visibile mentre le fasce scorrono verticalmente.
        val headerHorizontal=HorizontalScrollView(this).apply{isFillViewport=false;isHorizontalScrollBarEnabled=false}
        val headerWeek=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        calendarVisibleDays.forEachIndexed{i,shown->if(shown)headerWeek.addView(dayHeader(calendarWeekStart.plusDays(i.toLong())),LinearLayout.LayoutParams(columnWidth,-2))}
        headerHorizontal.addView(headerWeek,ViewGroup.LayoutParams(-2,-2))
        root.addView(headerHorizontal,LinearLayout.LayoutParams(-1,(dp(62)*calendarZoom).toInt()))

        val verticalScroll=ScrollView(this).apply{isFillViewport=false}
        val bodyHorizontal=HorizontalScrollView(this).apply{isFillViewport=false;isHorizontalScrollBarEnabled=true}
        val week=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        calendarVisibleDays.forEachIndexed{i,shown->if(shown)week.addView(dayColumn(calendarWeekStart.plusDays(i.toLong()),false),LinearLayout.LayoutParams(columnWidth,-2))}
        bodyHorizontal.addView(week,ViewGroup.LayoutParams(-2,-2))
        verticalScroll.addView(bodyHorizontal,ViewGroup.LayoutParams(-2,-2))

        // La testata e il corpo scorrono orizzontalmente insieme.
        var syncingHeader=false
        var syncingBody=false
        headerHorizontal.setOnScrollChangeListener{_,scrollX,_,_,_->if(!syncingHeader){syncingBody=true;bodyHorizontal.scrollTo(scrollX,0);syncingBody=false}}
        bodyHorizontal.setOnScrollChangeListener{_,scrollX,_,_,_->if(!syncingBody){syncingHeader=true;headerHorizontal.scrollTo(scrollX,0);syncingHeader=false}}

        // Settimana corrente: mostra automaticamente il giorno di oggi e posiziona la fascia vicina all'ora attuale.
        val today=LocalDate.now()
        val currentWeekStart=today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        if(calendarWeekStart==currentWeekStart){
            val todayOffset=today.dayOfWeek.value-1
            val visibleBeforeToday=calendarVisibleDays.take(todayOffset).count{it}
            val nowMinutes=LocalTime.now().hour*60+LocalTime.now().minute
            val slotIndex=((nowMinutes-(7*60))/45).coerceIn(0,19)
            val slotHeight=(dp(86)*calendarZoom).toInt()
            headerHorizontal.post{headerHorizontal.scrollTo(visibleBeforeToday*columnWidth,0)}
            bodyHorizontal.post{bodyHorizontal.scrollTo(visibleBeforeToday*columnWidth,0)}
            verticalScroll.post{verticalScroll.smoothScrollTo(0,(slotIndex-2).coerceAtLeast(0)*slotHeight)}
        }

        root.addView(verticalScroll,LinearLayout.LayoutParams(-1,0,1f))
        root.addView(softBlueButtonStyle("← Torna ai clienti").apply{setOnClickListener{build()}},LinearLayout.LayoutParams(-1,dp(48)))
        setContentView(root)
    }

    private fun calendarSearchScreen(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(14),dp(16),dp(10));setBackgroundColor(Color.rgb(247,248,250))}
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        top.addView(TextView(this).apply{text="🔎 Ricerca appuntamenti";textSize=22f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,dp(52),1f))
        top.addView(buttonStyle("Chiudi").apply{setOnClickListener{calendarScreen()}},LinearLayout.LayoutParams(dp(82),dp(44)))
        root.addView(top)
        searchInput=modernEditText().apply{
            hint="Cerca per nome cliente";textSize=16f;setSingleLine(true);setPadding(dp(14),0,dp(14),0);background=roundedSurface(Color.WHITE,20,Color.rgb(226,229,234),1)
            addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){searchList.removeAllViews();if(s.toString().trim().isNotEmpty())renderSearchResults(s.toString().trim().lowercase())};override fun afterTextChanged(s:Editable?){}})
        }
        root.addView(searchInput,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,dp(8),0,dp(8))})
        searchList=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,dp(4),0,0)}
        val scroll=ScrollView(this).apply{addView(searchList,ViewGroup.LayoutParams(-1,-2))}
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        root.addView(softBlueButtonStyle("← Torna al calendario").apply{setOnClickListener{calendarScreen()}},LinearLayout.LayoutParams(-1,dp(48)))
        setContentView(root)
        searchInput.requestFocus()
    }

    private fun dayHeader(day:LocalDate):View{
        val z=calendarZoom
        val today=day==LocalDate.now()
        val headerBg=GradientDrawable().apply{cornerRadius=(dp(12)*z);setColor(if(today)Color.rgb(232,242,255)else Color.WHITE);setStroke((dp(1)*z).toInt(),if(today)Color.rgb(145,190,232)else Color.rgb(226,229,234))}
        return TextView(this).apply{text="${dayShort(day.dayOfWeek.value-1)}\n${day.dayOfMonth.toString().padStart(2,'0')}/${day.monthValue.toString().padStart(2,'0')}";textSize=15f*z;gravity=Gravity.CENTER;setTextColor(if(today)Color.rgb(35,105,180)else Color.rgb(45,45,45));background=headerBg;setPadding(0,(dp(6)*z).toInt(),0,(dp(6)*z).toInt())}.apply{layoutParams=LinearLayout.LayoutParams(-1,(dp(58)*z).toInt()).apply{setMargins(0,0,0,(dp(4)*z).toInt())}}
    }

    private fun dayColumn(day:LocalDate, includeHeader:Boolean=true):View{
        val z=calendarZoom
        val col=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding((dp(4)*z).toInt(),0,(dp(4)*z).toInt(),(dp(4)*z).toInt())}
        if(includeHeader) col.addView(dayHeader(day))
        for(slot in 0 until 20){val mins=7*60+slot*45;val hour=mins/60;val minute=mins%60;val time=String.format("%02d:%02d",hour,minute);val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding((dp(5)*z).toInt(),(dp(4)*z).toInt(),(dp(5)*z).toInt(),(dp(4)*z).toInt());background=GradientDrawable().apply{cornerRadius=(dp(9)*z);setColor(if(slot%2==0)Color.WHITE else Color.rgb(250,251,252));setStroke((dp(1)*z).toInt(),Color.rgb(232,234,238))};isClickable=true}
            val items=appointments.filter{it.date==day&&it.time==time}.sortedBy{it.type}
            val maxTotal=calendarRoutines.getOrNull(activeRoutineIndex)?.maxTotal?:3;val countColor=when{items.size>=maxTotal->Color.rgb(205,55,55);items.size==maxTotal-1->Color.rgb(210,145,25);else->Color.GRAY}
            val timeRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            timeRow.addView(TextView(this).apply{text=time;textSize=11f*z;setTextColor(Color.rgb(105,110,118));setTypeface(null,android.graphics.Typeface.BOLD)},LinearLayout.LayoutParams(0,(dp(22)*z).toInt(),1f))
            timeRow.addView(TextView(this).apply{text="${items.size}/${calendarRoutines.getOrNull(activeRoutineIndex)?.maxTotal?:3}";textSize=9f*z;setTextColor(countColor);gravity=Gravity.CENTER},LinearLayout.LayoutParams((dp(30)*z).toInt(),(dp(22)*z).toInt()))
            box.addView(timeRow)
            if(items.isEmpty()){box.addView(TextView(this).apply{text="＋";textSize=18f*z;gravity=Gravity.CENTER;setTextColor(Color.LTGRAY)},LinearLayout.LayoutParams(-1,(dp(42)*z).toInt()));box.setOnClickListener{appointmentDialogForSlot(day,time)}}
            else{val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                items.forEachIndexed{index,a->row.addView(appointmentChip(a),LinearLayout.LayoutParams(0,(dp(46)*z).toInt(),1f).apply{if(index>0)setMargins((dp(3)*z).toInt(),0,0,0)})}
                box.addView(row,LinearLayout.LayoutParams(-1,(dp(46)*z).toInt()))
                box.addView(TextView(this).apply{text="${items.size}/${calendarRoutines.getOrNull(activeRoutineIndex)?.maxTotal?:3} appuntamenti";textSize=8.5f*z;setTextColor(Color.GRAY);gravity=Gravity.CENTER_VERTICAL;setPadding(0,(dp(2)*z).toInt(),0,0)},LinearLayout.LayoutParams(-1,(dp(16)*z).toInt()))
                box.setOnClickListener{appointmentDialogForSlot(day,time)}
            }
            col.addView(box,LinearLayout.LayoutParams(-1,(dp(84)*z).toInt()).apply{setMargins(0,(dp(2)*z).toInt(),0,0)})
        }
        return col
    }

    private fun calendarPackageExpired(name:String):Boolean{
        val key=identityKey(name)
        val regularExpired=packs.any{it.active&&identityKey(it.name)==key&&statusFor(it,ratesFor(it),dueDates(it)).label=="SCADUTA"}
        val sessionExpired=sessionPacks.any{it.active&&identityKey(it.name)==key&&sessionStatus(it).label in setOf("SCADUTA","DA PAGARE")}
        return regularExpired||sessionExpired
    }

    private fun appointmentChip(a:Appointment):View{
        val accent=typeColor(a.type)
        val bg=typeBgForColor(accent)
        val chip=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding((dp(3)*calendarZoom).toInt(),(dp(2)*calendarZoom).toInt(),(dp(3)*calendarZoom).toInt(),(dp(2)*calendarZoom).toInt());background=GradientDrawable().apply{cornerRadius=(dp(11)*calendarZoom);setColor(bg);setStroke((dp(1)*calendarZoom).toInt(),accent)};isClickable=true}
        if(calendarPackageExpired(a.name)){
            chip.addView(TextView(this).apply{setBackgroundColor(if(bg==Color.rgb(210,55,55))Color.WHITE else Color.rgb(210,45,45))},LinearLayout.LayoutParams(-1,(dp(3)*calendarZoom).toInt()).apply{setMargins((dp(4)*calendarZoom).toInt(),0,(dp(4)*calendarZoom).toInt(),(dp(4)*calendarZoom).toInt())})
        }
        chip.addView(TextView(this).apply{text=displaySurnameFirst(a.name);textSize=9.5f*calendarZoom;setTextColor(Color.rgb(25,30,35));gravity=Gravity.CENTER;maxLines=2;ellipsize=android.text.TextUtils.TruncateAt.END;setTypeface(null,android.graphics.Typeface.BOLD)},LinearLayout.LayoutParams(-1,(dp(if(calendarPackageExpired(a.name)) 37 else 42)*calendarZoom).toInt()))
        chip.setOnClickListener{appointmentActions(a)}
        return chip}

    private fun registerDeletedRegularAppointment(a:Appointment){
        if(!a.recovery){regularPackFor(a.name,a.date)?.let{it.missedSessions++}}
    }

    private fun appointmentActions(a:Appointment){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(4),dp(18),dp(8))}
        box.addView(TextView(this).apply{text=displaySurnameFirst(a.name);textSize=23f;setTextColor(Color.rgb(24,27,31));setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setPadding(0,dp(4),0,dp(2))},LinearLayout.LayoutParams(-1,dp(42)))
        box.addView(TextView(this).apply{text="${a.date.format(fmt)} • ${a.time} • ${typeDuration(a.type)} min";textSize=13.5f;setTextColor(Color.rgb(92,96,102));gravity=Gravity.CENTER;setPadding(0,0,0,dp(14))},LinearLayout.LayoutParams(-1,dp(30)))
        val edit=Button(this).apply{text="Modifica / sposta";setAllCaps(false);textSize=15f;gravity=Gravity.CENTER;setTextColor(Color.rgb(25,28,32));background=roundedSurface(Color.rgb(246,248,250),18,Color.rgb(228,231,235),1);stateListAnimator=null}
        val del=Button(this).apply{text="Elimina appuntamento";setAllCaps(false);textSize=15f;gravity=Gravity.CENTER;setTextColor(Color.rgb(205,55,55));background=roundedSurface(Color.rgb(255,244,244),18,Color.rgb(244,215,215),1);stateListAnimator=null}
        val missedPack=regularPackFor(a.name,a.date)
        val markMissed=if(a.date.isBefore(LocalDate.now()) && missedPack!=null) Button(this).apply{this.text=if(a.recovery)"Segna recupero non effettuato" else "Segna seduta come persa";setAllCaps(false);textSize=14.5f;gravity=Gravity.CENTER;setTextColor(Color.rgb(190,120,20));background=roundedSurface(Color.rgb(255,248,232),18,Color.rgb(244,224,190),1);stateListAnimator=null} else null
        val cancel=Button(this).apply{text="Annulla";setAllCaps(false);textSize=14f;setTextColor(Color.rgb(0,125,110));setBackgroundColor(Color.TRANSPARENT);stateListAnimator=null}
        box.addView(edit,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,0,0,dp(6))});
        if(markMissed!=null) box.addView(markMissed,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(5))})
        box.addView(del,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,0,0,dp(3))});box.addView(cancel,LinearLayout.LayoutParams(-1,dp(46)))
        val dialog=AlertDialog.Builder(this).setView(box).create();styleModernCoachDialog(dialog)
        dialog.setOnShowListener{dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28));dialog.window?.setDimAmount(0.40f);dialog.window?.let{w->w.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT)};edit.setOnClickListener{dialog.dismiss();appointmentDialog(a)};markMissed?.setOnClickListener{
            missedPack?.let{p->if(!a.recovery)p.missedSessions++}
            appointments.remove(a);saveData();dialog.dismiss();calendarScreen()
        };del.setOnClickListener{
            dialog.dismiss()
            if(a.seriesId!=0L){
                val series=appointments.filter{it.seriesId==a.seriesId}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
                val seriesCount=series.size
                val selectedIndex=series.indexOfFirst{it.id==a.id}
                val laterCount=if(selectedIndex>=0) series.size-selectedIndex else 0
                val boxSeq=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(8),dp(20),dp(10))}
                boxSeq.addView(TextView(this).apply{
                    text="Elimina appuntamento";textSize=23f;setTextColor(Color.rgb(24,27,31));setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setPadding(0,0,0,dp(8))
                },LinearLayout.LayoutParams(-1,dp(48)))
                boxSeq.addView(TextView(this).apply{
                    text="Questo appuntamento fa parte di una programmazione di $seriesCount appuntamenti.\n\nCosa vuoi eliminare?"
                    textSize=16f;setTextColor(Color.rgb(55,58,63));gravity=Gravity.CENTER;setPadding(0,0,0,dp(12))
                })
                fun seqButton(label:String, sub:String?=null, bg:Int=Color.rgb(246,248,250), fg:Int=Color.rgb(25,28,32)):Button{
                    return Button(this).apply{
                        text=if(sub.isNullOrBlank()) label else "$label\n$sub"
                        setAllCaps(false);textSize=15f;gravity=Gravity.CENTER;setTextColor(fg);setPadding(dp(10),0,dp(10),0)
                        background=roundedSurface(bg,18,Color.rgb(228,231,235),1);stateListAnimator=null
                    }
                }
                val one=seqButton("Solo questo appuntamento")
                val subsequent=seqButton("Questo e tutti i successivi","Elimina $laterCount appuntamenti da questo in poi")
                val all=seqButton("Tutta la sequenza","Elimina tutti i $seriesCount appuntamenti",Color.rgb(255,244,244),Color.rgb(195,55,55))
                val cancelSeq=Button(this).apply{text="Annulla";setAllCaps(false);textSize=14f;gravity=Gravity.CENTER;setTextColor(Color.rgb(0,125,110));setBackgroundColor(Color.TRANSPARENT);stateListAnimator=null}
                boxSeq.addView(one,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(7))})
                boxSeq.addView(subsequent,LinearLayout.LayoutParams(-1,dp(58)).apply{setMargins(0,0,0,dp(7))})
                boxSeq.addView(all,LinearLayout.LayoutParams(-1,dp(58)).apply{setMargins(0,0,0,dp(4))})
                boxSeq.addView(cancelSeq,LinearLayout.LayoutParams(-1,dp(44)))
                val seqDialog=AlertDialog.Builder(this).setView(boxSeq).create()
                styleOneUiDialog(seqDialog)
                seqDialog.setOnShowListener{
                    seqDialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28));seqDialog.window?.setDimAmount(0.42f)
                    one.setOnClickListener{registerDeletedRegularAppointment(a);appointments.remove(a);saveData();seqDialog.dismiss();calendarScreen()}
                    subsequent.setOnClickListener{
                        if(selectedIndex>=0){
                            val toRemove=appointments.filter{it.seriesId==a.seriesId && (it.date.isAfter(a.date) || (it.date==a.date && it.time>=a.time))}
                            toRemove.forEach{registerDeletedRegularAppointment(it)}
                            appointments.removeAll{it.id in toRemove.map{r->r.id}.toSet()}
                        }
                        saveData();seqDialog.dismiss();calendarScreen()
                    }
                    all.setOnClickListener{val toRemove=appointments.filter{it.seriesId==a.seriesId};toRemove.forEach{registerDeletedRegularAppointment(it)};appointments.removeAll{it.id in toRemove.map{r->r.id}.toSet()};saveData();seqDialog.dismiss();calendarScreen()}
                    cancelSeq.setOnClickListener{seqDialog.dismiss()}
                }
                seqDialog.show()
            }else{
                AlertDialog.Builder(this)
                    .setTitle("Elimina appuntamento?")
                    .setMessage("Vuoi eliminare questo appuntamento?")
                    .setNegativeButton("ANNULLA",null)
                    .setPositiveButton("ELIMINA"){_,_->registerDeletedRegularAppointment(a);appointments.remove(a);saveData();calendarScreen()}
                    .create().also{styleOneUiDialog(it);it.show()}
            }
        };cancel.setOnClickListener{dialog.dismiss()}}
        dialog.show()
    }

    private fun styleFullPageCoachDialog(dialog:AlertDialog){
        dialog.setOnShowListener{
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28))
            dialog.window?.setDimAmount(0.40f)
            dialog.window?.let{w->
                val metrics=resources.displayMetrics
                w.setLayout((metrics.widthPixels*0.92f).toInt(),(metrics.heightPixels*0.82f).toInt())
                w.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
                // La finestra resta ferma, mentre la pagina interna è realmente scrollabile
                // anche quando il contenuto, a tastiera chiusa, sarebbe più corto del viewport.
                fun prepareScroll(v:View){
                    if(v is ScrollView){
                        v.isFillViewport=true
                        v.clipToPadding=false
                        v.setPadding(0,dp(76),0,dp(76))
                        val child=v.getChildAt(0)
                        if(child!=null){
                            v.post{
                                val extra=dp(152)
                                child.minimumHeight=maxOf(child.measuredHeight,v.height+extra)
                            }
                        }
                    }
                    if(v is ViewGroup){
                        for(i in 0 until v.childCount) prepareScroll(v.getChildAt(i))
                    }
                }
                w.decorView.post{prepareScroll(w.decorView)}
            }
        }
    }

    private fun styleModernCoachDialog(dialog:AlertDialog){
        dialog.setOnShowListener{
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28))
            dialog.window?.setDimAmount(0.40f)
            dialog.window?.let{w->
                val metrics=resources.displayMetrics
                w.setLayout((metrics.widthPixels*0.92f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT)
                w.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
            }
            dialog.findViewById<TextView>(resources.getIdentifier("alertTitle","id","android"))?.apply{
                textSize=22f
                gravity=Gravity.CENTER
                textAlignment=View.TEXT_ALIGNMENT_CENTER
                setTextColor(Color.rgb(28,30,33))
                setTypeface(null,android.graphics.Typeface.NORMAL)
                layoutParams = (layoutParams ?: ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT)).apply {
                    width = ViewGroup.LayoutParams.MATCH_PARENT
                    gravity = Gravity.CENTER
                }
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.apply{setTextColor(Color.rgb(0,125,110));setAllCaps(false);stateListAnimator=null}
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.apply{setTextColor(Color.rgb(0,125,110));setAllCaps(false);stateListAnimator=null}
        }
    }

    private fun styleOneUiDialog(dialog:AlertDialog){
        dialog.setOnShowListener{
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28))
            dialog.window?.setDimAmount(0.38f)
            dialog.findViewById<TextView>(resources.getIdentifier("alertTitle","id","android"))?.apply{
                textSize=22f
                gravity=Gravity.CENTER
                textAlignment=View.TEXT_ALIGNMENT_CENTER
                setTextColor(Color.rgb(28,30,33))
                setTypeface(null,android.graphics.Typeface.NORMAL)
                setPadding(0,dp(2),0,dp(2))
                layoutParams = (layoutParams ?: ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT)).apply {
                    width = ViewGroup.LayoutParams.MATCH_PARENT
                    gravity = Gravity.CENTER
                }
            }
            dialog.findViewById<TextView>(android.R.id.message)?.apply{
                textSize=16f
                setTextColor(Color.rgb(55,58,63))
                setLineSpacing(0f,1.05f)
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.apply{setTextColor(Color.rgb(0,125,110));setAllCaps(false);stateListAnimator=null;minHeight=0;minimumHeight=0}
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.apply{setTextColor(Color.rgb(0,125,110));setAllCaps(false);stateListAnimator=null;minHeight=0;minimumHeight=0}
        }
    }

    private fun appointmentDialog(existing:Appointment?, forcedDay:LocalDate?=null, forcedTime:String?=null){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(4),dp(14),0)}
        val name=AutoCompleteTextView(this).apply{hint="Cognome e Nome";setText(existing?.name?:"");setSingleLine(true);setAdapter(ArrayAdapter(this@MainActivity,android.R.layout.simple_dropdown_item_1line,(packs.map{it.name}+sessionPacks.map{it.name}).distinct().toTypedArray()))}
        val date=modernEditText().apply{hint="Data (gg/mm/aaaa)";inputType=2;setText((existing?.date?:forcedDay?:calendarWeekStart).format(fmt))};setupDateInput(date)
        val time=Spinner(this)
        val type=Spinner(this);type.adapter=centeredSpinnerAdapter(appointmentTypes.map{it.name});type.setSelection(existing?.let{typeIndex(it.type)}?:0)
        var seriesEdit: Button? = null
        if(existing!=null && existing.seriesId!=0L){
            seriesEdit=Button(this).apply{
                text="🔄 Modifica programmazione";setAllCaps(false);textSize=15f;gravity=Gravity.CENTER_VERTICAL;setTextColor(Color.rgb(35,105,180))
                background=roundedSurface(Color.rgb(232,242,255),18,Color.rgb(185,210,238),1);stateListAnimator=null
            }
            box.addView(seriesEdit,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,dp(8),0,dp(4))})
        }
        var recovery: CheckBox? = null

        // Mantieni aggiornata la fascia oraria disponibile anche nella nuova UI compatta.
        fun refreshTimeSlots(){
            val selectedType=typeIdAt(type.selectedItemPosition)
            val selectedDate=runCatching{parseDate(date.text.toString())}.getOrNull()?: (existing?.date?:forcedDay?:calendarWeekStart)
            val slots=availableTimeSlots(selectedDate,selectedType,existing)
            val values=if(slots.isEmpty()) listOf("NESSUNA FASCIA DISPONIBILE") else slots
            time.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,values)
            val wanted=existing?.time?:forcedTime
            if(wanted!=null){val idx=values.indexOf(wanted);if(idx>=0)time.setSelection(idx)}
        }

        fun refreshRecoveryOption(){
            if(existing!=null || recovery==null) return
            val selectedDate=runCatching{parseDate(date.text.toString())}.getOrNull() ?: LocalDate.now()
            val possiblePack=regularPackFor(name.text.toString(),selectedDate)
            val pending=possiblePack?.let{recoveriesForPack(it)} ?: 0
            recovery!!.isChecked=false
            recovery!!.isEnabled=pending>0
            recovery!!.visibility=if(pending>0)View.VISIBLE else View.GONE
            if(pending>0) recovery!!.text="↩ Recupero seduta persa ($pending disponibile/i)"
        }

        if(existing==null){
            // Creazione appuntamento: UI compatta e moderna. La logica di calendario/ripetizione resta invariata.
            val page=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(14),dp(18),dp(12))}
            val scroll=ScrollView(this).apply{isFillViewport=true;clipToPadding=false;setPadding(0,0,0,dp(24))}
            scroll.addView(page,ViewGroup.LayoutParams(-1,-2))

            val header=LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
                setPadding(dp(14),dp(10),dp(14),dp(10))
                background=roundedSurface(Color.rgb(238,246,255),22,Color.rgb(200,222,246),1)
            }
            val icon=TextView(this).apply{
                text="📅";textSize=23f;gravity=Gravity.CENTER
                background=roundedSurface(Color.WHITE,18)
                setPadding(dp(8),dp(7),dp(8),dp(7))
            }
            header.addView(icon,LinearLayout.LayoutParams(dp(50),dp(50)))
            val headerText=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),0,0,0)}
            headerText.addView(TextView(this).apply{
                text="Nuovo appuntamento";textSize=18f;setTextColor(Color.rgb(25,55,85));setTypeface(null,android.graphics.Typeface.BOLD)
            })
            headerText.addView(TextView(this).apply{
                text="Aggiungi un nuovo appuntamento al calendario";textSize=12.5f;setTextColor(Color.rgb(82,104,125));setPadding(0,dp(3),0,0)
            })
            header.addView(headerText,LinearLayout.LayoutParams(0,-2,1f))
            page.addView(header,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})

            fun modernSpinner(spinner:Spinner){
                spinner.background=roundedSurface(Color.rgb(248,249,251),18,Color.rgb(220,226,234),1)
                spinner.setPadding(dp(14),0,dp(10),0)
            }
            name.background=roundedSurface(Color.rgb(248,249,251),18,Color.rgb(220,226,234),1)
            name.setPadding(dp(14),0,dp(14),0)
            name.textSize=16f
            name.setTextColor(Color.rgb(35,38,42))
            name.setHintTextColor(Color.rgb(135,140,147))
            name.isFocusable=true;name.isFocusableInTouchMode=true
            modernSpinner(time);modernSpinner(type)
            val fields=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
            fields.addView(TextView(this).apply{text="Cognome e Nome";textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,74,80));setPadding(dp(2),0,0,dp(5))})
            fields.addView(name,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(10))})
            fields.addView(TextView(this).apply{text="Data";textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,74,80));setPadding(dp(2),0,0,dp(5))})
            fields.addView(date,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(10))})
            fields.addView(TextView(this).apply{text="Fascia oraria disponibile";textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,74,80));setPadding(dp(2),0,0,dp(5))})
            fields.addView(time,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(10))})
            fields.addView(TextView(this).apply{text="Tipo allenamento";textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,74,80));setPadding(dp(2),0,0,dp(5))})
            fields.addView(type,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(10))})
            page.addView(fields)
            recovery=CheckBox(this).apply{
                text="↩ Recupero seduta persa";textSize=13.5f;setTextColor(Color.rgb(55,58,63));setPadding(0,0,0,0);visibility=View.GONE
            }
            page.addView(recovery,LinearLayout.LayoutParams(-1,dp(44)).apply{setMargins(dp(2),0,0,dp(2))})

            val repeat=CheckBox(this).apply{
                text="Ripeti ogni settimana";textSize=14f;setTextColor(Color.rgb(35,38,42));setPadding(0,0,0,0)
            }
            val repeatRow=LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
                setPadding(dp(12),dp(7),dp(10),dp(7))
                background=roundedSurface(Color.rgb(248,249,251),18,Color.rgb(220,226,234),1)
                addView(repeat,LinearLayout.LayoutParams(0,dp(48),1f))
            }
            page.addView(repeatRow,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})

            val repeatPanel=LinearLayout(this).apply{
                orientation=LinearLayout.VERTICAL;visibility=View.GONE
                setPadding(dp(12),dp(10),dp(12),dp(10))
                background=roundedSurface(Color.rgb(238,246,255),20,Color.rgb(205,225,247),1)
            }
            repeatPanel.addView(TextView(this).apply{
                text="Seleziona giorni e orari";textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,75,125));setPadding(0,0,0,dp(7))
            })
            val days=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
            val checks=(0..6).map{i->CheckBox(this).apply{text=dayShort(i);isChecked=i==((forcedDay?:calendarWeekStart).dayOfWeek.value-1);setPadding(0,0,0,0)}}
            val dayTimes=mutableMapOf<Int,Spinner>()
            val dayRows=mutableMapOf<Int,LinearLayout>()
            fun datesForWeekday(dayIndex:Int,start:LocalDate,end:LocalDate):List<LocalDate>{
                val out=mutableListOf<LocalDate>();var d=start
                while(!d.isAfter(end)){if(d.dayOfWeek.value-1==dayIndex)out.add(d);d=d.plusDays(1)}
                return out
            }
            fun slotsForWeekday(dayIndex:Int,start:LocalDate,end:LocalDate,selectedType:String):List<String>{
                val dates=datesForWeekday(dayIndex,start,end);if(dates.isEmpty())return emptyList()
                val first=availableTimeSlots(dates.first(),selectedType,existing)
                return first.filter{slot->dates.all{d->canAdd(d,slot,selectedType,if(existing?.date==d)existing else null)}}
            }
            val end=modernEditText().apply{hint="Fine ripetizione (gg/mm/aaaa)";inputType=2;setText(calendarWeekStart.plusWeeks(12).format(fmt));visibility=View.GONE};setupDateInput(end)
            repeatPanel.addView(days)
            repeatPanel.addView(end,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(8),0,0)})
            page.addView(repeatPanel,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})
            checks.forEachIndexed{idx,c->
                val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                row.addView(c,LinearLayout.LayoutParams(0,dp(48),1f))
                val spinner=Spinner(this);modernSpinner(spinner);dayTimes[idx]=spinner
                row.addView(spinner,LinearLayout.LayoutParams(dp(150),dp(46)))
                dayRows[idx]=row;days.addView(row)
            }
            fun refreshDayTimeRows(){
                val startDate=runCatching{parseDate(date.text.toString())}.getOrNull()?:calendarWeekStart
                val endDate=runCatching{parseDate(end.text.toString())}.getOrNull()?:startDate
                val selectedType=typeIdAt(type.selectedItemPosition)
                checks.forEachIndexed{idx,c->
                    val row=dayRows[idx]?:return@forEachIndexed;val spinner=dayTimes[idx]?:return@forEachIndexed
                    // I sette giorni restano sempre visibili: solo l'orario viene mostrato
                    // quando il relativo giorno è selezionato.
                    row.visibility=View.VISIBLE
                    spinner.visibility=if(c.isChecked)View.VISIBLE else View.INVISIBLE
                    spinner.isEnabled=c.isChecked
                    if(!c.isChecked)return@forEachIndexed
                    val values=slotsForWeekday(idx,startDate,endDate,selectedType);val shown=if(values.isEmpty())listOf("NESSUNA FASCIA DISPONIBILE") else values
                    spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,shown)
                    val preferred=if(idx==((forcedDay?:calendarWeekStart).dayOfWeek.value-1))time.selectedItem?.toString()else null
                    if(preferred!=null){val pi=shown.indexOf(preferred);if(pi>=0)spinner.setSelection(pi)}
                    spinner.isEnabled=values.isNotEmpty()
                }
            }
            // Listener collegati dopo la dichiarazione della funzione locale: evita riferimenti non risolti in Kotlin.
            checks.forEach{c->c.setOnCheckedChangeListener{_,_->refreshDayTimeRows()}}
            type.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{
                override fun onNothingSelected(parent:AdapterView<*>?){ }
                override fun onItemSelected(parent:AdapterView<*>?,view:View?,position:Int,id:Long){
                    refreshTimeSlots()
                    if(repeat.isChecked) refreshDayTimeRows()
                }
            }
            var dialogRef:AlertDialog?=null
            repeat.setOnCheckedChangeListener{_,checked->
                repeatPanel.visibility=if(checked)View.VISIBLE else View.GONE
                end.visibility=if(checked)View.VISIBLE else View.GONE
                time.visibility=if(checked)View.GONE else View.VISIBLE
                recovery?.visibility=if(checked)View.GONE else if(recovery?.isEnabled==true)View.VISIBLE else View.GONE
                refreshDayTimeRows()
                dialogRef?.window?.let{w->
                    val target=if(checked)ViewGroup.LayoutParams.WRAP_CONTENT else ViewGroup.LayoutParams.WRAP_CONTENT
                    w.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),target)
                }
                if(checked){
                    repeatPanel.alpha=0f
                    repeatPanel.translationY=-dp(10).toFloat()
                    repeatPanel.animate().alpha(1f).translationY(0f).setDuration(180).start()
                    // Dopo l'espansione porta automaticamente la nuova sezione in vista,
                    // lasciando comunque lo ScrollView libero di muoversi in entrambe le direzioni.
                    scroll.postDelayed({
                        val target=(repeatPanel.top-dp(12)).coerceAtLeast(0)
                        scroll.smoothScrollTo(0,target)
                    },220)
                } else {
                    scroll.post{scroll.smoothScrollTo(0,0)}
                }
            }
            date.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){refreshTimeSlots();if(repeat.isChecked)refreshDayTimeRows();refreshRecoveryOption()};override fun afterTextChanged(s:Editable?){}})
            name.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){refreshRecoveryOption()};override fun afterTextChanged(s:Editable?){}})
            end.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){if(repeat.isChecked)refreshDayTimeRows()};override fun afterTextChanged(s:Editable?){}})

            val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            val cancel=TextView(this).apply{text="Annulla";textSize=14f;setTextColor(Color.rgb(20,91,165));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);background=roundedSurface(Color.rgb(248,249,251),18,Color.rgb(220,226,234),1);isClickable=true}
            val save=TextView(this).apply{text="Salva";textSize=14f;setTextColor(Color.WHITE);gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);background=roundedSurface(Color.rgb(30,112,230),18,Color.rgb(30,112,230),1);isClickable=true}
            actions.addView(cancel,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(6),0)})
            actions.addView(save,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(6),0,0,0)})
            page.addView(actions,LinearLayout.LayoutParams(-1,dp(48)))
            page.setPadding(dp(18),dp(14),dp(18),dp(24))

            listOf<View>(name,date,end).forEach{field->field.setOnFocusChangeListener{_,hasFocus->if(hasFocus)scroll.post{scroll.smoothScrollTo(0,(field.top-dp(24)).coerceAtLeast(0))}}}
            val dialog=AlertDialog.Builder(this).setView(scroll).create()
            dialog.setOnShowListener{
                dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28));dialog.window?.setDimAmount(0.40f)
                dialog.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
                dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT)
                name.clearFocus();date.clearFocus();end.clearFocus()
            }
            cancel.setOnClickListener{dialog.dismiss()}
            save.setOnClickListener{
                val selectedDayTimes=dayTimes.filterKeys{checks[it].isChecked}.mapValues{it.value.selectedItem?.toString() ?: ""}
                createAppointments(name.text.toString().trim(),date.text.toString(),time.selectedItem?.toString() ?: "",typeIdAt(type.selectedItemPosition),repeat.isChecked,checks,end.text.toString(),recovery?.isChecked==true,dayTimes=selectedDayTimes)
                dialog.dismiss()
            }
            dialogRef=dialog
            dialog.show()
            refreshTimeSlots()
            refreshRecoveryOption()
            refreshDayTimeRows()
        }else{
            val page=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(8),dp(18),dp(10))}
            val scroll=ScrollView(this).apply{isFillViewport=true;clipToPadding=false;addView(page,ViewGroup.LayoutParams(-1,-2))}
            page.addView(TextView(this).apply{text="Modifica appuntamento";textSize=23f;setTextColor(Color.rgb(24,27,31));setPadding(dp(2),dp(2),dp(2),dp(10))},LinearLayout.LayoutParams(-1,dp(50)))
            page.addView(box,LinearLayout.LayoutParams(-1,-2))
            val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            val cancel=TextView(this).apply{text="ANNULLA";textSize=14f;setTextColor(Color.rgb(0,125,110));gravity=Gravity.CENTER;isClickable=true}
            val save=TextView(this).apply{text="SALVA";textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(0,125,110));gravity=Gravity.CENTER;isClickable=true}
            actions.addView(cancel,LinearLayout.LayoutParams(0,dp(48),1f));actions.addView(save,LinearLayout.LayoutParams(0,dp(48),1f));page.addView(actions,LinearLayout.LayoutParams(-1,dp(52)))
            listOf<View>(name,date).forEach{field->field.setOnFocusChangeListener{_,hasFocus->if(hasFocus)scroll.post{scroll.smoothScrollTo(0,(field.top-dp(20)).coerceAtLeast(0))}}}
            val dialog=AlertDialog.Builder(this).setView(scroll).create();styleFullPageCoachDialog(dialog)
            cancel.setOnClickListener{dialog.dismiss()}
            save.setOnClickListener{updateAppointment(existing,name.text.toString().trim(),date.text.toString(),time.selectedItem?.toString() ?: "",typeIdAt(type.selectedItemPosition));dialog.dismiss()}
            dialog.show();seriesEdit?.setOnClickListener{dialog.dismiss();editSeriesProgramming(existing!!)}
        }
    }

    private fun editSeriesProgramming(anchor:Appointment){
        val seriesId=anchor.seriesId
        if(seriesId==0L)return
        val series=appointments.filter{it.seriesId==seriesId}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        if(series.isEmpty())return
        val future=series.filter{!it.date.isBefore(anchor.date)}
        if(future.isEmpty())return
        val endDate=series.maxOf{it.date}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(2),dp(14),0)}
        box.addView(TextView(this).apply{text="Modifica da ${anchor.date.format(fmt)} in poi";textSize=13.5f;setTextColor(Color.rgb(92,96,102));setPadding(0,0,0,dp(10))})
        box.addView(TextView(this).apply{text="Scegli i giorni e gli orari della nuova programmazione";textSize=14f;setTextColor(Color.rgb(55,58,63));setPadding(0,0,0,dp(6))})
        val type=Spinner(this).apply{adapter=centeredSpinnerAdapter(appointmentTypes.map{it.name});setSelection(typeIndex(anchor.type))}
        box.addView(TextView(this).apply{text="Tipo allenamento";textSize=13f;setTextColor(Color.DKGRAY);setPadding(0,dp(6),0,dp(2))})
        box.addView(type)
        val days=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val checks=(0..6).map{i->CheckBox(this).apply{text=dayShort(i);setPadding(0,0,0,0);isChecked=future.any{it.date.dayOfWeek.value-1==i}}}
        val dayTimes=mutableMapOf<Int,Spinner>()
        val rows=mutableMapOf<Int,LinearLayout>()
        fun datesForDay(dayIndex:Int):List<LocalDate>{
            val out=mutableListOf<LocalDate>();var d=anchor.date
            while(!d.isAfter(endDate)){if(d.dayOfWeek.value-1==dayIndex)out.add(d);d=d.plusDays(1)}
            return out
        }
        fun availableSeriesSlots(dayIndex:Int,selectedType:String):List<String>{
            val dates=datesForDay(dayIndex)
            if(dates.isEmpty())return emptyList()
            val first=availableTimeSlotsAfterSeriesRemoval(dates.first(),selectedType,seriesId)
            return first.filter{slot->dates.all{d->canAddAfterSeriesRemoval(d,slot,selectedType,seriesId)}}
        }
        fun refresh(){
            val selectedType=typeIdAt(type.selectedItemPosition)
            checks.forEachIndexed{idx,c->
                val spinner=dayTimes[idx] ?: return@forEachIndexed
                spinner.visibility=if(c.isChecked)View.VISIBLE else View.GONE
                if(!c.isChecked)return@forEachIndexed
                val values=availableSeriesSlots(idx,selectedType)
                val shown=if(values.isEmpty())listOf("NESSUNA FASCIA DISPONIBILE") else values
                spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,shown)
                val preferred=future.firstOrNull{it.date.dayOfWeek.value-1==idx}?.time
                if(preferred!=null){val pi=shown.indexOf(preferred);if(pi>=0)spinner.setSelection(pi)}
                spinner.isEnabled=values.isNotEmpty()
            }
        }
        checks.forEachIndexed{idx,c->
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            row.addView(c,LinearLayout.LayoutParams(0,dp(50),1f))
            val spinner=Spinner(this);dayTimes[idx]=spinner
            row.addView(spinner,LinearLayout.LayoutParams(dp(155),dp(48)))
            rows[idx]=row;days.addView(row)
            c.setOnCheckedChangeListener{_,_->refresh()}
        }
        box.addView(TextView(this).apply{text="Giorni";textSize=13f;setTextColor(Color.DKGRAY);setPadding(0,dp(10),0,dp(2))})
        box.addView(days)
        box.addView(TextView(this).apply{text="Fine programmazione: ${endDate.format(fmt)}";textSize=13f;setTextColor(Color.rgb(92,96,102));setPadding(0,dp(8),0,dp(4))})
        val page=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(8),dp(18),dp(10))}
        val scroll=ScrollView(this).apply{isFillViewport=true;clipToPadding=false;addView(page,ViewGroup.LayoutParams(-1,-2))}
        page.addView(TextView(this).apply{text="Modifica programmazione";textSize=23f;setTextColor(Color.rgb(24,27,31));setPadding(dp(2),dp(2),dp(2),dp(10))},LinearLayout.LayoutParams(-1,dp(50)))
        page.addView(box,LinearLayout.LayoutParams(-1,-2))
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val cancel=TextView(this).apply{text="ANNULLA";textSize=14f;setTextColor(Color.rgb(0,125,110));gravity=Gravity.CENTER;isClickable=true}
        val save=TextView(this).apply{text="SALVA";textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(0,125,110));gravity=Gravity.CENTER;isClickable=true}
        actions.addView(cancel,LinearLayout.LayoutParams(0,dp(48),1f));actions.addView(save,LinearLayout.LayoutParams(0,dp(48),1f));page.addView(actions,LinearLayout.LayoutParams(-1,dp(52)))
        type.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(parent:AdapterView<*>?){ } override fun onItemSelected(parent:AdapterView<*>?,view:View?,position:Int,id:Long){refresh()}}
        val dialog=AlertDialog.Builder(this).setView(scroll).create();styleFullPageCoachDialog(dialog)
        cancel.setOnClickListener{dialog.dismiss()}
        save.setOnClickListener{
            val selected=checks.mapIndexedNotNull{idx,c->if(c.isChecked)idx else null}
            if(selected.isEmpty()){Toast.makeText(this,"Seleziona almeno un giorno.",Toast.LENGTH_LONG).show();return@setOnClickListener}
            val selectedType=typeIdAt(type.selectedItemPosition)
            val times=selected.associateWith{idx->dayTimes[idx]?.selectedItem?.toString()?.takeUnless{it=="NESSUNA FASCIA DISPONIBILE"}}
            if(times.values.any{it==null}){Toast.makeText(this,"Scegli un orario disponibile per ogni giorno selezionato.",Toast.LENGTH_LONG).show();return@setOnClickListener}
            applySeriesProgrammingFrom(anchor,selected,times.mapValues{it.value!!},selectedType,endDate);dialog.dismiss()
        }
        dialog.show();refresh()
    }

    private fun availableTimeSlotsAfterSeriesRemoval(date:LocalDate,type:String,seriesId:Long):List<String>{
        return (0 until 20).map{slot -> val mins=7*60+slot*45; String.format("%02d:%02d",mins/60,mins%60)}.filter{slot->canAddAfterSeriesRemoval(date,slot,type,seriesId)}
    }

    private fun canAddAfterSeriesRemoval(date:LocalDate,time:String,type:String,seriesId:Long):Boolean{
        val r=calendarRoutines.getOrNull(activeRoutineIndex)?:CalendarRoutine("Personalizzata",3,MutableList(appointmentTypes.size){3})
        val items=appointments.filter{it.date==date&&it.time==time&&it.seriesId!=seriesId}
        if(items.size>=r.maxTotal)return false
        val idx=typeIndex(type);if(items.count{typeIndex(it.type)==idx}>=(r.maxByType.getOrNull(idx)?:r.maxTotal))return false
        return true
    }

    private fun applySeriesProgrammingFrom(anchor:Appointment,selectedDays:List<Int>,dayTimes:Map<Int,String>,type:String,endDate:LocalDate){
        val seriesId=anchor.seriesId
        val future=appointments.filter{it.seriesId==seriesId&&!it.date.isBefore(anchor.date)}
        if(future.isEmpty())return
        val sessionPackId=future.firstOrNull{it.sessionPackId!=0L}?.sessionPackId ?: anchor.sessionPackId
        val futureIds=future.map{it.id}.toSet()
        appointments.removeAll{it.id in futureIds}
        var d=anchor.date;var created=0;var skipped=0
        val linked=sessionPackId.takeIf{it!=0L}?.let{id->sessionPacks.firstOrNull{it.id==id}}
        val usedBefore=linked?.let{s->sessionBooked(s)}?:0
        while(!d.isAfter(endDate)){
            val idx=d.dayOfWeek.value-1
            if(idx in selectedDays){
                val t=dayTimes[idx]!!
                val capacityOk=canAdd(d,t,type)
                val packageOk=linked==null||usedBefore+created<linked.totalSessions
                if(capacityOk&&packageOk){appointments.add(Appointment(nextAppointmentId++,anchor.name,d,t,type,seriesId,sessionPackId,anchor.recovery));created++}else skipped++
            }
            d=d.plusDays(1)
        }
        saveData();calendarScreen()
        if(skipped>0)Toast.makeText(this,"$skipped appuntamenti non inseriti perché la fascia o il pacchetto non erano disponibili.",Toast.LENGTH_LONG).show()
    }

    private fun dayShort(i:Int)=arrayOf("Lunedì","Martedì","Mercoledì","Giovedì","Venerdì","Sabato","Domenica")[i]
    private fun createAppointments(name:String,dateText:String,timeText:String,type:String,repeat:Boolean,checks:List<CheckBox>,endText:String,recovery:Boolean=false,allowWarnings:Boolean=false,dayTimes:Map<Int,String>?=null){
        try{
            val cleanName=normalizeDisplayName(name);require(cleanName.isNotEmpty());val start=parseDate(dateText);val time=normalizeTime(timeText);val linked=if(recovery)null else activeSessionPackFor(cleanName)
            if(recovery){
                val rp=regularPackFor(cleanName,start) ?: throw IllegalArgumentException("Nessun recupero disponibile")
                if(repeat || recoveriesForPack(rp)<=0) throw IllegalArgumentException("Nessun recupero disponibile")
            }
            if(!allowWarnings){
                val duplicateDates=if(repeat){
                    val end=runCatching{parseDate(endText)}.getOrNull()?:start
                    val selected=checks.mapIndexedNotNull{idx,c->if(c.isChecked)idx+1 else null}.toSet()
                    appointments.filter{identityKey(it.name)==identityKey(cleanName)&&selected.contains(it.date.dayOfWeek.value)&&!it.date.isBefore(start)&&!it.date.isAfter(end)}.map{it.date}.distinct().sorted()
                }else appointments.filter{identityKey(it.name)==identityKey(cleanName)&&it.date==start}.map{it.date}
                if(duplicateDates.isNotEmpty()){
                    val first=appointments.filter{identityKey(it.name)==identityKey(cleanName)&&duplicateDates.contains(it.date)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time}).first()
                    AlertDialog.Builder(this).setTitle("⚠️ Appuntamento già presente").setMessage(if(repeat)"$cleanName ha già appuntamenti in ${duplicateDates.size} giorno/i della ripetizione. Primo trovato: ${first.date.format(fmt)} alle ${first.time}. Vuoi comunque crearli?" else "$cleanName ha già un appuntamento il ${first.date.format(fmt)} alle ${first.time}. Vuoi comunque creare un altro appuntamento oggi?").setNegativeButton("ANNULLA",null).setPositiveButton("CREA COMUNQUE"){_,_->createAppointments(cleanName,dateText,timeText,type,repeat,checks,endText,recovery,true,dayTimes)}.show()
                    return
                }
                if(linked!=null){
                    val remaining=linked.totalSessions-sessionBooked(linked)
                    val potential=if(!repeat)1 else run {
                        val end=runCatching{parseDate(endText)}.getOrNull()?:start
                        val selected=checks.mapIndexedNotNull{idx,c->if(c.isChecked)idx+1 else null}.toSet()
                        var d=start;var count=0
                        while(!d.isAfter(end)){
                            if(selected.contains(d.dayOfWeek.value)){
                                val dayTime=dayTimes?.get(d.dayOfWeek.value-1)?.let{normalizeTime(it)} ?: time
                                if(canAdd(d,dayTime,type))count++
                            }
                            d=d.plusDays(1)
                        }
                        count
                    }
                    if(remaining>0&&potential>=remaining){
                        AlertDialog.Builder(this).setTitle("⚠️ Ultima seduta del pacchetto").setMessage("Questa prenotazione utilizzerà l'ultima seduta disponibile di $cleanName. Dopo questa prenotazione il pacchetto risulterà scaduto. Vuoi continuare?").setNegativeButton("ANNULLA",null).setPositiveButton("CONTINUA"){_,_->createAppointments(cleanName,dateText,timeText,type,repeat,checks,endText,recovery,true,dayTimes)}.show()
                        return
                    }
                }
            }
            if(!repeat){
                if(!canAdd(start,time,type))throw IllegalArgumentException("Fascia piena")
                if(linked!=null&&sessionBooked(linked)>=linked.totalSessions)throw IllegalArgumentException("Pacchetto sedute pieno")
                appointments.add(Appointment(nextAppointmentId++,cleanName,start,time,type,0L,linked?.id?:0L,recovery));saveData();calendarScreen();return
            }
            val end=parseDate(endText);require(!end.isBefore(start));val selected=checks.mapIndexedNotNull{idx,c->if(c.isChecked)idx+1 else null};require(selected.isNotEmpty())
            val series=nextAppointmentId;var d=start;var count=0;var sessionAdded=0
            while(!d.isAfter(end)){
                if(selected.contains(d.dayOfWeek.value)){
                    val dayTime=dayTimes?.get(d.dayOfWeek.value-1)?.let{normalizeTime(it)} ?: time
                    if(linked!=null&&sessionBooked(linked)+sessionAdded>=linked.totalSessions){count++;d=d.plusDays(1);continue}
                    if(canAdd(d,dayTime,type)){appointments.add(Appointment(nextAppointmentId++,cleanName,d,dayTime,type,series,linked?.id?:0L,recovery));sessionAdded++}else count++
                }
                d=d.plusDays(1)
            }
            saveData();calendarScreen();if(count>0)Toast.makeText(this,"$count ripetizioni non inserite perché la fascia o il pacchetto sedute non erano disponibili.",Toast.LENGTH_LONG).show()
        }catch(e:Exception){Toast.makeText(this,if(e.message=="Fascia piena")"Fascia non disponibile: massimo 3 persone e massimo 2 allenamenti." else "Controlla cliente, data, ora e ripetizione.",Toast.LENGTH_LONG).show()}
    }

    private fun normalizeTime(value:String):String{val clean=value.trim();val parts=clean.split(":");require(parts.size==2);val h=parts[0].toInt();val m=parts[1].toInt();require(h in 7..21&&m in 0..59);require((h*60+m-7*60)%45==0);return String.format("%02d:%02d",h,m)}
    private fun updateAppointment(a:Appointment,name:String,dateText:String,timeText:String,type:String){
        try{
            val cleanName=normalizeDisplayName(name);require(cleanName.isNotEmpty());val date=parseDate(dateText);val time=normalizeTime(timeText)
            val duplicate=appointments.firstOrNull{it!==a&&it.date==date&&identityKey(it.name)==identityKey(cleanName)}
            if(duplicate!=null){
                AlertDialog.Builder(this).setTitle("⚠️ Appuntamento già presente").setMessage("$cleanName ha già un appuntamento il ${date.format(fmt)} alle ${duplicate.time}. Vuoi comunque spostare/modificare questo appuntamento?").setNegativeButton("ANNULLA",null).setPositiveButton("CONTINUA"){_,_->updateAppointmentConfirmed(a,cleanName,date,time,type)}.show();return
            }
            updateAppointmentConfirmed(a,cleanName,date,time,type)
        }catch(_:Exception){Toast.makeText(this,"Controlla i dati dell'appuntamento.",Toast.LENGTH_LONG).show()}
    }

    private fun updateAppointmentConfirmed(a:Appointment,name:String,date:LocalDate,time:String,type:String){
        if(!canAdd(date,time,type,a)){Toast.makeText(this,"Questa fascia non è disponibile.",Toast.LENGTH_LONG).show();return}
        var linked=if(a.sessionPackId!=0L)sessionPacks.firstOrNull{it.id==a.sessionPackId} else null
        if(linked==null)linked=activeSessionPackFor(name)
        if(linked!=null&&a.sessionPackId!=linked.id){
            val bookedWithoutThis=sessionBooked(linked)-if(a.sessionPackId==linked.id) 1 else 0
            if(bookedWithoutThis>=linked.totalSessions){Toast.makeText(this,"Il pacchetto sedute è già completo.",Toast.LENGTH_LONG).show();return}
            a.sessionPackId=linked.id
        }
        a.name=name;a.date=date;a.time=time;a.type=type;saveData();calendarScreen()
    }

    private fun appointmentDialogForSlot(day:LocalDate,time:String){appointmentDialog(null,day,time)}

    private fun availableTimeSlots(date:LocalDate,type:String,ignore:Appointment?=null):List<String>{
        return (0 until 20).map{slot->
            val mins=7*60+slot*45
            String.format("%02d:%02d",mins/60,mins%60)
        }.filter{slot->canAdd(date,slot,type,ignore)}
    }

    private fun canAdd(date:LocalDate,time:String,type:String,ignore:Appointment?=null):Boolean{
        val r=calendarRoutines.getOrNull(activeRoutineIndex)?:CalendarRoutine("Personalizzata",3,MutableList(appointmentTypes.size){3})
        val items=appointments.filter{it.date==date&&it.time==time&&it!==ignore}
        if(items.size>=r.maxTotal)return false
        val idx=typeIndex(type);if(items.count{typeIndex(it.type)==idx}>=(r.maxByType.getOrNull(idx)?:r.maxTotal))return false
        return true
    }

}
