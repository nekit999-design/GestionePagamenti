package com.example.gestionescadenze

import android.app.*
import android.content.Intent
import android.content.Context
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Color
import android.graphics.RectF
import android.graphics.LinearGradient
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Path
import android.net.Uri
import android.provider.MediaStore
import android.content.ContentValues
import android.provider.Settings
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.Paint
import android.graphics.Canvas
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import android.text.Editable
import android.text.TextWatcher
import java.io.BufferedReader
import java.io.InputStreamReader
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters
import kotlin.math.roundToInt

private data class Pack(var name: String, val start: LocalDate, val total: Int, var paid: Int = 0, var customRates: MutableList<Int>? = null, var packageType: String = "PERSONALIZZATO", var sessionTotal: Int = 12, var active: Boolean = true, var missedSessions: Int = 0)
private data class SessionPack(
    val id: Long,
    var name: String,
    val start: LocalDate,
    val totalSessions: Int,
    val cost: Int,
    var paid: Int = 0,
    var active: Boolean = true,
    var customRates: MutableList<Int>? = null
)
private data class TrashItem(val id:Long, val kind:String, val deletedAt:LocalDateTime, val payload:String)
private data class AppointmentType(var id:String, var name:String, var color:Int, var duration:Int = 45)
private data class CalendarRoutine(var name:String, var maxTotal:Int, var maxByType:MutableList<Int>)

private data class Appointment(
    val id: Long,
    var name: String,
    var date: LocalDate,
    var time: String,
    var type: String,
    var seriesId: Long = 0L,
    var sessionPackId: Long = 0L,
    var recovery: Boolean = false
) {
    val duration: Int get() = if (type == "TYPE2") 30 else 45
}

class MainActivity : Activity() {
    private val fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy")
    private val timeFmt = DateTimeFormatter.ofPattern("HH:mm")
    private val packs = mutableListOf<Pack>()
    private val sessionPacks = mutableListOf<SessionPack>()
    private val appointments = mutableListOf<Appointment>()
    private val trashItems = mutableListOf<TrashItem>()
    private var ferieStart: LocalDate? = null
    private var ferieEnd: LocalDate? = null
    private lateinit var list: LinearLayout
    private var dashboardEnabled = false
    private var homeSortMode = 0
    private lateinit var searchInput: EditText
    private lateinit var searchList: LinearLayout
    private var calendarWeekStart: LocalDate = LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    private var nextAppointmentId = 1L
    private var nextSessionPackId = 1L
    private var nextTrashId = 1L
    private var calendarZoom = 1.0f
    private var calendarVisibleDays = booleanArrayOf(true,true,true,true,true,false,false)
    private var calendarAutoFocusOnOpen = true
    private var calendarScrollX = 0
    private var calendarScrollY = 0
    private var calendarSwipeArmed = 0
    private var calendarWeekAnimationDirection = 0
    private var calendarNavPosition = 1 // legacy: 0 = sotto il titolo, 1 = in basso
    private var calendarNavOrder = mutableListOf("PREV", "SEARCH", "TODAY", "NEXT") // legacy
    private var calendarTopButtons = mutableListOf("APPT")
    private var calendarBottomButtons = mutableListOf("SEARCH", "TODAY", "PREV", "NEXT")
    private val appointmentTypes = mutableListOf(
        AppointmentType("TYPE1","ALLENAMENTO",Color.rgb(45,135,210),45),
        AppointmentType("TYPE2","MEZZ'ORA",Color.rgb(215,55,55),30)
    )
    private val calendarRoutines = mutableListOf(
        CalendarRoutine("Standard",3,mutableListOf(2,3)),
        CalendarRoutine("Light",2,mutableListOf(1,2)),
        CalendarRoutine("Full",4,mutableListOf(3,4))
    )
    private var activeRoutineIndex = 0
    private var surnameFirstDisplay = true
    private var pendingSummaryText = ""
    private val expandedClients = mutableSetOf<String>()
    private var activePackageDialog: AlertDialog? = null
    private var settingsTransitionPending = false
    private var settingsOverlay: FrameLayout? = null
    private var settingsOverlayContent: View? = null
    private var settingsSubpageOverlay: FrameLayout? = null
    private var trashReturnToSettings = false
    // Effetti visivi popup.
    // effect: NONE, SATIN, VETRO_SOFT, LIQUID; mode: CONTOUR (finestra nitida) o IMMERSIVE.
    private var popupBackdropEffect = "NONE"
    private var popupBackdropMode = "CONTOUR"
    private var popupBackdropIntensity = 65

    // Stili calendario: completamente separati dagli effetti delle finestre pop-up.
    private var calendarStyleSet = "LIQUID_GLASS"
    private var liquidGlassSlotShape = "ARROTONDATO"
    private var liquidGlassSlotColor = Color.rgb(224,228,232)
    private var nebbiaSoftSlotShape = "ARROTONDATO"
    private var scuroEleganteSlotShape = "RETTANGOLARE"
    private var nebbiaSoftSlotColor = Color.rgb(244,247,250)
    private var scuroEleganteSlotColor = Color.rgb(43,51,61)
    private var calendarMaterialEffect = "WATER"
    private var calendarMaterialIntensity = 75
    // Stile appuntamenti indipendente dallo stile degli slot grandi.
    private var appointmentStyleSet = "LIQUID_GLASS"
    private var appointmentShape = "ARROTONDATO"
    private var liquidGlassAppointmentShape = "ARROTONDATO"
    private var vetroSoft14AppointmentShape = "ARROTONDATO"
    private var satinato14AppointmentShape = "RETTANGOLARE"
    private var scuroElegante14AppointmentShape = "ARROTONDATO"
    private var popupBackdropOverlay: View? = null
    private var popupBackdropTarget: View? = null
    private var popupBackdropCurrentDialog: Dialog? = null
    private val popupBackdropDialogs = mutableListOf<Dialog>()
    private var popupDialogGlassOverlay: View? = null
    private val popupDialogOriginalBackgrounds = mutableMapOf<View, Drawable?>()
    private val popupDialogOriginalWindowBackgrounds = mutableMapOf<Dialog, Drawable?>()
    private var currentScreen = "HOME"

    private inner class CalendarHorizontalScrollView(context: Context) : HorizontalScrollView(context) {
        var onEdgeWeekChange: ((Int) -> Unit)? = null
        private var downX = 0f
        private var lastX = 0f
        private var edgeOverscroll = 0f
        private var edgeDirection = 0
        private var transitionSent = false
        private var edgeGesture = false
        private var touchChild: View? = null
        // Soglia ridotta: il cambio settimana deve scattare con uno swipe breve,
        // così non è necessario arrivare vicino al bordo fisico dello schermo.
        private val weekSwipeTriggerDp = 36

        private fun edgeState(): Int {
            val maxX = (getChildAt(0)?.width?.minus(width) ?: 0).coerceAtLeast(0)
            return when {
                scrollX <= dp(2) -> -1   // left edge: right swipe = previous week
                scrollX >= maxX - dp(2) -> 1 // right edge: left swipe = next week
                else -> 0
            }
        }

        private fun resetEdgeStretch(animate: Boolean) {
            val child = touchChild ?: getChildAt(0)
            if (animate) child?.animate()?.translationX(0f)?.setDuration(140)?.start()
            else child?.translationX = 0f
            edgeOverscroll = 0f
            edgeDirection = 0
            edgeGesture = false
        }

        override fun onInterceptTouchEvent(event: android.view.MotionEvent): Boolean {
            when (event.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    downX = event.x
                    lastX = event.x
                    edgeGesture = false
                    transitionSent = false
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    val dx = event.x - downX
                    val slop = android.view.ViewConfiguration.get(context).scaledTouchSlop
                    if (!edgeGesture && kotlin.math.abs(dx) > slop) {
                        val edge = edgeState()
                        val outward = (edge == -1 && dx > 0f) || (edge == 1 && dx < 0f)
                        if (outward) {
                            // Take ownership of the gesture as soon as an outward
                            // drag starts at an edge. This prevents child views from
                            // swallowing the gesture and makes the gesture work from
                            // the whole calendar surface, not only near the screen edge.
                            edgeGesture = true
                            lastX = event.x
                            touchChild = getChildAt(0)
                            touchChild?.animate()?.cancel()
                            touchChild?.translationX = 0f
                            return true
                        }
                    }
                }
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                    edgeGesture = false
                }
            }
            return if (edgeGesture) true else super.onInterceptTouchEvent(event)
        }

        override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
            val child = getChildAt(0)
            when (event.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    downX = event.x
                    lastX = event.x
                    edgeOverscroll = 0f
                    edgeDirection = 0
                    transitionSent = false
                    edgeGesture = false
                    touchChild = child
                    child?.animate()?.cancel()
                    child?.translationX = 0f
                }

                android.view.MotionEvent.ACTION_MOVE -> {
                    val dx = event.x - lastX
                    val edge = edgeState()

                    if (edgeGesture) {
                        val outward = (edge == -1 && dx > 0f) || (edge == 1 && dx < 0f)
                        if (outward && !transitionSent) {
                            val sign = if (dx > 0f) 1 else -1
                            if (edgeDirection == 0 || edgeDirection == sign) {
                                edgeDirection = sign
                                edgeOverscroll += kotlin.math.abs(dx)
                            } else {
                                edgeOverscroll = 0f
                                edgeDirection = sign
                            }

                            val resistance = 0.32f
                            val stretch = (edgeOverscroll * resistance).coerceAtMost(dp(54).toFloat())
                            child?.translationX = if (edge == -1) stretch else -stretch

                            if (edgeOverscroll >= dp(weekSwipeTriggerDp)) {
                                transitionSent = true
                                child?.animate()?.translationX(0f)?.setDuration(90)?.start()
                                // Physical direction is authoritative:
                                // right swipe at left edge -> previous week (-1)
                                // left swipe at right edge -> next week (+1)
                                onEdgeWeekChange?.invoke(if (edge == -1) -1 else 1)
                                edgeOverscroll = 0f
                                edgeDirection = 0
                            }
                        } else if (!transitionSent) {
                            edgeOverscroll = (edgeOverscroll - kotlin.math.abs(dx) * 1.5f).coerceAtLeast(0f)
                            val resistance = 0.32f
                            val stretch = (edgeOverscroll * resistance).coerceAtMost(dp(54).toFloat())
                            child?.translationX = if (edge == -1) stretch else -stretch
                        }
                        lastX = event.x
                        return true
                    }

                    lastX = event.x
                }

                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                    if (edgeGesture) {
                        if (!transitionSent) resetEdgeStretch(true) else resetEdgeStretch(false)
                        transitionSent = false
                        touchChild = null
                        return true
                    }
                }
            }
            return super.onTouchEvent(event)
        }
    }

    companion object {
        private const val REQ_EXPORT = 1001
        private const val REQ_IMPORT = 1002
        private const val REQ_SUMMARY = 1003
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        // CoachFlow usa una superficie edge-to-edge: lo sfondo dell'app continua
        // dietro status bar e barra di navigazione, mentre i contenuti ricevono
        // gli inset necessari per non finire sotto le barre di sistema.
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (android.os.Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(false)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        loadData()
        purgeExpiredTrash()
        saveData()
        maybeAutoBackup()
        build()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (settingsSubpageOverlay != null) {
            closeSettingsSubpage()
            return
        }
        if (trashReturnToSettings) {
            trashReturnToSettings = false
            settings()
            return
        }
        if (settingsOverlay != null) {
            settingsOverlay?.animate()?.cancel()
            settingsOverlayContent?.animate()?.cancel()
            detachSettingsOverlay()
            restoreHomeSystemBars()
            build()
            return
        }
        if (currentScreen == "CALENDAR") {
            build()
            return
        }
        super.onBackPressed()
    }

    private fun prepareEdgeToEdgeRoot(root: View) {
        val baseLeft = root.paddingLeft
        val baseTop = root.paddingTop
        val baseRight = root.paddingRight
        val baseBottom = root.paddingBottom
        root.setOnApplyWindowInsetsListener { v, insets ->
            val bars = if (android.os.Build.VERSION.SDK_INT >= 30) {
                insets.getInsets(android.view.WindowInsets.Type.systemBars())
            } else {
                android.graphics.Insets.of(
                    insets.systemWindowInsetLeft,
                    insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight,
                    insets.systemWindowInsetBottom
                )
            }
            v.setPadding(baseLeft, baseTop + bars.top, baseRight, baseBottom + bars.bottom)
            insets
        }
        root.requestApplyInsets()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()
    private fun dpf(value: Float): Float = value * resources.displayMetrics.density

    /**
     * Crea un vero livello "vetro" dietro la finestra popup.
     * La finestra/dialog rimane una Window separata e quindi resta perfettamente nitida.
     * Su Android 12+ il contenuto dell'Activity viene sfocato con RenderEffect;
     * sotto Android 12 manteniamo il fallback al solo dim nativo.
     */
    private fun popupBlurRadiusDp(): Int {
        val intensity = popupBackdropIntensity.coerceIn(0, 100) / 100f
        val base = when (popupBackdropEffect) {
            // Resa precedente, mantenuta invariata: ora si chiama Satinato.
            "SATIN" -> 24
            // Resa dell'attuale Liquid Glass, conservata e rinominata Vetro Soft.
            "VETRO_SOFT" -> 10
            // Nuovo Liquid Glass ultra-trasparente: vetro leggero, poca distorsione e massima leggibilità del fondo.
            "LIQUID" -> 4
            else -> 0
        }
        return (base * intensity).roundToInt().coerceIn(0, base)
    }

    private fun savePopupVisualPreferences() {
        getSharedPreferences("gestione_pagamenti", MODE_PRIVATE).edit()
            .putString("popupBackdropEffect", popupBackdropEffect)
            .putString("popupBackdropMode", popupBackdropMode)
            .putInt("popupBackdropIntensity", popupBackdropIntensity)
            .apply()
    }

    /** Applica la trasparenza immersiva alle superfici bianche interne, comprese quelle
     * contenute dentro ScrollView/NestedScrollView. I controlli interattivi restano invariati. */
    private fun applyImmersiveSurfaces(view: View) {
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) applyImmersiveSurfaces(view.getChildAt(i))
        }
        if (view is Button || view is EditText || view is Spinner || view is SeekBar ||
            view is RadioButton || view is CheckBox || view is AutoCompleteTextView) return
        val bg = view.background ?: return
        if (bg is android.graphics.drawable.GradientDrawable) {
            val c = bg.color?.defaultColor
            if (c != null && android.graphics.Color.red(c) >= 235 &&
                android.graphics.Color.green(c) >= 235 && android.graphics.Color.blue(c) >= 235) {
                // Solo la superficie: niente modifica ai bordi o ai colori dei controlli.
                bg.alpha = 150
            }
        } else if (bg is android.graphics.drawable.ColorDrawable) {
            val c = bg.color
            if (android.graphics.Color.red(c) >= 235 && android.graphics.Color.green(c) >= 235 &&
                android.graphics.Color.blue(c) >= 235) {
                bg.alpha = 150
            }
        }
    }

    private fun applyPopupBackdropEffect(currentDialog: Dialog? = popupBackdropCurrentDialog) {
        if (currentDialog != null && !popupBackdropDialogs.contains(currentDialog)) popupBackdropDialogs.add(currentDialog)
        popupBackdropCurrentDialog = currentDialog ?: popupBackdropDialogs.lastOrNull()
        val activeDialog = popupBackdropCurrentDialog
        if (popupBackdropEffect == "NONE") { clearPopupBackdropEffect(); return }

        val stackIndex = activeDialog?.let { popupBackdropDialogs.indexOf(it) } ?: -1
        val underlyingDialog = if (stackIndex > 0) popupBackdropDialogs[stackIndex - 1] else null
        val underlyingDecor = underlyingDialog?.window?.decorView as? ViewGroup
        val root: ViewGroup = underlyingDecor?.findViewById<ViewGroup>(android.R.id.content)
            ?: underlyingDecor
            ?: findViewById<ViewGroup>(android.R.id.content)
            ?: return

        clearPopupBackdropEffect()
        val target: View = root.getChildAt(0) ?: root
        popupBackdropTarget = target
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            val radius = popupBlurRadiusDp()
            if (radius > 0) target.setRenderEffect(android.graphics.RenderEffect.createBlurEffect(dp(radius).toFloat(), dp(radius).toFloat(), android.graphics.Shader.TileMode.CLAMP))
        }

        val intensity = popupBackdropIntensity.coerceIn(0,100) / 100f
        val satin = popupBackdropEffect == "SATIN"
        val softGlass = popupBackdropEffect == "VETRO_SOFT"
        val liquid = popupBackdropEffect == "LIQUID"
        val alpha = when {
            satin -> (52 * intensity).roundToInt().coerceIn(0,70)
            softGlass -> (28 * intensity).roundToInt().coerceIn(0,48)
            liquid -> (7 * intensity).roundToInt().coerceIn(0,16)
            else -> 0
        }
        val overlay = View(this).apply {
            background = when {
                satin -> android.graphics.drawable.ColorDrawable(android.graphics.Color.argb(alpha,248,251,255))
                softGlass -> {
                    val softA = alpha.coerceAtLeast(8)
                    android.graphics.drawable.GradientDrawable(
                        android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                        intArrayOf(
                            android.graphics.Color.argb(softA + 8, 190, 222, 255),
                            android.graphics.Color.argb(softA, 235, 247, 255),
                            android.graphics.Color.argb((softA * 0.45f).roundToInt(), 255, 255, 255)
                        )
                    )
                }
                liquid -> android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                    intArrayOf(
                        android.graphics.Color.argb(alpha + 4, 150, 205, 255),
                        android.graphics.Color.argb(alpha + 2, 230, 244, 255),
                        android.graphics.Color.argb((alpha * 0.12f).roundToInt(), 255, 255, 255),
                        android.graphics.Color.argb(alpha + 2, 190, 225, 255)
                    )
                )
                else -> null
            }
            isClickable=false; isFocusable=false
        }
        root.addView(overlay, 0, ViewGroup.LayoutParams(-1,-1))
        popupBackdropOverlay = overlay

        // Immersivo: la finestra stessa diventa una superficie vetro traslucida.
        // Il contenuto resta nitido, ma lo sfondo della popup lascia filtrare
        // il livello sottostante: in questo modo la differenza con Contorno è reale.
        if (popupBackdropMode == "IMMERSIVE" && activeDialog?.window != null) {
            val window = activeDialog.window!!
            val content = window.findViewById<ViewGroup>(android.R.id.content)
            val panel = content?.getChildAt(0)
            if (panel != null) {
                if (!popupDialogOriginalBackgrounds.containsKey(panel)) {
                    popupDialogOriginalBackgrounds[panel] = panel.background?.constantState?.newDrawable()?.mutate() ?: panel.background
                }
                if (!popupDialogOriginalWindowBackgrounds.containsKey(activeDialog)) {
                    popupDialogOriginalWindowBackgrounds[activeDialog] = window.decorView.background?.constantState?.newDrawable()?.mutate() ?: window.decorView.background
                }
                val glass = android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                    when {
                        liquid -> intArrayOf(
                            android.graphics.Color.argb((92 + 62 * intensity).roundToInt().coerceIn(92,154), 178, 218, 250),
                            android.graphics.Color.argb((72 + 52 * intensity).roundToInt().coerceIn(72,124), 245, 250, 255),
                            android.graphics.Color.argb((86 + 58 * intensity).roundToInt().coerceIn(86,144), 188, 225, 250)
                        )
                        softGlass -> intArrayOf(
                            android.graphics.Color.argb((150 + 55 * intensity).roundToInt().coerceIn(150,205), 222, 239, 253),
                            android.graphics.Color.argb((132 + 48 * intensity).roundToInt().coerceIn(132,180), 252, 253, 255),
                            android.graphics.Color.argb((145 + 52 * intensity).roundToInt().coerceIn(145,197), 218, 235, 251)
                        )
                        else -> intArrayOf(
                            android.graphics.Color.argb((178 + 45 * intensity).roundToInt().coerceIn(178,223), 238, 245, 252),
                            android.graphics.Color.argb((160 + 42 * intensity).roundToInt().coerceIn(160,202), 255, 255, 255),
                            android.graphics.Color.argb((174 + 44 * intensity).roundToInt().coerceIn(174,218), 230, 240, 250)
                        )
                    }
                )
                glass.cornerRadius = dp(28).toFloat()
                val edgeAlpha = (55 + 60 * intensity).roundToInt().coerceIn(55,115)
                glass.setStroke(dp(1), android.graphics.Color.argb(edgeAlpha, 170, 215, 255))
                panel.background = glass
                window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))
                // Importante: la pagina può contenere ScrollView con card create separatamente.
                // Rendiamo trasparenti anche quelle superfici, così lo scrolling non scopre zone bianche.
                applyImmersiveSurfaces(panel)
                popupDialogGlassOverlay = panel
            }
        }
    }
    private fun clearPopupBackdropEffect() {
        popupBackdropOverlay?.let { (it.parent as? ViewGroup)?.removeView(it) }
        popupBackdropOverlay = null
        popupDialogGlassOverlay?.let { panel ->
            popupDialogOriginalBackgrounds.remove(panel)?.let { original -> panel.background = original }
        }
        popupDialogGlassOverlay = null
        popupDialogOriginalWindowBackgrounds.forEach { (dialog, original) ->
            if (dialog.isShowing) dialog.window?.setBackgroundDrawable(original)
        }
        popupDialogOriginalWindowBackgrounds.clear()
        popupBackdropTarget?.setRenderEffect(null)
        popupBackdropTarget = null
    }

    private fun removePopupBackdropDialog(dialog: Dialog) {
        popupBackdropDialogs.remove(dialog)
        if (popupBackdropCurrentDialog === dialog) popupBackdropCurrentDialog = popupBackdropDialogs.lastOrNull()
        clearPopupBackdropEffect()
        if (popupBackdropEffect != "NONE" && popupBackdropCurrentDialog != null) applyPopupBackdropEffect(popupBackdropCurrentDialog)
    }

    private fun preparePopupBackdrop(dialog: Dialog) {
        dialog.setOnDismissListener { removePopupBackdropDialog(dialog) }
    }

    private fun clientNameAutoCompleteAdapter(items: List<String>): ArrayAdapter<String> =
        object : ArrayAdapter<String>(this, 0, items) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = (convertView as? TextView) ?: TextView(this@MainActivity)
                v.text = getItem(position) ?: ""
                v.textSize = 16f
                v.setTextColor(Color.rgb(24,31,40))
                v.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                v.gravity = Gravity.CENTER_VERTICAL
                v.setPadding(dp(16), 0, dp(16), 0)
                v.background = ColorDrawable(Color.TRANSPARENT)
                v.layoutParams = AbsListView.LayoutParams(-1, dp(48))
                return v
            }
        }

    private fun styleClientNameSuggestions(field: AutoCompleteTextView) {
        field.setDropDownBackgroundDrawable(
            liquidInteractiveSurface(Color.rgb(248,249,251), 20, Color.rgb(220,226,234), 1)
        )
        field.dropDownVerticalOffset = dp(4)
        field.dropDownHorizontalOffset = 0
        field.dropDownWidth = ViewGroup.LayoutParams.MATCH_PARENT
        field.elevation = dp(2).toFloat()
    }

    private fun centeredSpinnerAdapter(items: List<String>): ArrayAdapter<String> =
        object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            init { setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent)
                (v as? TextView)?.apply { gravity = Gravity.CENTER; setTextColor(Color.rgb(24,31,40)); typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL) }
                return v
            }
            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getDropDownView(position, convertView, parent)
                (v as? TextView)?.apply { gravity = Gravity.CENTER; setTextColor(Color.rgb(24,31,40)); typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL) }
                return v
            }
        }
    // Selettore orario Niki UI: un unico pannello arrotondato, senza righe/pillole separate.
    private fun installNikiTimeDropdown(spinner: Spinner, centerOverAnchor: Boolean = false) {
        spinner.setOnTouchListener { v, event ->
            if (event.action != android.view.MotionEvent.ACTION_UP) return@setOnTouchListener true
            val adapter = spinner.adapter ?: return@setOnTouchListener true
            if (adapter.count == 0) return@setOnTouchListener true

            val content = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(6), dp(6), dp(6), dp(6))
                setBackgroundColor(Color.TRANSPARENT)
            }
            val scroll = ScrollView(this).apply {
                isFillViewport = false
                overScrollMode = View.OVER_SCROLL_NEVER
                setBackgroundColor(Color.TRANSPARENT)
            }
            scroll.addView(content, ViewGroup.LayoutParams(-1, -2))

            var popup: PopupWindow? = null
            for (i in 0 until adapter.count) {
                val label = adapter.getItem(i)?.toString() ?: continue
                val row = TextView(this).apply {
                    text = label
                    textSize = 16.5f
                    setTextColor(Color.rgb(24, 31, 40))
                    typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(14), 0, dp(14), 0)
                    background = liquidInteractiveSurface(
                        if (i == spinner.selectedItemPosition) Color.rgb(232, 243, 255) else Color.rgb(248,249,251),
                        16, Color.rgb(210,226,242), 1
                    )
                    applyLiquidControlDepth(this)
                    isClickable = true
                    setOnClickListener {
                        spinner.setSelection(i)
                        popup?.dismiss()
                    }
                }
                content.addView(row, LinearLayout.LayoutParams(-1, dp(44)).apply {
                    if (i > 0) setMargins(0, dp(1), 0, 0)
                })
            }

            val maxHeight = dp(360)
            val popupW = if (centerOverAnchor) v.width.coerceAtLeast(dp(84)) else dp(220)
            content.measure(
                View.MeasureSpec.makeMeasureSpec(popupW - dp(12), View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(maxHeight - dp(12), View.MeasureSpec.AT_MOST)
            )
            val popupH = content.measuredHeight.coerceIn(dp(52), maxHeight)
            popup = PopupWindow(scroll, popupW, popupH, true).apply {
                setBackgroundDrawable(liquidInteractiveSurface(Color.WHITE, 24, Color.rgb(190,220,246), 1))
                elevation = dp(12).toFloat()
                isOutsideTouchable = true
                isFocusable = true
                setOnDismissListener { spinner.clearFocus() }
            }

            val location = IntArray(2)
            v.getLocationOnScreen(location)
            val screenH = resources.displayMetrics.heightPixels
            if (centerOverAnchor) {
                // Il pannello orari ha la stessa larghezza dello slot e il suo centro
                // coincide esattamente con il centro dello slot da cui viene aperto.
                val x = location[0] + (v.width - popupW) / 2
                val y = location[1] + (v.height - popupH) / 2
                val clampedX = x.coerceIn(dp(8), resources.displayMetrics.widthPixels - popupW - dp(8))
                val clampedY = y.coerceIn(dp(12), screenH - popupH - dp(12))
                popup.showAtLocation(v, Gravity.TOP or Gravity.START, clampedX, clampedY)
            } else {
                val gapPx = dp(4)
                val belowY = location[1] + v.height + gapPx
                val fitsBelow = belowY + popupH <= screenH - dp(12)
                val xOffset = ((v.width - popupW) / 2).coerceIn(-dp(24), dp(24))
                if (fitsBelow) popup.showAsDropDown(v, xOffset, gapPx)
                else popup.showAsDropDown(v, xOffset, -(v.height + popupH + gapPx))
            }
            true
        }
    }
    // Selettore tipo appuntamento Niki UI: stesso pannello flottante del selettore orari.
    private fun installNikiTypeDropdown(spinner: Spinner, centerOnSpinner: Boolean = false) {
        spinner.setOnTouchListener { v, event ->
            if (event.action != android.view.MotionEvent.ACTION_UP) return@setOnTouchListener true
            val adapter = spinner.adapter ?: return@setOnTouchListener true
            if (adapter.count == 0) return@setOnTouchListener true

            val content = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(6), dp(6), dp(6), dp(6))
                setBackgroundColor(Color.TRANSPARENT)
            }
            val scroll = ScrollView(this).apply {
                overScrollMode = View.OVER_SCROLL_NEVER
                setBackgroundColor(Color.TRANSPARENT)
            }
            scroll.addView(content, ViewGroup.LayoutParams(-1, -2))
            var popup: PopupWindow? = null
            for (i in 0 until adapter.count) {
                val label = adapter.getItem(i)?.toString() ?: continue
                val row = TextView(this).apply {
                    text = label
                    textSize = 16f
                    setTextColor(Color.rgb(35,42,52))
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(14),0,dp(14),0)
                    isClickable = true
                    background = liquidInteractiveSurface(
                        if (i == spinner.selectedItemPosition) Color.rgb(232,243,255) else Color.rgb(248,249,251),
                        16, Color.rgb(210,226,242), 1
                    )
                    applyLiquidControlDepth(this)
                    setOnClickListener { spinner.setSelection(i); popup?.dismiss() }
                }
                content.addView(row, LinearLayout.LayoutParams(-1, dp(48)).apply {
                    if (i > 0) setMargins(0, dp(1), 0, 0)
                })
            }
            val popupW = dp(260)
            val maxHeight = dp(360)
            val popupH = (dp(12) + adapter.count * dp(48)).coerceAtMost(maxHeight)
            popup = PopupWindow(scroll, popupW, popupH, true).apply {
                setBackgroundDrawable(liquidInteractiveSurface(Color.WHITE,24,Color.rgb(190,220,246),1))
                elevation = dp(12).toFloat()
                isOutsideTouchable = true
                isFocusable = true
                setOnDismissListener { spinner.clearFocus() }
            }

            val location = IntArray(2)
            v.getLocationOnScreen(location)
            val screenH = resources.displayMetrics.heightPixels
            val gapPx = dp(4)
            val belowY = location[1] + v.height + gapPx
            val fitsBelow = belowY + popupH <= screenH - dp(12)
            val xOffset = if (centerOnSpinner) ((v.width - popupW) / 2).coerceAtLeast(-dp(24)) else (v.width - popupW)

            if (fitsBelow) {
                // Il popup resta direttamente sotto al selettore, anche dopo lo scroll della pagina.
                popup.showAsDropDown(v, xOffset, gapPx)
            } else {
                // Se non c'e spazio, si apre sopra mantenendo la stessa distanza dal campo.
                popup.showAsDropDown(v, xOffset, -(v.height + popupH + gapPx))
            }
            true
        }
    }
    private fun typeBgForColor(c:Int):Int = Color.rgb((Color.red(c)+255)/2,(Color.green(c)+255)/2,(Color.blue(c)+255)/2)
    private fun ensureAppointmentTypes(){
        if(appointmentTypes.isEmpty()){
            appointmentTypes.add(AppointmentType("TYPE1","ALLENAMENTO",Color.rgb(45,135,210),45))
            appointmentTypes.add(AppointmentType("TYPE2","MEZZ'ORA",Color.rgb(215,55,55),30))
        }else if(appointmentTypes.none{it.id=="TYPE1"}){
            appointmentTypes.add(0,AppointmentType("TYPE1","ALLENAMENTO",Color.rgb(45,135,210),45))
        }
    }
    private fun normalizedType(type:String):String = when(type){"ALLENAMENTO"->"TYPE1";"MEZZ'ORA"->"TYPE2";else->type}
    private fun typeIndex(type:String):Int {
        ensureAppointmentTypes()
        val id=normalizedType(type)
        val found=appointmentTypes.indexOfFirst{it.id==id}
        if(found>=0)return found
        val legacy=when(id){"TYPE1"->0;"TYPE2"->1;else->-1}
        return if(legacy>=0&&legacy<appointmentTypes.size)legacy else 0
    }
    private fun typeLabel(type:String):String { ensureAppointmentTypes(); return appointmentTypes.getOrNull(typeIndex(type))?.name ?: appointmentTypes.first().name }
    private fun typeColor(type:String):Int { ensureAppointmentTypes(); return appointmentTypes.getOrNull(typeIndex(type))?.color ?: appointmentTypes.first().color }
    private fun typeDuration(type:String):Int { ensureAppointmentTypes(); return appointmentTypes.getOrNull(typeIndex(type))?.duration ?: 45 }
    private fun typeIdAt(index:Int):String { ensureAppointmentTypes(); return appointmentTypes.getOrNull(index)?.id ?: appointmentTypes.first().id }

    private fun roundedSurface(color:Int, radius:Int=16, strokeColor:Int=Color.TRANSPARENT, strokeWidth:Int=0): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius=dp(radius).toFloat(); if(strokeWidth>0) setStroke(dp(strokeWidth),strokeColor) }

    /**
     * Controllo Liquid Glass: superficie leggermente gonfia/3D, traslucida e
     * lucida, pensata per campi e pulsanti. Il contenuto rimane sempre nitido.
     * Fuori dal profilo LIQUID restituisce volutamente lo stile precedente.
     */
    private fun liquidInteractiveSurface(color:Int, radius:Int=18, strokeColor:Int=Color.TRANSPARENT, strokeWidth:Int=1): GradientDrawable {
        if (popupBackdropEffect != "LIQUID") return roundedSurface(color, radius, strokeColor, strokeWidth)
        val r=Color.red(color); val g=Color.green(color); val b=Color.blue(color)
        // I controlli Liquid Glass seguono ora l'intensità scelta: a intensità bassa
        // la superficie lascia filtrare maggiormente lo sfondo, mentre al 100%
        // mantiene esattamente la resa attuale della 1.2.
        val t = popupBackdropIntensity.coerceIn(0,100) / 100f
        val factor = 0.20f + 0.80f * t
        fun a(base:Int) = (base * factor).roundToInt().coerceIn(0,255)
        val strokeA = (210 * factor).roundToInt().coerceIn(0,255)
        return GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
            Color.argb(a(178), minOf(255,r+22), minOf(255,g+24), minOf(255,b+28)),
            Color.argb(a(128), minOf(255,r+8), minOf(255,g+12), minOf(255,b+16)),
            Color.argb(a(162), r, g, b),
            Color.argb(a(188), minOf(255,r+18), minOf(255,g+22), minOf(255,b+26))
        )).apply {
            cornerRadius=dp(radius).toFloat()
            if(strokeWidth>0) setStroke(dp(strokeWidth), Color.argb(strokeA, 190, 225, 255))
        }
    }

    private fun applyLiquidControlDepth(view: View) {
        if (popupBackdropEffect == "LIQUID") {
            view.elevation=dp(3).toFloat()
            view.translationZ=dp(0.5f.roundToInt()).toFloat()
        } else {
            view.elevation=0f
            view.translationZ=0f
        }
    }

    /** Superfici dell'interfaccia principale: la scelta del vetro influenza anche
     * schede, pulsanti e blocchi, non solo le finestre popup. Il contenuto resta
     * sempre nitido; qui lavoriamo esclusivamente sulla superficie. */
    private fun appGlassSurface(color:Int, radius:Int=16, strokeColor:Int=Color.TRANSPARENT, strokeWidth:Int=1): GradientDrawable {
        if (popupBackdropEffect == "NONE") return roundedSurface(color, radius, strokeColor, strokeWidth)
        val a = when (popupBackdropEffect) {
            "SATIN" -> 226
            "VETRO_SOFT" -> 190
            "LIQUID" -> 148
            else -> 220
        }
        val edge = when (popupBackdropEffect) {
            "SATIN" -> if (strokeColor == Color.TRANSPARENT) Color.rgb(218,228,239) else strokeColor
            "VETRO_SOFT", "LIQUID" -> Color.argb(155, 175, 215, 248)
            else -> strokeColor
        }
        return GradientDrawable().apply {
            cornerRadius = dp(radius).toFloat()
            when (popupBackdropEffect) {
                "LIQUID" -> setColors(intArrayOf(
                    Color.argb(a, Color.red(color), Color.green(color), Color.blue(color)),
                    Color.argb((a * 0.78f).toInt(), minOf(255, Color.red(color)+12), minOf(255, Color.green(color)+16), minOf(255, Color.blue(color)+20)),
                    Color.argb((a * 0.90f).toInt(), Color.red(color), Color.green(color), Color.blue(color))
                ))
                "VETRO_SOFT" -> setColors(intArrayOf(
                    Color.argb(a, Color.red(color), Color.green(color), Color.blue(color)),
                    Color.argb((a * 0.90f).toInt(), minOf(255, Color.red(color)+8), minOf(255, Color.green(color)+10), minOf(255, Color.blue(color)+14))
                ))
                else -> setColor(Color.argb(a, Color.red(color), Color.green(color), Color.blue(color)))
            }
            if (strokeWidth > 0) setStroke(dp(strokeWidth), edge)
        }
    }

    /**
     * Superficie Liquid Glass "a goccia" per il calendario.
     * Il volume è costruito solo con luce, gradiente e bordi sfalsati:
     * nessun ovale o disegno interno.
     */
    private inner class LiquidDepthDrawable(
        private val radiusPx:Float,
        private val intensity:Float,
        private val accent:Int
    ) : Drawable() {
        private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val highlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val r = RectF()
        private val inner = RectF()

        override fun draw(canvas: Canvas) {
            val b = bounds
            if (b.width() <= 0 || b.height() <= 0) return
            val t = intensity.coerceIn(0f, 1f)
            val small = radiusPx <= dp(12)
            val inset = (0.9f + 0.7f * t).dp()
            r.set(b.left + inset, b.top + inset, b.right - inset, b.bottom - inset)

            // L'appuntamento è il livello "acqua" sopra la lastra: il colore del tipo
            // viene usato solo come riflesso, non come riempimento pieno.
            val ar = Color.red(accent)
            val ag = Color.green(accent)
            val ab = Color.blue(accent)
            val softR = ((ar * 0.20f) + 255f * 0.80f).roundToInt().coerceAtMost(255)
            val softG = ((ag * 0.20f) + 255f * 0.80f).roundToInt().coerceAtMost(255)
            val softB = ((ab * 0.20f) + 255f * 0.80f).roundToInt().coerceAtMost(255)

            // Corpo traslucido: più luminoso in alto e leggermente più denso in basso,
            // come una piccola lente d'acqua appoggiata sulla lastra.
            val topA = if (small) 38 + (12 * t).roundToInt() else 44 + (14 * t).roundToInt()
            val midA = if (small) 9 + (4 * t).roundToInt() else 11 + (5 * t).roundToInt()
            val bottomA = if (small) 27 + (10 * t).roundToInt() else 31 + (12 * t).roundToInt()
            fillPaint.shader = LinearGradient(
                r.left, r.top, r.left, r.bottom,
                intArrayOf(
                    Color.argb(topA, 255,255,255),
                    Color.argb(midA, softR,softG,softB),
                    Color.argb(bottomA, softR,softG,softB),
                    Color.argb((bottomA + 3).coerceAtMost(120), 246,251,255)
                ),
                floatArrayOf(0f,0.32f,0.78f,1f), Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(r, radiusPx, radiusPx, fillPaint)

            // Volume ottico centrale: una lente d'acqua non è uniforme come una card.
            // Una luce morbida attraversa il centro e si concentra verso la parte alta,
            // mentre il bordo inferiore rimane appena più denso. Le dimensioni restano
            // identiche: aumentiamo solo la percezione della curvatura.
            val bulge = RectF(r.left + 1.2f.dp(), r.top + 1.4f.dp(), r.right - 1.2f.dp(), r.bottom - 1.2f.dp())
            glowPaint.shader = RadialGradient(
                bulge.left + bulge.width()*0.50f, bulge.top + bulge.height()*0.34f,
                bulge.width()*0.62f,
                intArrayOf(
                    Color.argb((24 + 14*t).roundToInt(),255,255,255),
                    Color.argb((9 + 7*t).roundToInt(),255,255,255),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f,0.48f,1f), Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(bulge, radiusPx*0.92f, radiusPx*0.92f, glowPaint)

            // Riflesso diffuso superiore: la superficie sembra leggermente bombata.
            glowPaint.shader = RadialGradient(
                r.left + r.width()*0.34f, r.top + r.height()*0.12f,
                r.width()*0.72f,
                intArrayOf(
                    Color.argb((42 + 20*t).roundToInt(),255,255,255),
                    Color.argb((13 + 9*t).roundToInt(),255,255,255),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f,0.42f,1f), Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(r, radiusPx, radiusPx, glowPaint)

            // Rifrazione interna: una fascia chiarissima e molto trasparente appena
            // sotto il bordo superiore, come la luce che attraversa una superficie
            // d'acqua. Non aumenta lo spessore della card.
            val refraction = RectF(r.left + 2.4f.dp(), r.top + 4.0f.dp(), r.right - 2.4f.dp(), r.top + r.height()*0.46f)
            glowPaint.shader = LinearGradient(
                refraction.left, refraction.top, refraction.left, refraction.bottom,
                Color.argb((24 + 12*t).roundToInt(),255,255,255),
                Color.TRANSPARENT,
                Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(refraction, radiusPx*0.72f, radiusPx*0.72f, glowPaint)

            // Effetto lente/acqua più evidente: una luce concentrata attraversa il centro
            // e sfuma verso i bordi. Non cambia la geometria della card: simula la
            // rifrazione ottica dello strato liquido sopra nome e indicatore rosso.
            val lens = RectF(
                r.left + 3.0f.dp(), r.top + 2.2f.dp(),
                r.right - 3.0f.dp(), r.bottom - 2.0f.dp()
            )
            glowPaint.shader = RadialGradient(
                lens.left + lens.width()*0.50f,
                lens.top + lens.height()*0.50f,
                lens.width()*0.58f,
                intArrayOf(
                    Color.argb((18 + 12*t).roundToInt(),255,255,255),
                    Color.argb((6 + 6*t).roundToInt(),255,255,255),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f,0.48f,1f), Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(lens, radiusPx*0.86f, radiusPx*0.86f, glowPaint)

            // Due micro-caustiche superiori: fanno leggere la superficie come acqua
            // lucida senza trasformarla in una card gonfia.
            val caustic = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeCap = Paint.Cap.ROUND
                strokeWidth = (0.48f + 0.10f*t).dp()
                color = Color.argb((16 + 10*t).roundToInt(),255,255,255)
            }
            val c1 = Path()
            c1.moveTo(r.left + r.width()*0.20f, r.top + r.height()*0.30f)
            c1.quadTo(r.left + r.width()*0.38f, r.top + r.height()*0.22f,
                      r.left + r.width()*0.53f, r.top + r.height()*0.29f)
            canvas.drawPath(c1, caustic)
            val c2 = Path()
            c2.moveTo(r.left + r.width()*0.55f, r.top + r.height()*0.30f)
            c2.quadTo(r.left + r.width()*0.70f, r.top + r.height()*0.22f,
                      r.right - r.width()*0.18f, r.top + r.height()*0.30f)
            canvas.drawPath(c2, caustic)

            // Piccolo riflesso laterale, volutamente bianco/fumé: niente bordo blu pieno.
            edgePaint.shader = null
            edgePaint.strokeWidth = (if (small) 1.20f else 1.50f + 0.20f*t).dp()
            edgePaint.color = Color.argb((102 + 28*t).roundToInt(), 205, 226, 239)
            canvas.drawRoundRect(r, radiusPx, radiusPx, edgePaint)

            inner.set(r.left + 1.5f.dp(), r.top + 1.5f.dp(), r.right - 1.5f.dp(), r.bottom - 1.5f.dp())

            // Highlight superiore continuo: è il punto che deve far leggere "acqua".
            val hi = if (small) 64 + (18*t).roundToInt() else 72 + (20*t).roundToInt()
            highlightPaint.strokeWidth = (if (small) 1.45f else 1.8f).dp()
            highlightPaint.color = Color.argb(hi,255,255,255)
            val topPath = Path()
            topPath.moveTo(inner.left + inner.width()*0.13f, inner.top + 1f.dp())
            topPath.quadTo(inner.left + inner.width()*0.50f, inner.top - 0.9f.dp(), inner.right - inner.width()*0.13f, inner.top + 1f.dp())
            canvas.drawPath(topPath, highlightPaint)

            // Riflesso corto sul lato sinistro.
            val sidePath = Path()
            sidePath.moveTo(inner.left + 0.7f.dp(), inner.top + inner.height()*0.20f)
            sidePath.quadTo(inner.left - 0.1f.dp(), inner.top + inner.height()*0.38f, inner.left + 0.7f.dp(), inner.top + inner.height()*0.55f)
            highlightPaint.strokeWidth = (if (small) 1.15f else 1.35f).dp()
            highlightPaint.color = Color.argb((34 + 24*t).roundToInt(),255,255,255)
            canvas.drawPath(sidePath, highlightPaint)

            // Riflesso inferiore molto sottile: leggermente cromatico, ma attenuato.
            val low = Path()
            low.moveTo(inner.left + inner.width()*0.16f, inner.bottom - 0.7f.dp())
            low.quadTo(inner.left + inner.width()*0.50f, inner.bottom + 0.45f.dp(), inner.right - inner.width()*0.16f, inner.bottom - 0.7f.dp())
            highlightPaint.strokeWidth = (if (small) 1.45f else 1.75f).dp()
            highlightPaint.color = Color.argb((34 + 22*t).roundToInt(), softR, softG, softB)
            canvas.drawPath(low, highlightPaint)
        }

        private fun Float.dp():Float = this * resources.displayMetrics.density
        override fun setAlpha(alpha:Int) {}
        override fun setColorFilter(colorFilter:android.graphics.ColorFilter?) {}
        override fun getOpacity():Int = android.graphics.PixelFormat.TRANSLUCENT
    }

    /**
     * Strato superficiale dell'acqua: viene disegnato SOPRA il contenuto della card.
     * Non altera il testo/riga rossa, ma crea il tipico riflesso che fa percepire
     * il contenuto come immerso sotto una sottile pellicola d'acqua.
     */
    /**
     * Pellicola d'acqua più evidente sopra il contenuto dell'appuntamento.
     * Il contenuto resta sotto la superficie: luce, riflessi e caustiche vengono
     * disegnati in foreground senza modificare la riga rossa.
     */
    /** Transparent water film over the appointment content. */
    /**
     * Pellicola di gel/acqua trasparente sopra il contenuto dell'appuntamento.
     * È volutamente quasi invisibile al centro: la percezione viene dai menischi,
     * dal bordo e da riflessi sottili, così nome e riga restano leggibili.
     */
    /**
     * Pellicola di gel/acqua sopra l'appuntamento.
     * La superficie è quasi trasparente: il contenuto resta leggibile, mentre
     * menisco, riflessi e micro-rifrazione fanno percepire uno strato fisico sopra
     * nome e indicatore rosso, senza il precedente effetto "onda".
     */
    /** Transparent gel/water film drawn above appointment content. */
    /**
     * Ultima rifinitura della pellicola gel/acqua sugli appuntamenti.
     * La superficie resta molto trasparente: il volume viene percepito dai bordi,
     * dal menisco e da una rifrazione estremamente tenue che attraversa il contenuto.
     * Niente onde grafiche evidenti e niente copertura del nome/riga rossa.
     */
    /**
     * Pellicola gel/acqua: superficie ottica trasparente sopra il contenuto.
     * L'obiettivo è far percepire uno strato fisico senza coprire nome e indicatore.
     * La rifrazione viene suggerita da un menisco continuo e da una lieve lente
     * periferica; il centro resta volutamente limpido.
     */
    /**
     * Pellicola gel/acqua reale sopra il contenuto dell'appuntamento.
     * Viene applicata come foreground della card, quindi passa OTTICAMENTE
     * davanti al nome senza coprirlo: il testo sembra realmente immerso
     * sotto uno strato trasparente. La zona superiore viene lasciata libera
     * per non alterare la riga rossa di scadenza.
     */
    private inner class WaterSurfaceOverlayDrawable(
        private val radiusPx:Float,
        private val intensity:Float,
        private val accent:Int
    ): Drawable(){
        private val p=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeCap=Paint.Cap.ROUND}
        private val fill=Paint(Paint.ANTI_ALIAS_FLAG)
        private val rr=RectF()
        private val inner=RectF()
        override fun draw(canvas:Canvas){
            val b=bounds;if(b.width()<=0||b.height()<=0)return
            val d=resources.displayMetrics.density
            val t=intensity.coerceIn(.35f,1f)
            // La pellicola copre tutta la superficie dell'appuntamento: nessuna
            // targhetta separata sotto il nome. Nome e riga rossa sono nello stesso
            // volume di gel/acqua.
            rr.set(b.left+.45f*d,b.top+.45f*d,b.right-.45f*d,b.bottom-.45f*d)
            val r=(radiusPx-.45f*d).coerceAtLeast(8f*d)
            inner.set(rr.left+1.2f*d,rr.top+1.2f*d,rr.right-1.2f*d,rr.bottom-1.2f*d)

            // Velo ottico centrale quasi invisibile: il materiale passa sopra al testo.
            fill.shader=LinearGradient(
                rr.left,rr.top,rr.left,rr.bottom,
                intArrayOf(
                    Color.argb((1.5f*t).roundToInt(),255,255,255),
                    Color.argb((0.3f*t).roundToInt(),255,255,255),
                    Color.argb((0.8f*t).roundToInt(),205,228,239),
                    Color.TRANSPARENT
                ),floatArrayOf(0f,.30f,.68f,1f),Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(rr,r,r,fill)

            // La superficie non deve creare una "targhetta" o una mezzaluna sotto il nome.
            // Il volume deve essere continuo e occupare tutta la card: la profondita'
            // nasce dal materiale e dai riflessi, non da una linea decorativa dietro al testo.
            val depth=Paint(Paint.ANTI_ALIAS_FLAG)
            depth.shader=RadialGradient(
                rr.left+rr.width()*.50f,
                rr.top+rr.height()*.38f,
                rr.width()*.72f,
                intArrayOf(
                    Color.argb((7+4*t).roundToInt(),255,255,255),
                    Color.argb((1+1*t).roundToInt(),220,244,255),
                    Color.argb((2+2*t).roundToInt(),160,208,235),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f,.34f,.72f,1f),Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(rr,r,r,depth)

            // Menisco luminoso continuo: segue l'intera larghezza della superficie.
            p.strokeWidth=(.72f+.10f*t)*d
            p.color=Color.argb((82+28*t).roundToInt(),255,255,255)
            val top=Path()
            top.moveTo(inner.left+inner.width()*.10f,inner.top+1.0f*d)
            top.cubicTo(inner.left+inner.width()*.30f,inner.top-.05f*d,
                inner.left+inner.width()*.70f,inner.top-.05f*d,
                inner.right-inner.width()*.10f,inner.top+1.0f*d)
            canvas.drawPath(top,p)

            // Piccola rifrazione laterale cromatica, molto più debole del bordo LED.
            p.strokeWidth=.48f*d
            p.color=Color.argb((28+16*t).roundToInt(),190,225,240)
            val sideL=Path()
            sideL.moveTo(inner.left+.55f*d,inner.top+inner.height()*.20f)
            sideL.cubicTo(inner.left+.10f*d,inner.top+inner.height()*.42f,
                inner.left+.10f*d,inner.top+inner.height()*.60f,
                inner.left+.55f*d,inner.top+inner.height()*.78f)
            canvas.drawPath(sideL,p)
            val sideR=Path()
            sideR.moveTo(inner.right-.55f*d,inner.top+inner.height()*.20f)
            sideR.cubicTo(inner.right-.10f*d,inner.top+inner.height()*.42f,
                inner.right-.10f*d,inner.top+inner.height()*.60f,
                inner.right-.55f*d,inner.top+inner.height()*.78f)
            canvas.drawPath(sideR,p)

            // Specularita' fisica: il centro resta limpido e la luce si concentra
            // sui margini, sulle spalle e sui punti di curvatura del gel. Il contrasto
            // tra centro trasparente e bordo brillante deve far leggere lo spessore.
            val specular=Paint(Paint.ANTI_ALIAS_FLAG)
            specular.shader=RadialGradient(
                rr.left+rr.width()*.16f, rr.top+rr.height()*.08f,
                rr.width()*.38f,
                intArrayOf(
                    Color.argb((142+38*t).roundToInt(),255,255,255),
                    Color.argb((52+22*t).roundToInt(),255,255,255),
                    Color.argb((6+3*t).roundToInt(),255,255,255),
                    Color.TRANSPARENT
                ), floatArrayOf(0f,.25f,.52f,1f), Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(rr,r,r,specular)
            specular.shader=RadialGradient(
                rr.right-rr.width()*.12f, rr.bottom-rr.height()*.14f,
                rr.width()*.34f,
                intArrayOf(
                    Color.argb((76+30*t).roundToInt(),205,242,255),
                    Color.argb((22+12*t).roundToInt(),190,230,248),
                    Color.argb((3+2*t).roundToInt(),190,230,248),
                    Color.TRANSPARENT
                ), floatArrayOf(0f,.28f,.55f,1f), Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(rr,r,r,specular)

            // Riflesso bagnato: una fascia ampia e trasparente scivola nella parte
            // alta della superficie, poi svanisce prima della zona del nome.
            val gloss=Paint(Paint.ANTI_ALIAS_FLAG)
            gloss.shader=LinearGradient(
                rr.left, rr.top+rr.height()*.03f,
                rr.left, rr.top+rr.height()*.38f,
                intArrayOf(
                    Color.argb((132+42*t).roundToInt(),255,255,255),
                    Color.argb((42+20*t).roundToInt(),255,255,255),
                    Color.argb((5+2*t).roundToInt(),255,255,255),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f,.22f,.48f,1f), Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(
                RectF(rr.left+1.5f*d, rr.top+1.0f*d, rr.right-1.5f*d, rr.bottom-1.5f*d),
                (r-1.0f*d).coerceAtLeast(7f*d), (r-1.0f*d).coerceAtLeast(7f*d), gloss
            )

            // Riflesso largo e diagonale: deve essere percepibile come superficie bagnata,
            // ma attraversare il centro con pochissima opacità per non spegnere il nome.
            val wetBand=Paint(Paint.ANTI_ALIAS_FLAG)
            wetBand.shader=LinearGradient(
                rr.left+rr.width()*.08f, rr.top+rr.height()*.06f,
                rr.right-rr.width()*.12f, rr.top+rr.height()*.58f,
                intArrayOf(
                    Color.argb((70+24*t).roundToInt(),255,255,255),
                    Color.argb((18+10*t).roundToInt(),255,255,255),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f,.34f,1f), Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(
                RectF(rr.left+2.0f*d,rr.top+1.5f*d,rr.right-2.0f*d,rr.bottom-2.0f*d),
                (r-1.5f*d).coerceAtLeast(7f*d), (r-1.5f*d).coerceAtLeast(7f*d), wetBand
            )

            // Una seconda luce molto sottile dal basso simula lo spessore del gel,
            // senza velare il testo al centro.
            val bottom=Paint(Paint.ANTI_ALIAS_FLAG)
            bottom.shader=LinearGradient(
                rr.left,rr.top+rr.height()*.62f,rr.left,rr.bottom,
                Color.TRANSPARENT,
                Color.argb((22+14*t).roundToInt(),150,220,245),
                Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(rr,r,r,bottom)

            // Piccoli highlight speculari sugli spigoli: sono la parte che deve far
            // sembrare il materiale lucido/bagnato, non semplicemente azzurro.
            val wet=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeCap=Paint.Cap.ROUND}
            wet.strokeWidth=1.42f*d
            wet.color=Color.argb((170+38*t).roundToInt(),255,255,255)
            val wetTop=Path()
            wetTop.moveTo(rr.left+rr.width()*.12f,rr.top+2.0f*d)
            wetTop.cubicTo(rr.left+rr.width()*.32f,rr.top+.7f*d,
                rr.left+rr.width()*.68f,rr.top+.7f*d,
                rr.right-rr.width()*.12f,rr.top+2.0f*d)
            canvas.drawPath(wetTop,wet)
            wet.strokeWidth=.95f*d
            wet.color=Color.argb((112+32*t).roundToInt(),255,255,255)
            val wetBottom=Path()
            wetBottom.moveTo(rr.left+rr.width()*.18f,rr.bottom-2.0f*d)
            wetBottom.cubicTo(rr.left+rr.width()*.36f,rr.bottom-1.0f*d,
                rr.left+rr.width()*.64f,rr.bottom-1.0f*d,
                rr.right-rr.width()*.18f,rr.bottom-2.0f*d)
            canvas.drawPath(wetBottom,wet)

            // Filo cromatico perimetrale: il colore del tipo appuntamento deve
            // restare leggibile anche quando il materiale è molto trasparente.
            // È un filo sottile, non un neon: diventa semplicemente più presente
            // sui colori forti (rosso, verde, ecc.).
            val ar=Color.red(accent)
            val ag=Color.green(accent)
            val ab=Color.blue(accent)
            p.strokeWidth=(.98f+.12f*t)*d
            p.color=Color.argb((176+34*t).roundToInt(),ar,ag,ab)
            canvas.drawRoundRect(rr,r,r,p)

            // Micro-riflesso neutro appena interno al filo cromatico: conserva
            // l'aspetto bagnato senza sbiadire il colore del bordo.
            p.strokeWidth=.34f*d
            p.color=Color.argb((82+28*t).roundToInt(),235,250,255)
            canvas.drawRoundRect(
                RectF(rr.left+1.0f*d,rr.top+1.0f*d,rr.right-1.0f*d,rr.bottom-1.0f*d),
                (r-1.0f*d).coerceAtLeast(6f*d), (r-1.0f*d).coerceAtLeast(6f*d), p
            )
            fill.shader=null
        }
        private fun dp(v:Float)=v*resources.displayMetrics.density
        override fun setAlpha(alpha:Int){}
        override fun setColorFilter(colorFilter:android.graphics.ColorFilter?){ }
        override fun getOpacity():Int=android.graphics.PixelFormat.TRANSLUCENT
    }

    /**
     * Card appuntamento: rettangolare, trasparente e con un piccolo bordo LED
     * cromatico. Il colore arriva direttamente dal tipo di appuntamento impostato
     * nelle Impostazioni (blu, verde, rosso, ecc.). La riga rossa di scadenza resta
     * indipendente e quindi continua a significare esclusivamente "pacchetto scaduto".
     */
    private inner class AppointmentGelBaseDrawable(private val radiusPx:Float,private val accent:Int,private val material:String = calendarMaterialEffect,private val materialIntensity:Int = calendarMaterialIntensity):Drawable(){
        private val fill=Paint(Paint.ANTI_ALIAS_FLAG)
        private val edge=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE}
        private val led=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeCap=Paint.Cap.ROUND}
        private val rr=RectF()
        private val ledRect=RectF()
        override fun draw(canvas:Canvas){
            val b=bounds;if(b.width()<=0||b.height()<=0)return
            val d=resources.displayMetrics.density;val inset=.65f*d
            rr.set(b.left+inset,b.top+inset,b.right-inset,b.bottom-inset)
            val ar=Color.red(accent);val ag=Color.green(accent);val ab=Color.blue(accent)
            val tr=((ar*.08f)+255f*.92f).roundToInt().coerceAtMost(255)
            val tg=((ag*.08f)+255f*.92f).roundToInt().coerceAtMost(255)
            val tb=((ab*.08f)+255f*.92f).roundToInt().coerceAtMost(255)

            // Tutto il materiale dell'appuntamento viene confinato al proprio profilo.
            // Questo evita qualsiasi alone esterno, soprattutto sugli angoli.
            val clipPath=Path().apply{
                if(radiusPx>0f) addRoundRect(rr,radiusPx,radiusPx,Path.Direction.CW) else addRect(rr,Path.Direction.CW)
            }
            canvas.save()
            canvas.clipPath(clipPath)
            ledRect.set(rr)

            // Corpo Liquid Glass: più limpido e lucido, con una base quasi invisibile.
            // La tonalità viene lasciata alla luce laterale, così il piano non diventa lattiginoso.
            fill.shader=LinearGradient(rr.left,rr.top,rr.left,rr.bottom,
                intArrayOf(
                    Color.argb(24,255,255,255),
                    Color.argb(6,tr,tg,tb),
                    Color.argb(4,tr,tg,tb),
                    Color.argb(16,218,235,244)
                ),floatArrayOf(0f,.30f,.72f,1f),Shader.TileMode.CLAMP)
            canvas.drawRoundRect(rr,radiusPx,radiusPx,fill)

            val lightT=(materialIntensity.coerceIn(0,100)/100f)
            if(material=="SIDE_LIGHT") {
                // Luce che entra lateralmente nella lastra: il centro resta trasparente,
                // mentre i bordi ricevono una diffusione cromatica più intensa.
                // LED "sotto vetro": bordo finissimo e luce che entra nel materiale.
                // Il vetro resta lucido/trasparente; aumentando l'intensità aumenta
                // soprattutto la tonalità interna, non lo spessore del bordo.
                val edgeAlpha=(76+42*lightT).roundToInt()
                // Il LED deve condividere ESATTAMENTE la stessa geometria della card:
                // niente inset fisso e niente percorso più interno che negli angoli
                // faceva sembrare la luce staccata dal bordo dell'appuntamento.
                val glow=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeCap=Paint.Cap.ROUND}

                // Alone morbido, centrato sul perimetro reale della card.
                glow.strokeWidth=(3.0f+0.8f*lightT)*d
                glow.color=Color.argb((22+14*lightT).roundToInt(),ar,ag,ab)
                glow.maskFilter=android.graphics.BlurMaskFilter((2.2f+0.8f*lightT)*d,android.graphics.BlurMaskFilter.Blur.NORMAL)
                canvas.drawRoundRect(rr,radiusPx,radiusPx,glow)
                glow.maskFilter=null

                // Nucleo LED sottile: stesso identico percorso e stesso raggio della card.
                glow.strokeWidth=(0.82f+0.18f*lightT)*d
                glow.color=Color.argb((edgeAlpha+18).coerceAtMost(220),ar,ag,ab)
                canvas.drawRoundRect(rr,radiusPx,radiusPx,glow)

                // Diffusione interna: il colore entra dai lati e si perde dolcemente
                // verso il centro, lasciando il vetro trasparente.
                val spread=(rr.width()*.18f).coerceAtLeast(7f*d)
                val leftGrad=LinearGradient(
                    rr.left+0.8f*d,rr.top,rr.left+spread,rr.top,
                    Color.argb((52*lightT).roundToInt(),ar,ag,ab),
                    Color.TRANSPARENT,Shader.TileMode.CLAMP
                )
                val rightGrad=LinearGradient(
                    rr.right-0.8f*d,rr.top,rr.right-spread,rr.top,
                    Color.argb((42*lightT).roundToInt(),ar,ag,ab),
                    Color.TRANSPARENT,Shader.TileMode.CLAMP
                )
                val fillSide=Paint(Paint.ANTI_ALIAS_FLAG)
                fillSide.shader=leftGrad
                canvas.drawRect(rr.left,rr.top,rr.left+spread,rr.bottom,fillSide)
                fillSide.shader=rightGrad
                canvas.drawRect(rr.right-spread,rr.top,rr.right,rr.bottom,fillSide)

                // Leggero velo cromatico complessivo, molto trasparente: aumenta
                // con l'intensità e mantiene visibile la brillantezza del vetro.
                val tintAlpha=(5+16*lightT).roundToInt()
                val tint=Paint(Paint.ANTI_ALIAS_FLAG).apply{
                    color=Color.argb(tintAlpha,ar,ag,ab)
                    style=Paint.Style.FILL
                }
                canvas.drawRoundRect(
                    RectF(rr.left+1.2f*d,rr.top+1.2f*d,rr.right-1.2f*d,rr.bottom-1.2f*d),
                    (radiusPx-1.2f*d).coerceAtLeast(0f),
                    (radiusPx-1.2f*d).coerceAtLeast(0f),
                    tint
                )

                // Riflesso speculare molto morbido sulla superficie: mantiene il
                // carattere "lucido" senza trasformarlo in un contorno bianco.
                val shine=Paint(Paint.ANTI_ALIAS_FLAG)
                shine.shader=LinearGradient(
                    rr.left,rr.top,rr.right,rr.bottom,
                    Color.argb((26+24*lightT).roundToInt(),255,255,255),
                    Color.TRANSPARENT,Shader.TileMode.CLAMP
                )
                canvas.drawRoundRect(
                    RectF(rr.left+2.0f*d,rr.top+2.0f*d,rr.right-2.0f*d,rr.bottom-2.0f*d),
                    (radiusPx-2.0f*d).coerceAtLeast(0f),
                    (radiusPx-2.0f*d).coerceAtLeast(0f),
                    shine
                )

                // Riflesso di superficie: una fascia bianca molto ampia e tenue,
                // come luce che scivola sul vetro lucido.
                val surfaceSheen=Paint(Paint.ANTI_ALIAS_FLAG)
                surfaceSheen.shader=LinearGradient(
                    rr.left, rr.top+rr.height()*.10f,
                    rr.right, rr.top+rr.height()*.42f,
                    Color.argb((18+14*lightT).roundToInt(),255,255,255),
                    Color.TRANSPARENT, Shader.TileMode.CLAMP
                )
                canvas.drawRoundRect(
                    RectF(rr.left+3.0f*d,rr.top+2.5f*d,rr.right-3.0f*d,rr.bottom-2.5f*d),
                    (radiusPx-2.5f*d).coerceAtLeast(0f),
                    (radiusPx-2.5f*d).coerceAtLeast(0f),
                    surfaceSheen
                )
            } else {
                // Gel/acqua: alone LED molto morbido e continuo, senza trasformare la card in una pillola.
                ledRect.set(rr.left-.6f*d,rr.top-.6f*d,rr.right+.6f*d,rr.bottom+.6f*d)
                led.strokeWidth=3.2f*d
                led.color=Color.argb(12,ar,ag,ab)
                canvas.drawRoundRect(ledRect,radiusPx+1.2f*d,radiusPx+1.2f*d,led)
                led.strokeWidth=1.7f*d
                led.color=Color.argb(20,ar,ag,ab)
                canvas.drawRoundRect(ledRect,radiusPx+1.0f*d,radiusPx+1.0f*d,led)
                led.strokeWidth=.72f*d
                led.color=Color.argb(112,ar,ag,ab)
                canvas.drawRoundRect(rr,radiusPx,radiusPx,led)
            }

            // Punto luce superiore: solo per il gel, dove integra la superficie.
            // Nel Vetro + luce laterale il perimetro completo è già il LED, quindi
            // nessuna linea separata che possa disallinearsi dalla sagoma della card.
            val topY=rr.top+1.25f*d
            if(material!="SIDE_LIGHT") {
                led.strokeWidth=1.15f*d
                led.color=Color.argb(168,ar,ag,ab)
                canvas.drawLine(rr.left+rr.width()*.14f,topY,rr.right-rr.width()*.14f,topY,led)
                led.strokeWidth=.52f*d
                led.color=Color.argb(205,255,255,255)
                canvas.drawLine(rr.left+rr.width()*.17f,topY-.15f*d,rr.right-rr.width()*.17f,topY-.15f*d,led)
            }

            // Filo cromatico esterno più leggibile: sottile ma continuo, così
            // anche un appuntamento rosso resta immediatamente distinguibile.
            edge.strokeWidth=.92f*d
            edge.color=Color.argb((160+30*lightT).roundToInt(),ar,ag,ab)
            canvas.drawRoundRect(rr,radiusPx,radiusPx,edge)

            // Bordo interno neutro, molto più tenue, per mantenere il carattere vetro.
            edge.strokeWidth=.34f*d
            edge.color=Color.argb(72,225,242,250)
            canvas.drawRoundRect(
                RectF(rr.left+1.0f*d,rr.top+1.0f*d,rr.right-1.0f*d,rr.bottom-1.0f*d),
                (radiusPx-1.0f*d).coerceAtLeast(5f*d), (radiusPx-1.0f*d).coerceAtLeast(5f*d), edge
            )
            fill.shader=null
            canvas.restore()
        }
        override fun setAlpha(alpha:Int){}
        override fun setColorFilter(colorFilter:android.graphics.ColorFilter?){ }
        override fun getOpacity():Int=android.graphics.PixelFormat.TRANSLUCENT
    }

    private fun liquidDepthSurface(color:Int, radius:Int=12, accent:Int=Color.rgb(160,211,247)):Drawable {
        if (popupBackdropEffect != "LIQUID") return roundedSurface(color, radius, accent, 2)
        return LiquidDepthDrawable(dp(radius).toFloat(), popupBackdropIntensity.coerceIn(0,100)/100f, accent)
    }

    private fun calendarGlassBackground(): Drawable {
        if (popupBackdropEffect != "LIQUID") return ColorDrawable(Color.rgb(238,241,244))
        // Base neutra fredda: il vetro deve emergere dal piano senza rendere
        // l'interfaccia azzurra.
        return GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
            Color.rgb(224,228,232),
            Color.rgb(216,220,224),
            Color.rgb(230,233,236),
            Color.rgb(212,217,221)
        ))
    }

    private inner class SatinSlotDrawable(private val z:Float, private val slot:Int): Drawable() {
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val edge = Paint(Paint.ANTI_ALIAS_FLAG)
        private val highlight = Paint(Paint.ANTI_ALIAS_FLAG)
        private val r = RectF()

        override fun draw(canvas: Canvas) {
            val b = bounds
            if (b.width() <= 0 || b.height() <= 0) return
            val d = resources.displayMetrics.density
            val inset = (0.45f * z * d).coerceAtLeast(0.5f)
            r.set(b.left + inset, b.top + inset, b.right - inset, b.bottom - inset)

            // Lastra 45': piatta, satinata e leggermente fumé. Nessuna bombatura.
            val top = if (slot % 2 == 0) Color.rgb(226,230,233) else Color.rgb(222,226,229)
            val bottom = if (slot % 2 == 0) Color.rgb(214,219,223) else Color.rgb(210,215,219)
            fill.shader = LinearGradient(
                r.left, r.top, r.left, r.bottom,
                intArrayOf(
                    Color.argb(74, Color.red(top), Color.green(top), Color.blue(top)),
                    Color.argb(62, Color.red(bottom), Color.green(bottom), Color.blue(bottom)),
                    Color.argb(70, 235,238,240)
                ),
                floatArrayOf(0f, 0.52f, 1f), Shader.TileMode.CLAMP
            )
            canvas.drawRect(r, fill)

            // Satinatura: riflesso largo e diffuso, non lucido.
            highlight.shader = LinearGradient(
                r.left, r.top, r.right, r.top,
                Color.argb(25,255,255,255), Color.argb(7,255,255,255), Shader.TileMode.CLAMP
            )
            canvas.drawRect(r.left, r.top, r.right, r.top + (0.9f*z*d).coerceAtLeast(0.7f), highlight)

            // Bordo netto da taglio laser: sottile, squadrato, senza stondatura.
            edge.style = Paint.Style.STROKE
            edge.strokeWidth = (0.72f * z * d).coerceIn(0.8f*d, 1.1f*d)
            edge.color = Color.argb(92, 143,153,162)
            canvas.drawRect(r, edge)

            // Micro-luce sul taglio superiore e traccia più scura sul taglio inferiore:
            // fanno percepire lo spessore senza trasformare la lastra in una card.
            edge.strokeWidth = (0.5f * z * d).coerceAtLeast(0.5f)
            edge.color = Color.argb(128, 250,252,253)
            canvas.drawLine(r.left + edge.strokeWidth, r.top + edge.strokeWidth*0.5f,
                r.right - edge.strokeWidth, r.top + edge.strokeWidth*0.5f, edge)
            edge.color = Color.argb(72, 105,114,121)
            canvas.drawLine(r.left + edge.strokeWidth, r.bottom - edge.strokeWidth*0.5f,
                r.right - edge.strokeWidth, r.bottom - edge.strokeWidth*0.5f, edge)
        }

        override fun setAlpha(alpha:Int) {}
        override fun setColorFilter(colorFilter:android.graphics.ColorFilter?) {}
        override fun getOpacity():Int = android.graphics.PixelFormat.TRANSLUCENT
    }

    /**
     * Liquid Glass per gli slot grandi del calendario.
     *
     * Il materiale è costruito come una lastra sottile a più strati, tutti confinati
     * nella stessa geometria: superficie trasparente, parete interna, bordo ottico,
     * riflesso superiore/inferiore e luce raccolta sugli spigoli. Nessun layer viene
     * disegnato fuori dal profilo dello slot.
     */
    private inner class LiquidGlassSlotDrawable(
        private val z:Float,
        private val slot:Int,
        private val baseColor:Int,
        private val shape:String
    ): Drawable() {
        private val surface = Paint(Paint.ANTI_ALIAS_FLAG)
        private val depth = Paint(Paint.ANTI_ALIAS_FLAG)
        private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val innerEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val reflection = Paint(Paint.ANTI_ALIAS_FLAG)
        private val highlight = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val r = RectF()
        private val inner = RectF()

        override fun draw(canvas:Canvas){
            val b=bounds
            if(b.width()<=0 || b.height()<=0)return
            val d=resources.displayMetrics.density
            val scale=z.coerceIn(.75f,1.5f)
            val inset=(1.0f*scale*d).coerceAtLeast(.8f*d)
            r.set(b.left+inset,b.top+inset,b.right-inset,b.bottom-inset)

            val radius=(dpf(15f)*scale).coerceAtMost(r.height()*0.22f)
            val rr=if(shape=="ARROTONDATO") radius else 0f
            val clipPath=Path().apply{
                if(rr>0f)addRoundRect(r,rr,rr,Path.Direction.CW) else addRect(r,Path.Direction.CW)
            }
            canvas.save()
            canvas.clipPath(clipPath)

            val br=Color.red(baseColor)
            val bg=Color.green(baseColor)
            val bb=Color.blue(baseColor)

            // 1) Corpo della lastra: quasi neutro e trasparente. Il centro deve
            // lasciare leggere il piano sottostante, mentre i bordi hanno appena
            // abbastanza materia da far percepire il vetro.
            surface.shader=LinearGradient(
                r.left,r.top,r.right,r.bottom,
                intArrayOf(
                    Color.argb(24,255,255,255),
                    Color.argb(10,br,bg,bb),
                    Color.argb(7,255,255,255),
                    Color.argb(22,br,bg,bb)
                ),
                floatArrayOf(0f,.24f,.62f,1f),
                Shader.TileMode.CLAMP
            )
            if(rr>0f)canvas.drawRoundRect(r,rr,rr,surface)else canvas.drawRect(r,surface)

            // 2) Rifrazione di superficie: una luce ampia e sfumata attraversa la
            // lastra. È molto più debole al centro e aumenta verso il bordo superiore.
            reflection.shader=RadialGradient(
                r.left+r.width()*.50f,r.top+r.height()*.05f,r.width()*.78f,
                intArrayOf(
                    Color.argb(34,255,255,255),
                    Color.argb(12,255,255,255),
                    Color.TRANSPARENT
                ),floatArrayOf(0f,.42f,1f),Shader.TileMode.CLAMP
            )
            if(rr>0f)canvas.drawRoundRect(r,rr,rr,reflection)else canvas.drawRect(r,reflection)

            // 3) Banda interna: è la parete del vetro. La sua posizione interna
            // crea la percezione di spessore senza aumentare la dimensione dello slot.
            val depthInset=(3.0f*scale*d).coerceAtLeast(2.2f*d)
            inner.set(r.left+depthInset,r.top+depthInset,r.right-depthInset,r.bottom-depthInset)
            val innerRadius=(rr-depthInset*.55f).coerceAtLeast(0f)
            depth.shader=LinearGradient(
                inner.left,inner.top,inner.right,inner.bottom,
                intArrayOf(
                    Color.argb(16,255,255,255),
                    Color.argb(5,255,255,255),
                    Color.argb(17,220,238,248)
                ),floatArrayOf(0f,.55f,1f),Shader.TileMode.CLAMP
            )
            if(innerRadius>0f)canvas.drawRoundRect(inner,innerRadius,innerRadius,depth)else canvas.drawRect(inner,depth)

            // 4) Bordo ottico principale: luce bianca fredda, sottile e continua.
            edge.strokeWidth=(.82f*scale*d).coerceIn(.65f*d,1.15f*d)
            edge.shader=LinearGradient(
                r.left,r.top,r.right,r.bottom,
                intArrayOf(
                    Color.argb(178,255,255,255),
                    Color.argb(92,210,231,246),
                    Color.argb(125,255,255,255),
                    Color.argb(155,205,231,249)
                ),floatArrayOf(0f,.28f,.62f,1f),Shader.TileMode.CLAMP
            )
            if(rr>0f)canvas.drawRoundRect(r,rr,rr,edge)else canvas.drawRect(r,edge)

            // 5) Parete interna luminosa: due bordi separati fanno percepire una
            // piccola distanza tra superficie e bordo esterno.
            innerEdge.strokeWidth=(.46f*scale*d).coerceAtLeast(.45f*d)
            innerEdge.shader=LinearGradient(
                inner.left,inner.top,inner.right,inner.bottom,
                intArrayOf(
                    Color.argb(78,255,255,255),
                    Color.argb(34,190,220,240),
                    Color.argb(68,255,255,255),
                    Color.argb(54,190,220,240)
                ),floatArrayOf(0f,.30f,.68f,1f),Shader.TileMode.CLAMP
            )
            if(innerRadius>0f)canvas.drawRoundRect(inner,innerRadius,innerRadius,innerEdge)else canvas.drawRect(inner,innerEdge)

            // 6) Riflesso superiore: deve sembrare una superficie fisica, non una
            // linea decorativa. È continuo e leggermente curvo agli angoli.
            highlight.strokeWidth=(.48f*scale*d).coerceAtLeast(.45f*d)
            highlight.shader=LinearGradient(
                r.left,r.top,r.right,r.top,
                intArrayOf(Color.argb(22,255,255,255),Color.argb(118,255,255,255),Color.argb(38,255,255,255)),
                floatArrayOf(0f,.50f,1f),Shader.TileMode.CLAMP
            )
            val topPath=Path()
            val topY=r.top+(1.65f*scale*d)
            val topInset=if(rr>0f)rr*.68f else 7f*d
            topPath.moveTo(r.left+topInset,topY)
            topPath.quadTo(r.centerX(),topY-.65f*scale*d,r.right-topInset,topY)
            canvas.drawPath(topPath,highlight)

            // 7) Contro-luce inferiore: più scura e tenue, come la faccia inferiore
            // di una lastra trasparente appoggiata sul piano.
            highlight.shader=null
            highlight.strokeWidth=(.55f*scale*d).coerceAtLeast(.5f*d)
            highlight.color=Color.argb(62,115,151,180)
            val bottomY=r.bottom-(1.7f*scale*d)
            val bottomPath=Path()
            val bottomInset=if(rr>0f)rr*.72f else 7f*d
            bottomPath.moveTo(r.left+bottomInset,bottomY)
            bottomPath.quadTo(r.centerX(),bottomY+.55f*scale*d,r.right-bottomInset,bottomY)
            canvas.drawPath(bottomPath,highlight)

            // 8) Luce raccolta sui fianchi: non è un glow esterno. È una sottile
            // sfumatura interna, limitata dal clip, che fa leggere lo spessore laterale.
            val sideWidth=r.width()*.12f
            val leftSide=Paint(Paint.ANTI_ALIAS_FLAG)
            leftSide.shader=LinearGradient(r.left,r.top,r.left+sideWidth,r.top,
                Color.argb(54,225,244,255),Color.TRANSPARENT,Shader.TileMode.CLAMP)
            if(rr>0f)canvas.drawRoundRect(r,rr,rr,leftSide)else canvas.drawRect(r,leftSide)
            val rightSide=Paint(Paint.ANTI_ALIAS_FLAG)
            rightSide.shader=LinearGradient(r.right,r.top,r.right-sideWidth,r.top,
                Color.argb(42,190,222,247),Color.TRANSPARENT,Shader.TileMode.CLAMP)
            if(rr>0f)canvas.drawRoundRect(r,rr,rr,rightSide)else canvas.drawRect(r,rightSide)

            // 9) Riflesso diagonale molto ampio e quasi invisibile. Serve solo a dare
            // la sensazione che la superficie catturi l'ambiente, come vetro vero.
            val diag=Paint(Paint.ANTI_ALIAS_FLAG)
            diag.shader=LinearGradient(
                r.left+r.width()*.06f,r.bottom-r.height()*.06f,
                r.left+r.width()*.48f,r.top+r.height()*.08f,
                Color.TRANSPARENT,Color.argb(20,255,255,255),Shader.TileMode.CLAMP
            )
            if(rr>0f)canvas.drawRoundRect(r,rr,rr,diag)else canvas.drawRect(r,diag)

            canvas.restore()
        }

        override fun setAlpha(alpha:Int) {}
        override fun setColorFilter(colorFilter:android.graphics.ColorFilter?) {}
        override fun getOpacity():Int = android.graphics.PixelFormat.TRANSLUCENT
    }

    private inner class NebbiaSoftSlotDrawable(private val z:Float, private val slot:Int, private val shape:String, private val baseColor:Int):Drawable(){
        private val p=Paint(Paint.ANTI_ALIAS_FLAG)
        private val edge=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE}
        private val r=RectF()
        override fun draw(c:Canvas){
            val b=bounds;if(b.width()<=0||b.height()<=0)return
            val d=resources.displayMetrics.density;val inset=0.9f*d;r.set(b.left+inset,b.top+inset,b.right-inset,b.bottom-inset)
            val rad=if(shape=="ARROTONDATO") dpf(18f)*z else 0f
            p.shader=LinearGradient(r.left,r.top,r.right,r.bottom,
                intArrayOf(Color.argb(96,Color.red(baseColor),Color.green(baseColor),Color.blue(baseColor)),Color.argb(52,Color.red(baseColor),Color.green(baseColor),Color.blue(baseColor)),Color.argb(82,255,255,255)),
                floatArrayOf(0f,.52f,1f),Shader.TileMode.CLAMP)
            if(rad>0) c.drawRoundRect(r,rad,rad,p) else c.drawRect(r,p)
            edge.strokeWidth=.75f*d;edge.color=Color.argb(120,255,255,255)
            if(rad>0)c.drawRoundRect(r,rad,rad,edge)else c.drawRect(r,edge)
            edge.color=Color.argb(55,155,180,202);edge.strokeWidth=.55f*d
            if(rad>0)c.drawRoundRect(RectF(r.left+1.8f*d,r.top+1.8f*d,r.right-1.8f*d,r.bottom-1.8f*d),maxOf(0f,rad-1.2f*d),maxOf(0f,rad-1.2f*d),edge)else c.drawRect(r.left+1.8f*d,r.top+1.8f*d,r.right-1.8f*d,r.bottom-1.8f*d,edge)
        }
        override fun setAlpha(a:Int){};override fun setColorFilter(f:android.graphics.ColorFilter?){};override fun getOpacity()=android.graphics.PixelFormat.TRANSLUCENT
    }

    private inner class ScuroEleganteSlotDrawable(private val z:Float, private val slot:Int, private val shape:String, private val baseColor:Int):Drawable(){
        private val fill=Paint(Paint.ANTI_ALIAS_FLAG);private val edge=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE};private val r=RectF()
        override fun draw(c:Canvas){
            val b=bounds;if(b.width()<=0||b.height()<=0)return;val d=resources.displayMetrics.density;r.set(b.left+.9f*d,b.top+.9f*d,b.right-.9f*d,b.bottom-.9f*d)
            val rad=if(shape=="ARROTONDATO") dpf(16f)*z else 0f
            fill.shader=LinearGradient(r.left,r.top,r.right,r.bottom,intArrayOf(Color.argb(180,Color.red(baseColor),Color.green(baseColor),Color.blue(baseColor)),Color.argb(145,maxOf(0,Color.red(baseColor)-12),maxOf(0,Color.green(baseColor)-12),maxOf(0,Color.blue(baseColor)-12)),Color.argb(168,minOf(255,Color.red(baseColor)+15),minOf(255,Color.green(baseColor)+15),minOf(255,Color.blue(baseColor)+15))),floatArrayOf(0f,.55f,1f),Shader.TileMode.CLAMP)
            if(rad>0)c.drawRoundRect(r,rad,rad,fill)else c.drawRect(r,fill)
            edge.strokeWidth=.8f*d;edge.color=Color.argb(155,165,205,235);if(rad>0)c.drawRoundRect(r,rad,rad,edge)else c.drawRect(r,edge)
            edge.strokeWidth=.5f*d;edge.color=Color.argb(90,255,255,255);if(rad>0)c.drawRoundRect(RectF(r.left+2*d,r.top+2*d,r.right-2*d,r.bottom-2*d),maxOf(0f,rad-1.5f*d),maxOf(0f,rad-1.5f*d),edge)else c.drawRect(r.left+2*d,r.top+2*d,r.right-2*d,r.bottom-2*d,edge)
        }
        override fun setAlpha(a:Int){};override fun setColorFilter(f:android.graphics.ColorFilter?){};override fun getOpacity()=android.graphics.PixelFormat.TRANSLUCENT
    }

    private fun calendarSlotSurface(z:Float, slot:Int): Drawable {
        return when (calendarStyleSet) {
            "LIQUID_GLASS" -> LiquidGlassSlotDrawable(z, slot, liquidGlassSlotColor, liquidGlassSlotShape)
            "NEBBIA_SOFT" -> NebbiaSoftSlotDrawable(z, slot, nebbiaSoftSlotShape, nebbiaSoftSlotColor)
            "SCURO_ELEGANTE" -> ScuroEleganteSlotDrawable(z, slot, scuroEleganteSlotShape, scuroEleganteSlotColor)
            else -> SatinSlotDrawable(z, slot)
        }
    }

    /** Overlay ottico Niki UI per gli slot grandi: riflesso, profondita' e luce
     * raccolta, confinati esattamente al profilo dello slot. */
    private inner class NikiCalendarSlotOverlayDrawable(private val z:Float, private val shape:String):Drawable(){
        private val p=Paint(Paint.ANTI_ALIAS_FLAG)
        private val stroke=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeCap=Paint.Cap.ROUND}
        private val r=RectF()
        override fun draw(c:Canvas){
            val b=bounds;if(b.width()<=0||b.height()<=0)return
            val d=resources.displayMetrics.density
            val inset=(1.1f*z*d).coerceAtLeast(.8f*d)
            r.set(b.left+inset,b.top+inset,b.right-inset,b.bottom-inset)
            val rad=if(shape=="ARROTONDATO") dpf(17f)*z else 0f
            val path=Path().apply{if(rad>0)addRoundRect(r,rad,rad,Path.Direction.CW)else addRect(r,Path.Direction.CW)}
            c.save();c.clipPath(path)
            p.shader=LinearGradient(r.left,r.top,r.right,r.top,intArrayOf(Color.argb(0,255,255,255),Color.argb(34,255,255,255),Color.argb(0,255,255,255)),floatArrayOf(0f,.50f,1f),Shader.TileMode.CLAMP)
            if(rad>0)c.drawRoundRect(r,rad,rad,p)else c.drawRect(r,p)
            val glow=Paint(Paint.ANTI_ALIAS_FLAG)
            glow.shader=RadialGradient(r.centerX(),r.top-r.height()*.02f,r.width()*.72f,intArrayOf(Color.argb(38,255,255,255),Color.argb(8,255,255,255),Color.TRANSPARENT),floatArrayOf(0f,.42f,1f),Shader.TileMode.CLAMP)
            if(rad>0)c.drawRoundRect(r,rad,rad,glow)else c.drawRect(r,glow)
            stroke.strokeWidth=(.55f*z*d).coerceAtLeast(.5f*d)
            stroke.shader=LinearGradient(r.left,r.top,r.right,r.top,intArrayOf(Color.argb(80,255,255,255),Color.argb(22,255,255,255),Color.argb(65,255,255,255)),floatArrayOf(0f,.52f,1f),Shader.TileMode.CLAMP)
            val topY=r.top+(1.8f*z*d)
            val ti=if(rad>0)rad*.72f else 7f*d
            val top=Path().apply{moveTo(r.left+ti,topY);quadTo(r.centerX(),topY-.6f*z*d,r.right-ti,topY)}
            c.drawPath(top,stroke)
            c.restore()
        }
        override fun setAlpha(a:Int){};override fun setColorFilter(f:android.graphics.ColorFilter?){};override fun getOpacity()=android.graphics.PixelFormat.TRANSLUCENT
    }

    /** Overlay lucido per le schede appuntamento: un piccolo specchio di luce
     * che rende la card piu' profonda senza sporcare la leggibilita'. */
    private inner class NikiAppointmentGlossDrawable(private val radiusPx:Float):Drawable(){
        private val p=Paint(Paint.ANTI_ALIAS_FLAG)
        private val r=RectF()
        override fun draw(c:Canvas){
            val b=bounds;if(b.width()<=0||b.height()<=0)return
            val d=resources.displayMetrics.density
            r.set(b.left+.9f*d,b.top+.9f*d,b.right-.9f*d,b.bottom-.9f*d)
            val path=Path().apply{addRoundRect(r,radiusPx,radiusPx,Path.Direction.CW)}
            c.save();c.clipPath(path)
            val top=Paint(Paint.ANTI_ALIAS_FLAG)
            top.shader=LinearGradient(r.left,r.top,r.right,r.top,intArrayOf(Color.argb(0,255,255,255),Color.argb(55,255,255,255),Color.argb(0,255,255,255)),floatArrayOf(0f,.50f,1f),Shader.TileMode.CLAMP)
            c.drawRoundRect(r,radiusPx,radiusPx,top)
            val bloom=Paint(Paint.ANTI_ALIAS_FLAG)
            bloom.shader=RadialGradient(r.centerX(),r.top-r.height()*.02f,r.width()*.70f,intArrayOf(Color.argb(34,255,255,255),Color.argb(8,255,255,255),Color.TRANSPARENT),floatArrayOf(0f,.40f,1f),Shader.TileMode.CLAMP)
            c.drawRoundRect(r,radiusPx,radiusPx,bloom)
            c.restore()
        }
        override fun setAlpha(a:Int){};override fun setColorFilter(f:android.graphics.ColorFilter?){};override fun getOpacity()=android.graphics.PixelFormat.TRANSLUCENT
    }

    private fun applyCalendarSlotDepth(view: View) {
        // La profondita' dello slot appartiene al set calendario, non ai popup.
        // Niki UI aggiunge un micro-riflesso fisico ma resta sempre confinato al profilo.
        val shape=when(calendarStyleSet){
            "NEBBIA_SOFT"->nebbiaSoftSlotShape
            "SCURO_ELEGANTE"->scuroEleganteSlotShape
            else->liquidGlassSlotShape
        }
        view.foreground=NikiCalendarSlotOverlayDrawable(1f,shape)
        if (calendarStyleSet == "LIQUID_GLASS") {
            view.elevation = dp(1).toFloat()
            view.translationZ = dp(0.5f).toFloat()
        } else {
            view.elevation = dp(3).toFloat()
            view.translationZ = dp(1).toFloat()
        }
    }


    private fun appGlassBackground(): Drawable {
        return when (popupBackdropEffect) {
            "SATIN" -> GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
                Color.rgb(244,247,250), Color.rgb(231,236,241), Color.rgb(244,247,250)
            ))
            "VETRO_SOFT" -> GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
                Color.rgb(232,238,244), Color.rgb(214,222,230), Color.rgb(239,243,247)
            ))
            "LIQUID" -> GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
                Color.rgb(218,227,235), Color.rgb(226,224,231), Color.rgb(215,232,235), Color.rgb(235,229,234)
            ))
            else -> ColorDrawable(Color.rgb(240,242,244))
        }
    }


    private fun modernEditText(): EditText = EditText(this).apply {
        textSize = 16f
        setSingleLine(true)
        setTextColor(Color.rgb(24,31,40))
        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        setHintTextColor(Color.rgb(130,135,142))
        setPadding(dp(14),0,dp(14),0)
        background = liquidInteractiveSurface(Color.rgb(247,248,250),18,Color.rgb(222,226,232),1)
        applyLiquidControlDepth(this)
        stateListAnimator = null
    }

    private fun paymentButtonStyle(): Button = Button(this).apply {
        text = "PAGA"
        setAllCaps(false)
        textSize = 13.5f
        minWidth = 0; minimumWidth = 0
        minHeight = 0; minimumHeight = 0
        setPadding(0,0,0,0)
        setTextColor(Color.rgb(20,91,165))
        background = liquidInteractiveSurface(Color.rgb(238,246,255),17,Color.rgb(190,218,248),1)
        applyLiquidControlDepth(this)
        stateListAnimator = null
    }

    private fun menuIconButtonStyle(): Button = Button(this).apply {
        text = "⋮"
        textSize = 18f
        minWidth = 0; minimumWidth = 0
        minHeight = 0; minimumHeight = 0
        setPadding(0,0,0,dp(1))
        setTextColor(Color.rgb(55,58,63))
        background = liquidInteractiveSurface(Color.rgb(246,248,250),16,Color.rgb(225,229,234),1)
        applyLiquidControlDepth(this)
        stateListAnimator = null
    }

    private fun editIconButtonStyle(): Button = Button(this).apply {
        text = "✎"
        setAllCaps(false)
        textSize = 15f
        minWidth = 0; minimumWidth = 0
        minHeight = 0; minimumHeight = 0
        setPadding(0,0,0,dp(1))
        setTextColor(Color.rgb(20,91,165))
        background = liquidInteractiveSurface(Color.rgb(246,249,253),17,Color.rgb(205,220,238),1)
        applyLiquidControlDepth(this)
        stateListAnimator = null
    }

    private fun buttonStyle(textValue: String): Button = Button(this).apply {
        text = textValue; textSize = 13.5f; setTextColor(Color.rgb(35,38,42)); gravity = Gravity.CENTER; setPadding(0,0,0,0)
        minHeight = 0; minimumHeight = 0; setAllCaps(false); stateListAnimator = null
        background = liquidInteractiveSurface(Color.rgb(241,243,246),18,Color.rgb(226,229,234),1)
        applyLiquidControlDepth(this)
    }

    private fun whitePersonDrawable(): Drawable = object : Drawable() {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(25,92,170); style = Paint.Style.FILL }
        override fun draw(canvas: Canvas) {
            val w = bounds.width().toFloat(); val h = bounds.height().toFloat()
            canvas.drawCircle(w * 0.5f, h * 0.28f, w * 0.18f, paint)
            val body = android.graphics.RectF(w * 0.23f, h * 0.50f, w * 0.77f, h * 0.94f)
            canvas.drawRoundRect(body, w * 0.16f, w * 0.16f, paint)
        }
        override fun setAlpha(alpha: Int) { paint.alpha = alpha }
        override fun setColorFilter(filter: android.graphics.ColorFilter?) { paint.colorFilter = filter }
        override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
        override fun getIntrinsicWidth(): Int = dp(18)
        override fun getIntrinsicHeight(): Int = dp(18)
    }

    private fun primaryButtonStyle(textValue: String): Button = Button(this).apply {
        text = textValue; textSize = 13.5f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0,0,0,0)
        minHeight = 0; minimumHeight = 0; setAllCaps(false); stateListAnimator = null
        background = liquidInteractiveSurface(Color.rgb(20,112,232),20,Color.rgb(145,205,255),1)
        applyLiquidControlDepth(this)
    }

    private fun softBlueButtonStyle(textValue: String): Button = Button(this).apply {
        text = textValue; textSize = 13.5f; setTextColor(Color.rgb(30,83,145)); gravity = Gravity.CENTER; setPadding(0,0,0,0)
        minHeight = 0; minimumHeight = 0; setAllCaps(false); stateListAnimator = null
        background = liquidInteractiveSurface(Color.rgb(235,244,255),18,Color.rgb(205,224,248),1)
        applyLiquidControlDepth(this)
    }

    private fun build() {
        currentScreen = "HOME"
        clearPopupBackdropEffect()
        popupBackdropCurrentDialog=null
        popupBackdropDialogs.clear()
        detachSettingsOverlay()
        trashReturnToSettings=false
        if(::searchInput.isInitialized) searchInput.setText("")
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(14),dp(16),dp(10));background=appGlassBackground()}
        val titleRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val brand=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        brand.addView(TextView(this).apply{text="➤";textSize=31f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(20,91,165));gravity=Gravity.CENTER;rotation=-18f},LinearLayout.LayoutParams(dp(42),dp(52)))
        val brandText=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL}
        val brandName=TextView(this).apply{
            text=android.text.SpannableStringBuilder().apply{append("Coach");setSpan(android.text.style.ForegroundColorSpan(Color.rgb(25,62,112)),0,5,android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);append("Flow");setSpan(android.text.style.ForegroundColorSpan(Color.rgb(20,128,235)),5,9,android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)}
            textSize=29f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER_VERTICAL;setIncludeFontPadding(false)
        }
        brandText.addView(brandName,LinearLayout.LayoutParams(-1,dp(36)))
        brandText.addView(TextView(this).apply{text="ALLENA  •  ORGANIZZA  •  CRESCI";textSize=7.5f;setTextColor(Color.rgb(115,125,140));letterSpacing=0.18f;gravity=Gravity.CENTER_VERTICAL;setIncludeFontPadding(false)},LinearLayout.LayoutParams(-1,dp(16)))
        brand.addView(brandText,LinearLayout.LayoutParams(0,dp(54),1f))
        titleRow.addView(brand,LinearLayout.LayoutParams(0,dp(56),1f))
        val dashButton=Button(this).apply{
            text=if(dashboardEnabled)"DASH  ●" else "DASH  ○";textSize=12.5f;setTextColor(Color.rgb(70,74,80));gravity=Gravity.CENTER;minHeight=0;minimumHeight=0;setPadding(dp(8),0,dp(8),0);setAllCaps(false);stateListAnimator=null
            background=roundedSurface(if(dashboardEnabled)Color.rgb(235,241,248)else Color.rgb(248,249,250),18,Color.rgb(220,223,227),1)
            setOnClickListener{dashboardEnabled=!dashboardEnabled;saveData();updateDashboardButton(this);render()}
        }
        titleRow.addView(dashButton,LinearLayout.LayoutParams(dp(78),dp(42)).apply{setMargins(dp(6),0,dp(4),0)})
        val settingsButton=Button(this).apply{
            text="⚙";textSize=21f;setTextColor(Color.rgb(55,58,63));gravity=Gravity.CENTER;minHeight=0;minimumHeight=0;setPadding(0,0,0,dp(2));setAllCaps(false);stateListAnimator=null
            contentDescription="Impostazioni"
            background=roundedSurface(Color.rgb(248,249,251),18,Color.rgb(220,223,227),1);setOnClickListener{settings()}
        }
        titleRow.addView(settingsButton,LinearLayout.LayoutParams(dp(48),dp(42)))
        root.addView(titleRow,LinearLayout.LayoutParams(-1,dp(56)))
        root.addView(TextView(this).apply{text="Clienti  •  Pacchetti  •  Calendario  •  Pagamenti";textSize=15f;setTextColor(Color.rgb(92,95,101));setPadding(dp(2),0,0,dp(5))},LinearLayout.LayoutParams(-1,dp(34)))

        val searchRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        searchInput=modernEditText().apply{
            hint="🔍  Cerca cliente...";textSize=15f;setSingleLine(true);setPadding(dp(14),0,dp(14),0);background=roundedSurface(Color.WHITE,18,Color.rgb(226,229,234),1)
            addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){render()};override fun afterTextChanged(s:Editable?){}})
        }
        searchRow.addView(searchInput,LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(0,dp(6),dp(6),dp(8))})
        val sortButton=buttonStyle("☷").apply{
            textSize=21f;contentDescription="Ordina clienti"
            setOnClickListener{showHomeSortDialog()}
        }
        searchRow.addView(sortButton,LinearLayout.LayoutParams(dp(50),dp(50)).apply{setMargins(0,dp(6),0,dp(8))})
        root.addView(searchRow,LinearLayout.LayoutParams(-1,dp(58)))

        list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,dp(4),0,dp(10))}
        val scroll=ScrollView(this).apply{addView(list,ViewGroup.LayoutParams(-1,-2))}
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))

        val bottom=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val add=softBlueButtonStyle("＋ Nuovo").apply{setOnClickListener{newPackageMenu()}}
        val cal=softBlueButtonStyle("📅 Calendario").apply{setOnClickListener{calendarAutoFocusOnOpen=true;calendarSwipeArmed=0;calendarScreen()}}
        // I comandi inferiori della Home usano la stessa altezza del pulsante
        // "Torna ai clienti" del Calendario, così il passaggio Home ↔ Calendario
        // mantiene proporzioni coerenti e non fa percepire un cambio di scala.
        bottom.addView(add,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,dp(4),dp(4),0)})
        bottom.addView(cal,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(4),dp(4),0,0)})
        root.addView(bottom,LinearLayout.LayoutParams(-1,dp(56)))
        prepareEdgeToEdgeRoot(root)
        setContentView(root);render()
    }

    private fun updateDashboardButton(button:Button){button.text=if(dashboardEnabled)"DASH  ●" else "DASH  ○";button.background=appGlassSurface(if(dashboardEnabled)Color.rgb(235,241,248)else Color.rgb(248,249,250),18,Color.rgb(210,222,235),1)}

    private fun mainMoreMenu(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(4),dp(18),dp(8))}
        var optionsDialog: AlertDialog? = null
        var pendingOptionAction: (() -> Unit)? = null
        fun option(title:String,subtitle:String,icon:String,action:()->Unit){
            val row=LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL
                gravity=Gravity.CENTER_VERTICAL
                setPadding(dp(14),dp(12),dp(12),dp(12))
                background=roundedSurface(Color.rgb(246,248,250),20,Color.rgb(228,231,235),1)
                isClickable=true
                isFocusable=true
            }
            row.addView(TextView(this).apply{
                text=icon;textSize=22f;gravity=Gravity.CENTER
                setBackground(roundedSurface(Color.WHITE,16))
                setPadding(dp(8),dp(6),dp(8),dp(6))
            },LinearLayout.LayoutParams(dp(50),dp(50)))
            val texts=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
            texts.addView(TextView(this@MainActivity).apply{
                text=title;textSize=16f;setTextColor(Color.rgb(25,28,32))
                setTypeface(null,android.graphics.Typeface.BOLD)
            })
            texts.addView(TextView(this@MainActivity).apply{
                text=subtitle;textSize=12.5f;setTextColor(Color.rgb(100,104,110))
                setPadding(0,dp(3),0,0)
            })
            row.addView(texts,LinearLayout.LayoutParams(0,-2,1f))
            row.addView(TextView(this@MainActivity).apply{
                text="›";textSize=28f;setTextColor(Color.rgb(120,124,130));gravity=Gravity.CENTER
            },LinearLayout.LayoutParams(dp(28),dp(50)))
            row.setOnClickListener{
                pendingOptionAction=action
                optionsDialog?.dismiss()
            }
            box.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))})
        }
        option("Backup e dati","Automatico • Esporta • Importa","☁"){backupMenu()}
        val trashCount=trashItems.size
        option("Cestino",if(trashCount==0)"Vuoto" else "$trashCount elementi • eliminazione automatica dopo 10 giorni","🗑"){trashScreen()}
        option("Impostazioni","Preferenze e gestione dell'app","⚙"){settings()}
        val close=Button(this).apply{
            text="Chiudi";setAllCaps(false);textSize=14f;setTextColor(Color.rgb(0,125,110))
            setBackgroundColor(Color.TRANSPARENT);stateListAnimator=null
        }
        box.addView(close,LinearLayout.LayoutParams(-1,dp(46)).apply{setMargins(0,dp(4),0,0)})
        val dialog=AlertDialog.Builder(this).setTitle("Altre opzioni").setView(box).create()
        optionsDialog=dialog
        preparePopupBackdrop(dialog)
        dialog.setOnShowListener{
            popupBackdropCurrentDialog=dialog
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28))
            applyPopupBackdropEffect(dialog)
            dialog.window?.setDimAmount(0.42f)
            close.setOnClickListener{dialog.dismiss()}
        }
        dialog.setOnDismissListener{
            removePopupBackdropDialog(dialog)
            optionsDialog=null
            val next=pendingOptionAction
            pendingOptionAction=null
            next?.invoke()
        }
        dialog.show()
    }

    private fun newPackageMenu(){
        // Unica finestra Glass. Il contenuto del form è già nella stessa gerarchia:
        // al click cambiamo solo la visibilità e allarghiamo la Window, senza creare
        // o rimuovere View durante l'interazione.
        val scroll=ScrollView(this).apply{isFillViewport=true;clipToPadding=false;overScrollMode=View.OVER_SCROLL_NEVER}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(8),dp(18),dp(12))}
        scroll.addView(box,ViewGroup.LayoutParams(-1,-2))

        box.addView(TextView(this).apply{text="Crea nuovo pacchetto";textSize=22f;setTextColor(Color.rgb(28,30,33));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.NORMAL)},LinearLayout.LayoutParams(-1,dp(38)))
        box.addView(TextView(this).apply{text="Scegli il tipo di pacchetto da creare";textSize=14f;setTextColor(Color.rgb(95,100,108));gravity=Gravity.CENTER;setPadding(0,0,0,dp(8))},LinearLayout.LayoutParams(-1,dp(30)))

        val options=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        fun makeOption(title:String,subtitle:String,icon:String)=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(12),dp(12),dp(12));background=liquidInteractiveSurface(Color.rgb(246,248,250),20,Color.rgb(205,224,248),1);isClickable=true;isFocusable=true
            addView(TextView(this@MainActivity).apply{text=icon;textSize=23f;gravity=Gravity.CENTER;setBackground(roundedSurface(Color.WHITE,16));setPadding(dp(8),dp(6),dp(8),dp(6))},LinearLayout.LayoutParams(dp(50),dp(50)))
            val texts=LinearLayout(this@MainActivity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
            texts.addView(TextView(this@MainActivity).apply{text=title;textSize=16f;setTextColor(Color.rgb(25,28,32));setTypeface(null,android.graphics.Typeface.BOLD)})
            texts.addView(TextView(this@MainActivity).apply{text=subtitle;textSize=12.5f;setTextColor(Color.rgb(100,104,110));setPadding(0,dp(3),0,0)})
            addView(texts,LinearLayout.LayoutParams(0,-2,1f))
            addView(TextView(this@MainActivity).apply{text="›";textSize=28f;setTextColor(Color.rgb(120,124,130));gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(28),dp(50)))
        }
        val weeklyOption=makeOption("Pacchetto 12 settimane","3 rate • Bronze / Silver / Gold","📦")
        val sessionOption=makeOption("Pacchetto sedute","Numero sedute e costo personalizzabili","🏋️")
        options.addView(weeklyOption,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))})
        options.addView(sessionOption,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))})
        box.addView(options)

        fun label(t:String)=TextView(this).apply{text=t;textSize=13f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(82,87,94));setPadding(dp(2),0,0,dp(4))}
        fun field(title:String,hint:String,inputTypeValue:Int=0):LinearLayout{
            val group=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
            group.addView(label(title))
            val edit=modernEditText().apply{this.hint=hint;inputType=if(inputTypeValue==0) android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS else inputTypeValue;setSingleLine(true);textSize=16f;setPadding(dp(14),0,dp(14),0)}
            group.addView(edit,LinearLayout.LayoutParams(-1,dp(52)))
            return group
        }

        val form=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE}
        val nameGroup=field("Cliente","Cognome e Nome")
        val name=nameGroup.getChildAt(1) as EditText
        val dateGroup=field("Data di inizio","Data (gg/mm/aaaa)",2)
        val date=dateGroup.getChildAt(1) as EditText
        setupDateInput(date);date.setText(LocalDate.now().format(fmt))
        val typeGroup=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE}
        typeGroup.addView(label("Tipo pacchetto"))
        val type=Spinner(this).apply{adapter=centeredSpinnerAdapter(listOf("BRONZE • 12 sedute","SILVER • 24 sedute","GOLD • 36 sedute"));installNikiTypeDropdown(this,true)}
        typeGroup.addView(type,LinearLayout.LayoutParams(-1,dp(52)))
        val sessionGroup=field("Sedute disponibili","Numero sedute",2).apply{visibility=View.GONE}
        val sessions=sessionGroup.getChildAt(1) as EditText
        val costGroup=field("Costo totale","Costo totale (€)",2)
        val cost=costGroup.getChildAt(1) as EditText
        form.addView(nameGroup,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})
        form.addView(dateGroup,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})
        form.addView(typeGroup,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})
        form.addView(sessionGroup,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})
        form.addView(costGroup,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(16))})
        val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val cancel=TextView(this).apply{text="ANNULLA";textSize=14f;setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);isClickable=true;background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(218,225,234),1);applyLiquidControlDepth(this)}
        val create=TextView(this).apply{text="CREA PACCHETTO";textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;isClickable=true;background=liquidInteractiveSurface(Color.rgb(232,243,255),20,Color.rgb(188,211,238),1);applyLiquidControlDepth(this)}
        buttons.addView(cancel,LinearLayout.LayoutParams(0,dp(48),1f));buttons.addView(create,LinearLayout.LayoutParams(0,dp(48),1.25f))
        form.addView(buttons,LinearLayout.LayoutParams(-1,dp(52)))
        box.addView(form,LinearLayout.LayoutParams(-1,-2))

        val close=Button(this).apply{text="Chiudi";setAllCaps(false);textSize=14f;setTextColor(Color.rgb(20,91,165));minHeight=0;minimumHeight=0;stateListAnimator=null;background=liquidInteractiveSurface(Color.rgb(248,249,251),18,Color.rgb(220,226,234),1);applyLiquidControlDepth(this)}
        box.addView(close,LinearLayout.LayoutParams(-1,dp(46)).apply{setMargins(0,dp(6),0,0)})

        val dialog=AlertDialog.Builder(this).setView(scroll).create()
        styleOneUiDialog(dialog)
        dialog.setOnShowListener{
            popupBackdropCurrentDialog=dialog
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28))
            applyPopupBackdropEffect(dialog)
            dialog.window?.setDimAmount(0.38f)
        }

        fun showPackageForm(weekly:Boolean){
            options.visibility=View.GONE
            close.visibility=View.GONE
            form.visibility=View.VISIBLE
            typeGroup.visibility=if(weekly) View.VISIBLE else View.GONE
            sessionGroup.visibility=if(weekly) View.GONE else View.VISIBLE
            form.requestLayout()
            scroll.post{
                val w=dialog.window ?: return@post
                val m=resources.displayMetrics
                w.setLayout((m.widthPixels*0.92f).toInt(),(m.heightPixels*0.86f).toInt())
                w.setGravity(Gravity.CENTER)
                w.attributes = w.attributes.apply { gravity = Gravity.CENTER; x = 0; y = dp(80) }
                scroll.fullScroll(View.FOCUS_UP)
            }
        }
        weeklyOption.setOnClickListener{showPackageForm(true)}
        sessionOption.setOnClickListener{showPackageForm(false)}
        close.setOnClickListener{dialog.dismiss()}
        cancel.setOnClickListener{dialog.dismiss()}
        create.setOnClickListener{
            try{
                val n=normalizeDisplayName(name.text.toString());val d=parseDate(date.text.toString());val c=cost.text.toString().trim().toInt();require(n.isNotEmpty()&&c>0)
                if(typeGroup.visibility==View.VISIBLE){
                    val k=when(type.selectedItemPosition){0->"BRONZE";1->"SILVER";else->"GOLD"}
                    packs.add(Pack(n,d,c,0,null,k,when(k){"BRONZE"->12;"SILVER"->24;else->36},true))
                }else{
                    val total=sessions.text.toString().trim().toInt();require(total>0)
                    sessionPacks.add(SessionPack(nextSessionPackId++,n,d,total,c,0,true))
                }
                saveData();render();dialog.dismiss()
            }catch(_:Exception){Toast.makeText(this,if(typeGroup.visibility==View.VISIBLE)"Controlla nome, data, tipo e costo." else "Controlla nome, data, numero sedute e costo.",Toast.LENGTH_LONG).show()}
        }
        listOf<View>(name,date,sessions,cost).forEach{field->field.setOnFocusChangeListener{_,hasFocus->if(hasFocus)scroll.post{scroll.smoothScrollTo(0,(field.top-dp(24)).coerceAtLeast(0))}}}
        dialog.show()
    }

    private fun newSessionPack(){
        val page=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(8),dp(18),dp(12))}
        val scroll=ScrollView(this).apply{isFillViewport=true;clipToPadding=false}
        scroll.addView(page,ViewGroup.LayoutParams(-1,-2))
        // Il titolo e\"Nuovo pacchetto sedute\" non viene ripetuto: la card introduttiva identifica gia il tipo di pacchetto.
        val intro=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(12));background=roundedSurface(Color.rgb(239,247,255),20,Color.rgb(205,224,248),1)}
        intro.addView(TextView(this).apply{text="🏋️";textSize=22f;gravity=Gravity.CENTER;setBackground(roundedSurface(Color.WHITE,16));setPadding(dp(8),dp(6),dp(8),dp(6))},LinearLayout.LayoutParams(dp(50),dp(50)))
        val introText=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
        introText.addView(TextView(this@MainActivity).apply{text="Pacchetto a sedute";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,55,85))})
        introText.addView(TextView(this@MainActivity).apply{text="Pagamento unico • consumo sincronizzato con il calendario";textSize=12.5f;setTextColor(Color.rgb(75,100,125));setPadding(0,dp(3),0,0)})
        intro.addView(introText,LinearLayout.LayoutParams(0,-2,1f));page.addView(intro,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(16))})
        fun field(title:String,hint:String,inputTypeValue:Int=0):EditText{
            page.addView(TextView(this).apply{text=title;textSize=13f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(82,87,94));setPadding(dp(2),0,0,dp(4))})
            return modernEditText().apply{this.hint=hint;inputType=if(inputTypeValue==0) android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS else inputTypeValue;setSingleLine(true);textSize=16f;setPadding(dp(14),0,dp(14),0)}
        }
        val name=field("Cliente","Cognome e Nome").apply{
            isFocusable=true
            isFocusableInTouchMode=true
            isClickable=true
            showSoftInputOnFocus=true
            setOnTouchListener { v, event ->
                if(event.action == android.view.MotionEvent.ACTION_DOWN){
                    v.requestFocusFromTouch()
                }
                false
            }
        }
        page.addView(name,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(12))})
        val date=field("Data di inizio","Data (gg/mm/aaaa)",2);setupDateInput(date);date.setText(LocalDate.now().format(fmt))
        page.addView(date,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(12))})
        val sessions=field("Sedute disponibili","Numero sedute",2)
        page.addView(sessions,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(12))})
        val cost=field("Importo del pacchetto","Costo totale (€)",2)
        page.addView(cost,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(16))})
        val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val cancel=TextView(this).apply{text="ANNULLA";textSize=14f;setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);isClickable=true;background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(218,225,234),1);applyLiquidControlDepth(this)}
        val create=TextView(this).apply{text="CREA PACCHETTO";textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;isClickable=true;background=liquidInteractiveSurface(Color.rgb(232,243,255),20,Color.rgb(188,211,238),1);applyLiquidControlDepth(this)}
        buttons.addView(cancel,LinearLayout.LayoutParams(0,dp(48),1f));buttons.addView(create,LinearLayout.LayoutParams(0,dp(48),1.25f))
        page.addView(buttons,LinearLayout.LayoutParams(-1,dp(52)))
        val dialog=AlertDialog.Builder(this).setView(scroll).create()
        styleFullPageCoachDialog(dialog)
        // Il focus iniziale resta sulla pagina: il primo tocco sul nome deve
        // dare subito focus al campo e aprire la tastiera.
        scroll.isFocusableInTouchMode=true
        scroll.requestFocus()
        dialog.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        cancel.setOnClickListener{dialog.dismiss();window.decorView.post{newPackageMenu()}}
        create.setOnClickListener{
            try{val n=normalizeDisplayName(name.text.toString());val d=parseDate(date.text.toString());val total=sessions.text.toString().trim().toInt();val c=cost.text.toString().trim().toInt();require(n.isNotEmpty()&&total>0&&c>0)
                sessionPacks.add(SessionPack(nextSessionPackId++,n,d,total,c,0,true));saveData();render();dialog.dismiss()
            }catch(_:Exception){Toast.makeText(this,"Controlla nome, data, numero sedute e costo.",Toast.LENGTH_LONG).show()}
        }
        listOf<View>(name,date,sessions,cost).forEach{field->
            field.setOnFocusChangeListener{view,hasFocus->
                if(hasFocus){
                    scroll.post{scroll.smoothScrollTo(0,(field.top-dp(24)).coerceAtLeast(0))}
                }
            }
        }
        dialog.show()
        dialog.window?.decorView?.post{ name.clearFocus(); scroll.requestFocus(); val imm=getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager; imm.hideSoftInputFromWindow(name.windowToken,0) }
    }

    private fun normalizeDisplayName(value:String):String{
        return value.trim().split(Regex("\\s+")).filter{it.isNotBlank()}.joinToString(" "){word->
            word.lowercase().replaceFirstChar{if(it.isLowerCase())it.titlecase() else it.toString()}
        }
    }

    private fun identityKey(value:String):String{
        return value.trim().lowercase().split(Regex("\\s+")).filter{it.isNotBlank()}.sorted().joinToString(" ")
    }

    private fun newPack(){
        val page=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(8),dp(18),dp(12))}
        val scroll=ScrollView(this).apply{isFillViewport=true;clipToPadding=false}
        scroll.addView(page,ViewGroup.LayoutParams(-1,-2))
        // Il titolo e\"Nuovo pacchetto 12 settimane\" non viene ripetuto: la card introduttiva identifica gia il tipo di pacchetto.
        val intro=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(12));background=roundedSurface(Color.rgb(239,247,255),20,Color.rgb(205,224,248),1)}
        intro.addView(TextView(this).apply{text="📦";textSize=22f;gravity=Gravity.CENTER;setBackground(roundedSurface(Color.WHITE,16));setPadding(dp(8),dp(6),dp(8),dp(6))},LinearLayout.LayoutParams(dp(50),dp(50)))
        val it=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
        it.addView(TextView(this@MainActivity).apply{text="Pacchetto 12 settimane";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,55,85))})
        it.addView(TextView(this@MainActivity).apply{text="Bronze • Silver • Gold • programmazione dal calendario";textSize=12.5f;setTextColor(Color.rgb(75,100,125));setPadding(0,dp(3),0,0)})
        intro.addView(it,LinearLayout.LayoutParams(0,-2,1f));page.addView(intro,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(16))})
        fun label(t:String)=TextView(this).apply{text=t;textSize=13f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(82,87,94));setPadding(dp(2),0,0,dp(4))}
        val name=modernEditText().apply{hint="Cognome e Nome";setSingleLine(true);textSize=16f}
        val date=modernEditText().apply{hint="Data di inizio (gg/mm/aaaa)";inputType=2;setSingleLine(true);textSize=16f};setupDateInput(date);date.setText(LocalDate.now().format(fmt))
        val type=Spinner(this).also{installNikiTypeDropdown(it, true)}.apply{adapter=centeredSpinnerAdapter(listOf("BRONZE • 12 sedute","SILVER • 24 sedute","GOLD • 36 sedute"))}
        val cost=modernEditText().apply{hint="Costo totale (€)";inputType=2;setSingleLine(true);textSize=16f}
        page.addView(label("Cliente"));page.addView(name,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(12))})
        page.addView(label("Data di inizio"));page.addView(date,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(12))})
        page.addView(label("Tipo pacchetto"));page.addView(type,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(12))})
        page.addView(label("Costo totale"));page.addView(cost,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(16))})
        val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val cancel=TextView(this).apply{text="ANNULLA";textSize=14f;setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);isClickable=true;background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(218,225,234),1);applyLiquidControlDepth(this)}
        val create=TextView(this).apply{text="CREA PACCHETTO";textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;isClickable=true;background=liquidInteractiveSurface(Color.rgb(232,243,255),20,Color.rgb(188,211,238),1);applyLiquidControlDepth(this)}
        buttons.addView(cancel,LinearLayout.LayoutParams(0,dp(48),1f));buttons.addView(create,LinearLayout.LayoutParams(0,dp(48),1.25f));page.addView(buttons,LinearLayout.LayoutParams(-1,dp(52)))
        val dialog=AlertDialog.Builder(this).setView(scroll).create();styleFullPageCoachDialog(dialog)
        scroll.isFocusableInTouchMode=true
        scroll.requestFocus()
        dialog.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        cancel.setOnClickListener{dialog.dismiss();window.decorView.post{newPackageMenu()}}
        create.setOnClickListener{try{val n=normalizeDisplayName(name.text.toString());val d=parseDate(date.text.toString());val c=cost.text.toString().trim().toInt();require(n.isNotEmpty()&&c>0);val kind=when(type.selectedItemPosition){0->"BRONZE";1->"SILVER";else->"GOLD"};packs.add(Pack(n,d,c,0,null,kind,when(kind){"BRONZE"->12;"SILVER"->24;else->36},true));saveData();render();dialog.dismiss()}catch(_:Exception){Toast.makeText(this,"Controlla nome, data, tipo e costo.",Toast.LENGTH_LONG).show()}}
        listOf<View>(name,date,cost).forEach{field->field.setOnFocusChangeListener{_,hasFocus->if(hasFocus)scroll.post{scroll.smoothScrollTo(0,(field.top-dp(24)).coerceAtLeast(0))}}}
        dialog.show()
        dialog.window?.decorView?.post{ name.clearFocus(); scroll.requestFocus(); val imm=getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager; imm.hideSoftInputFromWindow(name.windowToken,0) }
    }

    private fun setupDateInput(edit:EditText){edit.addTextChangedListener(object:TextWatcher{private var editing=false;override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){};override fun afterTextChanged(s:Editable?){if(editing||s==null)return;val digits=s.toString().filter{it.isDigit()}.take(8);val formatted=buildString{digits.forEachIndexed{i,c->if(i==2||i==4)append('/');append(c)}};if(formatted!=s.toString()){editing=true;edit.setText(formatted);edit.setSelection(formatted.length);editing=false}}})}
    private fun parseDate(value:String):LocalDate=LocalDate.parse(value.trim(),fmt)

    private fun prepareSettingsSystemBars(){
        // Prima di mostrare la finestra Settings rendiamo già la system bar della
        // Activity sottostante identica a quella delle Settings. In questo modo
        // durante il passaggio non rimane per un attimo la Home con icone bianche
        // sotto al nuovo pannello bianco.
        window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor=Color.WHITE
        window.navigationBarColor=Color.WHITE
        if(android.os.Build.VERSION.SDK_INT >= 28) window.navigationBarDividerColor=Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        if(android.os.Build.VERSION.SDK_INT >= 30){
            window.insetsController?.setSystemBarsAppearance(
                android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,
                android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            )
        }
    }

    private fun restoreSettingsSystemBars(){
        window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor=Color.TRANSPARENT
        window.navigationBarColor=Color.TRANSPARENT
        if(android.os.Build.VERSION.SDK_INT >= 28) window.navigationBarDividerColor=Color.TRANSPARENT
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        if(android.os.Build.VERSION.SDK_INT >= 30){
            window.insetsController?.setSystemBarsAppearance(
                android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,
                android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            )
            window.setDecorFitsSystemWindows(false)
        }
    }

    private fun restoreHomeSystemBars(){
        window.statusBarColor=Color.TRANSPARENT
        window.navigationBarColor=Color.TRANSPARENT
        if(android.os.Build.VERSION.SDK_INT >= 28) window.navigationBarDividerColor=Color.TRANSPARENT
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        if(android.os.Build.VERSION.SDK_INT >= 30){
            window.insetsController?.setSystemBarsAppearance(
                android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,
                android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            )
        }
    }

    private fun detachSettingsOverlay(){
        settingsSubpageOverlay?.let { page ->
            (page.parent as? ViewGroup)?.removeView(page)
        }
        settingsSubpageOverlay=null
        settingsOverlay?.let { overlay ->
            (overlay.parent as? ViewGroup)?.removeView(overlay)
        }
        settingsOverlay=null
        settingsOverlayContent=null
        settingsTransitionPending=false
    }

    private fun settings(){
        // Impostazioni non è più una AlertDialog/Window separata: è un overlay
        // della stessa Activity. Così la status bar resta sotto il controllo
        // della stessa Window durante tutta la transizione Home → Impostazioni.
        if(settingsOverlay != null){
            settingsTransitionPending=false
            restoreSettingsSystemBars()
            settingsOverlayContent?.animate()?.cancel()
            settingsOverlayContent?.apply{
                alpha=0f
                translationX=dp(34).toFloat()
                scaleX=0.985f
                scaleY=0.985f
                animate().alpha(1f).translationX(0f).scaleX(1f).scaleY(1f)
                    .setDuration(210)
                    .setInterpolator(android.view.animation.DecelerateInterpolator(1.15f))
                    .withLayer().start()
            }
            return
        }

        prepareSettingsSystemBars()
        val contentRoot=findViewById<ViewGroup>(android.R.id.content)
        val overlay=FrameLayout(this).apply{
            setBackgroundColor(Color.WHITE)
            elevation=dp(12).toFloat()
            isClickable=true
            isFocusable=true
        }
        val scroll=ScrollView(this).apply{
            isFillViewport=true
            overScrollMode=View.OVER_SCROLL_IF_CONTENT_SCROLLS
            clipToPadding=false
        }
        val box=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(14),dp(8),dp(14),dp(18))
        }
        box.addView(TextView(this).apply{
            text="Impostazioni"
            textSize=24f
            setTextColor(Color.rgb(24,27,31))
            setTypeface(null,android.graphics.Typeface.BOLD)
            gravity=Gravity.CENTER
            setPadding(0,dp(4),0,dp(14))
        })

        fun card(title:String,subtitle:String,icon:String,enabled:Boolean=true,onClick:()->Unit={}){
            val row=LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL
                gravity=Gravity.CENTER_VERTICAL
                setPadding(dp(14),dp(11),dp(12),dp(11))
                isClickable=enabled
                isFocusable=enabled
                background=appGlassSurface(if(enabled)Color.WHITE else Color.rgb(246,247,249),20,Color.rgb(205,220,235),1)
                alpha=if(enabled)1f else 0.52f
                if(enabled)setOnClickListener{
                    settingsTransitionPending=true
                    scroll.animate().cancel()
                    scroll.animate().translationX((-dp(34)).toFloat()).alpha(0f)
                        .setDuration(145)
                        .setInterpolator(android.view.animation.AccelerateInterpolator(1.15f))
                        .withLayer()
                        .withEndAction{onClick()}
                        .start()
                }
            }
            val iconBox=TextView(this).apply{
                text=icon;textSize=21f;gravity=Gravity.CENTER
                setBackground(roundedSurface(if(enabled)Color.rgb(239,246,255) else Color.rgb(238,239,241),16))
                setPadding(dp(7),dp(5),dp(7),dp(5))
            }
            row.addView(iconBox,LinearLayout.LayoutParams(dp(50),dp(50)))
            val texts=LinearLayout(this).apply{
                orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),0,dp(8),0)
            }
            texts.addView(TextView(this@MainActivity).apply{
                text=title;textSize=16.5f;setTextColor(Color.rgb(25,28,32));setTypeface(null,android.graphics.Typeface.BOLD);setIncludeFontPadding(false)
            })
            texts.addView(TextView(this@MainActivity).apply{
                text=subtitle;textSize=12.5f;setTextColor(Color.rgb(95,99,105));setPadding(0,dp(5),0,0);setMaxLines(2);ellipsize=android.text.TextUtils.TruncateAt.END
            })
            row.addView(texts,LinearLayout.LayoutParams(0,-2,1f))
            row.addView(TextView(this).apply{
                text=if(enabled)"›" else "In arrivo";textSize=if(enabled)28f else 11f
                setTextColor(if(enabled)Color.rgb(105,110,116) else Color.rgb(115,120,126));gravity=Gravity.CENTER
            },LinearLayout.LayoutParams(if(enabled)dp(30) else dp(62),dp(50)))
            box.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})
        }

        card("Generali","Aspetto e preferenze dell'app","⚙"){generalSettingsDialog()}
        card("Calendario","Giorni, griglia e personalizzazione dei pulsanti","📅"){calendarSettingsDialog()}
        card("Appuntamenti","Tipi, durata e capienza","👥"){appointmentSettingsDialog()}
        card("Pagamenti","Rate, metodi e preferenze","💳",false)
        card("Chiusura ferie","Periodi di chiusura e recupero scadenze","🌴"){closureSettingsDialog()}
        card("Notifiche","Promemoria e avvisi","🔔",false)
        card("Backup e dati","Backup automatico, esportazione e importazione","☁"){backupMenu()}
        card("Cestino","Elementi eliminati e ripristino","🗑"){trashScreen(true)}
        card("Guida CoachFlow","Manuale e consigli per usare l'app","📖",false)
        card("Informazioni","Versione app, build e supporto","ⓘ"){informationDialog()}

        scroll.addView(box,ViewGroup.LayoutParams(-1,-2))
        overlay.addView(scroll,FrameLayout.LayoutParams(-1,-1))
        contentRoot.addView(overlay,ViewGroup.LayoutParams(-1,-1))
        settingsOverlay=overlay
        settingsOverlayContent=scroll

        overlay.setOnApplyWindowInsetsListener { v,insets ->
            val bars=if(android.os.Build.VERSION.SDK_INT>=30){
                insets.getInsets(android.view.WindowInsets.Type.systemBars())
            }else{
                android.graphics.Insets.of(insets.systemWindowInsetLeft,insets.systemWindowInsetTop,insets.systemWindowInsetRight,insets.systemWindowInsetBottom)
            }
            scroll.setPadding(0,bars.top,0,bars.bottom)
            insets
        }
        overlay.requestApplyInsets()

        restoreSettingsSystemBars()
        scroll.alpha=0f
        scroll.translationX=dp(24).toFloat()
        scroll.animate().alpha(1f).translationX(0f)
            .setDuration(210)
            .setInterpolator(android.view.animation.DecelerateInterpolator(1.15f))
            .withLayer().start()
    }

    private fun informationDialog(){
        val vName = BuildConfig.VERSION_NAME
        val vCode = BuildConfig.VERSION_CODE
        val box=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(20),dp(8),dp(20),dp(8))
        }
        box.addView(TextView(this).apply{
            text="CoachFlow"
            textSize=22f
            setTypeface(null,android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(25,62,112))
            gravity=Gravity.CENTER
            setPadding(0,0,0,dp(12))
        })
        fun row(label:String,value:String){
            val r=LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL
                gravity=Gravity.CENTER_VERTICAL
                setPadding(0,dp(7),0,dp(7))
            }
            r.addView(TextView(this).apply{
                text=label
                textSize=14f
                setTextColor(Color.rgb(95,99,105))
            },LinearLayout.LayoutParams(0,-2,1f))
            r.addView(TextView(this).apply{
                text=value
                textSize=14.5f
                setTypeface(null,android.graphics.Typeface.BOLD)
                setTextColor(Color.rgb(30,34,40))
                gravity=Gravity.RIGHT
            })
            box.addView(r)
        }
        row("Versione","$vName Beta")
        row("Build","$vCode")
        row("Codice versione","$vCode")
        val close=TextView(this).apply{
            text="CHIUDI"
            textSize=14f
            setTypeface(null,android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(32,68,104))
            gravity=Gravity.CENTER
            setPadding(0,0,0,0)
            background=liquidInteractiveSurface(
                Color.argb(30,220,235,248),
                18,
                Color.rgb(190,214,232),
                1
            )
            isClickable=true
            stateListAnimator=null
            applyLiquidControlDepth(this)
        }
        box.addView(close,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(8),0,dp(4))})
        val dialog = AlertDialog.Builder(this)
            .setTitle("Informazioni app")
            .setView(box)
            .create()
        styleModernCoachDialog(dialog)
        // La card Informazioni nasconde temporaneamente la lista Impostazioni
        // durante l'apertura. Alla chiusura della finestra dobbiamo rivelarla
        // esplicitamente, altrimenti restava visibile solo l'overlay bianco.
        dialog.setOnDismissListener {
            removePopupBackdropDialog(dialog)
            settingsOverlayContent?.apply {
                animate().cancel()
                alpha = 0f
                translationX = (-dp(18)).toFloat()
                scaleX = 1f
                scaleY = 1f
                animate().alpha(1f).translationX(0f)
                    .setDuration(190)
                    .setInterpolator(android.view.animation.DecelerateInterpolator(1.1f))
                    .withLayer().start()
            }
        }
        dialog.show()
        close.setOnClickListener { dialog.dismiss() }
    }

    private fun showSettingsSubpage(content:View,title:String){
        val parent=settingsOverlay ?: return
        settingsSubpageOverlay?.let{(it.parent as? ViewGroup)?.removeView(it)}
        val page=FrameLayout(this).apply{setBackgroundColor(Color.WHITE);isClickable=true;isFocusable=true;elevation=dp(16).toFloat()}
        val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(8),0,dp(14),0);background=ColorDrawable(Color.WHITE)}
        val back=TextView(this).apply{text="‹";textSize=36f;setTextColor(Color.rgb(55,60,66));gravity=Gravity.CENTER;setPadding(0,0,0,dp(3));isClickable=true;setOnClickListener{closeSettingsSubpage()}}
        header.addView(back,LinearLayout.LayoutParams(dp(48),dp(56)))
        header.addView(TextView(this).apply{text=title;textSize=19f;setTextColor(Color.rgb(24,27,31));setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,dp(56),1f))
        page.addView(header,FrameLayout.LayoutParams(-1,dp(56),Gravity.TOP))
        val body=FrameLayout(this).apply{addView(content,FrameLayout.LayoutParams(-1,-1));setPadding(0,dp(56),0,0);clipToPadding=false}
        page.addView(body,FrameLayout.LayoutParams(-1,-1))
        parent.addView(page,FrameLayout.LayoutParams(-1,-1))
        settingsSubpageOverlay=page
        page.setOnApplyWindowInsetsListener{v,insets->
            val bars=if(android.os.Build.VERSION.SDK_INT>=30)insets.getInsets(android.view.WindowInsets.Type.systemBars()) else android.graphics.Insets.of(insets.systemWindowInsetLeft,insets.systemWindowInsetTop,insets.systemWindowInsetRight,insets.systemWindowInsetBottom)
            header.setPadding(dp(8),bars.top,dp(14),0)
            body.setPadding(0,dp(56),0,bars.bottom)
            insets
        }
        page.requestApplyInsets()
        page.alpha=0f;page.translationX=dp(28).toFloat();page.scaleX=.985f;page.scaleY=.985f
        page.animate().alpha(1f).translationX(0f).scaleX(1f).scaleY(1f).setDuration(210).setInterpolator(android.view.animation.DecelerateInterpolator(1.15f)).withLayer().start()
    }

    private fun closeSettingsSubpage(revealSettings:Boolean=true){
        val page=settingsSubpageOverlay ?: return
        val parent=settingsOverlay
        val settingsContent=settingsOverlayContent
        page.animate().cancel()
        // The Settings list is intentionally hidden while a subpage is open.
        // Reveal it at the same time the subpage slides away, so Android back/swipe
        // never exposes a blank layer or the Home underneath.
        if(revealSettings){
            settingsContent?.animate()?.cancel()
            settingsContent?.apply{
                alpha=0f
                translationX=(-dp(18)).toFloat()
                animate().alpha(1f).translationX(0f)
                    .setDuration(190)
                    .setInterpolator(android.view.animation.DecelerateInterpolator(1.1f))
                    .withLayer().start()
            }
        }
        page.animate().alpha(0f).translationX(dp(28).toFloat()).setDuration(170)
            .setInterpolator(android.view.animation.DecelerateInterpolator(1.1f)).withLayer().withEndAction{
                (page.parent as? ViewGroup)?.removeView(page)
                settingsSubpageOverlay=null
                if(parent==null)settingsContent?.alpha=1f
            }.start()
    }

    private fun generalSettingsDialog(){
        val scroll=ScrollView(this).apply{isFillViewport=true;clipToPadding=false;overScrollMode=View.OVER_SCROLL_IF_CONTENT_SCROLLS}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(10),dp(18),dp(28))}

        fun sectionCard(title:String, subtitle:String?=null): LinearLayout {
            val card=LinearLayout(this).apply{
                orientation=LinearLayout.VERTICAL
                setPadding(dp(16),dp(14),dp(16),dp(14))
                background=roundedSurface(Color.WHITE,20,Color.rgb(224,229,235),1)
            }
            card.addView(TextView(this).apply{
                text=title;textSize=15f;setTextColor(Color.rgb(32,38,46));setTypeface(null,android.graphics.Typeface.BOLD)
            })
            if(!subtitle.isNullOrBlank()) card.addView(TextView(this).apply{
                text=subtitle;textSize=12.5f;setTextColor(Color.rgb(105,111,118));setPadding(0,dp(4),0,dp(10))
            })
            return card
        }

        box.addView(TextView(this).apply{
            text="Personalizza l'aspetto e il comportamento dell'app. Le nuove opzioni potranno essere aggiunte qui senza modificare le sezioni già configurate."
            textSize=13f;setTextColor(Color.rgb(96,101,108));setPadding(dp(4),0,dp(4),dp(14))
        })

        val displayCard=sectionCard("Visualizzazione","Come vengono mostrati i nomi dei clienti.")
        val displayGroup=RadioGroup(this).apply{orientation=RadioGroup.VERTICAL}
        val a=RadioButton(this).apply{text="Cognome Nome";textSize=15f;isChecked=surnameFirstDisplay;buttonTintList=android.content.res.ColorStateList.valueOf(Color.rgb(20,91,165));id=View.generateViewId()}
        val b=RadioButton(this).apply{text="Nome Cognome";textSize=15f;isChecked=!surnameFirstDisplay;buttonTintList=android.content.res.ColorStateList.valueOf(Color.rgb(20,91,165));id=View.generateViewId()}
        displayGroup.addView(a,RadioGroup.LayoutParams(-1,dp(44)));displayGroup.addView(b,RadioGroup.LayoutParams(-1,dp(44)))
        displayCard.addView(displayGroup)
        box.addView(displayCard,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})

        val effectCard=sectionCard("Effetti finestre pop-up","Scegli lo stile e regola l'intensità senza cambiare il contenuto delle finestre.")
        val effectGroup=RadioGroup(this).apply{orientation=RadioGroup.VERTICAL}
        fun effectChoice(label:String,value:String)=RadioButton(this).apply{
            text=label;textSize=13.5f;setTextColor(Color.rgb(35,42,52));isChecked=popupBackdropEffect==value
            buttonTintList=android.content.res.ColorStateList.valueOf(Color.rgb(20,91,165));id=View.generateViewId();setPadding(dp(2),0,0,0)
        }
        val none=effectChoice("Nessuno","NONE")
        val satin=effectChoice("Satinato","SATIN")
        val soft=effectChoice("Vetro Soft","VETRO_SOFT")
        val liquid=effectChoice("Liquid Glass","LIQUID")
        val effectRow1=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val effectRow2=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        effectRow1.addView(none,LinearLayout.LayoutParams(0,dp(46),1f));effectRow1.addView(satin,LinearLayout.LayoutParams(0,dp(46),1f))
        effectRow2.addView(soft,LinearLayout.LayoutParams(0,dp(46),1f));effectRow2.addView(liquid,LinearLayout.LayoutParams(0,dp(46),1f))
        effectGroup.addView(effectRow1);effectGroup.addView(effectRow2)
        effectCard.addView(effectGroup)

        effectCard.addView(TextView(this).apply{
            text="Modalità effetto";textSize=13.5f;setTextColor(Color.rgb(65,71,79));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(0,dp(12),0,dp(4))
        })
        val modeGroup=RadioGroup(this).apply{orientation=RadioGroup.HORIZONTAL}
        val contour=RadioButton(this).apply{text="Contorno";textSize=13.5f;isChecked=popupBackdropMode!="IMMERSIVE";buttonTintList=android.content.res.ColorStateList.valueOf(Color.rgb(20,91,165));id=View.generateViewId()}
        val immersive=RadioButton(this).apply{text="Immersivo";textSize=13.5f;isChecked=popupBackdropMode=="IMMERSIVE";buttonTintList=android.content.res.ColorStateList.valueOf(Color.rgb(20,91,165));id=View.generateViewId()}
        modeGroup.addView(contour,LinearLayout.LayoutParams(0,dp(46),1f));modeGroup.addView(immersive,LinearLayout.LayoutParams(0,dp(46),1f));effectCard.addView(modeGroup)
        none.isChecked=popupBackdropEffect=="NONE";satin.isChecked=popupBackdropEffect=="SATIN";soft.isChecked=popupBackdropEffect=="VETRO_SOFT";liquid.isChecked=popupBackdropEffect=="LIQUID"

        effectCard.addView(TextView(this).apply{
            text="Intensità effetto";textSize=13.5f;setTextColor(Color.rgb(65,71,79));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(0,dp(12),0,dp(2))
        })
        val intensityRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val slider=SeekBar(this).apply{max=100;progress=popupBackdropIntensity;splitTrack=false}
        val value=TextView(this).apply{text="${popupBackdropIntensity}%";textSize=14f;setTextColor(Color.rgb(20,91,165));gravity=Gravity.RIGHT;setTypeface(null,android.graphics.Typeface.BOLD)}
        intensityRow.addView(slider,LinearLayout.LayoutParams(0,dp(42),1f));intensityRow.addView(value,LinearLayout.LayoutParams(dp(54),dp(42)));effectCard.addView(intensityRow)

        val previewHost=FrameLayout(this).apply{
            setPadding(dp(12),dp(12),dp(12),dp(12));background=roundedSurface(Color.rgb(246,249,253),18,Color.rgb(220,229,239),1);visibility=View.VISIBLE
        }
        val previewTitle=TextView(this).apply{text="Anteprima live";textSize=13f;setTextColor(Color.rgb(20,91,165));setTypeface(null,android.graphics.Typeface.BOLD)}
        previewHost.addView(previewTitle,FrameLayout.LayoutParams(-1,dp(24),Gravity.TOP))
        val previewScene=FrameLayout(this).apply{clipToOutline=true;outlineProvider=object:android.view.ViewOutlineProvider(){override fun getOutline(v:View,o:android.graphics.Outline){o.setRoundRect(0,0,v.width,v.height,dp(18).toFloat())}};setBackgroundColor(Color.rgb(225,232,240))}
        val fakeTop=View(this).apply{setBackgroundColor(Color.rgb(180,210,245))};previewScene.addView(fakeTop,FrameLayout.LayoutParams(-1,dp(34),Gravity.TOP))
        val fakeLine=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(10),dp(14),0)}
        repeat(3){i->fakeLine.addView(View(this).apply{setBackgroundColor(if(i==0)Color.rgb(205,220,238) else Color.rgb(232,237,243))},LinearLayout.LayoutParams(-1,dp(18)).apply{setMargins(0,0,0,dp(7))})}
        previewScene.addView(fakeLine,FrameLayout.LayoutParams(-1,-1))
        val previewWindow=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(14),dp(8),dp(14),dp(8));background=roundedSurface(Color.WHITE,18,Color.rgb(205,224,248),1);elevation=dp(5).toFloat()}
        previewWindow.addView(TextView(this).apply{text="Nuovo appuntamento";textSize=14f;setTextColor(Color.rgb(25,31,38));setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER})
        previewWindow.addView(TextView(this).apply{text="Anteprima in tempo reale";textSize=11f;setTextColor(Color.rgb(105,111,118));gravity=Gravity.CENTER;setPadding(0,dp(3),0,0)})
        previewScene.addView(previewWindow,FrameLayout.LayoutParams((resources.displayMetrics.widthPixels*.56f).toInt(),dp(72),Gravity.CENTER))
        previewHost.addView(previewScene,FrameLayout.LayoutParams(-1,dp(150)).apply{topMargin=dp(26)})
        val previewHint=TextView(this).apply{text="Sposta la levetta per vedere l'effetto cambiare in tempo reale.";textSize=11.5f;setTextColor(Color.rgb(100,106,114));gravity=Gravity.CENTER;setPadding(dp(4),dp(7),dp(4),0)}
        previewHost.addView(previewHint,FrameLayout.LayoutParams(-1,dp(30),Gravity.BOTTOM))
        effectCard.addView(previewHost,LinearLayout.LayoutParams(-1,dp(218)).apply{setMargins(0,dp(8),0,0)})

        val reset=Button(this).apply{text="↺  Ripristina predefiniti";setAllCaps(false);textSize=13f;setTextColor(Color.rgb(30,83,145));background=roundedSurface(Color.rgb(238,246,255),16,Color.rgb(211,228,247),1);stateListAnimator=null}
        effectCard.addView(reset,LinearLayout.LayoutParams(-1,dp(42)).apply{setMargins(0,dp(10),0,0)})
        box.addView(effectCard,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})

        val calendarStyleCard=sectionCard("Stile calendario","Personalizza separatamente le fasce orarie e le schede degli appuntamenti.")

        // ===== SLOT GRANDI =====
        calendarStyleCard.addView(TextView(this).apply{text="Slot grandi (fasce orarie)";textSize=14f;setTextColor(Color.rgb(35,42,52));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(0,dp(4),0,dp(3))})
        calendarStyleCard.addView(TextView(this).apply{text="Scegli il materiale e la forma delle fasce orarie.";textSize=12f;setTextColor(Color.rgb(105,111,118));setPadding(0,0,0,dp(4))})
        val largeGroup=RadioGroup(this).apply{orientation=RadioGroup.VERTICAL}
        fun largeChoice(label:String,value:String)=RadioButton(this).apply{text=label;textSize=13.5f;setTextColor(Color.rgb(35,42,52));isChecked=calendarStyleSet==value;buttonTintList=android.content.res.ColorStateList.valueOf(Color.rgb(20,91,165));id=View.generateViewId()}
        val largeLiquid=largeChoice("Liquid Glass","LIQUID_GLASS")
        val largeFog=largeChoice("Nebbia Soft","NEBBIA_SOFT")
        val largeDark=largeChoice("Scuro Elegante","SCURO_ELEGANTE")
        largeGroup.addView(largeLiquid,RadioGroup.LayoutParams(-1,dp(42)));largeGroup.addView(largeFog,RadioGroup.LayoutParams(-1,dp(42)));largeGroup.addView(largeDark,RadioGroup.LayoutParams(-1,dp(42)))
        calendarStyleCard.addView(largeGroup)
        calendarStyleCard.addView(TextView(this).apply{text="Forma slot grandi • set selezionato";textSize=13.5f;setTextColor(Color.rgb(65,71,79));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(0,dp(7),0,dp(2))})
        val largeShape=RadioGroup(this).apply{orientation=RadioGroup.HORIZONTAL}
        val selectedLargeShape=when(calendarStyleSet){"NEBBIA_SOFT"->nebbiaSoftSlotShape;"SCURO_ELEGANTE"->scuroEleganteSlotShape;else->liquidGlassSlotShape}
        val largeRound=RadioButton(this).apply{text="Arrotondato";textSize=13.5f;isChecked=selectedLargeShape=="ARROTONDATO";buttonTintList=android.content.res.ColorStateList.valueOf(Color.rgb(20,91,165));id=View.generateViewId()}
        val largeRect=RadioButton(this).apply{text="Rettangolare";textSize=13.5f;isChecked=selectedLargeShape=="RETTANGOLARE";buttonTintList=android.content.res.ColorStateList.valueOf(Color.rgb(20,91,165));id=View.generateViewId()}
        largeShape.addView(largeRound,LinearLayout.LayoutParams(0,dp(44),1f));largeShape.addView(largeRect,LinearLayout.LayoutParams(0,dp(44),1f));calendarStyleCard.addView(largeShape)
        val largePreview=FrameLayout(this).apply{setPadding(dp(12),dp(12),dp(12),dp(12));background=roundedSurface(Color.rgb(246,249,253),18,Color.rgb(220,229,239),1)}
        largePreview.addView(TextView(this).apply{text="Anteprima slot grandi";textSize=13f;setTextColor(Color.rgb(20,91,165));setTypeface(null,android.graphics.Typeface.BOLD)},FrameLayout.LayoutParams(-1,dp(24),Gravity.TOP))
        val largePreviewSlot=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(6),dp(12),dp(6));background=calendarSlotSurface(1f,0)}
        val lpTime=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        lpTime.addView(TextView(this).apply{text="07:00";textSize=12f;setTextColor(Color.rgb(45,55,65));setTypeface(null,android.graphics.Typeface.BOLD)},LinearLayout.LayoutParams(0,dp(24),1f))
        lpTime.addView(TextView(this).apply{text="0/3";textSize=10f;setTextColor(Color.rgb(110,120,130));gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(34),dp(24)))
        largePreviewSlot.addView(lpTime)
        largePreviewSlot.addView(TextView(this).apply{text="＋";textSize=18f;gravity=Gravity.CENTER;setTextColor(Color.LTGRAY)},LinearLayout.LayoutParams(-1,dp(38)))
        largePreview.addView(largePreviewSlot,FrameLayout.LayoutParams(-1,dp(104)).apply{topMargin=dp(30)})
        calendarStyleCard.addView(largePreview,LinearLayout.LayoutParams(-1,dp(148)).apply{setMargins(0,dp(8),0,dp(12))})

        // ===== SLOT APPUNTAMENTO =====
        calendarStyleCard.addView(TextView(this).apply{text="Slot appuntamento (schede cliente)";textSize=14f;setTextColor(Color.rgb(35,42,52));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(0,dp(2),0,dp(3))})
        calendarStyleCard.addView(TextView(this).apply{text="Materiale e forma indipendenti dagli slot grandi.";textSize=12f;setTextColor(Color.rgb(105,111,118));setPadding(0,0,0,dp(4))})
        val apptGroup=RadioGroup(this).apply{orientation=RadioGroup.VERTICAL}
        fun apptChoice(label:String,value:String)=RadioButton(this).apply{text=label;textSize=13.5f;setTextColor(Color.rgb(35,42,52));isChecked=appointmentStyleSet==value;buttonTintList=android.content.res.ColorStateList.valueOf(Color.rgb(20,91,165));id=View.generateViewId()}
        val apptLiquid=apptChoice("Liquid Glass","LIQUID_GLASS")
        val apptSoft=apptChoice("Vetro Soft","VETRO_SOFT_14")
        val apptSoftFull=apptChoice("Vetro Soft • Full","VETRO_SOFT_FULL")
        val apptSatin=apptChoice("Vetro Satinato","SATINATO_14")
        val apptSatinFull=apptChoice("Vetro Satinato • Full","SATINATO_FULL")
        val apptDark=apptChoice("Vetro Scuro","SCURO_ELEGANTE_14")
        apptGroup.addView(apptLiquid,RadioGroup.LayoutParams(-1,dp(42)))
        apptGroup.addView(apptSoft,RadioGroup.LayoutParams(-1,dp(42)))
        apptGroup.addView(apptSoftFull,RadioGroup.LayoutParams(-1,dp(42)))
        apptGroup.addView(apptSatin,RadioGroup.LayoutParams(-1,dp(42)))
        apptGroup.addView(apptSatinFull,RadioGroup.LayoutParams(-1,dp(42)))
        apptGroup.addView(apptDark,RadioGroup.LayoutParams(-1,dp(42)))
        calendarStyleCard.addView(apptGroup)
        calendarStyleCard.addView(TextView(this).apply{text="Forma slot appuntamento • set selezionato";textSize=13.5f;setTextColor(Color.rgb(65,71,79));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(0,dp(7),0,dp(2))})
        val apptShapeGroup=RadioGroup(this).apply{orientation=RadioGroup.HORIZONTAL}
        val selectedApptShape=when(appointmentStyleSet){
            "VETRO_SOFT_14","VETRO_SOFT_FULL"->vetroSoft14AppointmentShape
            "SATINATO_14","SATINATO_FULL"->satinato14AppointmentShape
            "SCURO_ELEGANTE_14"->scuroElegante14AppointmentShape
            else->liquidGlassAppointmentShape
        }
        val apptRound=RadioButton(this).apply{text="Arrotondato";textSize=13.5f;isChecked=selectedApptShape=="ARROTONDATO";buttonTintList=android.content.res.ColorStateList.valueOf(Color.rgb(20,91,165));id=View.generateViewId()}
        val apptRect=RadioButton(this).apply{text="Rettangolare";textSize=13.5f;isChecked=selectedApptShape=="RETTANGOLARE";buttonTintList=android.content.res.ColorStateList.valueOf(Color.rgb(20,91,165));id=View.generateViewId()}
        apptShapeGroup.addView(apptRound,LinearLayout.LayoutParams(0,dp(44),1f));apptShapeGroup.addView(apptRect,LinearLayout.LayoutParams(0,dp(44),1f));calendarStyleCard.addView(apptShapeGroup)
        val materialTitle=TextView(this).apply{text="Materiale Liquid Glass";textSize=13.5f;setTextColor(Color.rgb(65,71,79));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(0,dp(7),0,dp(2))}
        calendarStyleCard.addView(materialTitle)
        val materialGroup=RadioGroup(this).apply{orientation=RadioGroup.HORIZONTAL}
        val water=RadioButton(this).apply{text="Gel / Acqua";textSize=13.5f;isChecked=calendarMaterialEffect=="WATER";buttonTintList=android.content.res.ColorStateList.valueOf(Color.rgb(20,91,165));id=View.generateViewId()}
        val side=RadioButton(this).apply{text="Vetro + luce laterale";textSize=13.5f;isChecked=calendarMaterialEffect=="SIDE_LIGHT";buttonTintList=android.content.res.ColorStateList.valueOf(Color.rgb(20,91,165));id=View.generateViewId()}
        materialGroup.addView(water,LinearLayout.LayoutParams(0,dp(46),1f));materialGroup.addView(side,LinearLayout.LayoutParams(0,dp(46),1f));calendarStyleCard.addView(materialGroup)
        val intensityTitle=TextView(this).apply{text="Intensità luce / materiale";textSize=13.5f;setTextColor(Color.rgb(65,71,79));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(0,dp(7),0,dp(2))}
        calendarStyleCard.addView(intensityTitle)
        val calIntensityRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val calSlider=SeekBar(this).apply{max=100;progress=calendarMaterialIntensity;splitTrack=false}
        val calValue=TextView(this).apply{text="${calendarMaterialIntensity}%";textSize=14f;setTextColor(Color.rgb(20,91,165));gravity=Gravity.RIGHT;setTypeface(null,android.graphics.Typeface.BOLD)}
        calIntensityRow.addView(calSlider,LinearLayout.LayoutParams(0,dp(42),1f));calIntensityRow.addView(calValue,LinearLayout.LayoutParams(dp(54),dp(42)));calendarStyleCard.addView(calIntensityRow)
        val apptPreview=FrameLayout(this).apply{setPadding(dp(12),dp(12),dp(12),dp(12));background=roundedSurface(Color.rgb(246,249,253),18,Color.rgb(220,229,239),1)}
        apptPreview.addView(TextView(this).apply{text="Anteprima slot appuntamento";textSize=13f;setTextColor(Color.rgb(20,91,165));setTypeface(null,android.graphics.Typeface.BOLD)},FrameLayout.LayoutParams(-1,dp(24),Gravity.TOP))
        val previewAppt=TextView(this).apply{text="Valitova Anna";textSize=14f;setTextColor(if(appointmentStyleSet=="SCURO_ELEGANTE_14") Color.rgb(242,246,250) else Color.rgb(28,35,48));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);background=appointmentSurfaceFor(Appointment(0,"Valitova Anna",LocalDate.now(),"07:00","TYPE1",0L,0L,false),Color.rgb(45,135,210))}
        apptPreview.addView(previewAppt,FrameLayout.LayoutParams((resources.displayMetrics.widthPixels*.72f).toInt(),dp(78),Gravity.CENTER).apply{topMargin=dp(28)})
        calendarStyleCard.addView(apptPreview,LinearLayout.LayoutParams(-1,dp(148)).apply{setMargins(0,dp(8),0,dp(10))})

        fun refreshCalendarStylePreview(){
            val largeShapeNow=when(calendarStyleSet){"NEBBIA_SOFT"->nebbiaSoftSlotShape;"SCURO_ELEGANTE"->scuroEleganteSlotShape;else->liquidGlassSlotShape}
            if(largeShape.checkedRadioButtonId!=if(largeShapeNow=="ARROTONDATO") largeRound.id else largeRect.id) largeShape.check(if(largeShapeNow=="ARROTONDATO") largeRound.id else largeRect.id)
            val apptShapeNow=when(appointmentStyleSet){
            "VETRO_SOFT_14","VETRO_SOFT_FULL"->vetroSoft14AppointmentShape
            "SATINATO_14","SATINATO_FULL"->satinato14AppointmentShape
            "SCURO_ELEGANTE_14"->scuroElegante14AppointmentShape
            else->liquidGlassAppointmentShape
        }
            if(apptShapeGroup.checkedRadioButtonId!=if(apptShapeNow=="ARROTONDATO") apptRound.id else apptRect.id) apptShapeGroup.check(if(apptShapeNow=="ARROTONDATO") apptRound.id else apptRect.id)
            largePreviewSlot.background=calendarSlotSurface(1f,0)
            previewAppt.background=appointmentSurfaceFor(Appointment(0,"Valitova Anna",LocalDate.now(),"07:00","TYPE1",0L,0L,false),Color.rgb(45,135,210))
            previewAppt.setTextColor(if(appointmentStyleSet=="SCURO_ELEGANTE_14") Color.rgb(242,246,250) else Color.rgb(28,35,48))
            calValue.text="${calendarMaterialIntensity}%"
            val liquid=appointmentStyleSet=="LIQUID_GLASS"
            materialTitle.visibility=if(liquid)View.VISIBLE else View.GONE
            materialGroup.visibility=if(liquid)View.VISIBLE else View.GONE
            intensityTitle.visibility=if(liquid)View.VISIBLE else View.GONE
            calIntensityRow.visibility=if(liquid)View.VISIBLE else View.GONE
        }
        fun persistCalendarStyleSelection(){saveData();refreshCalendarStylePreview()}
        largeGroup.setOnCheckedChangeListener{_,id->calendarStyleSet=when(id){largeLiquid.id->"LIQUID_GLASS";largeFog.id->"NEBBIA_SOFT";else->"SCURO_ELEGANTE"};persistCalendarStyleSelection()}
        largeShape.setOnCheckedChangeListener{_,id->val shape=if(id==largeRound.id)"ARROTONDATO" else "RETTANGOLARE";when(calendarStyleSet){"NEBBIA_SOFT"->nebbiaSoftSlotShape=shape;"SCURO_ELEGANTE"->scuroEleganteSlotShape=shape;else->liquidGlassSlotShape=shape};persistCalendarStyleSelection()}
        apptGroup.setOnCheckedChangeListener{_,id->appointmentStyleSet=when(id){
            apptLiquid.id->"LIQUID_GLASS"
            apptSoft.id->"VETRO_SOFT_14"
            apptSoftFull.id->"VETRO_SOFT_FULL"
            apptSatin.id->"SATINATO_14"
            apptSatinFull.id->"SATINATO_FULL"
            else->"SCURO_ELEGANTE_14"
        };persistCalendarStyleSelection()}
        apptShapeGroup.setOnCheckedChangeListener{_,id->val shape=if(id==apptRound.id)"ARROTONDATO" else "RETTANGOLARE";when(appointmentStyleSet){
            "VETRO_SOFT_14","VETRO_SOFT_FULL"->vetroSoft14AppointmentShape=shape
            "SATINATO_14","SATINATO_FULL"->satinato14AppointmentShape=shape
            "SCURO_ELEGANTE_14"->scuroElegante14AppointmentShape=shape
            else->{liquidGlassAppointmentShape=shape;appointmentShape=shape}
        };persistCalendarStyleSelection()}
        materialGroup.setOnCheckedChangeListener{_,id->calendarMaterialEffect=if(id==side.id)"SIDE_LIGHT" else "WATER";persistCalendarStyleSelection()}
        calSlider.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(s:SeekBar?,p:Int,fromUser:Boolean){calendarMaterialIntensity=p.coerceIn(0,100);calValue.text="${calendarMaterialIntensity}%";saveData();refreshCalendarStylePreview()}
            override fun onStartTrackingTouch(s:SeekBar?){ }
            override fun onStopTrackingTouch(s:SeekBar?){ }
        })
        box.addView(calendarStyleCard,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})
        refreshCalendarStylePreview()

        val infoCard=sectionCard("Preferenze","Le modifiche vengono registrate automaticamente.")
        infoCard.addView(TextView(this).apply{text="Le impostazioni future verranno aggiunte come nuove sezioni, mantenendo separate quelle già configurate.";textSize=12.5f;setTextColor(Color.rgb(105,111,118));setPadding(0,dp(2),0,0)})
        box.addView(infoCard,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})

        val close=Button(this).apply{text="Chiudi";setAllCaps(false);textSize=14f;setTextColor(Color.rgb(35,83,125));background=roundedSurface(Color.rgb(232,243,255),18,Color.rgb(178,210,239),1);stateListAnimator=null}
        box.addView(close,LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(2),0,0)})
        scroll.addView(box,ViewGroup.LayoutParams(-1,-2));showSettingsSubpage(scroll,"Generali")

        fun persistVisuals(){
            popupBackdropMode=if(modeGroup.checkedRadioButtonId==immersive.id)"IMMERSIVE" else "CONTOUR"
            popupBackdropIntensity=slider.progress.coerceIn(0,100)
            savePopupVisualPreferences();value.text="${popupBackdropIntensity}%"
        }
        fun refreshPreview(){
            val intensity=slider.progress.coerceIn(0,100)
            val effect=popupBackdropEffect
            val satin = effect=="SATIN"
            val softGlass = effect=="VETRO_SOFT"
            val liquid = effect=="LIQUID"
            val immersiveMode=popupBackdropMode=="IMMERSIVE"

            previewHost.visibility=View.VISIBLE
            if (effect=="NONE") {
                fakeLine.setRenderEffect(null)
                previewScene.setBackgroundColor(Color.rgb(225,232,240))
                fakeTop.setBackgroundColor(Color.rgb(205,220,238))
                previewWindow.background=roundedSurface(Color.WHITE,18,Color.rgb(205,224,248),1)
                previewWindow.elevation=dp(5).toFloat()
                previewHint.text="Anteprima del comportamento senza effetto."
                return
            }

            val base=when { satin->24; softGlass->10; liquid->4; else->0 }
            val radius=(base*(intensity/100f)).roundToInt().coerceIn(0,base)
            if(android.os.Build.VERSION.SDK_INT>=31 && radius>0) fakeLine.setRenderEffect(android.graphics.RenderEffect.createBlurEffect(dp(radius).toFloat(),dp(radius).toFloat(),android.graphics.Shader.TileMode.CLAMP)) else fakeLine.setRenderEffect(null)

            if (satin) {
                val a=(52*(intensity/100f)).roundToInt().coerceIn(0,70)
                fakeTop.setBackgroundColor(android.graphics.Color.rgb(190,214,242))
                previewScene.setBackgroundColor(android.graphics.Color.rgb(218 + (a/20).coerceIn(0,2),225 + (a/30).coerceIn(0,2),233))
                previewWindow.background=roundedSurface(if(immersiveMode)android.graphics.Color.argb(242,248,251,255) else Color.WHITE,18,Color.rgb(205,224,248),if(immersiveMode)2 else 1)
                previewHint.text=if(immersiveMode)"Satinato • Immersivo • ${intensity}%" else "Satinato • Contorno • ${intensity}%"
            } else if (softGlass) {
                val a=(28*(intensity/100f)).roundToInt().coerceIn(0,40)
                fakeTop.setBackgroundColor(android.graphics.Color.rgb(190,214,242))
                previewScene.setBackgroundColor(android.graphics.Color.rgb(222,230,239))
                previewWindow.background=roundedSurface(if(immersiveMode)android.graphics.Color.argb(242,248,251,255) else Color.WHITE,18,Color.rgb(205,224,248),if(immersiveMode)1 else 1)
                previewWindow.elevation=dp(5).toFloat()
                previewHint.text=if(immersiveMode)"Vetro Soft • Immersivo • ${intensity}%" else "Vetro Soft • Contorno • ${intensity}%"
            } else if (liquid) {
                val a=(7*(intensity/100f)).roundToInt().coerceIn(0,16)
                fakeTop.setBackgroundColor(android.graphics.Color.rgb(180,218,250))
                previewScene.setBackgroundColor(android.graphics.Color.rgb(226,235,243))
                previewWindow.background=roundedSurface(
                    if(immersiveMode)android.graphics.Color.argb(232,246,251,255) else android.graphics.Color.WHITE,
                    18,
                    android.graphics.Color.rgb(155,205,245),
                    1
                )
                previewWindow.elevation=dp(7).toFloat()
                previewHint.text=if(immersiveMode)"Liquid Glass • Immersivo • ${intensity}%" else "Liquid Glass • Contorno • ${intensity}%"
            }
        }
        displayGroup.setOnCheckedChangeListener{_,_->surnameFirstDisplay=a.isChecked;saveData()}
        fun chooseEffect(value:String){
            popupBackdropEffect=value
            none.isChecked=value=="NONE"
            satin.isChecked=value=="SATIN"
            soft.isChecked=value=="VETRO_SOFT"
            liquid.isChecked=value=="LIQUID"
            savePopupVisualPreferences();refreshPreview()
        }
        none.setOnClickListener{chooseEffect("NONE")}
        satin.setOnClickListener{chooseEffect("SATIN")}
        soft.setOnClickListener{chooseEffect("VETRO_SOFT")}
        liquid.setOnClickListener{chooseEffect("LIQUID")}
        modeGroup.setOnCheckedChangeListener{_,_->persistVisuals();refreshPreview()}
        slider.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(s:SeekBar?,p:Int,fromUser:Boolean){popupBackdropIntensity=p.coerceIn(0,100);value.text="${popupBackdropIntensity}%";savePopupVisualPreferences();refreshPreview()}
            override fun onStartTrackingTouch(s:SeekBar?){refreshPreview()}
            override fun onStopTrackingTouch(s:SeekBar?){refreshPreview()}
        })
        reset.setOnClickListener{
            surnameFirstDisplay=true;popupBackdropEffect="NONE";popupBackdropMode="CONTOUR";popupBackdropIntensity=65;calendarStyleSet="LIQUID_GLASS";liquidGlassSlotShape="ARROTONDATO";liquidGlassSlotColor=Color.rgb(224,228,232);calendarMaterialEffect="WATER";calendarMaterialIntensity=75;appointmentStyleSet="LIQUID_GLASS";appointmentShape="ARROTONDATO";liquidGlassAppointmentShape="ARROTONDATO";vetroSoft14AppointmentShape="ARROTONDATO";satinato14AppointmentShape="RETTANGOLARE";scuroElegante14AppointmentShape="ARROTONDATO";nebbiaSoftSlotShape="ARROTONDATO";scuroEleganteSlotShape="RETTANGOLARE"
            a.isChecked=true;none.isChecked=true;satin.isChecked=false;soft.isChecked=false;liquid.isChecked=false;modeGroup.check(contour.id);slider.progress=65;savePopupVisualPreferences();saveData();value.text="65%";refreshPreview()
        }
        close.setOnClickListener{surnameFirstDisplay=a.isChecked;persistVisuals();saveData();closeSettingsSubpage()}
        refreshPreview()
    }

    private fun closureSettingsDialog(){
        val scroll=ScrollView(this).apply{isFillViewport=true};val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(8),dp(18),dp(8))}
        box.addView(TextView(this).apply{text="Le scadenze che cadono nella chiusura vengono spostate al giorno successivo alla riapertura.";textSize=14f;setTextColor(Color.GRAY);setPadding(0,dp(4),0,dp(10))})
        val s=modernEditText().apply{hint="Data inizio • gg/mm/aaaa";inputType=2;setSingleLine(true);setText(ferieStart?.format(fmt) ?: "")};setupDateInput(s)
        val e=modernEditText().apply{hint="Data fine • gg/mm/aaaa";inputType=2;setSingleLine(true);setText(ferieEnd?.format(fmt) ?: "")};setupDateInput(e)
        box.addView(s,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,0,0,dp(7))});box.addView(e,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,0,0,dp(10))})
        val clear=Button(this).apply{text="Cancella periodo";setAllCaps(false);textSize=13.5f;setTextColor(Color.rgb(205,55,55));setBackgroundColor(Color.TRANSPARENT);stateListAnimator=null}
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val close=Button(this).apply{text="Chiudi";setAllCaps(false);textSize=13.5f;setTextColor(Color.rgb(0,125,110));setBackgroundColor(Color.TRANSPARENT);stateListAnimator=null}
        val save=Button(this).apply{text="Salva";setAllCaps(false);textSize=13.5f;setTextColor(Color.WHITE);background=roundedSurface(Color.rgb(0,125,110),18);stateListAnimator=null}
        actions.addView(clear,LinearLayout.LayoutParams(0,dp(46),1f));actions.addView(close,LinearLayout.LayoutParams(0,dp(46),1f));actions.addView(save,LinearLayout.LayoutParams(dp(86),dp(44)));box.addView(actions)
        scroll.addView(box);showSettingsSubpage(scroll,"Chiusura ferie")
        clear.setOnClickListener{s.setText("");e.setText("")}
        close.setOnClickListener{closeSettingsSubpage()}
        save.setOnClickListener{try{val st=s.text.toString().trim();val et=e.text.toString().trim();if(st.isEmpty()&&et.isEmpty()){ferieStart=null;ferieEnd=null}else{val sd=parseDate(st);val ed=parseDate(et);require(!ed.isBefore(sd));ferieStart=sd;ferieEnd=ed};saveData();closeSettingsSubpage();Toast.makeText(this,"Chiusura ferie salvata.",Toast.LENGTH_SHORT).show()}catch(_:Exception){Toast.makeText(this,"Inserisci date valide.",Toast.LENGTH_LONG).show()}}
    }

    private fun appointmentSettingsDialog(){
        val scroll=ScrollView(this).apply{isFillViewport=true;overScrollMode=View.OVER_SCROLL_IF_CONTENT_SCROLLS}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(10),dp(18),dp(20))}
        box.addView(TextView(this).apply{text="Personalizza ogni tipo di appuntamento: nome, colore e capienza.";textSize=14f;setTextColor(Color.rgb(92,96,102));gravity=Gravity.CENTER;setPadding(0,dp(2),0,dp(14))})

        val working=appointmentTypes.map{it.copy()}.toMutableList()
        val fields=mutableListOf<EditText>()
        val colorViews=mutableListOf<TextView>()
        val capacitySpinners=mutableListOf<Spinner>()
        val rows=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val palette=listOf(
            Color.rgb(45,135,210), Color.rgb(0,145,125), Color.rgb(220,75,75),
            Color.rgb(235,145,35), Color.rgb(135,90,190), Color.rgb(35,155,175),
            Color.rgb(70,120,75), Color.rgb(210,75,135), Color.rgb(90,105,120)
        )

        fun chooseColor(index:Int){
            val title=TextView(this).apply{text="Colore appuntamento";textSize=20f;setTextColor(Color.rgb(25,28,32));setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setPadding(dp(8),dp(4),dp(8),dp(8))}
            val grid=GridLayout(this).apply{columnCount=3;setPadding(dp(12),dp(4),dp(12),dp(10))}
            lateinit var cd:AlertDialog
            palette.forEach{c->
                val swatch=TextView(this).apply{
                    text=if(working[index].color==c)"✓" else "";textSize=18f;gravity=Gravity.CENTER;setTextColor(Color.WHITE)
                    background=roundedSurface(c,18,Color.WHITE,2);setOnClickListener{
                        working[index].color=c
                        colorViews.getOrNull(index)?.apply{setTextColor(c);background=roundedSurface(Color.WHITE,16,c,2)}
                        cd.dismiss()
                    }
                }
                grid.addView(swatch,GridLayout.LayoutParams().apply{width=dp(64);height=dp(56);setMargins(dp(7),dp(7),dp(7),dp(7))})
            }
            val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),dp(8),dp(10),dp(8));addView(title);addView(grid)}
            cd=AlertDialog.Builder(this).setView(content).create()
            preparePopupBackdrop(cd)
            cd.setOnShowListener{popupBackdropCurrentDialog=cd;cd.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28));applyPopupBackdropEffect(cd);cd.window?.setDimAmount(.40f);cd.window?.setLayout((resources.displayMetrics.widthPixels*.86f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT)}
            cd.show();cd.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28));cd.window?.setDimAmount(.40f);cd.window?.setLayout((resources.displayMetrics.widthPixels*.86f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT)
        }

        fun render(){
            rows.removeAllViews();fields.clear();colorViews.clear();capacitySpinners.clear()
            working.forEachIndexed{i,t->
                val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(10),dp(12),dp(10));background=roundedSurface(Color.WHITE,20,Color.rgb(226,229,234),1)}
                val head=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                val swatch=TextView(this).apply{text="●";textSize=26f;gravity=Gravity.CENTER;setTextColor(t.color);background=roundedSurface(Color.WHITE,16,t.color,2);isClickable=true;setOnClickListener{chooseColor(i)}}
                colorViews.add(swatch);head.addView(swatch,LinearLayout.LayoutParams(dp(52),dp(52)))
                val f=modernEditText().apply{setSingleLine(true);setText(t.name);hint="Nome appuntamento";gravity=Gravity.CENTER_VERTICAL}
                fields.add(f);head.addView(f,LinearLayout.LayoutParams(0,dp(52),1f).apply{setMargins(dp(10),0,0,0)})
                card.addView(head)
                val info=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(8),0,0)}
                info.addView(TextView(this).apply{text="Capienza";textSize=13f;setTextColor(Color.rgb(92,96,102));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,dp(42),1f))
                val current=calendarRoutines.getOrNull(activeRoutineIndex)?.maxByType?.getOrNull(i) ?: calendarRoutines.getOrNull(activeRoutineIndex)?.maxTotal ?: 3
                val cap=Spinner(this).also{installNikiTimeDropdown(it)}.apply{adapter=centeredSpinnerAdapter((1..10).map{it.toString()});setSelection(current.coerceIn(1,10)-1)}
                capacitySpinners.add(cap);info.addView(cap,LinearLayout.LayoutParams(dp(105),dp(42)))
                card.addView(info)
                rows.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(4),0,dp(8))})
            }
        }
        render();box.addView(rows)

        val add=softBlueButtonStyle("＋ Aggiungi tipo di appuntamento")
        box.addView(add,LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(4),0,dp(12))})
        add.setOnClickListener{
            val id="TYPE${((working.map{it.id.removePrefix("TYPE").toIntOrNull()?:0}.maxOrNull()?:0)+1)}"
            working.add(AppointmentType(id,"Nuovo appuntamento",palette[working.size%palette.size],45));render();scroll.post{scroll.smoothScrollTo(0,box.measuredHeight)}
        }

        box.addView(TextView(this).apply{text="Capienza massima complessiva per fascia";textSize=15f;setTextColor(Color.rgb(55,59,64));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(0,dp(4),0,dp(4))})
        val routine=calendarRoutines.getOrNull(activeRoutineIndex)
        val max=Spinner(this).also{installNikiTimeDropdown(it)}.apply{adapter=centeredSpinnerAdapter((1..10).map{it.toString()});setSelection(((routine?.maxTotal?:3).coerceIn(1,10))-1)}
        box.addView(max,LinearLayout.LayoutParams(-1,dp(48)))
        box.addView(TextView(this).apply{text="Tocca il pallino colorato per cambiare il colore.";textSize=12.5f;setTextColor(Color.rgb(120,124,130));gravity=Gravity.CENTER;setPadding(0,dp(8),0,dp(4))})

        val save=Button(this).apply{text="Salva";setAllCaps(false);textSize=14f;setTextColor(Color.WHITE);background=roundedSurface(Color.rgb(0,125,110),18);stateListAnimator=null}
        box.addView(save,LinearLayout.LayoutParams(dp(96),dp(44)).apply{gravity=Gravity.RIGHT;setMargins(0,dp(12),0,0)})
        scroll.addView(box,ViewGroup.LayoutParams(-1,-2))
        showSettingsSubpage(scroll,"Appuntamenti")
        save.setOnClickListener{
            working.forEachIndexed{i,t->t.name=fields.getOrNull(i)?.text?.toString()?.trim().orEmpty().ifEmpty{"Tipo ${i+1}"}}
            appointmentTypes.clear();appointmentTypes.addAll(working)
            calendarRoutines.forEach{routineItem->
                routineItem.maxTotal=max.selectedItemPosition+1
                while(routineItem.maxByType.size<appointmentTypes.size)routineItem.maxByType.add(routineItem.maxTotal)
                appointmentTypes.forEachIndexed{i,_->routineItem.maxByType[i]=capacitySpinners.getOrNull(i)?.selectedItemPosition?.plus(1)?:routineItem.maxByType.getOrElse(i){routineItem.maxTotal}}
            }
            saveData();closeSettingsSubpage();Toast.makeText(this,"Impostazioni appuntamenti salvate.",Toast.LENGTH_SHORT).show()
        }
    }

    private fun calendarSettingsDialog(){
        val scroll=ScrollView(this).apply{isFillViewport=true}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(6),dp(18),dp(10))}
        fun section(title:String,subtitle:String){
            box.addView(TextView(this).apply{text=title;textSize=18f;setTextColor(Color.rgb(24,27,31));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(0,dp(10),0,dp(3))})
            box.addView(TextView(this).apply{text=subtitle;textSize=13f;setTextColor(Color.rgb(92,96,102));setPadding(0,0,0,dp(8))})
        }
        section("Giorni visualizzati","Scegli quali giorni della settimana mostrare nel calendario.")
        val dayChecks=(0..6).map{i->CheckBox(this).apply{text=dayShort(i);textSize=15f;isChecked=calendarVisibleDays[i];setPadding(0,0,0,0)}}
        dayChecks.forEach{cb->box.addView(cb,LinearLayout.LayoutParams(-1,dp(40)))}

        section("Personalizzazione dei tasti","Scegli quali tasti mostrare sopra e quali sotto. Ogni riga si ridimensiona automaticamente per occupare tutta la larghezza.")
        val labels=mapOf("APPT" to "＋  Appuntamento","SEARCH" to "🔎  Cerca","TODAY" to "Oggi","PREV" to "‹  Settimana precedente","NEXT" to "›  Settimana successiva")
        val allKeys=listOf("APPT","SEARCH","TODAY","PREV","NEXT")
        val topWorking=calendarTopButtons.filter{it in allKeys}.distinct().toMutableList()
        val bottomWorking=calendarBottomButtons.filter{it in allKeys && it !in topWorking}.distinct().toMutableList()
        if(topWorking.isEmpty()&&bottomWorking.isEmpty()){topWorking.add("APPT");bottomWorking.addAll(listOf("SEARCH","TODAY","PREV","NEXT"))}
        if("PREV" in topWorking && "NEXT" in topWorking && topWorking.indexOf("PREV")>topWorking.indexOf("NEXT")){val a=topWorking.indexOf("PREV");val b=topWorking.indexOf("NEXT");val t=topWorking[a];topWorking[a]=topWorking[b];topWorking[b]=t}
        if("PREV" in bottomWorking && "NEXT" in bottomWorking && bottomWorking.indexOf("PREV")>bottomWorking.indexOf("NEXT")){val a=bottomWorking.indexOf("PREV");val b=bottomWorking.indexOf("NEXT");val t=bottomWorking[a];bottomWorking[a]=bottomWorking[b];bottomWorking[b]=t}
        fun validArrowOrder():Boolean{
            val combined=topWorking+bottomWorking
            val pi=combined.indexOf("PREV");val ni=combined.indexOf("NEXT")
            return pi<0||ni<0||pi<ni
        }
        val topContainer=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val bottomContainer=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val preview=TextView(this).apply{textSize=13f;setTextColor(Color.rgb(75,100,125));setPadding(0,dp(12),0,dp(4))}
        fun renderPlacement(){
            fun renderList(container:LinearLayout, working:MutableList<String>, other:MutableList<String>){
                container.removeAllViews()
                if(working.isEmpty()){
                    container.addView(TextView(this).apply{text="Nessun tasto in questa barra";textSize=13f;setTextColor(Color.GRAY);setGravity(Gravity.CENTER);setPadding(0,dp(12),0,dp(12))},LinearLayout.LayoutParams(-1,dp(44)))
                } else working.forEachIndexed{i,key->
                    val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(2),dp(4),dp(2));background=roundedSurface(Color.WHITE,16,Color.rgb(226,229,234),1)}
                    row.addView(TextView(this).apply{text=labels[key]?:key;textSize=14f;setTextColor(Color.rgb(30,33,38));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,dp(46),1f))
                    val move=Button(this).apply{text="⇄";setAllCaps(false);textSize=16f;stateListAnimator=null;setTextColor(Color.rgb(20,91,165));setBackgroundColor(Color.TRANSPARENT);setOnClickListener{working.removeAt(i);other.add(key);renderPlacement()}}
                    val up=Button(this).apply{text="↑";setAllCaps(false);textSize=18f;stateListAnimator=null;setTextColor(Color.rgb(20,91,165));setBackgroundColor(Color.TRANSPARENT);isEnabled=i>0;alpha=if(i>0)1f else .35f;setOnClickListener{if(i>0){val c=working[i];working[i]=working[i-1];working[i-1]=c;if(validArrowOrder())renderPlacement()else{val d=working[i];working[i]=working[i-1];working[i-1]=d}}}}
                    val down=Button(this).apply{text="↓";setAllCaps(false);textSize=18f;stateListAnimator=null;setTextColor(Color.rgb(20,91,165));setBackgroundColor(Color.TRANSPARENT);isEnabled=i<working.lastIndex;alpha=if(i<working.lastIndex)1f else .35f;setOnClickListener{if(i<working.lastIndex){val c=working[i];working[i]=working[i+1];working[i+1]=c;if(validArrowOrder())renderPlacement()else{val d=working[i];working[i]=working[i+1];working[i+1]=d}}}}
                    row.addView(move,LinearLayout.LayoutParams(dp(42),dp(46)));row.addView(up,LinearLayout.LayoutParams(dp(40),dp(46)));row.addView(down,LinearLayout.LayoutParams(dp(40),dp(46)))
                    container.addView(row,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,dp(4),0,0)})
                }
            }
            renderList(topContainer,topWorking,bottomWorking);renderList(bottomContainer,bottomWorking,topWorking)
            val topText=if(topWorking.isEmpty())"Nessuno" else topWorking.joinToString("  •  "){labels[it]?:it}
            val bottomText=if(bottomWorking.isEmpty())"Nessuno" else bottomWorking.joinToString("  •  "){labels[it]?:it}
            preview.text="Anteprima:\nSopra: $topText\nSotto: $bottomText\n\nLe frecce ‹ e › mantengono sempre questo ordine." 
        }
        box.addView(TextView(this).apply{text="Barra superiore";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,38,43));setPadding(0,dp(8),0,dp(2))})
        box.addView(topContainer)
        box.addView(TextView(this).apply{text="Barra inferiore";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,38,43));setPadding(0,dp(14),0,dp(2))})
        box.addView(bottomContainer)
        box.addView(TextView(this).apply{text="⇄ sposta  •  ↑ ↓ riordina";textSize=12.5f;setTextColor(Color.rgb(92,96,102));setPadding(0,dp(8),0,0)})
        box.addView(preview)
        renderPlacement()
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(12),0,0)}
        val close=Button(this).apply{text="Annulla";setAllCaps(false);textSize=13.5f;setTextColor(Color.rgb(0,125,110));setBackgroundColor(Color.TRANSPARENT);stateListAnimator=null}
        val save=Button(this).apply{text="Salva";setAllCaps(false);textSize=13.5f;setTextColor(Color.WHITE);background=roundedSurface(Color.rgb(20,91,165),18);stateListAnimator=null}
        actions.addView(close,LinearLayout.LayoutParams(0,dp(46),1f));actions.addView(save,LinearLayout.LayoutParams(dp(90),dp(44)));box.addView(actions)
        scroll.addView(box,ViewGroup.LayoutParams(-1,-2))
        showSettingsSubpage(scroll,"Impostazioni Calendario")
        close.setOnClickListener{closeSettingsSubpage()}
        save.setOnClickListener{
            if(dayChecks.none{it.isChecked}){Toast.makeText(this,"Seleziona almeno un giorno del calendario.",Toast.LENGTH_LONG).show();return@setOnClickListener}
            if(!validArrowOrder()){Toast.makeText(this,"Le frecce ‹ e › devono rimanere in questo ordine.",Toast.LENGTH_LONG).show();return@setOnClickListener}
            calendarVisibleDays=BooleanArray(7){i->dayChecks[i].isChecked}
            calendarTopButtons=topWorking.toMutableList();calendarBottomButtons=bottomWorking.toMutableList()
            calendarNavOrder=(calendarTopButtons+calendarBottomButtons).filter{it!="APPT"}.toMutableList()
            calendarNavPosition=if(calendarTopButtons.any{it!="APPT"})0 else 1
            saveData();closeSettingsSubpage(false);Toast.makeText(this,"Impostazioni calendario salvate.",Toast.LENGTH_SHORT).show();calendarScreen()
        }
    }

    private fun backupMenu(){
        val last=getSharedPreferences("gestione_pagamenti",MODE_PRIVATE).getString("autoBackupDate","")
        val lastText=if(last.isNullOrBlank())"Nessun backup automatico ancora"else"Ultimo backup automatico: $last"
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(4),dp(18),dp(8))}
        fun option(title:String,subtitle:String,icon:String,action:()->Unit){
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(12),dp(12),dp(12));background=roundedSurface(Color.rgb(246,248,250),20,Color.rgb(228,231,235),1);isClickable=true;isFocusable=true}
            row.addView(TextView(this).apply{text=icon;textSize=22f;gravity=Gravity.CENTER;setBackground(roundedSurface(Color.WHITE,16));setPadding(dp(8),dp(6),dp(8),dp(6))},LinearLayout.LayoutParams(dp(50),dp(50)))
            val texts=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
            texts.addView(TextView(this@MainActivity).apply{text=title;textSize=16f;setTextColor(Color.rgb(25,28,32));setTypeface(null,android.graphics.Typeface.BOLD)})
            texts.addView(TextView(this@MainActivity).apply{text=subtitle;textSize=12.5f;setTextColor(Color.rgb(100,104,110));setPadding(0,dp(3),0,0)})
            row.addView(texts,LinearLayout.LayoutParams(0,-2,1f))
            row.addView(TextView(this@MainActivity).apply{text="›";textSize=28f;setTextColor(Color.rgb(120,124,130));gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(28),dp(50)))
            row.setOnClickListener{action()}
            box.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))})
        }
        option("Backup automatico","Attivo • 1 copia automatica al giorno, separata dal manuale","☁"){maybeAutoBackup();Toast.makeText(this,"$lastText",Toast.LENGTH_LONG).show()}
        option("Esporta backup manuale","Salva una copia completa dove preferisci","↑"){exportData()}
        option("Importa backup manuale","Ripristina una copia precedentemente salvata","↓"){importData()}
        option("Ripristina backup automatico",lastText,"↺"){restoreAutoBackup()}
        val close=Button(this).apply{text="Chiudi";setAllCaps(false);textSize=14f;setTextColor(Color.rgb(0,125,110));setBackgroundColor(Color.TRANSPARENT);stateListAnimator=null}
        box.addView(close,LinearLayout.LayoutParams(-1,dp(46)).apply{setMargins(0,dp(4),0,0)})
        showSettingsSubpage(box,"Backup e dati")
        close.setOnClickListener{closeSettingsSubpage()}
    }
    private fun exportData(){startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/json";putExtra(Intent.EXTRA_TITLE,"GestionePagamenti_backup.json")},REQ_EXPORT)}
    private fun importData(){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/json"},REQ_IMPORT)}
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode!=RESULT_OK)return
        val uri=data?.data?:return
        if(requestCode==REQ_EXPORT)writeBackup(uri)
        else if(requestCode==REQ_IMPORT){
            backupConfirmDialog(
                "Importare backup manuale?",
                "Il backup selezionato sostituirà i dati attualmente presenti nell'app.\n\nNessun dato verrà modificato prima della tua conferma.",
                "↓",
                "IMPORTA",
                Color.rgb(20,91,165)
            ){readBackup(uri)}
        }else if(requestCode==REQ_SUMMARY)writeSummary(uri)
    }

    private fun backupJson():JSONObject{
        val root=JSONObject();root.put("format","GestionePagamenti");root.put("version",6);root.put("exportedAt",LocalDateTime.now().toString());root.put("ferieStart",ferieStart?.toString()?:JSONObject.NULL);root.put("ferieEnd",ferieEnd?.toString()?:JSONObject.NULL);root.put("dashboardEnabled",dashboardEnabled);root.put("surnameFirstDisplay",surnameFirstDisplay);root.put("calendarVisibleDays",JSONArray().apply{calendarVisibleDays.forEach{put(it)}});root.put("calendarNavPosition",calendarNavPosition);root.put("calendarNavOrder",JSONArray().apply{calendarNavOrder.forEach{put(it)}});root.put("calendarTopButtons",JSONArray().apply{calendarTopButtons.forEach{put(it)}});root.put("calendarBottomButtons",JSONArray().apply{calendarBottomButtons.forEach{put(it)}});root.put("appointmentTypes",JSONArray().apply{appointmentTypes.forEach{t->put(JSONObject().apply{put("id",t.id);put("name",t.name);put("color",t.color);put("duration",t.duration)})}});root.put("activeRoutineIndex",activeRoutineIndex);root.put("calendarRoutines",JSONArray().apply{calendarRoutines.forEach{r->put(JSONObject().apply{put("name",r.name);put("maxTotal",r.maxTotal);put("maxByType",JSONArray().apply{r.maxByType.forEach{put(it)}})})}})
        val array=JSONArray();packs.forEach{p->val rates=ratesFor(p);val dates=dueDates(p);array.put(JSONObject().apply{put("name",p.name);put("start",p.start.toString());put("total",p.total);put("paid",p.paid);put("dueDates",JSONArray().apply{dates.forEach{put(it.toString())}});put("rateAmounts",JSONArray().apply{rates.forEach{put(it)}});put("packageType",p.packageType);put("sessionTotal",p.sessionTotal);put("active",p.active);put("missedSessions",p.missedSessions)})};root.put("packs",array)
        root.put("sessionPacks",JSONArray().apply{sessionPacks.forEach{s->put(JSONObject().apply{put("id",s.id);put("name",s.name);put("start",s.start.toString());put("totalSessions",s.totalSessions);put("cost",s.cost);put("paid",s.paid);put("active",s.active);put("rateAmounts",JSONArray().apply{sessionRatesFor(s).forEach{put(it)}})})}})
        root.put("appointments",JSONArray().apply{appointments.forEach{a->put(JSONObject().apply{put("id",a.id);put("name",a.name);put("date",a.date.toString());put("time",a.time);put("type",a.type);put("seriesId",a.seriesId);put("sessionPackId",a.sessionPackId);put("recovery",a.recovery)})}});root.put("trashItems",JSONArray().apply{trashItems.forEach{t->put(JSONObject().apply{put("id",t.id);put("kind",t.kind);put("deletedAt",t.deletedAt.toString());put("payload",t.payload)})}});return root
    }

    private fun loadCalendarConfig(root:JSONObject){
        appointmentTypes.clear();root.optJSONArray("appointmentTypes")?.let{ta->for(i in 0 until ta.length()){val t=ta.getJSONObject(i);appointmentTypes.add(AppointmentType(t.optString("id","TYPE${i+1}"),t.optString("name",if(i==0)"ALLENAMENTO" else if(i==1)"MEZZ'ORA" else "Tipo ${i+1}"),t.optInt("color",if(i==0)Color.rgb(45,135,210) else Color.rgb(215,55,55)),t.optInt("duration",if(i==1)30 else 45)))}};if(appointmentTypes.isEmpty()){appointmentTypes.add(AppointmentType("TYPE1","ALLENAMENTO",Color.rgb(45,135,210),45));appointmentTypes.add(AppointmentType("TYPE2","MEZZ'ORA",Color.rgb(215,55,55),30))}
        calendarRoutines.clear();root.optJSONArray("calendarRoutines")?.let{ra->for(i in 0 until ra.length()){val r=ra.getJSONObject(i);val limits=mutableListOf<Int>();r.optJSONArray("maxByType")?.let{ja->for(j in 0 until ja.length())limits.add(ja.optInt(j,3))};if(limits.isEmpty()){limits.add(2);limits.add(3)};while(limits.size<appointmentTypes.size)limits.add(r.optInt("maxTotal",3));calendarRoutines.add(CalendarRoutine(r.optString("name","Routine ${i+1}"),r.optInt("maxTotal",3),limits))}};if(calendarRoutines.isEmpty())calendarRoutines.add(CalendarRoutine("Personalizzata",3,MutableList(appointmentTypes.size){if(it==0)2 else 3}));activeRoutineIndex=root.optInt("activeRoutineIndex",0).coerceIn(0,calendarRoutines.lastIndex);calendarNavPosition=root.optInt("calendarNavPosition",1).coerceIn(0,1);calendarNavOrder=mutableListOf<String>().apply{root.optJSONArray("calendarNavOrder")?.let{ja->for(i in 0 until ja.length())add(ja.optString(i))}}.filter{it in listOf("PREV","SEARCH","TODAY","NEXT")}.toMutableList().also{if(it.size==3&&it.distinct().size==3){val ni=it.indexOf("NEXT");if(ni>=0)it.add(ni,"TODAY") else it.add("TODAY")};if(it.size!=4||it.distinct().size!=4)it.clear();if(it.isEmpty())it.addAll(listOf("PREV","SEARCH","TODAY","NEXT"));if(it.indexOf("PREV")>it.indexOf("NEXT")){val pi=it.indexOf("PREV");val ni=it.indexOf("NEXT");it[pi]="NEXT";it[ni]="PREV"}};calendarTopButtons=mutableListOf<String>().apply{root.optJSONArray("calendarTopButtons")?.let{ja->for(i in 0 until ja.length())add(ja.optString(i))}}.filter{it in listOf("APPT","SEARCH","TODAY","PREV","NEXT")}.toMutableList();calendarBottomButtons=mutableListOf<String>().apply{root.optJSONArray("calendarBottomButtons")?.let{ja->for(i in 0 until ja.length())add(ja.optString(i))}}.filter{it in listOf("APPT","SEARCH","TODAY","PREV","NEXT")}.toMutableList();if(calendarTopButtons.isEmpty()&&calendarBottomButtons.isEmpty()){if(calendarNavPosition==0){calendarTopButtons.add("APPT");calendarTopButtons.addAll(calendarNavOrder)}else{calendarTopButtons.add("APPT");calendarBottomButtons.addAll(calendarNavOrder)}};if(calendarTopButtons.contains("APPT")||calendarBottomButtons.contains("APPT")){calendarTopButtons.remove("APPT");calendarBottomButtons.remove("APPT");calendarTopButtons.add(0,"APPT")};calendarTopButtons=calendarTopButtons.distinct().toMutableList();calendarBottomButtons=calendarBottomButtons.filter{it !in calendarTopButtons}.distinct().toMutableList();val combined=calendarTopButtons+calendarBottomButtons;if("PREV" in combined&&"NEXT" in combined&&combined.indexOf("PREV")>combined.indexOf("NEXT")){val pi=combined.indexOf("PREV");val ni=combined.indexOf("NEXT");if(pi<calendarTopButtons.size&&ni<calendarTopButtons.size){val t=calendarTopButtons[pi];calendarTopButtons[pi]=calendarTopButtons[ni];calendarTopButtons[ni]=t}else if(pi>=calendarTopButtons.size&&ni>=calendarTopButtons.size){val a=pi-calendarTopButtons.size;val b=ni-calendarTopButtons.size;val t=calendarBottomButtons[a];calendarBottomButtons[a]=calendarBottomButtons[b];calendarBottomButtons[b]=t}else{calendarTopButtons=mutableListOf("APPT","PREV");calendarBottomButtons=mutableListOf("SEARCH","TODAY","NEXT")}}
    }
    private fun writeSummary(uri:Uri){try{contentResolver.openOutputStream(uri)?.use{it.write(pendingSummaryText.toByteArray(Charsets.UTF_8))};Toast.makeText(this,"Riepilogo esportato.",Toast.LENGTH_LONG).show()}catch(_:Exception){Toast.makeText(this,"Impossibile esportare il riepilogo.",Toast.LENGTH_LONG).show()}}

    private fun regularPackFor(name:String, date:LocalDate):Pack? = packs.filter {
        it.active && identityKey(it.name)==identityKey(name) && !date.isBefore(it.start) && !date.isAfter(it.start.plusWeeks(12).minusDays(1))
    }.maxByOrNull { it.start }

    private fun recoveryUsedForPack(p:Pack):Int = 0

    private fun recoveriesForPack(p:Pack):Int {
        val end=p.start.plusWeeks(12).minusDays(1)
        val target=when(p.packageType){
            "GOLD"->3
            "SILVER"->2
            "BRONZE"->1
            else->0
        }
        if(target<=0)return 0
        val inWindow=appointments.filter{
            identityKey(it.name)==identityKey(p.name) &&
            !it.date.isBefore(p.start) && !it.date.isAfter(end)
        }
        if(inWindow.isEmpty())return 0
        var deficit=0
        var surplus=0
        for(week in 0 until 12){
            val ws=p.start.plusWeeks(week.toLong())
            val we=ws.plusDays(6)
            val count=inWindow.count{!it.date.isBefore(ws)&&!it.date.isAfter(we)}
            if(count==0)continue
            if(count<target) deficit += target-count
            else if(count>target) surplus += count-target
        }
        return (deficit-surplus).coerceAtLeast(0)
    }

    private fun sessionsForPack(p:Pack,until:LocalDate=LocalDate.now()):List<Appointment>{
        val end=p.start.plusWeeks(12).minusDays(1)
        return appointments.filter{identityKey(it.name)==identityKey(p.name)&&!it.date.isBefore(p.start)&&!it.date.isAfter(until)&&!it.date.isAfter(end)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
    }

    private fun sessionsForSessionPack(s:SessionPack,until:LocalDate=LocalDate.now()):List<Appointment>{
        return sessionAppointments(s).filter{!it.date.isAfter(until)&&!it.date.isBefore(s.start)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
    }

    private fun summaryForPack(p: Pack): String {
        val today = LocalDate.now()
        val packageEnd = p.start.plusWeeks(12).minusDays(1)
        val done = sessionsForPack(p, today)
        val expected = p.sessionTotal
        val recoveryDue = recoveriesForPack(p)
        val scheduledInWindow = appointments.count {
            identityKey(it.name)==identityKey(p.name) &&
            !it.date.isBefore(p.start) && !it.date.isAfter(packageEnd)
        }
        val remaining = (expected - scheduledInWindow).coerceAtLeast(0)
        val futurePackage = appointments.filter {
            identityKey(it.name) == identityKey(p.name) &&
            it.date.isAfter(today) && !it.date.isAfter(packageEnd) && !it.date.isBefore(p.start)
        }.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        val usedRecoveries = appointments.filter {
            it.recovery && identityKey(it.name)==identityKey(p.name) &&
            !it.date.isBefore(p.start) && !it.date.isAfter(packageEnd)
        }.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        return buildString {
            appendLine("📊 RIEPILOGO PROGRAMMAZIONE")
            appendLine()
            appendLine("Cliente: ${displaySurnameFirst(p.name)}")
            appendLine("Pacchetto: ${p.packageType} • $expected sedute • 12 settimane")
            appendLine("Periodo: ${p.start.format(fmt)} → ${packageEnd.format(fmt)}")
            appendLine()
            appendLine("SITUAZIONE")
            appendLine("• Sedute effettuate: ${done.size}")
            appendLine("• Sedute rimaste: $remaining")
            appendLine("• Recuperi disponibili: $recoveryDue")
            appendLine()
            appendLine("SEDUTE EFFETTUATE")
            if (done.isEmpty()) appendLine("Nessuna seduta effettuata.")
            done.forEachIndexed { index, a ->
                appendLine("${index + 1}. ${a.date.format(fmt)} • ${a.time} • ${typeLabel(a.type)}")
            }
            appendLine()
            appendLine("RECUPERI")
            if (usedRecoveries.isEmpty()) appendLine("Nessun recupero utilizzato.")
            usedRecoveries.forEachIndexed { index, a ->
                appendLine("${index + 1}. ${a.date.format(fmt)} • ${a.time} • RECUPERO • ${typeLabel(a.type)}")
            }
            appendLine("Disponibili: $recoveryDue")
            appendLine()
            appendLine("PROSSIMI APPUNTAMENTI")
            if (futurePackage.isEmpty()) appendLine("Nessun appuntamento futuro nel pacchetto.")
            futurePackage.forEachIndexed { index, a ->
                appendLine("${index + 1}. ${a.date.format(fmt)} • ${a.time} • ${typeLabel(a.type)}")
            }
        }
    }

    private fun summaryForSessionPack(s: SessionPack): String {
        val today = LocalDate.now()
        val done = sessionsForSessionPack(s, today)
        val futurePackage = sessionAppointments(s).filter { it.date.isAfter(today) }
            .sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        val annualFuture = appointments.filter {
            identityKey(it.name)==identityKey(s.name) && it.date.isAfter(today) && it.sessionPackId != s.id
        }.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        return buildString {
            appendLine("📋 PROGRAMMAZIONE ${displaySurnameFirst(s.name).uppercase()}")
            appendLine("Pacchetto • ${s.totalSessions} sedute")
            appendLine("Periodo pacchetto: ${s.start.format(fmt)} → aperto fino a esaurimento sedute")
            appendLine()
            appendLine("📊 SITUAZIONE")
            appendLine("• Sedute previste: ${s.totalSessions}")
            appendLine("• Sedute effettuate: ${done.size}")
            appendLine("• Sedute prenotate nel pacchetto: ${futurePackage.size}")
            appendLine("• Sedute rimanenti: ${(s.totalSessions-done.size).coerceAtLeast(0)}")
            appendLine()
            appendLine("🗓 PROGRAMMAZIONE DEL PACCHETTO")
            if(futurePackage.isEmpty()) appendLine("Nessun appuntamento futuro nel pacchetto.")
            futurePackage.forEachIndexed{index,a->
                val type=typeLabel(a.type)
                appendLine("${index+1}. ${a.date.format(fmt)} • ${a.time} • $type")
            }
            if(annualFuture.isNotEmpty()){
                appendLine()
                appendLine("📅 PROGRAMMAZIONE SUCCESSIVA")
                appendLine("Gli appuntamenti successivi restano nel calendario e verranno considerati per il prossimo pacchetto.")
                annualFuture.forEachIndexed{index,a->
                    val type=typeLabel(a.type)
                    appendLine("${index+1}. ${a.date.format(fmt)} • ${a.time} • $type")
                }
            }
        }
    }

    private fun copySummaryToClipboard(text:String,name:String){
        pendingSummaryText=text
        val clipboard=getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Riepilogo $name",text))
        val preview=TextView(this).apply{this.text=text;textSize=14f;setTextColor(Color.rgb(35,35,35));setPadding(dp(16),dp(8),dp(16),dp(8))}
        val dialog=AlertDialog.Builder(this).setTitle("📊 Riepilogo pronto per WhatsApp").setMessage("Il riepilogo è già stato copiato negli appunti. Puoi incollarlo direttamente su WhatsApp.").setView(ScrollView(this).apply{addView(preview)}).setPositiveButton("COPIA DI NUOVO"){_,_->
            clipboard.setPrimaryClip(ClipData.newPlainText("Riepilogo $name",text))
            Toast.makeText(this,"Riepilogo copiato negli appunti.",Toast.LENGTH_SHORT).show()
        }.setNegativeButton("CHIUDI",null).create()
        styleOneUiDialog(dialog)
        dialog.show()
    }

    private fun exportSummary(text:String,name:String){copySummaryToClipboard(text,name)}

    private fun maybeAutoBackup(){
        val prefs=getSharedPreferences("gestione_pagamenti",MODE_PRIVATE)
        val today=LocalDate.now().format(fmt)
        if(prefs.getString("autoBackupDate","")==today)return
        if(writeAutoBackup())prefs.edit().putString("autoBackupDate",today).apply()
    }

    private fun writeAutoBackup():Boolean{
        return try{
            val json=backupJson().toString(2).toByteArray(Charsets.UTF_8)
            val day=LocalDate.now().toString()
            val fileName="GestionePagamenti_auto_${day}.json"
            if(android.os.Build.VERSION.SDK_INT>=29){
                val resolver=contentResolver
                val projection=arrayOf(MediaStore.Downloads._ID)
                val selection="${MediaStore.Downloads.DISPLAY_NAME}=? AND ${MediaStore.Downloads.RELATIVE_PATH}=?"
                val args=arrayOf(fileName,"Download/GestionePagamenti/Backup automatici/")
                var uri:Uri?=null
                resolver.query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,projection,selection,args,null)?.use{c->if(c.moveToFirst())uri=Uri.withAppendedPath(MediaStore.Downloads.EXTERNAL_CONTENT_URI,c.getLong(0).toString())}
                val target=uri ?: resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,ContentValues().apply{
                    put(MediaStore.Downloads.DISPLAY_NAME,fileName)
                    put(MediaStore.Downloads.MIME_TYPE,"application/json")
                    put(MediaStore.Downloads.RELATIVE_PATH,"Download/GestionePagamenti/Backup automatici/")
                })
                target!=null && resolver.openOutputStream(target,"wt")?.use{it.write(json);true}==true
            }else{
                val dir=java.io.File(filesDir,"auto_backup");if(!dir.exists())dir.mkdirs()
                java.io.File(dir,fileName).writeBytes(json);true
            }
        }catch(_:Exception){false}
    }

    private fun backupConfirmDialog(title:String,message:String,icon:String,positiveText:String,positiveColor:Int,onConfirm:()->Unit){
        val root=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(20),dp(16),dp(20),dp(20))
            background=roundedSurface(Color.WHITE,28)
        }
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        top.addView(Space(this),LinearLayout.LayoutParams(0,dp(36),1f))
        val close=TextView(this).apply{
            text="×";textSize=28f;gravity=Gravity.CENTER;setTextColor(Color.rgb(70,82,105))
            background=roundedSurface(Color.rgb(246,248,252),18)
        }
        top.addView(close,LinearLayout.LayoutParams(dp(36),dp(36)))
        root.addView(top)
        val iconView=TextView(this).apply{
            text=icon;textSize=25f;gravity=Gravity.CENTER
            setTextColor(positiveColor);background=roundedSurface(Color.rgb(232,249,242),32)
        }
        root.addView(iconView,LinearLayout.LayoutParams(dp(66),dp(66)).apply{gravity=Gravity.CENTER;setMargins(0,dp(4),0,dp(14))})
        root.addView(TextView(this).apply{
            text=title;textSize=21f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER
            setTextColor(Color.rgb(25,32,45))
        },LinearLayout.LayoutParams(-1,-2))
        root.addView(TextView(this).apply{
            text=message;textSize=15.5f;gravity=Gravity.CENTER
            setTextColor(Color.rgb(70,82,105));setPadding(dp(8),dp(8),dp(8),dp(18))
        },LinearLayout.LayoutParams(-1,-2))
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val cancel=Button(this).apply{
            text="Annulla";setAllCaps(false);textSize=14f;setTextColor(Color.rgb(35,65,110));
            background=roundedSurface(Color.rgb(244,247,252),18,Color.rgb(203,218,239),1)
            minHeight=0;minimumHeight=0;minWidth=0;minimumWidth=0;stateListAnimator=null
        }
        val confirm=Button(this).apply{
            text=positiveText;setAllCaps(false);textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.WHITE)
            background=roundedSurface(positiveColor,18);minHeight=0;minimumHeight=0;minWidth=0;minimumWidth=0;stateListAnimator=null
        }
        actions.addView(cancel,LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(0,0,dp(6),0)})
        actions.addView(confirm,LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(dp(6),0,0,0)})
        root.addView(actions)
        val dialog=AlertDialog.Builder(this).setView(root).create()
        preparePopupBackdrop(dialog)
        dialog.setOnShowListener{
            popupBackdropCurrentDialog=dialog
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.TRANSPARENT,28))
            applyPopupBackdropEffect(dialog)
            dialog.window?.setDimAmount(0.42f)
            dialog.window?.let{w->w.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT)}
        }
        close.setOnClickListener{dialog.dismiss()}
        cancel.setOnClickListener{dialog.dismiss()}
        confirm.setOnClickListener{dialog.dismiss();onConfirm()}
        dialog.show()
    }

    private fun restoreAutoBackup(){
        try{
            val text=if(android.os.Build.VERSION.SDK_INT>=29){
                val resolver=contentResolver
                val projection=arrayOf(MediaStore.Downloads._ID,MediaStore.Downloads.DISPLAY_NAME)
                val selection="${MediaStore.Downloads.DISPLAY_NAME} LIKE ? AND ${MediaStore.Downloads.RELATIVE_PATH}=?"
                val args=arrayOf("GestionePagamenti_auto_%.json","Download/GestionePagamenti/Backup automatici/")
                var uri:Uri?=null;var latestName=""
                resolver.query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,projection,selection,args,"${MediaStore.Downloads.DISPLAY_NAME} DESC")?.use{c->if(c.moveToFirst()){latestName=c.getString(1);uri=Uri.withAppendedPath(MediaStore.Downloads.EXTERNAL_CONTENT_URI,c.getLong(0).toString())}}
                uri?.let{resolver.openInputStream(it)?.use{ins->BufferedReader(InputStreamReader(ins,Charsets.UTF_8)).readText()}}
            }else{
                val dir=java.io.File(filesDir,"auto_backup")
                dir.listFiles()?.sortedByDescending{it.name}?.firstOrNull()?.takeIf{it.exists()}?.readText()
            } ?: throw Exception()
            val root=JSONObject(text);require(root.optString("format")=="GestionePagamenti")
            val exportedAt=root.optString("exportedAt", "data non disponibile")
            backupConfirmDialog(
                "Ripristinare backup automatico?",
                "Il backup automatico sostituirà i dati attualmente presenti nell'app.\n\nBackup del: $exportedAt",
                "↺",
                "RIPRISTINA",
                Color.rgb(0,145,125)
            ){restoreFromJson(root)}
        }catch(_:Exception){Toast.makeText(this,"Nessun backup automatico disponibile.",Toast.LENGTH_LONG).show()}
    }

    private fun restoreFromJson(root:JSONObject){
        try{
            val newPacks=mutableListOf<Pack>();val array=root.getJSONArray("packs");for(i in 0 until array.length()){val o=array.getJSONObject(i);newPacks.add(Pack(o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("total"),o.optInt("paid",0),o.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}},o.optString("packageType","PERSONALIZZATO"),o.optInt("sessionTotal",12),o.optBoolean("active",true),o.optInt("missedSessions",0)))}
            val newSessionPacks=mutableListOf<SessionPack>();val sp=root.optJSONArray("sessionPacks");if(sp!=null)for(i in 0 until sp.length()){val o=sp.getJSONObject(i);newSessionPacks.add(SessionPack(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("totalSessions"),o.getInt("cost"),o.optInt("paid",o.optInt("cost",0)),o.optBoolean("active",true),o.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}}))}
            val newAppointments=mutableListOf<Appointment>();val ap=root.optJSONArray("appointments");if(ap!=null)for(i in 0 until ap.length()){val o=ap.getJSONObject(i);newAppointments.add(Appointment(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("date")),o.getString("time"),normalizedType(o.optString("type","TYPE1")),o.optLong("seriesId",0L),o.optLong("sessionPackId",0L),o.optBoolean("recovery",false)))}
            packs.clear();packs.addAll(newPacks);sessionPacks.clear();sessionPacks.addAll(newSessionPacks);appointments.clear();appointments.addAll(newAppointments);nextAppointmentId=(appointments.maxOfOrNull{it.id}?:0L)+1;nextSessionPackId=(sessionPacks.maxOfOrNull{it.id}?:0L)+1
            ferieStart=if(root.isNull("ferieStart"))null else LocalDate.parse(root.getString("ferieStart"));ferieEnd=if(root.isNull("ferieEnd"))null else LocalDate.parse(root.getString("ferieEnd"));dashboardEnabled=root.optBoolean("dashboardEnabled",false);surnameFirstDisplay=root.optBoolean("surnameFirstDisplay",true);loadCalendarConfig(root);calendarVisibleDays=booleanArrayOf(true,true,true,true,true,false,false);root.optJSONArray("calendarVisibleDays")?.let{ja->if(ja.length()==7)calendarVisibleDays=BooleanArray(7){i->ja.optBoolean(i,i<5)}}
            saveData();build();Toast.makeText(this,"Backup automatico ripristinato.",Toast.LENGTH_LONG).show()
        }catch(_:Exception){Toast.makeText(this,"Backup automatico non valido.",Toast.LENGTH_LONG).show()}
    }

    private fun writeBackup(uri:Uri){try{contentResolver.openOutputStream(uri)?.use{it.write(backupJson().toString(2).toByteArray(Charsets.UTF_8))};Toast.makeText(this,"Backup esportato correttamente.",Toast.LENGTH_LONG).show()}catch(_:Exception){Toast.makeText(this,"Impossibile esportare il backup.",Toast.LENGTH_LONG).show()}}
    private fun readBackup(uri:Uri){try{val text=contentResolver.openInputStream(uri)?.use{BufferedReader(InputStreamReader(it,Charsets.UTF_8)).readText()}?:throw Exception();val root=JSONObject(text);require(root.optString("format")=="GestionePagamenti");val newPacks=mutableListOf<Pack>();val array=root.getJSONArray("packs");for(i in 0 until array.length()){val o=array.getJSONObject(i);newPacks.add(Pack(o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("total"),o.optInt("paid",0), o.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}}, o.optString("packageType","PERSONALIZZATO"), o.optInt("sessionTotal",when(o.optString("packageType","PERSONALIZZATO")){"BRONZE"->12;"SILVER"->24;"GOLD"->36;else->12}), o.optBoolean("active",true), o.optInt("missedSessions",0)))};ferieStart=if(root.isNull("ferieStart"))null else LocalDate.parse(root.getString("ferieStart"));ferieEnd=if(root.isNull("ferieEnd"))null else LocalDate.parse(root.getString("ferieEnd"));dashboardEnabled=root.optBoolean("dashboardEnabled",false);surnameFirstDisplay=root.optBoolean("surnameFirstDisplay",true);loadCalendarConfig(root);calendarVisibleDays=booleanArrayOf(true,true,true,true,true,false,false);root.optJSONArray("calendarVisibleDays")?.let{ja->if(ja.length()==7)calendarVisibleDays=BooleanArray(7){i->ja.optBoolean(i,i<5)}};val newSessionPacks=mutableListOf<SessionPack>();val sp=root.optJSONArray("sessionPacks");if(sp!=null)for(i in 0 until sp.length()){val o=sp.getJSONObject(i);newSessionPacks.add(SessionPack(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("totalSessions"),o.getInt("cost"),o.optInt("paid",o.optInt("cost",0)),o.optBoolean("active",true),o.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}}))};val newAppointments=mutableListOf<Appointment>();val ap=root.optJSONArray("appointments");if(ap!=null)for(i in 0 until ap.length()){val o=ap.getJSONObject(i);newAppointments.add(Appointment(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("date")),o.getString("time"),normalizedType(o.optString("type","TYPE1")),o.optLong("seriesId",0L),o.optLong("sessionPackId",0L),o.optBoolean("recovery",false)))};val newTrash=mutableListOf<TrashItem>();val tr=root.optJSONArray("trashItems");if(tr!=null)for(i in 0 until tr.length()){val o=tr.getJSONObject(i);runCatching{newTrash.add(TrashItem(o.optLong("id",i.toLong()+1),o.optString("kind","APPOINTMENT"),LocalDateTime.parse(o.optString("deletedAt")),o.optString("payload","")))}};packs.clear();packs.addAll(newPacks);sessionPacks.clear();sessionPacks.addAll(newSessionPacks);appointments.clear();appointments.addAll(newAppointments);trashItems.clear();trashItems.addAll(newTrash);nextAppointmentId=(appointments.maxOfOrNull{it.id}?:0L)+1;nextSessionPackId=(sessionPacks.maxOfOrNull{it.id}?:0L)+1;nextTrashId=(trashItems.maxOfOrNull{it.id}?:0L)+1;saveData();build();Toast.makeText(this,"Backup importato: dati, ferie, pagamenti e appuntamenti ripristinati.",Toast.LENGTH_LONG).show()}catch(_:Exception){Toast.makeText(this,"Backup non valido o non leggibile.",Toast.LENGTH_LONG).show()}}

    private fun saveData(){
        val prefs=getSharedPreferences("gestione_pagamenti",MODE_PRIVATE);val array=JSONArray();packs.forEach{p->array.put(JSONObject().apply{put("name",p.name);put("start",p.start.toString());put("total",p.total);put("paid",p.paid);put("rateAmounts",JSONArray().apply{ratesFor(p).forEach{put(it)}});put("packageType",p.packageType);put("sessionTotal",p.sessionTotal);put("active",p.active);put("missedSessions",p.missedSessions)})};val sp=JSONArray();sessionPacks.forEach{s->sp.put(JSONObject().apply{put("id",s.id);put("name",s.name);put("start",s.start.toString());put("totalSessions",s.totalSessions);put("cost",s.cost);put("paid",s.paid);put("active",s.active);put("rateAmounts",JSONArray().apply{sessionRatesFor(s).forEach{put(it)}})})};val ap=JSONArray();appointments.forEach{a->ap.put(JSONObject().apply{put("id",a.id);put("name",a.name);put("date",a.date.toString());put("time",a.time);put("type",a.type);put("seriesId",a.seriesId);put("sessionPackId",a.sessionPackId);put("recovery",a.recovery)})};prefs.edit().putString("packs",array.toString()).putString("sessionPacks",sp.toString()).putString("appointments",ap.toString()).putString("ferieStart",ferieStart?.toString()).putString("ferieEnd",ferieEnd?.toString()).putBoolean("dashboardEnabled",dashboardEnabled).putBoolean("surnameFirstDisplay",surnameFirstDisplay).putString("popupBackdropEffect",popupBackdropEffect).putString("popupBackdropMode",popupBackdropMode).putInt("popupBackdropIntensity",popupBackdropIntensity).putString("calendarStyleSet",calendarStyleSet).putString("liquidGlassSlotShape",liquidGlassSlotShape).putInt("liquidGlassSlotColor",liquidGlassSlotColor).putString("nebbiaSoftSlotShape",nebbiaSoftSlotShape).putString("scuroEleganteSlotShape",scuroEleganteSlotShape).putInt("nebbiaSoftSlotColor",nebbiaSoftSlotColor).putInt("scuroEleganteSlotColor",scuroEleganteSlotColor).putString("calendarMaterialEffect",calendarMaterialEffect).putInt("calendarMaterialIntensity",calendarMaterialIntensity).putString("appointmentStyleSet",appointmentStyleSet).putString("appointmentShape",appointmentShape).putString("liquidGlassAppointmentShape",liquidGlassAppointmentShape).putString("vetroSoft14AppointmentShape",vetroSoft14AppointmentShape).putString("satinato14AppointmentShape",satinato14AppointmentShape).putString("scuroElegante14AppointmentShape",scuroElegante14AppointmentShape).putString("calendarVisibleDays",calendarVisibleDays.joinToString(","){if(it)"1" else "0"}).putInt("calendarNavPosition",calendarNavPosition).putString("calendarNavOrder",calendarNavOrder.joinToString(",")).putString("calendarTopButtons",calendarTopButtons.joinToString(",")).putString("calendarBottomButtons",calendarBottomButtons.joinToString(",")).putString("appointmentTypes",JSONArray().apply{appointmentTypes.forEach{t->put(JSONObject().apply{put("id",t.id);put("name",t.name);put("color",t.color);put("duration",t.duration)})}}.toString()).putInt("activeRoutineIndex",activeRoutineIndex).putString("calendarRoutines",JSONArray().apply{calendarRoutines.forEach{r->put(JSONObject().apply{put("name",r.name);put("maxTotal",r.maxTotal);put("maxByType",JSONArray().apply{r.maxByType.forEach{put(it)}})})}}.toString()).putLong("nextAppointmentId",nextAppointmentId).putLong("nextSessionPackId",nextSessionPackId).putString("trashItems",JSONArray().apply{trashItems.forEach{t->put(JSONObject().apply{put("id",t.id);put("kind",t.kind);put("deletedAt",t.deletedAt.toString());put("payload",t.payload)})}}.toString()).putLong("nextTrashId",nextTrashId).apply();maybeAutoBackup()
    }
    private fun loadData(){
        val prefs=getSharedPreferences("gestione_pagamenti",MODE_PRIVATE);packs.clear();sessionPacks.clear();appointments.clear();trashItems.clear();val saved=prefs.getString("packs",null);if(!saved.isNullOrEmpty())try{val array=JSONArray(saved);for(i in 0 until array.length()){val o=array.getJSONObject(i);packs.add(Pack(o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("total"),o.optInt("paid",0), o.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}}, o.optString("packageType","PERSONALIZZATO"), o.optInt("sessionTotal",when(o.optString("packageType","PERSONALIZZATO")){"BRONZE"->12;"SILVER"->24;"GOLD"->36;else->12}), o.optBoolean("active",true), o.optInt("missedSessions",0)))}}catch(_:Exception){packs.clear()};val ap=prefs.getString("appointments",null);if(!ap.isNullOrEmpty())try{val array=JSONArray(ap);for(i in 0 until array.length()){val o=array.getJSONObject(i);appointments.add(Appointment(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("date")),o.getString("time"),normalizedType(o.optString("type","TYPE1")),o.optLong("seriesId",0L),o.optLong("sessionPackId",0L),o.optBoolean("recovery",false)))}}catch(_:Exception){appointments.clear()};val savedSp=prefs.getString("sessionPacks",null);if(!savedSp.isNullOrEmpty())try{val array=JSONArray(savedSp);for(i in 0 until array.length()){val o=array.getJSONObject(i);sessionPacks.add(SessionPack(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("totalSessions"),o.getInt("cost"),o.optInt("paid",o.optInt("cost",0)),o.optBoolean("active",true),o.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}}))}}catch(_:Exception){sessionPacks.clear()};val savedTrash=prefs.getString("trashItems",null);if(!savedTrash.isNullOrEmpty())try{val array=JSONArray(savedTrash);for(i in 0 until array.length()){val o=array.getJSONObject(i);trashItems.add(TrashItem(o.optLong("id",i.toLong()+1),o.optString("kind","APPOINTMENT"),LocalDateTime.parse(o.optString("deletedAt")),o.optString("payload","")))}}catch(_:Exception){trashItems.clear()};nextTrashId=maxOf(prefs.getLong("nextTrashId",1L),(trashItems.maxOfOrNull{it.id}?:0L)+1);nextAppointmentId=maxOf(prefs.getLong("nextAppointmentId",1L),(appointments.maxOfOrNull{it.id}?:0L)+1);nextSessionPackId=maxOf(prefs.getLong("nextSessionPackId",1L),(sessionPacks.maxOfOrNull{it.id}?:0L)+1)
        appointments.filter{it.sessionPackId==0L}.forEach{a->activeSessionPackFor(a.name)?.let{sp->a.sessionPackId=sp.id}}
        ferieStart=prefs.getString("ferieStart",null)?.let{runCatching{LocalDate.parse(it)}.getOrNull()};ferieEnd=prefs.getString("ferieEnd",null)?.let{runCatching{LocalDate.parse(it)}.getOrNull()};dashboardEnabled=prefs.getBoolean("dashboardEnabled",false);surnameFirstDisplay=prefs.getBoolean("surnameFirstDisplay",true);popupBackdropEffect=prefs.getString("popupBackdropEffect","NONE")?.uppercase()?.takeIf{it in setOf("NONE","SATIN","VETRO_SOFT","LIQUID")}?:"NONE";popupBackdropMode=prefs.getString("popupBackdropMode","CONTOUR")?.uppercase()?.takeIf{it in setOf("CONTOUR","IMMERSIVE")}?:"CONTOUR";popupBackdropIntensity=prefs.getInt("popupBackdropIntensity",65).coerceIn(0,100);calendarStyleSet=prefs.getString("calendarStyleSet","LIQUID_GLASS")?.uppercase()?.let{when(it){"BASE"->"NEBBIA_SOFT";"STYLE_3"->"SCURO_ELEGANTE";else->it}}?.takeIf{it in setOf("LIQUID_GLASS","NEBBIA_SOFT","SCURO_ELEGANTE")}?:"LIQUID_GLASS";liquidGlassSlotShape=prefs.getString("liquidGlassSlotShape","ARROTONDATO")?.uppercase()?.takeIf{it in setOf("ARROTONDATO","RETTANGOLARE")}?:"ARROTONDATO";liquidGlassSlotColor=prefs.getInt("liquidGlassSlotColor",Color.rgb(224,228,232));nebbiaSoftSlotShape=prefs.getString("nebbiaSoftSlotShape","ARROTONDATO")?.uppercase()?.takeIf{it in setOf("ARROTONDATO","RETTANGOLARE")}?:"ARROTONDATO";scuroEleganteSlotShape=prefs.getString("scuroEleganteSlotShape","RETTANGOLARE")?.uppercase()?.takeIf{it in setOf("ARROTONDATO","RETTANGOLARE")}?:"RETTANGOLARE";nebbiaSoftSlotColor=prefs.getInt("nebbiaSoftSlotColor",Color.rgb(244,247,250));scuroEleganteSlotColor=prefs.getInt("scuroEleganteSlotColor",Color.rgb(43,51,61));calendarMaterialEffect=prefs.getString("calendarMaterialEffect","WATER")?.uppercase()?.takeIf{it in setOf("WATER","SIDE_LIGHT")}?:"WATER";calendarMaterialIntensity=prefs.getInt("calendarMaterialIntensity",75).coerceIn(0,100);appointmentStyleSet=prefs.getString("appointmentStyleSet","LIQUID_GLASS")?.uppercase()?.takeIf{it in setOf("LIQUID_GLASS","VETRO_SOFT_14","VETRO_SOFT_FULL","SATINATO_14","SATINATO_FULL","SCURO_ELEGANTE_14")}?:"LIQUID_GLASS";appointmentShape=prefs.getString("appointmentShape","ARROTONDATO")?.uppercase()?.takeIf{it in setOf("ARROTONDATO","RETTANGOLARE")}?:"ARROTONDATO";liquidGlassAppointmentShape=prefs.getString("liquidGlassAppointmentShape","ARROTONDATO")?.uppercase()?.takeIf{it in setOf("ARROTONDATO","RETTANGOLARE")}?:"ARROTONDATO";vetroSoft14AppointmentShape=prefs.getString("vetroSoft14AppointmentShape","ARROTONDATO")?.uppercase()?.takeIf{it in setOf("ARROTONDATO","RETTANGOLARE")}?:"ARROTONDATO";satinato14AppointmentShape=prefs.getString("satinato14AppointmentShape","RETTANGOLARE")?.uppercase()?.takeIf{it in setOf("ARROTONDATO","RETTANGOLARE")}?:"RETTANGOLARE";scuroElegante14AppointmentShape=prefs.getString("scuroElegante14AppointmentShape","ARROTONDATO")?.uppercase()?.takeIf{it in setOf("ARROTONDATO","RETTANGOLARE")}?:"ARROTONDATO";val savedDays=prefs.getString("calendarVisibleDays",null);calendarVisibleDays=if(!savedDays.isNullOrBlank()){val parts=savedDays.split(",");if(parts.size==7)BooleanArray(7){i->parts[i]=="1"}else booleanArrayOf(true,true,true,true,true,false,false)}else booleanArrayOf(true,true,true,true,true,false,false);calendarNavPosition=prefs.getInt("calendarNavPosition",1).coerceIn(0,1);calendarNavOrder=prefs.getString("calendarNavOrder",null)?.split(",")?.filter{it in listOf("PREV","SEARCH","TODAY","NEXT")}?.toMutableList()?:mutableListOf("PREV","SEARCH","TODAY","NEXT");if(calendarNavOrder.size==3&&calendarNavOrder.distinct().size==3){val ni=calendarNavOrder.indexOf("NEXT");if(ni>=0)calendarNavOrder.add(ni,"TODAY") else calendarNavOrder.add("TODAY")};if(calendarNavOrder.size!=4||calendarNavOrder.distinct().size!=4)calendarNavOrder=mutableListOf("PREV","SEARCH","TODAY","NEXT");if(calendarNavOrder.indexOf("PREV")>calendarNavOrder.indexOf("NEXT")){val pi=calendarNavOrder.indexOf("PREV");val ni=calendarNavOrder.indexOf("NEXT");calendarNavOrder[pi]="NEXT";calendarNavOrder[ni]="PREV"};calendarTopButtons=prefs.getString("calendarTopButtons",null)?.split(",")?.filter{it in listOf("APPT","SEARCH","TODAY","PREV","NEXT")}?.toMutableList()?:mutableListOf();calendarBottomButtons=prefs.getString("calendarBottomButtons",null)?.split(",")?.filter{it in listOf("APPT","SEARCH","TODAY","PREV","NEXT")}?.toMutableList()?:mutableListOf();if(calendarTopButtons.isEmpty()&&calendarBottomButtons.isEmpty()){calendarTopButtons.add("APPT");if(calendarNavPosition==0)calendarTopButtons.addAll(calendarNavOrder)else calendarBottomButtons.addAll(calendarNavOrder)};calendarTopButtons=calendarTopButtons.distinct().toMutableList();calendarBottomButtons=calendarBottomButtons.filter{it !in calendarTopButtons}.distinct().toMutableList();appointmentTypes.clear();prefs.getString("appointmentTypes",null)?.let{runCatching{val a=JSONArray(it);for(i in 0 until a.length()){val t=a.getJSONObject(i);appointmentTypes.add(AppointmentType(t.optString("id","TYPE${i+1}"),t.optString("name",if(i==0)"ALLENAMENTO" else if(i==1)"MEZZ'ORA" else "Tipo ${i+1}"),t.optInt("color",if(i==0)Color.rgb(45,135,210) else Color.rgb(215,55,55)),t.optInt("duration",if(i==1)30 else 45)))}}};if(appointmentTypes.isEmpty()){appointmentTypes.add(AppointmentType("TYPE1","ALLENAMENTO",Color.rgb(45,135,210),45));appointmentTypes.add(AppointmentType("TYPE2","MEZZ'ORA",Color.rgb(215,55,55),30))};activeRoutineIndex=prefs.getInt("activeRoutineIndex",0);prefs.getString("calendarRoutines",null)?.let{runCatching{val a=JSONArray(it);calendarRoutines.clear();for(i in 0 until a.length()){val r=a.getJSONObject(i);val limits=mutableListOf<Int>();r.optJSONArray("maxByType")?.let{ja->for(j in 0 until ja.length())limits.add(ja.optInt(j,3))};if(limits.isEmpty()){limits.add(2);limits.add(3)};while(limits.size<appointmentTypes.size)limits.add(r.optInt("maxTotal",3));calendarRoutines.add(CalendarRoutine(r.optString("name","Routine ${i+1}"),r.optInt("maxTotal",3),limits))}}};if(calendarRoutines.isEmpty())calendarRoutines.add(CalendarRoutine("Personalizzata",3,MutableList(appointmentTypes.size){if(it==0)2 else 3}));ensureAppointmentTypes();calendarRoutines.forEach{while(it.maxByType.size<appointmentTypes.size)it.maxByType.add(it.maxTotal)};activeRoutineIndex=activeRoutineIndex.coerceIn(0,calendarRoutines.lastIndex)
    }

    private fun ratesFor(p:Pack):List<Int>{
        val c=p.customRates
        if(c!=null&&c.size>=3&&c.all{it>0}&&c.sum()==p.total)return c.toList()
        val r1=p.total/3;return listOf(r1,r1,p.total-r1*2)
    }

    private fun saveRates(p:Pack,rates:List<Int>){p.customRates=rates.toMutableList()}

    private fun registerPayment(p:Pack,index:Int,paidNow:Int){
        try{
            val rates=ratesFor(p)
            val due=rates[index]
            require(paidNow>0)
            require(p.paid+paidNow<=p.total)

            val paidBeforeCurrent=rates.take(index).sum()
            val alreadyPaidOnCurrent=(p.paid-paidBeforeCurrent).coerceAtLeast(0)
            val totalPaidOnCurrent=alreadyPaidOnCurrent+paidNow
            val newRates=rates.toMutableList()

            p.paid+=paidNow

            // Se il cliente paga più della rata prevista, la rata corrente
            // diventa pari a quanto effettivamente versato e il residuo viene
            // redistribuito sulle rate successive.
            if(totalPaidOnCurrent>due){
                newRates[index]=totalPaidOnCurrent
                val remainingCount=newRates.size-index-1
                if(remainingCount>0){
                    val remaining=p.total-rates.take(index).sum()-totalPaidOnCurrent
                    require(remaining>=0)
                    val base=remaining/remainingCount
                    val extra=remaining%remainingCount
                    for(j in index+1 until newRates.size){
                        newRates[j]=base+if(j-index-1<extra)1 else 0
                    }
                } else require(totalPaidOnCurrent==p.total-rates.take(index).sum())
            }

            require(newRates.sum()==p.total)
            saveRates(p,newRates)
            expandedClients.add(identityKey(p.name))
            saveData()
            // Aggiorna immediatamente anche la scheda Gestione pacchetto già aperta.
            // Prima veniva aggiornata solo dopo averla chiusa e riaperta.
            activePackageDialog?.dismiss()
            activePackageDialog = null
            render()
            packageInfoDialog(p)
            val residual=p.total-p.paid
            if(index==rates.lastIndex && residual>0 && totalPaidOnCurrent<due){
                Toast.makeText(this,"Pagamento registrato. Rimangono €$residual da pagare.",Toast.LENGTH_LONG).show()
                proposeResidualRate(p,index,residual)
            } else if(totalPaidOnCurrent>due) Toast.makeText(this,"Pagamento registrato: rate successive ricalcolate automaticamente.",Toast.LENGTH_LONG).show()
            else Toast.makeText(this,"Pagamento di €$paidNow registrato.",Toast.LENGTH_SHORT).show()
        }catch(_:Exception){
            Toast.makeText(this,"Importo non valido o superiore al totale residuo.",Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmPaymentDialog(p:Pack,index:Int,amount:Int){
        val rates=ratesFor(p)
        val (dialog,outer,body)=packActionDialogBase(
            "Conferma pagamento",
            "✓",
            Color.rgb(0,145,112),
            Color.rgb(205,244,233),
            Color.rgb(248,255,252)
        )

        body.addView(dialogBodyText("Confermi il pagamento della rata ${index+1}?"))
        body.addView(dialogInfoCard(
            "€",
            "Importo rata",
            "€$amount",
            Color.rgb(0,145,112),
            Color.rgb(224,248,241)
        ),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,dp(8))})

        body.addView(dialogInfoCard(
            "▣",
            "Rata ${index+1} di ${rates.size}",
            "${dueDates(p)[index]}",
            Color.rgb(25,100,190),
            Color.rgb(235,244,255)
        ),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(14))})

        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        row.addView(dialogButton("Annulla",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(210,220,232)){dialog.dismiss()},
            LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(5),0)})
        row.addView(dialogButton("✓ Conferma",Color.WHITE,Color.rgb(0,145,112),Color.rgb(0,145,112)){
            dialog.dismiss()
            registerPayment(p,index,amount)
        },LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(5),0,0,0)})
        body.addView(row)
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun proposeResidualRate(p:Pack,index:Int,residual:Int){
        if(residual<=0 || index!=ratesFor(p).lastIndex)return
        val dialog=buildResidualRateDialog(
            previousRate=index+1,
            dueAmount=ratesFor(p)[index],
            alreadyPaid=(p.paid-ratesFor(p).dropLast(1).sum()).coerceAtLeast(0),
            residual=residual,
            nextRate=index+2,
            onCreate={
                val current=ratesFor(p).toMutableList()
                val paidOnLast=(p.paid-current.dropLast(1).sum()).coerceAtLeast(0)
                if(paidOnLast>0 && paidOnLast<current.last()){
                    current[current.lastIndex]=paidOnLast
                    current.add(residual)
                    saveRates(p,current)
                    saveData()
                    activePackageDialog?.dismiss();activePackageDialog=null
                    render();packageInfoDialog(p)
                    Toast.makeText(this,"4ª rata creata: €$residual.",Toast.LENGTH_SHORT).show()
                }
            }
        )
        dialog.show()
    }

    private fun addRateDialog(p:Pack){
        val rates=ratesFor(p)
        val lastIndex=rates.lastIndex
        val paidBeforeLast=rates.dropLast(1).sum()
        val paidOnLast=(p.paid-paidBeforeLast).coerceAtLeast(0)
        val residual=(p.total-p.paid).coerceAtLeast(0)
        if(rates.size>=12){Toast.makeText(this,"Numero massimo di rate raggiunto.",Toast.LENGTH_SHORT).show();return}
        if(residual<=0){Toast.makeText(this,"Il pacchetto è già completamente pagato.",Toast.LENGTH_SHORT).show();return}
        if(lastIndex<0 || paidOnLast<=0 || paidOnLast>=rates[lastIndex]){
            Toast.makeText(this,"La 4ª rata viene proposta automaticamente quando l'ultima rata viene pagata solo in parte.",Toast.LENGTH_LONG).show()
            return
        }
        val dialog=AlertDialog.Builder(this)
            .setTitle("Aggiungi 4ª rata")
            .setMessage("Restano €$residual da pagare. Vuoi trasformare il residuo in una 4ª rata con scadenza tra 28 giorni?")
            .setNegativeButton("ANNULLA",null)
            .setPositiveButton("CREA 4ª RATA"){_,_->
                val newRates=rates.toMutableList()
                newRates[lastIndex]=paidOnLast
                newRates.add(residual)
                saveRates(p,newRates)
                saveData()
                activePackageDialog?.dismiss();activePackageDialog=null
                render();packageInfoDialog(p)
                Toast.makeText(this,"4ª rata creata: €$residual.",Toast.LENGTH_SHORT).show()
            }
            .create()
        styleOneUiDialog(dialog);dialog.show()
    }

    private fun paymentAmountDialog(p:Pack,index:Int){
        val rates=ratesFor(p)
        val due=rates[index]
        val (dialog,outer,body)=packActionDialogBase(
            "Modifica importo pagamento",
            "✎",
            Color.rgb(20,91,165),
            Color.rgb(224,238,255),
            Color.WHITE
        )

        body.addView(dialogBodyText("Rata ${index+1} di ${rates.size} • prevista €$due"))
        body.addView(dialogInfoCard(
            "ⓘ",
            "Inserisci il nuovo importo per questa rata.",
            "L'importo originale era €$due.",
            Color.rgb(25,100,190),
            Color.rgb(235,244,255)
        ),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,dp(12))})

        body.addView(TextView(this).apply{
            text="Nuovo importo"
            textSize=12.5f
            setTypeface(null,android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(82,87,94))
            setPadding(dp(2),0,0,dp(5))
        })

        val amount=modernEditText().apply{
            hint="Importo (€)"
            inputType=2
            setSingleLine(true)
            setText(due.toString())
            selectAll()
            textSize=16f
        }
        body.addView(amount,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(14))})

        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        row.addView(dialogButton("Annulla",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(210,220,232)){dialog.dismiss()},
            LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(5),0)})
        row.addView(dialogButton("✓ Conferma",Color.WHITE,Color.rgb(36,112,225),Color.rgb(36,112,225)){
            val value=amount.text.toString().trim().toIntOrNull()
            if(value==null||value<=0||p.paid+value>p.total){
                Toast.makeText(this,"Importo non valido o superiore al totale residuo.",Toast.LENGTH_LONG).show()
            }else{
                dialog.dismiss()
                registerPayment(p,index,value)
            }
        },LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(5),0,0,0)})
        body.addView(row)

        preparePopupBackdrop(dialog)
        dialog.setOnShowListener{
            popupBackdropCurrentDialog=dialog
            dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
            applyPopupBackdropEffect(dialog)
            dialog.window?.setDimAmount(0.40f)
            dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
            amount.clearFocus()
        }
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun paymentOptionsDialog(p:Pack,index:Int){
        val rates=ratesFor(p)
        val (dialog,outer,body)=packActionDialogBase(
            "Opzioni pagamento",
            "✎",
            Color.rgb(20,91,165),
            Color.rgb(224,238,255),
            Color.rgb(248,252,255)
        )

        body.addView(dialogBodyText("Rata ${index+1} di ${rates.size} • €${rates[index]}"))
        val editRow=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(12),dp(10),dp(10),dp(10))
            background=roundedSurface(Color.rgb(235,244,255),18,Color.rgb(205,224,248),1)
        }
        editRow.addView(TextView(this).apply{
            text="✎";textSize=21f;gravity=Gravity.CENTER;setTextColor(Color.rgb(20,91,165));
            background=roundedSurface(Color.rgb(216,234,255),20)
        },LinearLayout.LayoutParams(dp(46),dp(46)))
        val et=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,dp(6),0)}
        et.addView(TextView(this).apply{
            text="Modifica importo da pagare";textSize=15f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,70,125))
        })
        et.addView(TextView(this).apply{
            text="Puoi modificare l'importo di questa rata.";textSize=12.5f;setTextColor(Color.rgb(70,100,130));setPadding(0,dp(3),0,0)
        })
        editRow.addView(et,LinearLayout.LayoutParams(0,-2,1f))
        editRow.addView(TextView(this).apply{text="›";textSize=28f;gravity=Gravity.CENTER;setTextColor(Color.rgb(20,91,165))},LinearLayout.LayoutParams(dp(28),dp(50)))
        body.addView(editRow,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,dp(12))})

        val cancel=dialogButton("Annulla",Color.rgb(20,91,165),Color.rgb(246,249,253),Color.rgb(205,220,238)){dialog.dismiss()}
        body.addView(cancel,LinearLayout.LayoutParams(-1,dp(48)))
        editRow.setOnClickListener{dialog.dismiss();paymentAmountDialog(p,index)}
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun editRateDialog(p:Pack,index:Int){
        val rates=ratesFor(p);val firstUnpaid=p.paidRateIndex(rates);if(index<firstUnpaid){Toast.makeText(this,"Questa rata è già pagata.",Toast.LENGTH_SHORT).show();return}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(8),dp(16),0)}
        val amount=modernEditText().apply{hint="Nuovo importo rata";inputType=2;setSingleLine(true);setText(rates[index].toString())};box.addView(amount)
        val laterCount=rates.size-index-1
        AlertDialog.Builder(this).setTitle("Modifica rata ${index+1}").setMessage(if(laterCount>0)"Modifica questa rata: le rate successive verranno ricalcolate automaticamente per mantenere invariato il totale di €${p.total}." else "Essendo l'ultima rata, l'importo viene calcolato sul residuo del pacchetto.").setView(box).setNegativeButton("Annulla",null).setPositiveButton("SALVA"){_,_->
            try{
                val newAmount=amount.text.toString().trim().toInt();require(newAmount>0)
                val paidBefore=rates.take(index).sum();val alreadyOnRate=p.paid-paidBefore;require(newAmount>=alreadyOnRate)
                val remainingAfter=p.total-paidBefore-newAmount;require(remainingAfter>=0)
                val newRates=rates.toMutableList();newRates[index]=newAmount
                if(laterCount>0){val base=remainingAfter/laterCount;val extra=remainingAfter%laterCount;for(j in index+1 until newRates.size)newRates[j]=base+if(j-index-1<extra)1 else 0}else require(remainingAfter==0)
                require(newRates.sum()==p.total);saveRates(p,newRates);saveData();render()
            }catch(_:Exception){Toast.makeText(this,"Importo non valido: controlla il residuo del pacchetto.",Toast.LENGTH_LONG).show()}
        }.create().also{styleOneUiDialog(it);it.show()}
    }
    private fun dueDates(p:Pack):List<LocalDate>{val count=ratesFor(p).size;val out=mutableListOf<LocalDate>();var d=p.start;repeat(count){out.add(d);d=advance(d,28)};return out}
    private fun advance(d0:LocalDate,days:Int):LocalDate{var d=d0.plusDays(days.toLong());val fs=ferieStart;val fe=ferieEnd;if(fs!=null&&fe!=null&&!fe.isBefore(fs)&&!d.isBefore(fs)&&!d.isAfter(fe))d=fe.plusDays(1);return d}
    private fun closureText():String{val fs=ferieStart;val fe=ferieEnd;return if(fs!=null&&fe!=null)"🏖 Chiusura ferie: ${fs.format(fmt)} → ${fe.format(fmt)}" else "Nessuna chiusura ferie impostata"}

    private fun displaySurnameFirst(name:String):String{
        val clean=name.trim()
        if(!surnameFirstDisplay)return clean.split(Regex("\\s+")).filter{it.isNotBlank()}.let{parts->if(parts.size<=1)clean else parts.drop(1).joinToString(" ")+" "+parts.first()}
        return clean
    }


    private fun render(){
        // Quando si cambia vista (es. DASH), la lista deve ripartire dall'inizio:
        // altrimenti lo ScrollView può conservare lo scroll precedente e nascondere
        // la sezione SCADUTI lasciando visibile solo una sezione più in basso.
        (list.parent as? ScrollView)?.scrollTo(0,0)
        list.removeAllViews()
        val query=if(::searchInput.isInitialized)searchInput.text.toString().trim().lowercase() else ""
        if(query.isNotEmpty()){
            renderSearchResults(query)
            return
        }
        val filteredBase=packs.filter{it.active}
        val filteredSessionsBase=sessionPacks.filter{it.active&&(query.isEmpty()||it.name.lowercase().contains(query))}
        val filtered=when(homeSortMode){
            1->filteredBase.sortedBy{it.name.lowercase()}
            2->filteredBase.sortedByDescending{it.name.lowercase()}
            else->filteredBase.sortedWith(compareBy<Pack>{statusRank(statusFor(it,ratesFor(it),dueDates(it)))}.thenBy{it.start}.thenBy{it.name.lowercase()})
        }
        val filteredSessions=when(homeSortMode){
            1->filteredSessionsBase.sortedBy{it.name.lowercase()}
            2->filteredSessionsBase.sortedByDescending{it.name.lowercase()}
            else->filteredSessionsBase.sortedWith(compareBy<SessionPack>{statusRank(sessionStatus(it))}.thenBy{it.start}.thenBy{it.name.lowercase()})
        }
        if(dashboardEnabled){renderDashboard(filtered,filteredSessions)}else{
            if(filtered.isEmpty()&&filteredSessions.isEmpty()){
                list.addView(TextView(this).apply{text=if(packs.isEmpty()&&sessionPacks.isEmpty())"Nessun pacchetto inserito." else "Nessun cliente trovato.";textSize=18f;setTextColor(Color.DKGRAY);setPadding(0,dp(12),0,dp(12))})
                return
            }
            val unified=mutableListOf<Any>()
            filtered.forEach{unified.add(it)}
            filteredSessions.forEach{unified.add(it)}
            val ordered=when(homeSortMode){
                1->unified.sortedBy{when(it){is Pack->it.name.lowercase();is SessionPack->it.name.lowercase();else->""}}
                2->unified.sortedByDescending{when(it){is Pack->it.name.lowercase();is SessionPack->it.name.lowercase();else->""}}
                else->unified.sortedWith(compareBy<Any>{when(it){is Pack->statusRank(statusFor(it,ratesFor(it),dueDates(it)));is SessionPack->statusRank(sessionStatus(it));else->Int.MAX_VALUE}}.thenBy{when(it){is Pack->it.start;is SessionPack->it.start;else->LocalDate.MAX}}.thenBy{when(it){is Pack->it.name.lowercase();is SessionPack->it.name.lowercase();else->""}})
            }
            ordered.forEach{item->when(item){is Pack->card(item);is SessionPack->sessionCard(item)}}
        }
    }

    private fun renderSearchResults(query:String){
        val target=if(::searchList.isInitialized)searchList else list
        target.removeAllViews()
        val matchingNames=(packs.filter{it.name.lowercase().contains(query)}.map{it.name}+sessionPacks.filter{it.name.lowercase().contains(query)}.map{it.name}+appointments.filter{it.name.lowercase().contains(query)}.map{it.name}).distinctBy{identityKey(it)}.sortedBy{it.lowercase()}
        val matchingAppointments=appointments.filter{it.name.lowercase().contains(query)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        if(matchingNames.isEmpty()&&matchingAppointments.isEmpty()){
            target.addView(TextView(this).apply{text="Nessun risultato";textSize=17f;setTextColor(Color.DKGRAY);setPadding(dp(8),dp(16),dp(8),dp(16))})
            return
        }
        if(matchingNames.isNotEmpty()){
            target.addView(TextView(this).apply{text="CLIENTI";textSize=12f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(100,104,110));setPadding(dp(6),dp(4),dp(6),dp(6))})
            matchingNames.forEach{name->
                val key=identityKey(name)
                val regular=packs.firstOrNull{it.active&&identityKey(it.name)==key}
                val session=sessionPacks.firstOrNull{it.active&&identityKey(it.name)==key}
                val statusColor=when{regular!=null->statusFor(regular,ratesFor(regular),dueDates(regular)).color;session!=null->sessionStatus(session).color;else->Color.GRAY}
                val future=appointments.filter{identityKey(it.name)==key&&it.date.isAfter(LocalDate.now())}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
                val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;background=roundedSurface(Color.WHITE,18,Color.rgb(228,231,235),1);setPadding(dp(14),dp(10),dp(10),dp(10))}
                val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                top.addView(TextView(this).apply{text=displaySurnameFirst(name);textSize=17f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(24,27,31));gravity=Gravity.CENTER_VERTICAL;maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END},LinearLayout.LayoutParams(0,dp(44),1f))
                top.addView(TextView(this).apply{text=if(future.isNotEmpty())"${future.size} appuntamenti" else "Nessun futuro";textSize=12.5f;setTextColor(Color.rgb(90,94,100));gravity=Gravity.CENTER},LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,dp(44)))
                top.addView(TextView(this).apply{text="●";textSize=18f;setTextColor(statusColor);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(28),dp(44)))
                row.addView(top)
                val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(6),0,0)}
                val program=Button(this).apply{text="📋 Programmazione";setAllCaps(false);textSize=12.5f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(Color.rgb(20,95,150));background=roundedSurface(Color.rgb(240,247,253),15,Color.rgb(190,220,248),1);setOnClickListener{copyProgrammingToClipboard(name)}}
                actions.addView(program,LinearLayout.LayoutParams(0,dp(42),1f).apply{setMargins(0,0,dp(5),0)})
                val packageButton=Button(this).apply{text="📦 Pacchetto";setAllCaps(false);textSize=12.5f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(Color.rgb(65,70,185));background=roundedSurface(Color.rgb(246,246,255),15,Color.rgb(214,214,246),1);setOnClickListener{openPackageFromSearch(name)}}
                actions.addView(packageButton,LinearLayout.LayoutParams(0,dp(42),0.82f).apply{setMargins(0,0,dp(5),0)})
                val open=Button(this).apply{text="Apri";setAllCaps(false);textSize=12.5f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(Color.rgb(0,125,110));background=roundedSurface(Color.rgb(244,249,248),15,Color.rgb(190,225,216),1);setOnClickListener{showSearchClientAppointments(name)}}
                actions.addView(open,LinearLayout.LayoutParams(dp(72),dp(42)))
                row.addView(actions)
                row.setOnClickListener{showSearchClientAppointments(name)}
                target.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})
            }
        }
        if(matchingAppointments.isNotEmpty()){
            target.addView(TextView(this).apply{text="APPUNTAMENTI";textSize=12f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(100,104,110));setPadding(dp(6),dp(10),dp(6),dp(6))})
            matchingAppointments.forEach{a->
                val accent=typeColor(a.type)
                val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;background=roundedSurface(Color.WHITE,16,Color.rgb(228,231,235),1);setPadding(dp(12),dp(8),dp(12),dp(8))}
                row.addView(TextView(this).apply{text=displaySurnameFirst(a.name);textSize=15f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(30,32,36));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,dp(52),1f))
                row.addView(TextView(this).apply{text="${a.date.format(fmt)}\n${a.time} • ${typeLabel(a.type)}";textSize=11.5f;setTextColor(accent);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(118),dp(52)))
                row.setOnClickListener{appointmentActions(a)}
                target.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(6))})
            }
        }
    }

    private fun openPackageFromSearch(name:String){
        val key=identityKey(name)
        val regular=packs.firstOrNull{it.active&&identityKey(it.name)==key}
        val session=sessionPacks.firstOrNull{it.active&&identityKey(it.name)==key}
        when{
            regular!=null&&session==null -> packageInfoDialog(regular)
            session!=null&&regular==null -> sessionInfoDialog(session)
            regular!=null&&session!=null -> {
                val choices=arrayOf("📦 ${regular.packageType} • 12 settimane","🎯 Pacchetto sedute • ${session.totalSessions} sedute")
                AlertDialog.Builder(this).setTitle(displaySurnameFirst(name)).setItems(choices){_,which->
                    if(which==0) packageInfoDialog(regular) else sessionInfoDialog(session)
                }.setNegativeButton("ANNULLA",null).create().also{styleOneUiDialog(it);it.show()}
            }
            else -> Toast.makeText(this,"Nessun pacchetto attivo per ${displaySurnameFirst(name)}.",Toast.LENGTH_SHORT).show()
        }
    }

    private fun showSearchClientAppointments(name:String){
        val key=identityKey(name)
        val all=appointments.filter{identityKey(it.name)==key}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        val future=all.filter{it.date.isAfter(LocalDate.now())}
        if(future.isEmpty()){
            Toast.makeText(this,"Nessun appuntamento futuro per ${displaySurnameFirst(name)}.",Toast.LENGTH_SHORT).show()
            return
        }
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(4),dp(16),dp(6))}
        box.addView(TextView(this).apply{text="${future.size} appuntamenti futuri";textSize=13f;setTextColor(Color.rgb(100,104,110));setPadding(0,0,0,dp(8))})
        future.forEach{a->
            val accent=typeColor(a.type)
            box.addView(TextView(this).apply{text="${a.date.format(fmt)} • ${a.time} • ${typeLabel(a.type)}";textSize=14.5f;setTextColor(accent);setPadding(0,dp(5),0,dp(5))})
        }
        val dialog=AlertDialog.Builder(this).setTitle(displaySurnameFirst(name)).setView(box).setNegativeButton("CHIUDI",null).setPositiveButton("📋 COPIA PROGRAMMAZIONE"){_,_->copyProgrammingToClipboard(name)}.create()
        styleOneUiDialog(dialog);dialog.show()
    }

    private fun programmingAppointments(name:String, choice:Int):List<Appointment>{
        val today=LocalDate.now()
        val all=appointments.filter{identityKey(it.name)==identityKey(name)&&it.date.isAfter(today)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        return when(choice){
            0 -> all.take(10)
            1 -> all.take(30)
            2 -> {
                val pack=packs.filter{it.active&&identityKey(it.name)==identityKey(name)}.maxByOrNull{it.start}
                val session=sessionPacks.filter{it.active&&identityKey(it.name)==identityKey(name)}.maxByOrNull{it.start}
                when {
                    pack!=null -> all.filter{!it.date.isAfter(pack.start.plusWeeks(12).minusDays(1))&& !it.date.isBefore(pack.start)}
                    session!=null -> all.filter{it.sessionPackId==session.id}
                    else -> all
                }
            }
            else -> all
        }
    }

    private fun programmingText(name:String, choice:Int):String{
        val selected=programmingAppointments(name,choice)
        if(selected.isEmpty()) return "Nessun appuntamento futuro disponibile."
        val title=when(choice){0->"PROSSIMI 10 APPUNTAMENTI";1->"PROSSIMI 30 APPUNTAMENTI";2->"PROGRAMMAZIONE PACCHETTO";else->"PROGRAMMAZIONE ANNUALE"}
        return buildString{
            appendLine("📋 $title")
            appendLine("Cliente: ${displaySurnameFirst(name)}")
            appendLine()
            selected.forEachIndexed{index,a->
                val type=typeLabel(a.type)
                appendLine("${index+1}. ${a.date.format(fmt)} • ${a.time} • $type")
            }
        }
    }

    private fun programmingOptionsDialog(name:String){
        val options=arrayOf("Prossimi 10 appuntamenti","Prossimi 30 appuntamenti","Tutto il pacchetto","Tutta la programmazione annuale")
        val dialog=AlertDialog.Builder(this)
            .setTitle("📋 Copia programmazione")
            .setItems(options){_,which->
                val text=programmingText(name,which)
                if(text.startsWith("Nessun appuntamento")) Toast.makeText(this,text,Toast.LENGTH_SHORT).show()
                else copyProgrammingTextToClipboard(text,name)
            }
            .setNegativeButton("ANNULLA",null)
            .create()
        styleOneUiDialog(dialog);dialog.show()
    }

    private fun copyProgrammingTextToClipboard(text:String,name:String){
        val clipboard=getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Programmazione $name",text))
        val preview=TextView(this).apply{this.text=text;textSize=14f;setTextColor(Color.rgb(35,35,35));setPadding(dp(16),dp(8),dp(16),dp(8))}
        val dialog=AlertDialog.Builder(this).setTitle("📋 Programmazione pronta").setMessage("La programmazione è già stata copiata negli appunti. Puoi incollarla direttamente su WhatsApp.").setView(ScrollView(this).apply{addView(preview)}).setNegativeButton("CHIUDI",null).setPositiveButton("COPIA DI NUOVO"){_,_->clipboard.setPrimaryClip(ClipData.newPlainText("Programmazione $name",text));Toast.makeText(this,"Programmazione copiata.",Toast.LENGTH_SHORT).show()}.create()
        styleOneUiDialog(dialog);dialog.show()
    }

    private fun copyProgrammingToClipboard(name:String){ programmingOptionsDialog(name) }

    private fun renderDashboard(items:List<Pack>,sessionItems:List<SessionPack>){
        val today=LocalDate.now()
        val activeClients=(items.map{identityKey(it.name)}+sessionItems.map{identityKey(it.name)}).distinct().size
        val todayAppointments=appointments.count{it.date==today}
        val toCollect=packs.filter{it.active}.fold(0){acc,p -> acc + (p.total-p.paid).coerceAtLeast(0)} + sessionPacks.filter{it.active}.fold(0){acc,s -> acc + (s.cost-s.paid).coerceAtLeast(0)}
        val stats=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(0,0,0,dp(10))}
        fun stat(value:String,label:String):View=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(6),dp(8),dp(6),dp(8));background=roundedSurface(Color.WHITE,16,Color.rgb(230,232,236),1)
            addView(TextView(this@MainActivity).apply{text=value;textSize=19f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(28,31,35));gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,dp(28)))
            addView(TextView(this@MainActivity).apply{text=label;textSize=10.5f;setTextColor(Color.rgb(105,108,114));gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,dp(22))) }
        stats.addView(stat(activeClients.toString(),"CLIENTI ATTIVI"),LinearLayout.LayoutParams(0,dp(58),1f).apply{setMargins(0,0,dp(4),0)})
        stats.addView(stat(todayAppointments.toString(),"SEDUTE OGGI"),LinearLayout.LayoutParams(0,dp(58),1f).apply{setMargins(dp(2),0,dp(2),0)})
        stats.addView(stat("€$toCollect","DA INCASSARE"),LinearLayout.LayoutParams(0,dp(58),1f).apply{setMargins(dp(4),0,0,0)})
        list.addView(stats)
        val groups=listOf(
            Triple("SCADUTI",Color.rgb(210,45,45),items.filter{statusFor(it,ratesFor(it),dueDates(it)).label=="SCADUTA"}),
            Triple("IN SCADENZA",Color.rgb(220,160,20),items.filter{statusFor(it,ratesFor(it),dueDates(it)).label=="IN SCADENZA"}),
            Triple("IN REGOLA",Color.rgb(35,150,70),items.filter{statusFor(it,ratesFor(it),dueDates(it)).label=="IN REGOLA"})
        )
        val sessionGroups=listOf(
            Triple("SCADUTI",Color.rgb(210,45,45),sessionItems.filter{sessionStatus(it).label in setOf("SCADUTA","DA PAGARE")}),
            Triple("IN SCADENZA",Color.rgb(220,160,20),sessionItems.filter{sessionStatus(it).label=="IN SCADENZA"}),
            Triple("IN REGOLA",Color.rgb(35,150,70),sessionItems.filter{sessionStatus(it).label=="IN REGOLA"})
        )
        groups.indices.forEach{idx->
            val clients=groups[idx].third
            val sessions=sessionGroups[idx].third
            if(clients.isEmpty()&&sessions.isEmpty())return@forEach
            val label=groups[idx].first;val color=groups[idx].second
            val section=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;background=appGlassSurface(Color.WHITE,18,Color.rgb(218,228,239),1)}
            val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;isClickable=true;isFocusable=true;setPadding(dp(12),dp(4),dp(12),dp(4))}
            header.addView(TextView(this).apply{text="●";textSize=18f;setTextColor(color);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(28),dp(48)))
            val totalCount=clients.size+sessions.size
            header.addView(TextView(this).apply{text="$label ($totalCount)";textSize=17f;setTextColor(Color.rgb(35,35,35));gravity=Gravity.CENTER_VERTICAL;setPadding(dp(8),0,0,0)},LinearLayout.LayoutParams(0,dp(48),1f))
            val arrow=TextView(this).apply{text="▾";textSize=20f;setTextColor(Color.DKGRAY);gravity=Gravity.CENTER}
            header.addView(arrow,LinearLayout.LayoutParams(dp(36),dp(48)));section.addView(header)
            val sectionHasExpandedClient = clients.any{expandedClients.contains(identityKey(it.name))} || sessions.any{expandedClients.contains(identityKey(it.name))}
            val clientsBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=if(sectionHasExpandedClient)View.VISIBLE else View.GONE;setPadding(dp(8),0,dp(8),dp(4))}
            clients.forEach{card(it,clientsBox)};sessions.forEach{sessionCard(it,clientsBox)}
            section.addView(clientsBox)
            arrow.text=if(sectionHasExpandedClient)"▴" else "▾"
            header.setOnClickListener{val open=clientsBox.visibility!=View.VISIBLE;clientsBox.visibility=if(open)View.VISIBLE else View.GONE;arrow.text=if(open)"▴" else "▾"}
            list.addView(section,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})
        }
    }

    private fun card(p:Pack,parent:ViewGroup=list){
        val rates=ratesFor(p);val dates=dueDates(p);val status=statusFor(p,rates,dates)
        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(4),dp(10),dp(4));background=appGlassSurface(Color.WHITE,18,Color.rgb(218,228,239),1)}
        val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;isClickable=true;isFocusable=true;setPadding(dp(2),0,0,0)}
        val nameView=TextView(this).apply{text=displaySurnameFirst(p.name);textSize=17.5f;setTextColor(Color.rgb(20,20,20));gravity=Gravity.CENTER_VERTICAL;maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END}
        header.addView(nameView,LinearLayout.LayoutParams(0,dp(48),1f))
        val menu=menuIconButtonStyle().apply{setOnClickListener{packageInfoDialog(p)}}
        header.addView(menu,LinearLayout.LayoutParams(dp(38),dp(40)).apply{setMargins(dp(6),0,dp(6),0)})
        header.addView(TextView(this).apply{text="●";textSize=18f;setTextColor(status.color);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(26),dp(44)))
        card.addView(header)

        val isExpanded=expandedClients.contains(identityKey(p.name))
        val details=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=if(isExpanded)View.VISIBLE else View.GONE;setPadding(dp(2),dp(4),dp(2),dp(2))}
        details.addView(TextView(this).apply{text="${p.packageType} • ${p.sessionTotal} sedute • Partenza: ${p.start.format(fmt)}    Totale: €${p.total}";textSize=14f;setTextColor(Color.DKGRAY);setPadding(0,dp(2),0,dp(8))})
        for(i in rates.indices){
            val isPaid=p.paid>=rates.take(i+1).sum();val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
            val suffix = if(isPaid) " ✓ pagata" else if(i==p.paidRateIndex(rates)) " • parziale €${p.paid-rates.take(i).sum()}" else ""
            row.addView(TextView(this).apply{this.text="Rata ${i+1}: €${rates[i]} • ${dates[i].format(fmt)}$suffix";textSize=15f;setTextColor(Color.rgb(30,30,30));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,dp(48),1f))
            if(!isPaid){
                if(i==p.paidRateIndex(rates)) row.addView(paymentButtonStyle().apply{setOnClickListener{
                    val alreadyPaidOnCurrent=(p.paid-rates.take(i).sum()).coerceAtLeast(0)
                    val remainingToPay=(rates[i]-alreadyPaidOnCurrent).coerceAtLeast(0)
                    if(remainingToPay>0) confirmPaymentDialog(p,i,remainingToPay)
                }},LinearLayout.LayoutParams(dp(72),dp(40)))
                row.addView(editIconButtonStyle().apply{setOnClickListener{paymentOptionsDialog(p,i)}},LinearLayout.LayoutParams(dp(44),dp(40)))
            }
            details.addView(row)
        }
        card.addView(details)
        header.setOnClickListener{val open=details.visibility!=View.VISIBLE;details.visibility=if(open)View.VISIBLE else View.GONE;if(open)expandedClients.add(identityKey(p.name)) else expandedClients.remove(identityKey(p.name))}
        parent.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})
    }

    private fun programmingDetailDialog(s:SessionPack){
        val now=LocalDateTime.now()
        val done=sessionsForSessionPack(s,LocalDate.now())
        val doneCount=done.size
        val future=appointments.filter{it.sessionPackId==s.id && it.date.isAfter(LocalDate.now())}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        val futureCount=future.size
        val remaining=(s.totalSessions-sessionBooked(s)).coerceAtLeast(0)
        val text=summaryForSessionPack(s)
        showProgrammingDetail(
            title="Programmazione",
            name=s.name,
            subtitle="Pacchetto a sedute • ${s.totalSessions} sedute",
            stats=listOf("$doneCount" to "EFFETTUATE","$remaining" to "RIMASTE","$futureCount" to "PRENOTATE"),
            sections=buildList{
                add("Sedute effettuate" to done.map{"${it.date.format(fmt)}  •  ${it.time}  •  ${typeLabel(it.type)}"})
                add("Prossimi appuntamenti" to future.map{"${it.date.format(fmt)}  •  ${it.time}  •  ${typeLabel(it.type)}"})
            },
            shareText=text
        )
    }

    private fun programmingDetailDialog(p:Pack){
        val today=LocalDate.now()
        val end=p.start.plusWeeks(12).minusDays(1)
        val done=sessionsForPack(p,today)
        val future=appointments.filter{identityKey(it.name)==identityKey(p.name)&&it.date.isAfter(today)&&!it.date.isAfter(end)&&!it.date.isBefore(p.start)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        val scheduled=appointments.count{identityKey(it.name)==identityKey(p.name)&&!it.date.isBefore(p.start)&&!it.date.isAfter(end)}
        val remaining=(p.sessionTotal-scheduled).coerceAtLeast(0)
        val recoveries=recoveriesForPack(p)
        val usedRecoveries=appointments.filter{it.recovery&&identityKey(it.name)==identityKey(p.name)&&!it.date.isBefore(p.start)&&!it.date.isAfter(end)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        val text=summaryForPack(p)
        showProgrammingDetail(
            title="Programmazione",
            name=p.name,
            subtitle="${p.packageType} • ${p.sessionTotal} sedute • 12 settimane",
            stats=listOf("${done.size}" to "EFFETTUATE","$remaining" to "RIMASTE","$recoveries" to "RECUPERI"),
            sections=buildList{
                add("Sedute effettuate" to done.map{"${it.date.format(fmt)}  •  ${it.time}  •  ${typeLabel(it.type)}"})
                add("Recuperi" to if(usedRecoveries.isEmpty()) listOf("$recoveries recuperi disponibili") else usedRecoveries.map{"${it.date.format(fmt)}  •  ${it.time}  •  RECUPERO • ${typeLabel(it.type)}"} + if(recoveries>0) listOf("$recoveries recuperi disponibili") else emptyList())
                add("Prossimi appuntamenti" to future.map{"${it.date.format(fmt)}  •  ${it.time}  •  ${typeLabel(it.type)}"})
            },
            shareText=text
        )
    }

    private fun showProgrammingDetail(title:String,name:String,subtitle:String,stats:List<Pair<String,String>>,sections:List<Pair<String,List<String>>>,shareText:String){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),0,dp(14),dp(10))}
        val scroll=ScrollView(this).apply{isFillViewport=true;addView(root)}
        val head=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(14),dp(12),dp(14),dp(10));background=roundedSurface(Color.rgb(247,249,252),20,Color.rgb(228,232,238),1)}
        val initials=displaySurnameFirst(name).split(" ").filter{it.isNotBlank()}.take(2).joinToString(""){it.first().uppercase()}
        head.addView(TextView(this).apply{text=initials;textSize=18f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(20,70,130));background=roundedSurface(Color.rgb(230,240,252),28)},LinearLayout.LayoutParams(dp(54),dp(54)))
        head.addView(TextView(this).apply{text=displaySurnameFirst(name);textSize=20f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(25,28,32));setPadding(0,dp(7),0,0)},LinearLayout.LayoutParams(-1,dp(34)))
        head.addView(TextView(this).apply{text=subtitle;textSize=13f;gravity=Gravity.CENTER;setTextColor(Color.rgb(85,90,98))},LinearLayout.LayoutParams(-1,dp(24)))
        root.addView(head,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(8),0,dp(10))})

        val statRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        stats.forEachIndexed{index,(value,label)->
            val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(3),dp(8),dp(3),dp(8));background=roundedSurface(Color.WHITE,16,Color.rgb(230,233,238),1)}
            card.addView(TextView(this).apply{text=value;textSize=17f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(25,30,38))},LinearLayout.LayoutParams(-1,dp(27)))
            card.addView(TextView(this).apply{text=label;textSize=9.5f;gravity=Gravity.CENTER;setTextColor(Color.rgb(85,90,98));maxLines=2},LinearLayout.LayoutParams(-1,dp(30)))
            statRow.addView(card,LinearLayout.LayoutParams(0,dp(74),1f).apply{setMargins(if(index==0)0 else dp(2),0,if(index==stats.lastIndex)0 else dp(2),0)})
        }
        root.addView(statRow)

        sections.forEach{(heading,items)->
            val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(10),dp(14),dp(10));background=roundedSurface(Color.WHITE,18,Color.rgb(230,233,238),1)}
            card.addView(TextView(this).apply{text=heading;textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32))},LinearLayout.LayoutParams(-1,dp(30)))
            if(items.isEmpty()) card.addView(TextView(this).apply{text="Nessuna informazione";textSize=13f;setTextColor(Color.rgb(100,104,110));setPadding(0,dp(3),0,dp(3))})
            else items.forEach{item->card.addView(TextView(this).apply{text=item;textSize=13f;setTextColor(Color.rgb(55,59,65));setPadding(0,dp(4),0,dp(4))})}
            root.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(8),0,0)})
        }
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(10),0,dp(2))}
        val copy=Button(this).apply{text="📋 Copia testo";setAllCaps(false);textSize=12f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(Color.rgb(15,95,180));background=roundedSurface(Color.rgb(238,246,255),16,Color.rgb(190,218,248),1);setOnClickListener{val cb=getSystemService(CLIPBOARD_SERVICE) as ClipboardManager;cb.setPrimaryClip(ClipData.newPlainText("Programmazione $name",shareText));Toast.makeText(this@MainActivity,"Testo copiato. Puoi incollarlo su WhatsApp.",Toast.LENGTH_SHORT).show()}}
        val wa=Button(this).apply{text="WhatsApp";setAllCaps(false);textSize=12f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(Color.WHITE);background=roundedSurface(Color.rgb(25,155,100),16,Color.rgb(25,155,100),1);setOnClickListener{val intent=Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,shareText)};try{intent.setPackage("com.whatsapp");startActivity(intent)}catch(_:Exception){startActivity(Intent.createChooser(intent,"Invia programmazione"))}}}
        actions.addView(copy,LinearLayout.LayoutParams(0,dp(46),1f).apply{setMargins(0,0,dp(4),0)})
        actions.addView(wa,LinearLayout.LayoutParams(0,dp(46),1f).apply{setMargins(dp(4),0,0,0)})
        root.addView(actions)
        lateinit var dialog:AlertDialog
        val back=Button(this).apply{text="‹  Indietro";setAllCaps(false);textSize=12f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(Color.rgb(15,95,180));background=liquidInteractiveSurface(Color.rgb(238,246,255),16,Color.rgb(190,218,248),1);applyLiquidControlDepth(this);setOnClickListener{dialog.dismiss()}}
        root.addView(back,LinearLayout.LayoutParams(-1,dp(46)).apply{setMargins(0,dp(10),0,dp(2))})
        val dialogHeader=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),dp(2),dp(10),dp(2))}
        val topBack=TextView(this).apply{text="‹";textSize=32f;gravity=Gravity.CENTER;setTextColor(Color.rgb(25,95,175));setPadding(0,0,0,dp(3));setOnClickListener{dialog.dismiss()}}
        dialogHeader.addView(topBack,LinearLayout.LayoutParams(dp(44),dp(48)))
        dialogHeader.addView(TextView(this).apply{text=title;textSize=20f;setTypeface(null,android.graphics.Typeface.NORMAL);gravity=Gravity.CENTER;setTextColor(Color.rgb(25,28,32))},LinearLayout.LayoutParams(0,dp(48),1f))
        dialogHeader.addView(Space(this),LinearLayout.LayoutParams(dp(44),dp(48)))
        dialog=AlertDialog.Builder(this).setCustomTitle(dialogHeader).setView(scroll).create()
        styleModernCoachDialog(dialog)
        dialog.show()
    }

    private fun packageInfoDialog(p:Pack){
        val rates=ratesFor(p)
        val dates=dueDates(p)
        val status=statusFor(p,rates,dates)
        val expected=p.sessionTotal
        val done=sessionsForPack(p,LocalDate.now()).size
        val recoveries=recoveriesForPack(p)
        val scheduled=appointments.count {
            identityKey(it.name)==identityKey(p.name) &&
            !it.date.isBefore(p.start) && !it.date.isAfter(p.start.plusWeeks(12).minusDays(1))
        }
        val remaining=(expected-scheduled).coerceAtLeast(0)

        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),0,dp(14),dp(10))}
        val scroll=ScrollView(this).apply{isFillViewport=true;addView(root)}

        val client=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(10),dp(8),dp(10));background=roundedSurface(Color.rgb(247,249,252),20,Color.rgb(228,232,238),1)}
        val initials=displaySurnameFirst(p.name).split(" ").filter{it.isNotBlank()}.take(2).joinToString(""){it.first().uppercase()}
        client.addView(TextView(this).apply{text=initials;textSize=18f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(20,70,130));background=roundedSurface(Color.rgb(230,240,252),28);},LinearLayout.LayoutParams(dp(52),dp(52)))
        val clientText=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
        clientText.addView(TextView(this@MainActivity).apply{text=displaySurnameFirst(p.name);textSize=18f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32))})
        clientText.addView(TextView(this@MainActivity).apply{text="●  ${status.label}";textSize=13f;setTextColor(status.color);setPadding(0,dp(3),0,0)})
        client.addView(clientText,LinearLayout.LayoutParams(0,-2,1f))
        root.addView(client,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(8),0,dp(10))})

        val stats=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        fun stat(value:String,label:String):View=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(4),dp(7),dp(4),dp(7));background=roundedSurface(Color.WHITE,16,Color.rgb(230,233,238),1)
            addView(TextView(this@MainActivity).apply{text=value;textSize=17f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,30,38));gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,dp(27)))
            addView(TextView(this@MainActivity).apply{text=label;textSize=9.5f;setTextColor(Color.rgb(85,90,98));gravity=Gravity.CENTER;maxLines=2},LinearLayout.LayoutParams(-1,dp(30))) }
        stats.addView(stat("$expected","SEDUTE TOTALI"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(0,0,dp(4),0)})
        stats.addView(stat("$remaining","SEDUTE RIMASTE"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(dp(2),0,dp(2),0)})
        stats.addView(stat("$recoveries","RECUPERI"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(dp(2),0,dp(2),0)})
        stats.addView(stat("€${p.total}","TOTALE PACCHETTO"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(dp(4),0,0,0)})
        root.addView(stats)

        val info=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(8),dp(14),dp(8));background=roundedSurface(Color.WHITE,18,Color.rgb(230,233,238),1)}
        fun infoRow(label:String,value:String){val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(7),0,dp(7))};r.addView(TextView(this@MainActivity).apply{text=label;textSize=13f;setTextColor(Color.rgb(85,90,98))},LinearLayout.LayoutParams(0,dp(34),1f));r.addView(TextView(this@MainActivity).apply{text=value;textSize=13.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,40,48));gravity=Gravity.CENTER_VERTICAL});info.addView(r)}
        infoRow("Tipo pacchetto",p.packageType.replace("PERSONALIZZATO","Personalizzato"))
        infoRow("Data di inizio",p.start.format(fmt))
        infoRow("Importo totale","€${p.total}")
        infoRow("Pagato","€${p.paid}")
        infoRow("Stato","${status.label}")
        root.addView(info,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(10),0,dp(14))})

        val rateTitle=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        rateTitle.addView(TextView(this).apply{text="Rate di pagamento";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32))},LinearLayout.LayoutParams(0,dp(42),1f))
        root.addView(rateTitle)
        for(i in rates.indices){
            val isPaid=p.paid>=rates.take(i+1).sum()
            val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),dp(5),dp(6),dp(5));background=roundedSurface(Color.WHITE,16,Color.rgb(230,233,238),1)}
            r.addView(TextView(this).apply{text="${i+1}";textSize=13f;gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);background=roundedSurface(Color.rgb(242,245,249),22);setTextColor(Color.rgb(40,45,52))},LinearLayout.LayoutParams(dp(34),dp(40)))
            r.addView(TextView(this).apply{this.text="€${rates[i]}\n${dates[i].format(fmt)}${if(isPaid)" • ✓ Pagata" else ""}";textSize=13.5f;setTextColor(Color.rgb(35,40,48));setPadding(dp(10),0,0,0)},LinearLayout.LayoutParams(0,dp(52),1f))
            if(!isPaid&&i==p.paidRateIndex(rates)) r.addView(paymentButtonStyle().apply{setOnClickListener{val already=(p.paid-rates.take(i).sum()).coerceAtLeast(0);val amount=(rates[i]-already).coerceAtLeast(0);if(amount>0) confirmPaymentDialog(p,i,amount)}},LinearLayout.LayoutParams(dp(68),dp(40)))
            r.addView(editIconButtonStyle().apply{setOnClickListener{paymentOptionsDialog(p,i)}},LinearLayout.LayoutParams(dp(40),dp(40)).apply{setMargins(dp(5),0,0,0)})
            root.addView(r,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(4),0,dp(4))})
        }

        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(12),0,dp(4))}
        fun actionButton(label:String,accent:Int,bg:Int,click:()->Unit)=Button(this).apply{text=label;setAllCaps(false);textSize=11.5f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(accent);background=liquidInteractiveSurface(bg,18,Color.rgb(205,220,238),1);applyLiquidControlDepth(this);setOnClickListener{click()}}
        actions.addView(actionButton("✓ Segna tutto pagato",Color.rgb(15,95,180),Color.rgb(238,246,255)){
            val remainingToPay=(p.total-p.paid).coerceAtLeast(0)
            if(remainingToPay<=0){
                Toast.makeText(this@MainActivity,"Tutte le rate risultano già pagate.",Toast.LENGTH_SHORT).show()
                return@actionButton
            }
            val (paymentDialog,outer,body)=packActionDialogBase("Conferma pagamento","✓",Color.rgb(0,145,112),Color.rgb(205,244,233),Color.rgb(248,255,252))
            body.addView(dialogBodyText("Vuoi segnare come pagate tutte le rate del pacchetto?"))
            body.addView(dialogInfoCard("≋","Importo ancora da pagare","€$remainingToPay",Color.rgb(0,145,112),Color.rgb(224,248,241)),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,dp(10))})
            body.addView(LinearLayout(this@MainActivity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),dp(9),dp(10),dp(9));background=roundedSurface(Color.rgb(224,248,241),18)
                addView(TextView(this@MainActivity).apply{text="i";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(0,145,112));background=roundedSurface(Color.WHITE,24)},LinearLayout.LayoutParams(dp(34),dp(34)))
                addView(TextView(this@MainActivity).apply{text="Tutte le rate del pacchetto verranno segnate come pagate.";textSize=13.5f;setTextColor(Color.rgb(45,70,65));setPadding(dp(10),0,0,0)},LinearLayout.LayoutParams(0,dp(34),1f))
            },LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(14))})
            val row=LinearLayout(this@MainActivity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            row.addView(dialogButton("Annulla",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(210,220,232)){paymentDialog.dismiss()},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(4),0)})
            row.addView(dialogButton("Conferma",Color.WHITE,Color.rgb(0,145,112),Color.rgb(0,145,112)){
                p.paid=p.total;saveData();paymentDialog.dismiss();activePackageDialog?.dismiss();activePackageDialog=null;render();packageInfoDialog(p);Toast.makeText(this@MainActivity,"Tutte le rate sono state segnate come pagate.",Toast.LENGTH_SHORT).show()
            },LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(4),0,0,0)})
            body.addView(row)
            paymentDialog.show()
            paymentDialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
        },LinearLayout.LayoutParams(0,dp(46),1f).apply{setMargins(0,0,dp(4),0)})
        actions.addView(actionButton("✎ Modifica",Color.rgb(20,91,165),Color.rgb(238,246,255)){editPackDialog(p)},LinearLayout.LayoutParams(0,dp(46),0.7f).apply{setMargins(dp(2),0,dp(2),0)})
        actions.addView(actionButton("⏹ Termina",Color.rgb(120,80,25),Color.rgb(255,248,232)){terminatePackDialog(p)},LinearLayout.LayoutParams(0,dp(46),0.7f).apply{setMargins(dp(2),0,dp(2),0)})
        actions.addView(actionButton("🗑 Elimina",Color.rgb(200,45,45),Color.rgb(255,244,244)){confirmDeletePack(p)},LinearLayout.LayoutParams(0,dp(46),0.7f).apply{setMargins(dp(4),0,0,0)})
        root.addView(actions)
        root.addView(Button(this).apply{text="🗂 Storico cliente";setAllCaps(false);textSize=13f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(Color.rgb(15,95,180));background=liquidInteractiveSurface(Color.rgb(238,246,255),18,Color.rgb(205,220,238),1);applyLiquidControlDepth(this);setOnClickListener{showClientHistory(p.name)}},LinearLayout.LayoutParams(-1,dp(44)).apply{setMargins(0,dp(4),0,dp(2))})
        val programming=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(10),dp(8),dp(10));background=roundedSurface(Color.rgb(238,246,255),20,Color.rgb(190,218,248),1);isClickable=true;isFocusable=true}
        val programIcon=TextView(this).apply{text="📅";textSize=21f;gravity=Gravity.CENTER;background=roundedSurface(Color.WHITE,18,Color.rgb(205,224,246),1)}
        programming.addView(programIcon,LinearLayout.LayoutParams(dp(44),dp(44)))
        val programBody=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),0,dp(3),0)}
        programBody.addView(TextView(this).apply{text="Programmazione";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32));setSingleLine(true)},LinearLayout.LayoutParams(-1,dp(24)))
        val programStats=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        fun programStat(value:String,label:String)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL;addView(TextView(this@MainActivity).apply{text=value;textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,75,125));setSingleLine(true)},LinearLayout.LayoutParams(-1,dp(19)));addView(TextView(this@MainActivity).apply{text=label;textSize=8.5f;setTextColor(Color.rgb(85,98,115));setSingleLine(true)},LinearLayout.LayoutParams(-1,dp(16)))}
        programStats.addView(programStat("$scheduled","TOTALI"),LinearLayout.LayoutParams(0,dp(35),1f))
        programStats.addView(programStat("$done","EFFETTUATI"),LinearLayout.LayoutParams(0,dp(35),1f))
        programStats.addView(programStat("$remaining","DISPONIBILI"),LinearLayout.LayoutParams(0,dp(35),1f))
        programBody.addView(programStats,LinearLayout.LayoutParams(-1,dp(35)))
        programming.addView(programBody,LinearLayout.LayoutParams(0,dp(59),1f))
        programming.addView(TextView(this).apply{text="›";textSize=28f;gravity=Gravity.CENTER;setTextColor(Color.rgb(15,95,180))},LinearLayout.LayoutParams(dp(28),dp(52)))
        programming.setOnClickListener{programmingDetailDialog(p)}
        root.addView(programming,LinearLayout.LayoutParams(-1,dp(76)).apply{setMargins(0,dp(8),0,dp(4))})

        activePackageDialog?.dismiss()
        lateinit var packageDialog:AlertDialog
        val dialogHeader=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;setPadding(dp(10),dp(2),dp(10),dp(2))}
        dialogHeader.addView(TextView(this).apply{text="Gestione pacchetto";textSize=20f;setTypeface(null,android.graphics.Typeface.NORMAL);gravity=Gravity.CENTER;setTextColor(Color.rgb(25,28,32));setSingleLine(true)},LinearLayout.LayoutParams(-1,dp(46)))
        val backBottom=Button(this).apply{text="‹  Indietro";setAllCaps(false);textSize=12f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(Color.rgb(15,95,180));background=liquidInteractiveSurface(Color.rgb(238,246,255),16,Color.rgb(190,218,248),1);applyLiquidControlDepth(this)}
        root.addView(backBottom,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(10),0,dp(2))})
        val dialog=AlertDialog.Builder(this).setCustomTitle(dialogHeader).setView(scroll).create()
        packageDialog=dialog
        backBottom.setOnClickListener{packageDialog.dismiss()}
        activePackageDialog=dialog
        styleOneUiDialog(dialog)
        dialog.setOnDismissListener{removePopupBackdropDialog(dialog);if(activePackageDialog===dialog) activePackageDialog=null}
        dialog.show()
    }

    private fun appointmentHasPassed(a:Appointment,now:LocalDateTime=LocalDateTime.now()):Boolean{
        val t=runCatching{LocalTime.parse(a.time,timeFmt)}.getOrNull()?:LocalTime.MIDNIGHT
        return LocalDateTime.of(a.date,t).isBefore(now)
    }

    private fun sessionAppointments(s:SessionPack):List<Appointment>{
        val key=identityKey(s.name)
        return appointments.filter{
            (it.sessionPackId==s.id || (it.sessionPackId==0L && identityKey(it.name)==key)) &&
            !it.date.isBefore(s.start)
        }.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
    }

    private fun sessionBooked(s:SessionPack):Int=sessionAppointments(s).size
    private fun sessionUsed(s:SessionPack,now:LocalDateTime=LocalDateTime.now()):Int=sessionAppointments(s).count{appointmentHasPassed(it,now)}
    private fun sessionStatus(s:SessionPack):PackStatus{
        val booked=sessionBooked(s)
        val remaining=(s.totalSessions-booked).coerceAtLeast(0)
        return when{
            remaining<=0->PackStatus("SCADUTA",Color.rgb(210,45,45))
            s.paid<s.cost->PackStatus("DA PAGARE",Color.rgb(210,45,45))
            remaining<=2->PackStatus("IN SCADENZA",Color.rgb(220,160,20))
            else->PackStatus("IN REGOLA",Color.rgb(35,150,70))
        }
    }
    private fun activeSessionPackFor(name:String):SessionPack?=sessionPacks.filter{it.active&&identityKey(it.name)==identityKey(name)&&sessionBooked(it)<it.totalSessions}.maxByOrNull{it.start}

    private fun sessionCard(s:SessionPack,parent:ViewGroup=list){
        val used=sessionUsed(s);val booked=sessionBooked(s);val remaining=(s.totalSessions-booked).coerceAtLeast(0);val status=sessionStatus(s)
        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(4),dp(10),dp(4));background=appGlassSurface(Color.WHITE,18,Color.rgb(218,228,239),1)}
        val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;isClickable=true;isFocusable=true;setPadding(dp(2),0,0,0)}
        val name=TextView(this).apply{text=displaySurnameFirst(s.name);textSize=17.5f;setTextColor(Color.rgb(20,20,20));gravity=Gravity.CENTER_VERTICAL;maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END}
        header.addView(name,LinearLayout.LayoutParams(0,dp(48),1f))
        header.addView(TextView(this).apply{text="$remaining rimaste";textSize=13f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(status.color);gravity=Gravity.CENTER_VERTICAL;maxLines=1},LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,dp(44)))
        val menu=menuIconButtonStyle().apply{setOnClickListener{sessionInfoDialog(s)}}
        header.addView(menu,LinearLayout.LayoutParams(dp(38),dp(40)).apply{setMargins(dp(6),0,dp(6),0)})
        header.addView(TextView(this).apply{text="●";textSize=18f;setTextColor(status.color);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(26),dp(44)))
        card.addView(header)

        val details=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE;setPadding(dp(4),dp(4),0,dp(2))}
        details.addView(TextView(this).apply{text="Pacchetto sedute • €${s.cost} • $used effettuate • $booked prenotate";textSize=14f;setTextColor(Color.rgb(75,78,84));setPadding(0,0,0,dp(4))})
        val dates=appointments.filter{it.sessionPackId==s.id}.sortedBy{it.date}.joinToString(" • " ){it.date.format(fmt)}
        if(dates.isNotEmpty())details.addView(TextView(this).apply{text="Date: $dates";textSize=12.5f;setTextColor(Color.DKGRAY);setPadding(0,0,0,dp(5))})
        details.addView(TextView(this).apply{
            text="ALTRE INFORMAZIONI"
            textSize=12.5f
            setTypeface(null,android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(20,91,165))
            gravity=Gravity.CENTER
            isClickable=true
            isFocusable=true
            background=roundedSurface(Color.rgb(238,246,255),16,Color.rgb(190,218,248),1)
            setOnClickListener{sessionOptionsDialog(s)}
        },LinearLayout.LayoutParams(-1,dp(40)).apply{setMargins(0,dp(2),0,dp(2))})
        card.addView(details)
        header.setOnClickListener{val open=details.visibility!=View.VISIBLE;details.visibility=if(open)View.VISIBLE else View.GONE;if(open)expandedClients.add(identityKey(s.name)) else expandedClients.remove(identityKey(s.name))}
        parent.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})
    }

    private fun showHomeSortDialog(){
        val (dialog,outer,body)=packActionDialogBase("Ordina clienti","☷",Color.rgb(20,91,165),Color.rgb(224,238,255),Color.WHITE)
        val labels=arrayOf("Stato","Nome A-Z","Nome Z-A")
        val icons=arrayOf("☷","A↕Z","Z↕A")
        labels.forEachIndexed{index,label->
            val option=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),0,dp(12),0);background=roundedSurface(if(homeSortMode==index)Color.rgb(238,246,255) else Color.WHITE,18,if(homeSortMode==index)Color.rgb(190,218,248) else Color.rgb(228,232,238),1);isClickable=true}
            option.addView(TextView(this).apply{text=icons[index];textSize=20f;gravity=Gravity.CENTER;setTextColor(Color.rgb(20,91,165))},LinearLayout.LayoutParams(dp(42),dp(48)))
            option.addView(TextView(this).apply{text=label;textSize=15.5f;setTypeface(null,if(homeSortMode==index)android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL);setTextColor(Color.rgb(30,38,50));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,dp(48),1f))
            option.addView(TextView(this).apply{text=if(homeSortMode==index)"●" else "○";textSize=22f;gravity=Gravity.CENTER;setTextColor(if(homeSortMode==index)Color.rgb(25,105,210) else Color.rgb(125,132,142))},LinearLayout.LayoutParams(dp(34),dp(48)))
            option.setOnClickListener{homeSortMode=index;dialog.dismiss();render()}
            body.addView(option,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,if(index==0)0 else dp(7),0,0)})
        }
        body.addView(dialogButton("✓  Applica",Color.rgb(30,83,145),Color.rgb(235,244,255),Color.rgb(205,224,248)){dialog.dismiss();render()},LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(14),0,0)})
        dialog.show()
    }

    private fun sessionInfoDialog(s:SessionPack){
        lateinit var dialog: AlertDialog
        val now=LocalDateTime.now()
        val used=sessionUsed(s,now)
        val booked=sessionBooked(s)
        val remaining=(s.totalSessions-booked).coerceAtLeast(0)
        val status=sessionStatus(s)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),0,dp(16),dp(10))}
        val scroll=ScrollView(this).apply{isFillViewport=true;addView(root)}

        val client=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(14),dp(14),dp(14),dp(12));background=roundedSurface(Color.rgb(247,249,252),20,Color.rgb(228,232,238),1)}
        val initials=displaySurnameFirst(s.name).split(" ").filter{it.isNotBlank()}.take(2).joinToString(""){it.first().uppercase()}
        client.addView(TextView(this).apply{text=initials;textSize=19f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(20,70,130));background=roundedSurface(Color.rgb(230,240,252),30)},LinearLayout.LayoutParams(dp(58),dp(58)))
        client.addView(TextView(this).apply{text=displaySurnameFirst(s.name);textSize=21f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32));gravity=Gravity.CENTER;setPadding(0,dp(8),0,0)},LinearLayout.LayoutParams(-1,dp(36)))
        client.addView(TextView(this).apply{text="●  ${status.label}";textSize=13.5f;setTextColor(status.color);gravity=Gravity.CENTER;setPadding(0,dp(2),0,0)},LinearLayout.LayoutParams(-1,dp(24)))
        root.addView(client,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(8),0,dp(12))})

        val stats=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        fun stat(value:String,label:String):View=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(3),dp(8),dp(3),dp(8));background=roundedSurface(Color.WHITE,16,Color.rgb(230,233,238),1)
            addView(TextView(this@MainActivity).apply{text=value;textSize=17f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,30,38));gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,dp(27)))
            addView(TextView(this@MainActivity).apply{text=label;textSize=9.5f;setTextColor(Color.rgb(85,90,98));gravity=Gravity.CENTER;maxLines=2},LinearLayout.LayoutParams(-1,dp(30)))}
        stats.addView(stat("${s.totalSessions}","SEDUTE TOTALI"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(0,0,dp(4),0)})
        stats.addView(stat("$remaining","SEDUTE RIMASTE"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(dp(2),0,dp(2),0)})
        stats.addView(stat("$used","EFFETTUATE"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(dp(2),0,dp(2),0)})
        stats.addView(stat("€${s.cost}","TOTALE PACCHETTO"),LinearLayout.LayoutParams(0,dp(76),1f).apply{setMargins(dp(4),0,0,0)})
        root.addView(stats)

        val info=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(10),dp(16),dp(10));background=roundedSurface(Color.WHITE,20,Color.rgb(224,229,236),1)}
        fun infoRow(label:String,value:String){val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(7),0,dp(7))};r.addView(TextView(this@MainActivity).apply{text=label;textSize=13f;setTextColor(Color.rgb(85,90,98))},LinearLayout.LayoutParams(0,dp(34),1f));r.addView(TextView(this@MainActivity).apply{text=value;textSize=13.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,40,48));gravity=Gravity.CENTER_VERTICAL}) ;info.addView(r)}
        infoRow("Tipo pacchetto","PACCHETTO A SEDUTE")
        infoRow("Data di inizio",s.start.format(fmt))
        infoRow("Numero sedute","${s.totalSessions}")
        infoRow("Importo totale","€${s.cost}")
        infoRow("Pagamento",if(s.paid>=s.cost)"Saldato per intero" else "Da pagare • €${s.cost-s.paid}")
        infoRow("Stato",status.label)
        root.addView(info,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(12),0,dp(14))})

        val rates=sessionRatesFor(s)
        val paymentBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        rates.forEachIndexed{index,due->
            val paidBefore=rates.take(index).sum()
            val alreadyOnRate=(s.paid-paidBefore).coerceAtLeast(0)
            val isPaid=s.paid>=rates.take(index+1).sum()
            val remainingOnRate=(due-alreadyOnRate).coerceAtLeast(0)
            val date=s.start.plusDays((28L*index))
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),dp(8),dp(8),dp(8));background=roundedSurface(Color.WHITE,20,Color.rgb(226,231,238),1)}
            row.addView(TextView(this).apply{text=if(isPaid)"✓" else "€";textSize=18f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(if(isPaid)Color.rgb(20,150,95) else Color.rgb(210,45,45));background=roundedSurface(if(isPaid)Color.rgb(232,248,240) else Color.rgb(255,240,240),23)},LinearLayout.LayoutParams(dp(46),dp(46)))
            val details=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),0,dp(5),0)}
            val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            top.addView(TextView(this).apply{text="Rata ${index+1}/${rates.size}";textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,40,48));gravity=Gravity.CENTER_VERTICAL;setSingleLine(true)},LinearLayout.LayoutParams(0,dp(24),1f))
            top.addView(TextView(this).apply{text="€$due";textSize=14.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,40,48));gravity=Gravity.CENTER_VERTICAL;setSingleLine(true)},LinearLayout.LayoutParams(dp(58),dp(24)))
            details.addView(top)
            details.addView(TextView(this).apply{text="${date.format(fmt)}  •  ${if(isPaid)"Pagata" else if(alreadyOnRate>0)"Parziale • €$alreadyOnRate pagati" else "Da pagare • €$remainingOnRate"}";textSize=11.5f;setTextColor(if(isPaid)Color.rgb(20,125,85) else Color.rgb(92,98,108));gravity=Gravity.CENTER_VERTICAL;setSingleLine(true)},LinearLayout.LayoutParams(-1,dp(25)))
            row.addView(details,LinearLayout.LayoutParams(0,dp(54),1f))
            if(!isPaid && index==s.paidRateIndex(rates)){
                row.addView(paymentButtonStyle().apply{setOnClickListener{confirmSessionPaymentDialog(s,index,remainingOnRate,dialog)}},LinearLayout.LayoutParams(dp(68),dp(40)))
                row.addView(editIconButtonStyle().apply{setOnClickListener{sessionPaymentAmountDialog(s,index)}},LinearLayout.LayoutParams(dp(40),dp(40)).apply{setMargins(dp(4),0,0,0)})
            } else if(!isPaid){
                row.addView(TextView(this).apply{text=""},LinearLayout.LayoutParams(dp(112),dp(40)))
            }
            paymentBox.addView(row,LinearLayout.LayoutParams(-1,dp(70)).apply{setMargins(0,0,0,dp(7))})
        }
        root.addView(TextView(this).apply{text="💳  Pagamento";textSize=17f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,35,48));setPadding(dp(2),0,0,0)},LinearLayout.LayoutParams(-1,dp(38)).apply{setMargins(0,dp(2),0,dp(2))})
        root.addView(paymentBox,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})

        val programming=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(10),dp(8),dp(10));background=roundedSurface(Color.rgb(238,246,255),20,Color.rgb(190,218,248),1);isClickable=true;isFocusable=true}
        val programIcon=TextView(this).apply{text="📅";textSize=21f;gravity=Gravity.CENTER;background=roundedSurface(Color.WHITE,18,Color.rgb(205,224,246),1)}
        programming.addView(programIcon,LinearLayout.LayoutParams(dp(44),dp(44)))
        val programBody=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),0,dp(3),0)}
        programBody.addView(TextView(this).apply{text="Programmazione";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32));setSingleLine(true)},LinearLayout.LayoutParams(-1,dp(24)))
        val programStats=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        fun programStat(value:String,label:String)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL;addView(TextView(this@MainActivity).apply{text=value;textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,75,125));setSingleLine(true)},LinearLayout.LayoutParams(-1,dp(19)));addView(TextView(this@MainActivity).apply{text=label;textSize=8.5f;setTextColor(Color.rgb(85,98,115));setSingleLine(true)},LinearLayout.LayoutParams(-1,dp(16)))}
        programStats.addView(programStat("$booked","TOTALI"),LinearLayout.LayoutParams(0,dp(35),1f))
        programStats.addView(programStat("$used","EFFETTUATI"),LinearLayout.LayoutParams(0,dp(35),1f))
        programStats.addView(programStat("$remaining","DISPONIBILI"),LinearLayout.LayoutParams(0,dp(35),1f))
        programBody.addView(programStats,LinearLayout.LayoutParams(-1,dp(35)))
        programming.addView(programBody,LinearLayout.LayoutParams(0,dp(59),1f))
        programming.addView(TextView(this).apply{text="›";textSize=28f;gravity=Gravity.CENTER;setTextColor(Color.rgb(15,95,180))},LinearLayout.LayoutParams(dp(28),dp(52)))
        programming.setOnClickListener{programmingDetailDialog(s)}
        root.addView(programming,LinearLayout.LayoutParams(-1,dp(76)).apply{setMargins(0,0,0,dp(12))})

        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        fun actionButton(label:String,accent:Int,bg:Int,click:()->Unit)=Button(this).apply{text=label;setAllCaps(false);textSize=11.5f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(accent);background=liquidInteractiveSurface(bg,18,Color.rgb(205,220,238),1);applyLiquidControlDepth(this);setOnClickListener{click()}}
        actions.addView(actionButton("✎ Rinomina",Color.rgb(15,95,180),Color.rgb(238,246,255)){renameSessionPackDialog(s,dialog)},LinearLayout.LayoutParams(0,dp(46),1f).apply{setMargins(0,0,dp(4),0)})
        actions.addView(actionButton("⏹ Termina",Color.rgb(120,80,25),Color.rgb(255,248,232)){confirmTerminateSessionPack(s,dialog)},LinearLayout.LayoutParams(0,dp(46),1f).apply{setMargins(dp(2),0,dp(2),0)})
        actions.addView(actionButton("🗑 Elimina",Color.rgb(200,45,45),Color.rgb(255,244,244)){confirmDeleteSessionPack(s,dialog)},LinearLayout.LayoutParams(0,dp(46),0.9f).apply{setMargins(dp(4),0,0,0)})
        root.addView(actions,LinearLayout.LayoutParams(-1,dp(50)))
        val backBottom=Button(this).apply{text="‹  Indietro";setAllCaps(false);textSize=12f;minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(Color.rgb(15,95,180));background=liquidInteractiveSurface(Color.rgb(238,246,255),16,Color.rgb(190,218,248),1);applyLiquidControlDepth(this);setOnClickListener{dialog.dismiss()}}
        root.addView(backBottom,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(10),0,dp(2))})

        val dialogHeader=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;setPadding(dp(10),dp(2),dp(10),dp(2))}
        dialogHeader.addView(TextView(this).apply{text="Gestione pacchetto";textSize=20f;setTypeface(null,android.graphics.Typeface.NORMAL);gravity=Gravity.CENTER;setTextColor(Color.rgb(25,28,32));setSingleLine(true)},LinearLayout.LayoutParams(-1,dp(46)))
        dialog=AlertDialog.Builder(this).setCustomTitle(dialogHeader).setView(scroll).create()
        styleModernCoachDialog(dialog)
        dialog.show()
    }

    private fun sessionRatesFor(s:SessionPack):List<Int>{
        val c=s.customRates
        if(c!=null&&c.isNotEmpty()&&c.all{it>0}&&c.sum()==s.cost)return c.toList()
        return listOf(s.cost)
    }

    private fun saveSessionRates(s:SessionPack,rates:List<Int>){s.customRates=rates.toMutableList()}

    private fun SessionPack.paidRateIndex(rates:List<Int>):Int=rates.indices.firstOrNull{paid<rates.take(it+1).sum()}?:rates.size

    private fun registerSessionPayment(s:SessionPack,index:Int,paidNow:Int,sourceDialog:AlertDialog?=null){
        try{
            val rates=sessionRatesFor(s);val due=rates[index];require(paidNow>0);require(s.paid+paidNow<=s.cost)
            val paidBefore=rates.take(index).sum();val already=(s.paid-paidBefore).coerceAtLeast(0);val totalOnRate=already+paidNow
            val newRates=rates.toMutableList();s.paid+=paidNow
            if(totalOnRate<due && index==rates.lastIndex){
                // Keep the original installment schedule until the user confirms
                // creation of the new residual installment.
                saveData();sourceDialog?.dismiss();render();sessionInfoDialog(s)
                val residual=s.cost-s.paid
                if(residual>0)proposeResidualSessionRate(s,index,residual)
                return
            }
            if(totalOnRate>due){
                newRates[index]=totalOnRate
                val remainingCount=newRates.size-index-1
                if(remainingCount>0){
                    val remaining=s.cost-rates.take(index).sum()-totalOnRate;require(remaining>=0)
                    val base=remaining/remainingCount;val extra=remaining%remainingCount
                    for(j in index+1 until newRates.size)newRates[j]=base+if(j-index-1<extra)1 else 0
                } else require(totalOnRate==s.cost-rates.take(index).sum())
            }
            require(newRates.sum()==s.cost);saveSessionRates(s,newRates);saveData();sourceDialog?.dismiss();render();sessionInfoDialog(s)
            Toast.makeText(this,"Pagamento di €$paidNow registrato.",Toast.LENGTH_SHORT).show()
        }catch(_:Exception){Toast.makeText(this,"Importo non valido o superiore al totale residuo.",Toast.LENGTH_LONG).show()}
    }

    private fun confirmSessionPaymentDialog(s:SessionPack,index:Int,amount:Int,parentDialog:AlertDialog?=null){
        if(amount<=0)return
        val rates=sessionRatesFor(s)
        val date=s.start.plusDays(28L*index)
        val (dialog,outer,body)=packActionDialogBase(
            "Conferma pagamento",
            "✓",
            Color.rgb(0,145,112),
            Color.rgb(205,244,233),
            Color.rgb(248,255,252)
        )

        body.addView(dialogBodyText("Confermi il pagamento della rata ${index+1}?"))
        body.addView(dialogInfoCard(
            "€",
            "Importo rata",
            "€$amount",
            Color.rgb(0,145,112),
            Color.rgb(224,248,241)
        ),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,dp(8))})

        body.addView(dialogInfoCard(
            "▣",
            "Rata ${index+1} di ${rates.size}",
            "${date.format(fmt)}",
            Color.rgb(25,100,190),
            Color.rgb(235,244,255)
        ),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(14))})

        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        row.addView(dialogButton("Annulla",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(210,220,232)){dialog.dismiss()},
            LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(5),0)})
        row.addView(dialogButton("✓ Conferma",Color.WHITE,Color.rgb(0,145,112),Color.rgb(0,145,112)){
            dialog.dismiss()
            registerSessionPayment(s,index,amount,parentDialog)
        },LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(5),0,0,0)})
        body.addView(row)

        preparePopupBackdrop(dialog)
        dialog.setOnShowListener{popupBackdropCurrentDialog=dialog;dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28));applyPopupBackdropEffect(dialog);dialog.window?.setDimAmount(0.40f);dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)}
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun sessionPaymentAmountDialog(s:SessionPack,index:Int){
        val rates=sessionRatesFor(s)
        val due=rates[index]
        val paidBefore=rates.take(index).sum()
        val already=(s.paid-paidBefore).coerceAtLeast(0)
        val remaining=(due-already).coerceAtLeast(0)
        val (dialog,outer,body)=packActionDialogBase(
            "Modifica importo pagamento",
            "✎",
            Color.rgb(20,91,165),
            Color.rgb(224,238,255),
            Color.WHITE
        )

        body.addView(dialogBodyText("Rata ${index+1} di ${rates.size} • prevista €$due • da pagare €$remaining"))
        body.addView(dialogInfoCard(
            "ⓘ",
            "Inserisci l'importo da pagare",
            "L'importo previsto è €$due.",
            Color.rgb(25,100,190),
            Color.rgb(235,244,255)
        ),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,dp(12))})

        body.addView(TextView(this).apply{
            text="Nuovo importo"
            textSize=12.5f
            setTypeface(null,android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(82,87,94))
            setPadding(dp(2),0,0,dp(5))
        })

        val amount=modernEditText().apply{
            hint="Importo (€)"
            inputType=2
            setSingleLine(true)
            setText(remaining.toString())
            selectAll()
            textSize=16f
        }
        body.addView(amount,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(14))})

        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        row.addView(dialogButton("Annulla",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(210,220,232)){dialog.dismiss()},
            LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(5),0)})
        row.addView(dialogButton("✓ Conferma",Color.WHITE,Color.rgb(36,112,225),Color.rgb(36,112,225)){
            val value=amount.text.toString().trim().toIntOrNull()
            if(value==null||value<=0||s.paid+value>s.cost){
                Toast.makeText(this,"Importo non valido o superiore al totale residuo.",Toast.LENGTH_LONG).show()
            }else{
                dialog.dismiss()
                confirmSessionPaymentDialog(s,index,value)
            }
        },LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(5),0,0,0)})
        body.addView(row)

        preparePopupBackdrop(dialog)
        dialog.setOnShowListener{
            popupBackdropCurrentDialog=dialog
            dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
            applyPopupBackdropEffect(dialog)
            dialog.window?.setDimAmount(0.40f)
            dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
            amount.clearFocus()
        }
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun proposeResidualSessionRate(s:SessionPack,index:Int,residual:Int){
        if(residual<=0)return
        val next=index+2
        val dialog=buildResidualRateDialog(
            previousRate=index+1,
            dueAmount=sessionRatesFor(s)[index],
            alreadyPaid=(s.paid-sessionRatesFor(s).take(index).sum()).coerceAtLeast(0),
            residual=residual,
            nextRate=next,
            onCreate={
                val current=sessionRatesFor(s).toMutableList()
                val paidBefore=current.take(index).sum()
                val paidOnCurrent=(s.paid-paidBefore).coerceAtLeast(0)
                if(index in current.indices && paidOnCurrent>0 && paidOnCurrent<current[index]){
                    current[index]=paidOnCurrent
                    current.add(residual)
                    if(current.sum()==s.cost){
                        saveSessionRates(s,current);saveData();render();sessionInfoDialog(s)
                        Toast.makeText(this,"${next}ª rata creata: €$residual.",Toast.LENGTH_SHORT).show()
                    }
                }
            }
        )
        dialog.show()
    }

    private fun buildResidualRateDialog(previousRate:Int,dueAmount:Int,alreadyPaid:Int,residual:Int,nextRate:Int,onCreate:()->Unit):Dialog{
        val (dialog,outer,body)=packActionDialogBase(
            "Importo residuo",
            "◷",
            Color.rgb(225,135,0),
            Color.rgb(255,239,205),
            Color.WHITE
        )

        body.addView(dialogBodyText(
            "La rata ${previousRate} è stata pagata solo in parte."
        ))

        val stats=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(16),dp(12),dp(16),dp(12))
            background=roundedSurface(Color.rgb(235,244,255),20)
        }
        fun statRow(label:String,value:String,bold:Boolean=false,accent:Int=Color.rgb(25,55,100)):LinearLayout{
            return LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL
                gravity=Gravity.CENTER_VERTICAL
                addView(TextView(this@MainActivity).apply{
                    text=label;textSize=13.5f;setTextColor(Color.rgb(65,82,105))
                },LinearLayout.LayoutParams(0,-2,1f))
                addView(TextView(this@MainActivity).apply{
                    text=value;textSize=if(bold)17f else 14.5f
                    setTypeface(null,if(bold)android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
                    setTextColor(accent);gravity=Gravity.RIGHT
                })
            }
        }
        stats.addView(statRow("Importo totale rata","€$dueAmount"))
        stats.addView(statRow("Importo già pagato","€$alreadyPaid"),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(7),0,dp(7))})
        val divider=View(this).apply{setBackgroundColor(Color.rgb(205,220,240))}
        stats.addView(divider,LinearLayout.LayoutParams(-1,dp(1)))
        stats.addView(statRow("Importo residuo","€$residual",true,Color.rgb(25,100,190)),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(7),0,0)})
        body.addView(stats,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,dp(12))})

        body.addView(dialogInfoCard(
            "▣",
            "Nuova rata",
            "€$residual",
            Color.rgb(25,100,190),
            Color.rgb(235,244,255)
        ),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})

        body.addView(dialogBodyText(
            "Vuoi creare la ${nextRate}ª rata di €$residual con scadenza tra 28 giorni?"
        ).apply{setPadding(dp(6),0,dp(6),dp(10))})

        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        row.addView(dialogButton(
            "Non ora",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(210,220,232)
        ){dialog.dismiss()},LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(0,0,dp(5),0)})
        row.addView(dialogButton(
            "▣  Crea ${nextRate}ª rata",Color.WHITE,Color.rgb(36,112,225),Color.rgb(36,112,225)
        ){dialog.dismiss();onCreate()},LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(dp(5),0,0,0)})
        body.addView(row)

        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
        return dialog
    }

    private fun confirmTerminateSessionPack(s:SessionPack,source:AlertDialog){
        val future=appointments.filter{it.sessionPackId==s.id&&it.date.isAfter(LocalDate.now())}
        val (dialog,outer,body)=packActionDialogBase("Terminare il pacchetto?","✓",Color.rgb(205,120,0),Color.rgb(255,236,198),Color.rgb(255,252,246))
        body.addView(dialogBodyText("Il pacchetto di ${displaySurnameFirst(s.name)} verrà spostato nello storico e non sarà più considerato attivo."))
        body.addView(dialogInfoCard("▣","Appuntamenti futuri","${future.size}",Color.rgb(205,120,0),Color.rgb(255,241,213)),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,dp(10))})
        body.addView(TextView(this).apply{
            text=if(future.isEmpty()) "Non ci sono appuntamenti futuri da gestire." else "Puoi scegliere se mantenere gli appuntamenti futuri oppure eliminarli dal calendario."
            textSize=13.5f;gravity=Gravity.CENTER;setTextColor(Color.rgb(95,78,52));setLineSpacing(0f,1.05f);setPadding(dp(6),0,dp(6),dp(12))
        },LinearLayout.LayoutParams(-1,-2))
        if(future.isNotEmpty()){
            body.addView(dialogButton("Mantieni appuntamenti",Color.WHITE,Color.rgb(235,140,0),Color.rgb(235,140,0)){
                s.active=false;saveData();dialog.dismiss();source.dismiss();render();Toast.makeText(this,"Pacchetto terminato. Appuntamenti mantenuti.",Toast.LENGTH_SHORT).show()
            },LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,0,0,dp(8))})
            body.addView(dialogButton("Elimina futuri",Color.rgb(190,105,0),Color.rgb(255,252,246),Color.rgb(245,190,95)){
                appointments.removeAll{it.sessionPackId==s.id&&it.date.isAfter(LocalDate.now())};s.active=false;saveData();dialog.dismiss();source.dismiss();render();Toast.makeText(this,"Pacchetto terminato e appuntamenti futuri eliminati.",Toast.LENGTH_SHORT).show()
            },LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,0,0,dp(5))})
        } else {
            body.addView(dialogButton("Conferma terminazione",Color.WHITE,Color.rgb(235,140,0),Color.rgb(235,140,0)){
                s.active=false;saveData();dialog.dismiss();source.dismiss();render();Toast.makeText(this,"Pacchetto terminato.",Toast.LENGTH_SHORT).show()
            },LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,0,0,dp(5))})
        }
        body.addView(TextView(this).apply{text="Annulla";textSize=14.5f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(125,75,20));setPadding(0,dp(7),0,dp(2));setOnClickListener{dialog.dismiss()}},LinearLayout.LayoutParams(-1,dp(40)))
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun addTrashItem(kind:String,payload:JSONObject){ trashItems.add(TrashItem(nextTrashId++,kind,LocalDateTime.now(),payload.toString())) }
    private fun packTrashPayload(p:Pack):JSONObject=JSONObject().apply{put("name",p.name);put("start",p.start.toString());put("total",p.total);put("paid",p.paid);put("rateAmounts",JSONArray().apply{ratesFor(p).forEach{put(it)}});put("packageType",p.packageType);put("sessionTotal",p.sessionTotal);put("active",p.active);put("missedSessions",p.missedSessions)}
    private fun sessionPackTrashPayload(s:SessionPack):JSONObject=JSONObject().apply{put("id",s.id);put("name",s.name);put("start",s.start.toString());put("totalSessions",s.totalSessions);put("cost",s.cost);put("paid",s.paid);put("active",s.active);put("rateAmounts",JSONArray().apply{sessionRatesFor(s).forEach{put(it)}});put("linkedAppointmentIds",JSONArray().apply{appointments.filter{it.sessionPackId==s.id}.forEach{put(it.id)}})}
    private fun appointmentTrashPayload(a:Appointment):JSONObject=JSONObject().apply{put("id",a.id);put("name",a.name);put("date",a.date.toString());put("time",a.time);put("type",a.type);put("seriesId",a.seriesId);put("sessionPackId",a.sessionPackId);put("recovery",a.recovery)}
    private fun purgeExpiredTrash(){ val cutoff=LocalDateTime.now().minusDays(10); trashItems.removeAll{it.deletedAt.isBefore(cutoff)} }

    private fun trashScreen(returnToSettings:Boolean=false,filter:String="ALL"){
        detachSettingsOverlay()
        trashReturnToSettings=returnToSettings
        purgeExpiredTrash();saveData()
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(12),dp(16),dp(12));background=appGlassBackground()}
        val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        header.addView(TextView(this).apply{text="←";textSize=28f;setTextColor(Color.rgb(25,65,120));gravity=Gravity.CENTER;setOnClickListener{if(trashReturnToSettings){trashReturnToSettings=false;settings()}else build()}},LinearLayout.LayoutParams(dp(46),dp(46)))
        header.addView(TextView(this).apply{text="Cestino";textSize=24f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,35,55));gravity=Gravity.CENTER},LinearLayout.LayoutParams(0,dp(46),1f))
        header.addView(TextView(this).apply{text="🗑";textSize=22f;gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(46),dp(46)))
        root.addView(header)
        root.addView(LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(10),dp(12),dp(10));background=roundedSurface(Color.rgb(232,243,255),18,Color.rgb(195,220,248),1)
            addView(TextView(this@MainActivity).apply{text="i";textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(25,100,190));background=roundedSurface(Color.WHITE,24)},LinearLayout.LayoutParams(dp(34),dp(34)))
            addView(TextView(this@MainActivity).apply{text="Gli elementi restano nel cestino per 10 giorni, poi vengono eliminati automaticamente.";textSize=13f;setTextColor(Color.rgb(40,75,115));setPadding(dp(10),0,0,0)},LinearLayout.LayoutParams(0,-2,1f))
        },LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(8),0,dp(10))})
        val tabs=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val allCount=trashItems.size;val packCount=trashItems.count{it.kind=="PACK"||it.kind=="SESSION_PACK"};val apCount=trashItems.count{it.kind=="APPOINTMENT"}
        fun tab(label:String,active:Boolean,click:()->Unit)=Button(this).apply{text=label;setAllCaps(false);textSize=11.5f;setTypeface(null,android.graphics.Typeface.BOLD);minHeight=0;minimumHeight=0;stateListAnimator=null;setTextColor(if(active)Color.WHITE else Color.rgb(55,65,80));background=roundedSurface(if(active)Color.rgb(36,112,225) else Color.WHITE,16,if(active)Color.rgb(36,112,225) else Color.rgb(220,225,232),1);setOnClickListener{click()}}
        tabs.addView(tab("Tutti ($allCount)",filter=="ALL"){trashScreen(trashReturnToSettings,"ALL")},LinearLayout.LayoutParams(0,dp(40),1f).apply{setMargins(0,0,dp(3),0)})
        tabs.addView(tab("Pacchetti ($packCount)",filter=="PACKAGES"){trashScreen(trashReturnToSettings,"PACKAGES")},LinearLayout.LayoutParams(0,dp(40),1f).apply{setMargins(dp(2),0,dp(2),0)})
        tabs.addView(tab("Appuntamenti ($apCount)",filter=="APPOINTMENTS"){trashScreen(trashReturnToSettings,"APPOINTMENTS")},LinearLayout.LayoutParams(0,dp(40),1f).apply{setMargins(dp(3),0,0,0)})
        root.addView(tabs,LinearLayout.LayoutParams(-1,dp(42)))
        val filtered=when(filter){"PACKAGES"->trashItems.filter{it.kind=="PACK"||it.kind=="SESSION_PACK"};"APPOINTMENTS"->trashItems.filter{it.kind=="APPOINTMENT"};else->trashItems}
        val listBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,dp(4),0,dp(10))}
        if(filtered.isEmpty()) listBox.addView(TextView(this).apply{text="🗑\n\nNessun elemento\n\nIn questa sezione non ci sono elementi nel cestino.";textSize=16f;setTextColor(Color.rgb(75,85,100));gravity=Gravity.CENTER;setPadding(dp(20),dp(50),dp(20),dp(50))})
        else filtered.sortedByDescending{it.deletedAt}.forEach{listBox.addView(trashItemView(it),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(7))})}
        val scroll=ScrollView(this).apply{addView(listBox)};root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));prepareEdgeToEdgeRoot(root);setContentView(root)
    }
    private fun trashItemView(item:TrashItem):View{
        val obj=runCatching{JSONObject(item.payload)}.getOrElse{JSONObject()};val isAp=item.kind=="APPOINTMENT";val title=obj.optString("name","Elemento");val subtitle=if(isAp)"Appuntamento • ${obj.optString("date","")} • ${obj.optString("time","")}" else if(item.kind=="SESSION_PACK")"Pacchetto a sedute • ${obj.optInt("totalSessions",0)} sedute • €${obj.optInt("cost",0)}" else "Pacchetto ${obj.optString("packageType","PERSONALIZZATO")} • ${obj.optInt("sessionTotal",0)} sedute • €${obj.optInt("total",0)}";val days=(10-(java.time.Duration.between(item.deletedAt,LocalDateTime.now()).toHours()/24).toInt()).coerceIn(0,10)
        val card=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(10),dp(8),dp(10));background=roundedSurface(Color.WHITE,18,Color.rgb(225,230,237),1);isClickable=true}
        card.addView(TextView(this).apply{text=if(isAp)"📅" else "📦";textSize=22f;gravity=Gravity.CENTER;setTextColor(Color.rgb(30,100,190));background=roundedSurface(Color.rgb(235,244,255),28)},LinearLayout.LayoutParams(dp(48),dp(48)))
        val texts=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),0,dp(8),0)};texts.addView(TextView(this).apply{text=title;textSize=15.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,30,40))});texts.addView(TextView(this).apply{text=subtitle;textSize=12.5f;setTextColor(Color.rgb(80,88,100));setPadding(0,dp(2),0,0)});texts.addView(TextView(this).apply{text="Eliminato ${item.deletedAt.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))}";textSize=11.5f;setTextColor(Color.rgb(120,125,135));setPadding(0,dp(2),0,0)});card.addView(texts,LinearLayout.LayoutParams(0,-2,1f));card.addView(TextView(this).apply{text="$days giorni";textSize=12f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(if(days<=3)Color.rgb(205,55,55) else Color.rgb(30,110,190));gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(62),dp(42)));card.setOnClickListener{trashItemOptions(item)};return card
    }
    private fun trashItemOptions(item:TrashItem){
        val obj=runCatching{JSONObject(item.payload)}.getOrElse{JSONObject()}
        val name=obj.optString("name","Elemento")
        val typeLabel=when(item.kind){"APPOINTMENT"->"Appuntamento";"SESSION_PACK"->"Pacchetto a sedute";else->"Pacchetto 12 settimane"}
        val (d,outer,body)=packActionDialogBase("Elemento nel Cestino",if(item.kind=="APPOINTMENT")"📅" else "📦",Color.rgb(25,100,190),Color.rgb(232,243,255),Color.WHITE)
        body.addView(TextView(this).apply{text=name;textSize=20f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(25,35,55));setPadding(dp(6),0,dp(6),dp(4))})
        body.addView(TextView(this).apply{text=typeLabel;textSize=13.5f;gravity=Gravity.CENTER;setTextColor(Color.rgb(95,105,120));setPadding(0,0,0,dp(10))})
        body.addView(dialogButton("↩  Ripristina",Color.WHITE,Color.rgb(0,150,112),Color.rgb(0,150,112)){restoreTrashItem(item,d)},LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(7))})
        body.addView(dialogButton("🗑  Elimina definitivamente",Color.rgb(205,45,55),Color.rgb(255,244,244),Color.rgb(245,210,214)){confirmPermanentTrashDelete(item,d)},LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(5))})
        body.addView(Button(this).apply{text="Annulla";setAllCaps(false);textSize=14f;setTextColor(Color.rgb(0,125,110));setBackgroundColor(Color.TRANSPARENT);stateListAnimator=null;setOnClickListener{d.dismiss()}},LinearLayout.LayoutParams(-1,dp(44)))
        d.show()
    }
    private fun confirmPermanentTrashDelete(item:TrashItem,source:Dialog?=null){
        source?.dismiss()
        val obj=runCatching{JSONObject(item.payload)}.getOrElse{JSONObject()};val name=obj.optString("name","Elemento")
        val (d,outer,body)=packActionDialogBase("Eliminare definitivamente?","🗑",Color.rgb(205,45,55),Color.rgb(255,225,228),Color.rgb(255,250,250))
        body.addView(dialogBodyText("$name verrà eliminato in modo permanente e non potrà più essere ripristinato."))
        body.addView(dialogInfoCard("!","Attenzione","L'operazione non può essere annullata.",Color.rgb(205,45,55),Color.rgb(255,235,237)),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,dp(12))})
        val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        buttons.addView(dialogButton("Annulla",Color.rgb(65,80,100),Color.WHITE,Color.rgb(215,223,232)){d.dismiss()},LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(0,0,dp(4),0)})
        buttons.addView(dialogButton("🗑  Elimina",Color.WHITE,Color.rgb(205,45,55),Color.rgb(205,45,55)){trashItems.removeAll{it.id==item.id};saveData();d.dismiss();trashScreen(trashReturnToSettings)},LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(dp(4),0,0,0)})
        body.addView(buttons)
        d.show()
    }
    private fun restoreTrashItem(item:TrashItem,source:Dialog?=null){try{val obj=JSONObject(item.payload);when(item.kind){"APPOINTMENT"->appointments.add(Appointment(obj.getLong("id"),obj.getString("name"),LocalDate.parse(obj.getString("date")),obj.getString("time"),normalizedType(obj.optString("type","TYPE1")),obj.optLong("seriesId",0L),obj.optLong("sessionPackId",0L),obj.optBoolean("recovery",false)));"PACK"->packs.add(Pack(obj.getString("name"),LocalDate.parse(obj.getString("start")),obj.getInt("total"),obj.optInt("paid",0),obj.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}},obj.optString("packageType","PERSONALIZZATO"),obj.optInt("sessionTotal",12),obj.optBoolean("active",true),obj.optInt("missedSessions",0)));"SESSION_PACK"->{val restored=SessionPack(obj.getLong("id"),obj.getString("name"),LocalDate.parse(obj.getString("start")),obj.getInt("totalSessions"),obj.getInt("cost"),obj.optInt("paid",0),obj.optBoolean("active",true),obj.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}});sessionPacks.add(restored);obj.optJSONArray("linkedAppointmentIds")?.let{ja->for(i in 0 until ja.length()){val id=ja.getLong(i);appointments.firstOrNull{it.id==id}?.sessionPackId=restored.id}}}};trashItems.removeAll{it.id==item.id};nextAppointmentId=maxOf(nextAppointmentId,(appointments.maxOfOrNull{it.id}?:0L)+1);nextSessionPackId=maxOf(nextSessionPackId,(sessionPacks.maxOfOrNull{it.id}?:0L)+1);saveData();source?.dismiss();trashScreen(trashReturnToSettings);Toast.makeText(this,"Elemento ripristinato.",Toast.LENGTH_SHORT).show()}catch(_:Exception){Toast.makeText(this,"Impossibile ripristinare l'elemento.",Toast.LENGTH_LONG).show()}}

    private fun confirmDeleteSessionPack(s:SessionPack,source:AlertDialog){
        val (dialog,outer,body)=packActionDialogBase("Eliminare pacchetto?","▣",Color.rgb(215,35,45),Color.rgb(255,215,218),Color.rgb(255,250,250))
        body.addView(dialogBodyText("Stai per spostare nel Cestino il pacchetto di ${displaySurnameFirst(s.name)}."))
        body.addView(dialogInfoCard("!","Cestino • 10 giorni","Sedute, pagamenti e dati del pacchetto verranno conservati per 10 giorni.",Color.rgb(215,35,45),Color.rgb(255,230,232)),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,dp(12))})
        body.addView(TextView(this).apply{text="Gli appuntamenti resteranno nel calendario.";textSize=13.5f;gravity=Gravity.CENTER;setTextColor(Color.rgb(105,65,68));setPadding(dp(6),0,dp(6),dp(14))},LinearLayout.LayoutParams(-1,-2))
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        row.addView(dialogButton("Annulla",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(210,220,232)){dialog.dismiss()},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(4),0)})
        row.addView(dialogButton("Elimina",Color.WHITE,Color.rgb(225,40,50),Color.rgb(225,40,50)){
            addTrashItem("SESSION_PACK",sessionPackTrashPayload(s));sessionPacks.remove(s);appointments.filter{it.sessionPackId==s.id}.forEach{it.sessionPackId=0L};saveData();dialog.dismiss();source.dismiss();render();Toast.makeText(this,"Pacchetto spostato nel Cestino.",Toast.LENGTH_SHORT).show()
        },LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(4),0,0,0)})
        body.addView(row)
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun sessionPaymentInfo(s:SessionPack){ sessionInfoDialog(s) }

    private fun packActionDialogBase(title:String, icon:String, iconColor:Int, iconBg:Int, dialogBg:Int=Color.WHITE): Triple<Dialog,LinearLayout,LinearLayout>{
        val dialog=Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val outer=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(14),dp(12),dp(14),dp(12))
            background=roundedSurface(dialogBg,28)
        }
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val spacer=Space(this)
        top.addView(spacer,LinearLayout.LayoutParams(0,dp(36),1f))
        top.addView(TextView(this).apply{
            text="×";textSize=27f;gravity=Gravity.CENTER;setTextColor(Color.rgb(70,80,95));setPadding(0,0,0,dp(2))
            setOnClickListener{dialog.dismiss()}
        },LinearLayout.LayoutParams(dp(38),dp(36)))
        outer.addView(top)
        val iconView=TextView(this).apply{
            text=icon;textSize=28f;gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(iconColor)
            background=roundedSurface(iconBg,40)
        }
        outer.addView(iconView,LinearLayout.LayoutParams(dp(66),dp(66)).apply{gravity=Gravity.CENTER;setMargins(0,dp(0),0,dp(10))})
        val titleView=TextView(this).apply{
            text=title;textSize=21f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(28,35,48))
        }
        outer.addView(titleView,LinearLayout.LayoutParams(-1,dp(40)).apply{setMargins(dp(8),0,dp(8),dp(2))})
        val body=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(8),0,dp(8),0)}
        outer.addView(body,LinearLayout.LayoutParams(-1,-2))
        dialog.setContentView(outer)
        preparePopupBackdrop(dialog)
        dialog.window?.apply{
            setBackgroundDrawableResource(android.R.color.transparent)
            addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            attributes=attributes.apply{dimAmount=0.40f}
        }
        preparePopupBackdrop(dialog)
        dialog.setOnShowListener{
            popupBackdropCurrentDialog=dialog
            applyPopupBackdropEffect(dialog)
            dialog.window?.apply{
                setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
                attributes=attributes.apply{windowAnimations=0}
            }
            outer.animate().cancel()
            outer.alpha=0f
            outer.scaleX=0.972f
            outer.scaleY=0.972f
            outer.animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(155)
                .setInterpolator(android.view.animation.DecelerateInterpolator(1.5f))
                .withLayer()
                .start()
        }
        return Triple(dialog,outer,body)
    }

    private fun dialogBodyText(text:String):TextView=TextView(this).apply{
        this.text=text;textSize=15.5f;gravity=Gravity.CENTER;setTextColor(Color.rgb(55,62,75));setLineSpacing(0f,1.08f);setPadding(dp(6),0,dp(6),dp(12))
    }

    private fun dialogInfoCard(icon:String,title:String,value:String?,accent:Int,bg:Int):LinearLayout=LinearLayout(this).apply{
        orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),dp(10),dp(12),dp(10));background=roundedSurface(bg,18)
        addView(TextView(this@MainActivity).apply{text=icon;textSize=22f;gravity=Gravity.CENTER;setTextColor(accent);background=roundedSurface(Color.WHITE,32);},LinearLayout.LayoutParams(dp(48),dp(48)))
        val txt=LinearLayout(this@MainActivity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),0,0,0)}
        txt.addView(TextView(this@MainActivity).apply{text=title;textSize=13f;setTextColor(Color.rgb(70,78,90))},LinearLayout.LayoutParams(-1,-2))
        if(value!=null) txt.addView(TextView(this@MainActivity).apply{text=value;textSize=24f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(accent);setPadding(0,dp(2),0,0)},LinearLayout.LayoutParams(-1,-2))
        addView(txt,LinearLayout.LayoutParams(0,-2,1f))
    }

    private fun dialogButton(text:String,textColor:Int,bg:Int,stroke:Int,click:()->Unit):Button=Button(this).apply{
        this.text=text;setAllCaps(false);textSize=14.5f;setTypeface(null,android.graphics.Typeface.BOLD);minHeight=0;minimumHeight=0;stateListAnimator=null
        setTextColor(textColor);background=roundedSurface(bg,18,stroke,1);setPadding(dp(8),0,dp(8),0);setOnClickListener{click()}
    }

    private fun terminatePackDialog(p:Pack){
        val future=appointments.filter{identityKey(it.name)==identityKey(p.name)&&it.date.isAfter(LocalDate.now())}
        val (dialog,outer,body)=packActionDialogBase("Terminare il pacchetto?","✓",Color.rgb(205,120,0),Color.rgb(255,236,198),Color.rgb(255,252,246))
        body.addView(dialogBodyText("Il pacchetto di ${displaySurnameFirst(p.name)} verrà spostato nello storico e non sarà più considerato attivo."))
        body.addView(dialogInfoCard("▣","Appuntamenti futuri","${future.size}",Color.rgb(205,120,0),Color.rgb(255,241,213)),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,dp(10))})
        body.addView(TextView(this).apply{
            text=if(future.isEmpty()) "Non ci sono appuntamenti futuri da gestire." else "Puoi scegliere se mantenere gli appuntamenti futuri oppure eliminarli dal calendario."
            textSize=13.5f;gravity=Gravity.CENTER;setTextColor(Color.rgb(95,78,52));setLineSpacing(0f,1.05f);setPadding(dp(6),0,dp(6),dp(12))
        },LinearLayout.LayoutParams(-1,-2))
        if(future.isNotEmpty()){
            body.addView(dialogButton("Mantieni appuntamenti",Color.WHITE,Color.rgb(235,140,0),Color.rgb(235,140,0)){
                p.active=false;saveData();dialog.dismiss();render();Toast.makeText(this,"Pacchetto terminato. Appuntamenti mantenuti.",Toast.LENGTH_SHORT).show()
            },LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,0,0,dp(8))})
            body.addView(dialogButton("Elimina futuri",Color.rgb(190,105,0),Color.rgb(255,252,246),Color.rgb(245,190,95)){
                appointments.removeAll{identityKey(it.name)==identityKey(p.name)&&it.date.isAfter(LocalDate.now())};p.active=false;saveData();dialog.dismiss();render();Toast.makeText(this,"Pacchetto terminato e appuntamenti futuri eliminati.",Toast.LENGTH_SHORT).show()
            },LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,0,0,dp(5))})
        } else {
            body.addView(dialogButton("Conferma terminazione",Color.WHITE,Color.rgb(235,140,0),Color.rgb(235,140,0)){
                p.active=false;saveData();dialog.dismiss();render();Toast.makeText(this,"Pacchetto terminato.",Toast.LENGTH_SHORT).show()
            },LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,0,0,dp(5))})
        }
        body.addView(TextView(this).apply{text="Annulla";textSize=14.5f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setTextColor(Color.rgb(125,75,20));setPadding(0,dp(7),0,dp(2));setOnClickListener{dialog.dismiss()}},LinearLayout.LayoutParams(-1,dp(40)))
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun confirmDeletePack(p:Pack){
        val (dialog,outer,body)=packActionDialogBase("Eliminare pacchetto?","▣",Color.rgb(215,35,45),Color.rgb(255,215,218),Color.rgb(255,250,250))
        body.addView(dialogBodyText("Stai per spostare nel Cestino il pacchetto di ${displaySurnameFirst(p.name)}."))
        body.addView(dialogInfoCard("!","Cestino • 10 giorni","Rate, sedute e dati del pacchetto verranno conservati per 10 giorni.",Color.rgb(215,35,45),Color.rgb(255,230,232)),LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(2),0,dp(12))})
        body.addView(TextView(this).apply{
            text="Gli appuntamenti resteranno nel calendario."
            textSize=13.5f;gravity=Gravity.CENTER;setTextColor(Color.rgb(105,65,68));setPadding(dp(6),0,dp(6),dp(14))
        },LinearLayout.LayoutParams(-1,-2))
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        row.addView(dialogButton("Annulla",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(210,220,232)){dialog.dismiss()},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(4),0)})
        row.addView(dialogButton("Elimina",Color.WHITE,Color.rgb(225,40,50),Color.rgb(225,40,50)){
            addTrashItem("PACK",packTrashPayload(p));packs.remove(p);saveData();dialog.dismiss();activePackageDialog?.dismiss();activePackageDialog=null;render();Toast.makeText(this,"Pacchetto spostato nel Cestino.",Toast.LENGTH_SHORT).show()
        },LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(4),0,0,0)})
        body.addView(row)
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun editPackDialog(p:Pack){
        val (dialog,outer,body)=packActionDialogBase("Modifica pacchetto","✎",Color.rgb(20,91,165),Color.rgb(224,238,255),Color.WHITE)
        body.addView(dialogBodyText("Modifica i dati del pacchetto di ${displaySurnameFirst(p.name)}."))

        val intro=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(12),dp(9),dp(12),dp(9))
            background=roundedSurface(Color.rgb(247,249,252),18,Color.rgb(225,231,239),1)
        }
        val initials=displaySurnameFirst(p.name).split(" ").filter{it.isNotBlank()}.take(2).joinToString(""){it.first().uppercase()}
        intro.addView(TextView(this).apply{
            text=initials;textSize=17f;setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER
            setTextColor(Color.rgb(20,70,130));background=roundedSurface(Color.rgb(230,240,252),28)
        },LinearLayout.LayoutParams(dp(50),dp(50)))
        intro.addView(TextView(this).apply{
            text=displaySurnameFirst(p.name);textSize=16f;setTypeface(null,android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(25,28,32));gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),0,0,0)
        },LinearLayout.LayoutParams(0,dp(50),1f))
        body.addView(intro,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(13))})

        fun label(t:String)=TextView(this).apply{
            text=t;textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(82,87,94));setPadding(dp(2),0,0,dp(4))
        }
        val name=modernEditText().apply{
            setSingleLine(true);setText(p.name);setSelection(text.length);textSize=16f;hint="Cognome e Nome"
        }
        body.addView(label("Cliente"))
        body.addView(name,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(10))})

        body.addView(label("Tipo pacchetto"))
        val type=Spinner(this).apply{
            adapter=centeredSpinnerAdapter(listOf("BRONZE • 12 sedute","SILVER • 24 sedute","GOLD • 36 sedute","PERSONALIZZATO"))
            setSelection(when(p.packageType){"BRONZE"->0;"SILVER"->1;"GOLD"->2;else->3})
        }
        body.addView(type,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(10))})

        body.addView(label("Numero sedute"))
        val sessions=modernEditText().apply{
            setSingleLine(true);inputType=2;setText(p.sessionTotal.toString());hint="Numero sedute";textSize=16f
        }
        body.addView(sessions,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(14))})
        fun sync(){sessions.setText(when(type.selectedItemPosition){0->"12";1->"24";2->"36";else->p.sessionTotal.toString()})}
        type.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent:AdapterView<*>?){ }
            override fun onItemSelected(parent:AdapterView<*>?,view:View?,position:Int,id:Long){if(position<3)sync()}
        }

        body.addView(LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
            val cancel=dialogButton("Annulla",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(210,220,232)){dialog.dismiss()}
            val save=dialogButton("▣ Salva",Color.WHITE,Color.rgb(36,112,225),Color.rgb(36,112,225)){
                val newName=normalizeDisplayName(name.text.toString())
                val newTotal=sessions.text.toString().trim().toIntOrNull()
                if(newName.isBlank()||newTotal==null||newTotal<=0){
                    Toast.makeText(this@MainActivity,"Controlla nome e numero sedute.",Toast.LENGTH_LONG).show();return@dialogButton
                }
                val done=sessionsForPack(p,LocalDate.now()).size
                if(newTotal<done){
                    Toast.makeText(this@MainActivity,"Non puoi impostare $newTotal sedute: ne risultano già effettuate $done.",Toast.LENGTH_LONG).show();return@dialogButton
                }
                val oldKey=identityKey(p.name)
                val kind=when(type.selectedItemPosition){0->"BRONZE";1->"SILVER";2->"GOLD";else->"PERSONALIZZATO"}
                p.name=newName;p.packageType=kind;p.sessionTotal=if(kind=="BRONZE")12 else if(kind=="SILVER")24 else if(kind=="GOLD")36 else newTotal
                appointments.filter{identityKey(it.name)==oldKey}.forEach{it.name=newName}
                saveData();dialog.dismiss();render();Toast.makeText(this@MainActivity,"Pacchetto aggiornato.",Toast.LENGTH_SHORT).show()
            }
            addView(cancel,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(4),0)})
            addView(save,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(4),0,0,0)})
        },LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,0,0,dp(2))})

        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun renamePackDialog(p:Pack){
        val (dialog,outer,body)=packActionDialogBase("Rinomina pacchetto","✎",Color.rgb(20,91,165),Color.rgb(224,238,255),Color.WHITE)
        body.addView(dialogBodyText("Modifica il nome del cliente associato al pacchetto."))
        val input=modernEditText().apply{
            setSingleLine(true)
            setText(p.name)
            setSelection(text.length)
            textSize=16f
            hint="Cognome e Nome"
        }
        body.addView(TextView(this).apply{text="Nuovo nome del cliente/pacchetto";textSize=13f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(75,82,92));setPadding(dp(6),0,dp(6),dp(6))},LinearLayout.LayoutParams(-1,dp(28)))
        body.addView(input,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(dp(2),0,dp(2),dp(14))})
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        row.addView(dialogButton("Annulla",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(210,220,232)){dialog.dismiss()},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(4),0)})
        row.addView(dialogButton("✓  Salva",Color.WHITE,Color.rgb(36,112,225),Color.rgb(36,112,225)){
            val newName=normalizeDisplayName(input.text.toString())
            if(newName.isBlank()){input.error="Inserisci un nome";return@dialogButton}
            val oldKey=identityKey(p.name)
            p.name=newName
            appointments.filter{identityKey(it.name)==oldKey}.forEach{it.name=newName}
            saveData();dialog.dismiss()
            activePackageDialog?.dismiss();activePackageDialog=null
            render();packageInfoDialog(p)
            Toast.makeText(this,"Pacchetto rinominato.",Toast.LENGTH_SHORT).show()
        },LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(4),0,0,0)})
        body.addView(row)
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun sessionOptionsDialog(s:SessionPack){
        val used=sessionUsed(s);val booked=sessionBooked(s);val remaining=(s.totalSessions-booked).coerceAtLeast(0)
        val actions=arrayOf("Rinomina pacchetto","Termina pacchetto","Elimina pacchetto")
        AlertDialog.Builder(this).setTitle(displaySurnameFirst(s.name)).setMessage("Pacchetto da ${s.totalSessions} sedute • €${s.cost} saldato per intero\nSedute effettuate: $used/${s.totalSessions}\nSedute prenotate: $booked\nSedute rimanenti: $remaining").setItems(actions){_,which->when(which){
            0->{renameSessionPackDialog(s)}
            1->{confirmTerminateSessionPackFromOptions(s)}
            else->{confirmDeleteSessionPackFromOptions(s)}
        }}.setNegativeButton("Chiudi",null).create().also{styleOneUiDialog(it);it.show()}
    }

    private fun confirmTerminateSessionPackFromOptions(s:SessionPack){
        val dialog=AlertDialog.Builder(this).setTitle("Terminare il pacchetto?").setMessage("Il pacchetto verrà spostato nello storico e non sarà più considerato attivo.").setNegativeButton("ANNULLA",null).setPositiveButton("CONFERMA"){_,_->s.active=false;saveData();render();Toast.makeText(this,"Pacchetto terminato.",Toast.LENGTH_SHORT).show()}.create();styleOneUiDialog(dialog);dialog.show()
    }
    private fun confirmDeleteSessionPackFromOptions(s:SessionPack){
        val dialog=AlertDialog.Builder(this).setTitle("Eliminare pacchetto?").setMessage("Stai per eliminare definitivamente il pacchetto di ${displaySurnameFirst(s.name)}. I pagamenti e i dati del pacchetto verranno rimossi, mentre gli appuntamenti resteranno nel calendario.").setNegativeButton("ANNULLA",null).setPositiveButton("ELIMINA"){_,_->addTrashItem("SESSION_PACK",sessionPackTrashPayload(s));sessionPacks.remove(s);appointments.filter{it.sessionPackId==s.id}.forEach{it.sessionPackId=0L};saveData();render();Toast.makeText(this,"Pacchetto spostato nel Cestino.",Toast.LENGTH_SHORT).show()}.create();styleOneUiDialog(dialog);dialog.show()
    }

    private fun renameSessionPackDialog(s:SessionPack,source:AlertDialog?=null){
        val (dialog,outer,body)=packActionDialogBase("Rinomina pacchetto","✎",Color.rgb(20,91,165),Color.rgb(224,238,255),Color.WHITE)
        body.addView(dialogBodyText("Modifica il nome del cliente associato al pacchetto."))
        val input=modernEditText().apply{
            setSingleLine(true)
            setText(s.name)
            setSelection(text.length)
            textSize=16f
            hint="Cognome e Nome"
        }
        body.addView(TextView(this).apply{text="Nuovo nome del cliente/pacchetto";textSize=13f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(75,82,92));setPadding(dp(6),0,dp(6),dp(6))},LinearLayout.LayoutParams(-1,dp(28)))
        body.addView(input,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(dp(2),0,dp(2),dp(14))})
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        row.addView(dialogButton("Annulla",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(210,220,232)){dialog.dismiss()},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(4),0)})
        row.addView(dialogButton("✓  Salva",Color.WHITE,Color.rgb(36,112,225),Color.rgb(36,112,225)){
            val newName=normalizeDisplayName(input.text.toString())
            if(newName.isBlank()){input.error="Inserisci un nome";return@dialogButton}
            val oldKey=identityKey(s.name)
            s.name=newName
            appointments.filter{it.sessionPackId==s.id||identityKey(it.name)==oldKey}.forEach{it.name=newName}
            saveData();dialog.dismiss();source?.dismiss();render()
            if(source!=null) sessionInfoDialog(s)
            Toast.makeText(this,"Pacchetto rinominato.",Toast.LENGTH_SHORT).show()
        },LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(4),0,0,0)})
        body.addView(row)
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun showClientHistory(name:String){
        val oldPacks=packs.filter{!it.active&&identityKey(it.name)==identityKey(name)}
        val oldSessions=sessionPacks.filter{!it.active&&identityKey(it.name)==identityKey(name)}
        if(oldPacks.isEmpty()&&oldSessions.isEmpty()){Toast.makeText(this,"Nessun pacchetto terminato nello storico di $name.",Toast.LENGTH_SHORT).show();return}
        val items=mutableListOf<Pair<String,()->Unit>>()
        oldPacks.forEach{p->items.add("${p.packageType} • ${p.start.format(fmt)} • €${p.total}" to {exportSummary(summaryForPack(p),p.name)})}
        oldSessions.forEach{s->items.add("${s.totalSessions} sedute • ${s.start.format(fmt)} • €${s.cost}" to {exportSummary(summaryForSessionPack(s),s.name)})}
        AlertDialog.Builder(this).setTitle("🗂 Storico • $name").setItems(items.map{it.first}.toTypedArray()){_,which->items[which].second.invoke()}.setNegativeButton("Chiudi",null).show()
    }

    private fun Pack.paidRateIndex(rates:List<Int>):Int=rates.indices.firstOrNull{paid<rates.take(it+1).sum()}?:rates.size

    private data class PackStatus(val label:String,val color:Int)
    private fun statusRank(status:PackStatus):Int=when(status.label){"SCADUTA","DA PAGARE"->0;"IN SCADENZA"->1;"IN REGOLA"->2;else->2}
    private fun statusFor(p:Pack,rates:List<Int>,dates:List<LocalDate>):PackStatus{if(p.paid>=p.total)return PackStatus("IN REGOLA",Color.rgb(35,150,70));val nextIndex=rates.indices.firstOrNull{p.paid<rates.take(it+1).sum()}?:rates.lastIndex;val due=dates[nextIndex];val today=LocalDate.now();return when{due.isBefore(today)->PackStatus("SCADUTA",Color.rgb(210,45,45));!due.isAfter(today.plusDays(7))->PackStatus("IN SCADENZA",Color.rgb(220,160,20));else->PackStatus("IN REGOLA",Color.rgb(35,150,70))}}

    // ---------------- CALENDARIO ----------------
    private fun calendarScreen(){
        currentScreen = "CALENDAR"
        detachSettingsOverlay()
        trashReturnToSettings=false
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),dp(12),dp(10),dp(8));background=calendarGlassBackground()}

        fun changeCalendarWeekAnimated(direction:Int){
            if (calendarWeekAnimationDirection != 0) return
            calendarWeekAnimationDirection = direction
            root.animate().translationX((-direction * dp(70)).toFloat()).alpha(0f).setDuration(180).withEndAction{
                calendarWeekStart=if(direction<0)calendarWeekStart.minusWeeks(1) else calendarWeekStart.plusWeeks(1)
                calendarAutoFocusOnOpen=false
                calendarSwipeArmed=0
                calendarScrollX=0
                calendarScrollY=0
                calendarScreen()
            }.start()
        }

        fun calendarGlassButton(label:String):Button = Button(this).apply{
            text=label; textSize=13.5f; setAllCaps(false); setTextColor(Color.rgb(35,60,82));
            minHeight=0; minimumHeight=0; setPadding(0,0,0,0); stateListAnimator=null
            background=liquidInteractiveSurface(Color.rgb(238,241,243),18,Color.rgb(188,200,210),1)
            applyLiquidControlDepth(this)
        }

        fun calendarActionButton(key:String):View=when(key){
            "APPT"->Button(this).apply{
                setTextColor(Color.rgb(48,72,92))
                background=liquidInteractiveSurface(Color.rgb(239,242,244),20,Color.rgb(190,202,211),1)
                applyLiquidControlDepth(this)
                stateListAnimator=null
                contentDescription="＋ Appuntamento"
                textSize=15f
                val person=whitePersonDrawable().apply{setBounds(0,0,dp(17),dp(17))}
                val label=android.text.SpannableString("＋  \uFFFC")
                label.setSpan(android.text.style.ImageSpan(person,android.text.style.ImageSpan.ALIGN_CENTER),3,4,android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                text=label
                setOnClickListener{appointmentDialog(null)}
            }
            "PREV"->calendarGlassButton("‹").apply{setOnClickListener{changeCalendarWeekAnimated(-1)}}
            "NEXT"->calendarGlassButton("›").apply{setOnClickListener{changeCalendarWeekAnimated(1)}}
            "TODAY"->calendarGlassButton("Oggi").apply{setOnClickListener{calendarWeekStart=LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));calendarAutoFocusOnOpen=true;calendarSwipeArmed=0;calendarScreen()}}
            else->Button(this).apply{
                text="🔎 Cerca"; textSize=15f; setAllCaps(false); setTextColor(Color.rgb(48,72,92));
                minHeight=0; minimumHeight=0; stateListAnimator=null;
                background=liquidInteractiveSurface(Color.rgb(239,242,244),20,Color.rgb(190,202,211),1);
                applyLiquidControlDepth(this); setOnClickListener{calendarSearchScreen()}
            }
        }
        fun addButtonBar(keys:List<String>,top:Boolean){
            if(keys.isEmpty())return
            val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            keys.forEach{key->bar.addView(calendarActionButton(key),LinearLayout.LayoutParams(0,dp(46),1f).apply{setMargins(dp(3),0,dp(3),0)})}
            if(top)root.addView(bar,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(4))})
            else root.addView(bar,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(4),0,0)})
        }
        addButtonBar(calendarTopButtons,true)

        val titleRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val visibleOffsets=mutableListOf<Int>();calendarVisibleDays.forEachIndexed{i,shown->if(shown)visibleOffsets.add(i)};val firstVisibleOffset=visibleOffsets.firstOrNull()?:0;val lastVisibleOffset=visibleOffsets.lastOrNull()?:4;titleRow.addView(TextView(this).apply{text="${calendarWeekStart.plusDays(firstVisibleOffset.toLong()).format(fmt)}  →  ${calendarWeekStart.plusDays(lastVisibleOffset.toLong()).format(fmt)}";textSize=14f;setTextColor(Color.DKGRAY);gravity=Gravity.CENTER;setPadding(0,dp(4),0,dp(8))},LinearLayout.LayoutParams(0,dp(34),1f))
        val zoomLabel=TextView(this).apply{text="${(calendarZoom*100).toInt()}%";textSize=12f;setTextColor(Color.GRAY);gravity=Gravity.CENTER}
        titleRow.addView(buttonStyle("−").apply{setOnClickListener{calendarZoom=(calendarZoom-0.25f).coerceAtLeast(0.75f);calendarAutoFocusOnOpen=false;calendarScreen()}},LinearLayout.LayoutParams(dp(44),dp(34)))
        titleRow.addView(zoomLabel,LinearLayout.LayoutParams(dp(44),dp(34)))
        titleRow.addView(buttonStyle("+").apply{setOnClickListener{calendarZoom=(calendarZoom+0.25f).coerceAtMost(1.75f);calendarAutoFocusOnOpen=false;calendarScreen()}},LinearLayout.LayoutParams(dp(44),dp(34)))
        root.addView(titleRow,LinearLayout.LayoutParams(-1,dp(38)))

        val columnWidth=(dp(178)*calendarZoom).toInt().coerceAtLeast(dp(132))

        // Testata dei giorni fissa: resta sempre visibile mentre le fasce scorrono verticalmente.
        val headerHorizontal=CalendarHorizontalScrollView(this).apply{isFillViewport=false;isHorizontalScrollBarEnabled=false}
        val headerWeek=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        calendarVisibleDays.forEachIndexed{i,shown->if(shown)headerWeek.addView(dayHeader(calendarWeekStart.plusDays(i.toLong())),LinearLayout.LayoutParams(columnWidth,-2))}
        headerHorizontal.addView(headerWeek,ViewGroup.LayoutParams(-2,-2))
        root.addView(headerHorizontal,LinearLayout.LayoutParams(-1,(dp(62)*calendarZoom).toInt()))

        val verticalScroll=ScrollView(this).apply{isFillViewport=false}
        val bodyHorizontal=CalendarHorizontalScrollView(this).apply{isFillViewport=false;isHorizontalScrollBarEnabled=true}
        val week=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        calendarVisibleDays.forEachIndexed{i,shown->if(shown)week.addView(dayColumn(calendarWeekStart.plusDays(i.toLong()),false),LinearLayout.LayoutParams(columnWidth,-2))}
        bodyHorizontal.addView(week,ViewGroup.LayoutParams(-2,-2))
        verticalScroll.addView(bodyHorizontal,ViewGroup.LayoutParams(-2,-2))

        // La testata e il corpo scorrono orizzontalmente insieme.
        var syncingHeader=false
        var syncingBody=false
        headerHorizontal.setOnScrollChangeListener{_,scrollX,_,_,_->if(!syncingHeader){syncingBody=true;bodyHorizontal.scrollTo(scrollX,0);syncingBody=false};calendarScrollX=scrollX}
        bodyHorizontal.setOnScrollChangeListener{_,scrollX,_,_,_->if(!syncingBody){syncingHeader=true;headerHorizontal.scrollTo(scrollX,0);syncingHeader=false};calendarScrollX=scrollX}
        verticalScroll.setOnScrollChangeListener{_,_,scrollY,_,_->calendarScrollY=scrollY}

        // Cambio settimana con gesto continuo sui bordi.
        // Il controllo viene fatto dalla HorizontalScrollView stessa, così il gesto
        // non viene perso durante l'intercettazione dello scroll nativo.
        val weekChange: (Int) -> Unit = { direction ->
            val currentRoot = root
            currentRoot.animate().translationX((-direction * dp(70)).toFloat()).alpha(0f).setDuration(180).withEndAction {
                calendarWeekStart=if(direction<0)calendarWeekStart.minusWeeks(1) else calendarWeekStart.plusWeeks(1)
                calendarAutoFocusOnOpen=false
                calendarSwipeArmed=0
                calendarScrollX=0
                calendarScrollY=0
                calendarWeekAnimationDirection=direction
                calendarScreen()
            }.start()
        }
        bodyHorizontal.onEdgeWeekChange = weekChange
        headerHorizontal.onEdgeWeekChange = weekChange

        val today=LocalDate.now()
        val currentWeekStart=today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        if(calendarAutoFocusOnOpen && calendarWeekStart==currentWeekStart){
            val todayOffset=today.dayOfWeek.value-1
            val visibleBeforeToday=calendarVisibleDays.take(todayOffset).count{it}
            val nowMinutes=LocalTime.now().hour*60+LocalTime.now().minute
            val slotIndex=((nowMinutes-(7*60))/45).coerceIn(0,19)
            val slotHeight=(dp(86)*calendarZoom).toInt()
            headerHorizontal.post{headerHorizontal.scrollTo(visibleBeforeToday*columnWidth,0)}
            bodyHorizontal.post{bodyHorizontal.scrollTo(visibleBeforeToday*columnWidth,0)}
            verticalScroll.post{verticalScroll.smoothScrollTo(0,(slotIndex-2).coerceAtLeast(0)*slotHeight)}
        }else{
            headerHorizontal.post{headerHorizontal.scrollTo(calendarScrollX,0)}
            bodyHorizontal.post{bodyHorizontal.scrollTo(calendarScrollX,0)}
            verticalScroll.post{verticalScroll.scrollTo(0,calendarScrollY)}
        }
        calendarAutoFocusOnOpen=false
        root.addView(verticalScroll,LinearLayout.LayoutParams(-1,0,1f))
        addButtonBar(calendarBottomButtons,false)
        root.addView(calendarGlassButton("← Torna ai clienti").apply{setTextColor(Color.rgb(48,72,92));setOnClickListener{build()}},LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(4),0,0)})
        prepareEdgeToEdgeRoot(root)
        setContentView(root)
        if(calendarWeekAnimationDirection!=0){
            val direction=calendarWeekAnimationDirection
            calendarWeekAnimationDirection=0
            root.translationX=(direction * dp(70)).toFloat()
            root.alpha=0f
            root.animate().translationX(0f).alpha(1f).setDuration(180).start()
        }
    }

    private fun calendarSearchScreen(){
        currentScreen = "CALENDAR"
        detachSettingsOverlay()
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(14),dp(16),dp(10));background=appGlassBackground()}
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        top.addView(TextView(this).apply{text="🔎 Ricerca appuntamenti";textSize=22f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,28,32));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,dp(52),1f))
        top.addView(buttonStyle("Chiudi").apply{setOnClickListener{calendarScreen()}},LinearLayout.LayoutParams(dp(82),dp(44)))
        root.addView(top)
        searchInput=modernEditText().apply{
            hint="Cerca per nome cliente";textSize=16f;setSingleLine(true);setPadding(dp(14),0,dp(14),0);background=roundedSurface(Color.WHITE,20,Color.rgb(226,229,234),1)
            addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){searchList.removeAllViews();if(s.toString().trim().isNotEmpty())renderSearchResults(s.toString().trim().lowercase())};override fun afterTextChanged(s:Editable?){}})
        }
        root.addView(searchInput,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,dp(8),0,dp(8))})
        searchList=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,dp(4),0,0)}
        val scroll=ScrollView(this).apply{addView(searchList,ViewGroup.LayoutParams(-1,-2))}
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        root.addView(softBlueButtonStyle("← Torna al calendario").apply{setOnClickListener{calendarScreen()}},LinearLayout.LayoutParams(-1,dp(48)))
        prepareEdgeToEdgeRoot(root)
        setContentView(root)
        searchInput.requestFocus()
    }

    private fun dayHeader(day:LocalDate):View{
        val z=calendarZoom
        val today=day==LocalDate.now()
        val headerBg=GradientDrawable().apply{cornerRadius=(dp(12)*z);setColor(if(today)Color.argb(210,238,242,246)else Color.argb(195,255,255,255));setStroke((dp(1)*z).toInt(),if(today)Color.rgb(184,198,210)else Color.rgb(205,220,235))}
        return TextView(this).apply{text="${dayShort(day.dayOfWeek.value-1)}\n${day.dayOfMonth.toString().padStart(2,'0')}/${day.monthValue.toString().padStart(2,'0')}";textSize=15f*z;gravity=Gravity.CENTER;setTextColor(Color.rgb(45,50,56));background=headerBg;setPadding(0,(dp(6)*z).toInt(),0,(dp(6)*z).toInt())}.apply{layoutParams=LinearLayout.LayoutParams(-1,(dp(58)*z).toInt()).apply{setMargins(0,0,0,(dp(4)*z).toInt())}}
    }

    private fun dayColumn(day:LocalDate, includeHeader:Boolean=true):View{
        val z=calendarZoom
        val col=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding((dp(4)*z).toInt(),0,(dp(4)*z).toInt(),(dp(4)*z).toInt())}
        if(includeHeader) col.addView(dayHeader(day))
        for(slot in 0 until 20){val mins=7*60+slot*45;val hour=mins/60;val minute=mins%60;val time=String.format("%02d:%02d",hour,minute);val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding((dp(5)*z).toInt(),(dp(4)*z).toInt(),(dp(5)*z).toInt(),(dp(4)*z).toInt());background=calendarSlotSurface(z,slot);isClickable=true}.also{applyCalendarSlotDepth(it)}
            val items=appointments.filter{it.date==day&&it.time==time}.sortedBy{it.type}
            val maxTotal=calendarRoutines.getOrNull(activeRoutineIndex)?.maxTotal?:3;val countColor=when{items.size>=maxTotal->Color.rgb(205,55,55);items.size==maxTotal-1->Color.rgb(210,145,25);else->Color.GRAY}
            val timeRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            timeRow.addView(TextView(this).apply{text=time;textSize=11f*z;setTextColor(Color.rgb(105,110,118));setTypeface(null,android.graphics.Typeface.BOLD)},LinearLayout.LayoutParams(0,(dp(22)*z).toInt(),1f))
            timeRow.addView(TextView(this).apply{text="${items.size}/${calendarRoutines.getOrNull(activeRoutineIndex)?.maxTotal?:3}";textSize=9f*z;setTextColor(countColor);gravity=Gravity.CENTER},LinearLayout.LayoutParams((dp(30)*z).toInt(),(dp(22)*z).toInt()))
            box.addView(timeRow)
            if(items.isEmpty()){box.addView(TextView(this).apply{text="＋";textSize=18f*z;gravity=Gravity.CENTER;setTextColor(Color.LTGRAY)},LinearLayout.LayoutParams(-1,(dp(42)*z).toInt()));box.setOnClickListener{appointmentDialogForSlot(day,time)}}
            else{val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                items.forEachIndexed{index,a->row.addView(appointmentChip(a),LinearLayout.LayoutParams(0,(dp(52)*z).toInt(),1f).apply{if(index>0)setMargins((dp(2)*z).toInt(),0,0,0)})}
                box.addView(row,LinearLayout.LayoutParams(-1,(dp(52)*z).toInt()))
                box.addView(TextView(this).apply{text="${items.size}/${calendarRoutines.getOrNull(activeRoutineIndex)?.maxTotal?:3} appuntamenti";textSize=8.5f*z;setTextColor(Color.GRAY);gravity=Gravity.CENTER_VERTICAL;setPadding(0,(dp(1)*z).toInt(),0,0)},LinearLayout.LayoutParams(-1,(dp(10)*z).toInt()))
                box.setOnClickListener{appointmentDialogForSlot(day,time)}
            }
            col.addView(box,LinearLayout.LayoutParams(-1,(dp(86)*z).toInt()).apply{setMargins(0,(dp(2)*z).toInt(),0,0)})
        }
        return col
    }

    private fun calendarPackageExpired(name:String):Boolean{
        val key=identityKey(name)
        val regularExpired=packs.any{it.active&&identityKey(it.name)==key&&statusFor(it,ratesFor(it),dueDates(it)).label=="SCADUTA"}
        val sessionExpired=sessionPacks.any{it.active&&identityKey(it.name)==key&&sessionStatus(it).label in setOf("SCADUTA","DA PAGARE")}
        return regularExpired||sessionExpired
    }

    private inner class SiliconeStripeDrawable(private val z:Float) : Drawable() {
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val highlight = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val edgeGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val rr = RectF()

        override fun draw(canvas: Canvas) {
            if (bounds.width() <= 0 || bounds.height() <= 0) return
            val inset = 0.55f.dp()
            rr.set(bounds.left + inset, bounds.top + inset, bounds.right - inset, bounds.bottom - inset)
            val radius = rr.height() * 0.50f

            // Corpo rosso: pieno, morbido e leggermente più luminoso nella parte alta.
            fill.shader = LinearGradient(
                rr.left, rr.top, rr.left, rr.bottom,
                intArrayOf(
                    Color.rgb(255,106,114),
                    Color.rgb(247,64,74),
                    Color.rgb(220,43,54),
                    Color.rgb(198,35,47)
                ),
                floatArrayOf(0f,0.24f,0.68f,1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(rr, radius, radius, fill)

            // Un bordo morbido chiude la forma senza creare una linea separata.
            edgeGlow.strokeWidth = (0.70f * z).dp().coerceAtLeast(0.7f)
            edgeGlow.color = Color.argb(110,255,142,148)
            canvas.drawRoundRect(rr, radius, radius, edgeGlow)

            // Riflesso principale: una sola luce continua, perfettamente orizzontale.
            // Parte dentro la curva sinistra e arriva dentro la curva destra, senza
            // interrompersi prima delle estremità.
            val y = rr.top + rr.height() * 0.28f
            val left = rr.left + rr.height() * 0.34f
            val right = rr.right - rr.height() * 0.34f
            highlight.strokeWidth = (0.82f * z).dp().coerceAtLeast(0.8f)
            highlight.shader = LinearGradient(
                left, y, right, y,
                intArrayOf(
                    Color.argb(105,255,238,239),
                    Color.argb(195,255,246,247),
                    Color.argb(195,255,246,247),
                    Color.argb(105,255,238,239)
                ),
                floatArrayOf(0f,0.13f,0.87f,1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawLine(left, y, right, y, highlight)

            // Micro-riflesso inferiore: molto tenue, segue la stessa geometria e
            // completa la sensazione di silicone senza aumentare lo spessore percepito.
            val low = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeCap = Paint.Cap.ROUND
                strokeWidth = (0.45f * z).dp().coerceAtLeast(0.5f)
                color = Color.argb(78,142,18,30)
            }
            val lowY = rr.bottom - rr.height() * 0.22f
            canvas.drawLine(left + rr.height()*0.10f, lowY, right - rr.height()*0.10f, lowY, low)
        }

        private fun Float.dp():Float = this * resources.displayMetrics.density
        override fun setAlpha(alpha:Int) {}
        override fun setColorFilter(colorFilter:android.graphics.ColorFilter?) {}
        override fun getOpacity():Int = android.graphics.PixelFormat.TRANSLUCENT
    }

    private inner class LegacyAppointmentStyleDrawable(private val radiusPx:Float, private val accent:Int, private val mode:String):Drawable(){
        private val fill=Paint(Paint.ANTI_ALIAS_FLAG)
        private val edge=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE}
        private val r=RectF()
        override fun draw(c:Canvas){
            val b=bounds;if(b.width()<=0||b.height()<=0)return
            val d=resources.displayMetrics.density
            val inset=0.9f*d
            r.set(b.left+inset,b.top+inset,b.right-inset,b.bottom-inset)
            val rr=radiusPx
            val ar=Color.red(accent);val ag=Color.green(accent);val ab=Color.blue(accent)
            if(mode=="VETRO_SOFT_14"){
                // Stile 1.4: vetro chiaro, molto leggibile, con bordo cromatico sottile.
                fill.shader=LinearGradient(r.left,r.top,r.right,r.bottom,
                    intArrayOf(Color.argb(205,255,255,255),Color.argb(155,242,248,253),Color.argb(188,224,239,249)),
                    floatArrayOf(0f,.5f,1f),Shader.TileMode.CLAMP)
                c.drawRoundRect(r,rr,rr,fill)
                edge.strokeWidth=1.15f*d
                edge.color=Color.argb(170,ar,ag,ab)
                c.drawRoundRect(r,rr,rr,edge)
                edge.strokeWidth=.55f*d
                edge.color=Color.argb(115,255,255,255)
                c.drawRoundRect(RectF(r.left+2*d,r.top+2*d,r.right-2*d,r.bottom-2*d),maxOf(0f,rr-1.3f*d),maxOf(0f,rr-1.3f*d),edge)
                val shine=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeWidth=.65f*d;strokeCap=Paint.Cap.ROUND;shader=LinearGradient(r.left,r.top,r.right,r.top,intArrayOf(Color.argb(35,255,255,255),Color.argb(150,255,255,255),Color.argb(35,255,255,255)),floatArrayOf(0f,.5f,1f),Shader.TileMode.CLAMP)}
                c.drawLine(r.left+rr*.65f,r.top+2.6f*d,r.right-rr*.65f,r.top+2.6f*d,shine)
            }else if(mode=="VETRO_SOFT_FULL"){
                // Niki UI: vetro colorato pieno, lucido e profondo. Il colore riempie
                // la scheda ma la luce passa attraverso piu' strati per evitare l'effetto piatto.
                fill.shader=LinearGradient(r.left,r.top,r.right,r.bottom,
                    intArrayOf(Color.argb(214,ar,ag,ab),Color.argb(172,ar,ag,ab),Color.argb(196,ar,ag,ab)),
                    floatArrayOf(0f,.48f,1f),Shader.TileMode.CLAMP)
                c.drawRoundRect(r,rr,rr,fill)
                val gloss=Paint(Paint.ANTI_ALIAS_FLAG)
                gloss.shader=RadialGradient(r.left+r.width()*.50f,r.top-r.height()*.08f,r.width()*.78f,
                    intArrayOf(Color.argb(92,255,255,255),Color.argb(25,255,255,255),Color.TRANSPARENT),floatArrayOf(0f,.38f,1f),Shader.TileMode.CLAMP)
                c.drawRoundRect(r,rr,rr,gloss)
                val lower=Paint(Paint.ANTI_ALIAS_FLAG)
                lower.shader=LinearGradient(r.left,r.top,r.left,r.bottom,
                    intArrayOf(Color.TRANSPARENT,Color.argb(18,0,0,0),Color.argb(28,0,0,0)),floatArrayOf(0f,.58f,1f),Shader.TileMode.CLAMP)
                c.drawRoundRect(r,rr,rr,lower)
                edge.strokeWidth=1.35f*d
                edge.color=Color.argb(235,ar,ag,ab)
                c.drawRoundRect(r,rr,rr,edge)
                edge.strokeWidth=.72f*d
                edge.color=Color.argb(185,255,255,255)
                c.drawRoundRect(RectF(r.left+1.8f*d,r.top+1.8f*d,r.right-1.8f*d,r.bottom-1.8f*d),maxOf(0f,rr-1.2f*d),maxOf(0f,rr-1.2f*d),edge)
                val shine=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeWidth=1.0f*d;strokeCap=Paint.Cap.ROUND;shader=LinearGradient(r.left,r.top,r.right,r.top,intArrayOf(Color.argb(25,255,255,255),Color.argb(205,255,255,255),Color.argb(55,255,255,255)),floatArrayOf(0f,.48f,1f),Shader.TileMode.CLAMP)}
                c.drawLine(r.left+rr*.70f,r.top+3.0f*d,r.right-rr*.70f,r.top+3.0f*d,shine)
                val glint=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.FILL;shader=RadialGradient(r.centerX(),r.top+4*d,7*d,Color.argb(70,255,255,255),Color.TRANSPARENT,Shader.TileMode.CLAMP)}
                c.drawCircle(r.centerX(),r.top+4*d,7*d,glint)
            }else if(mode=="SATINATO_14"){
                // Stile Satinato 1.4: piu' opaco e diffuso, con bordo del colore del tipo.
                fill.shader=LinearGradient(r.left,r.top,r.left,r.bottom,
                    intArrayOf(Color.argb(225,244,247,249),Color.argb(190,218,225,232),Color.argb(214,246,249,251)),
                    floatArrayOf(0f,.52f,1f),Shader.TileMode.CLAMP)
                c.drawRoundRect(r,rr,rr,fill)
                edge.strokeWidth=1.0f*d
                edge.color=Color.argb(155,ar,ag,ab)
                c.drawRoundRect(r,rr,rr,edge)
                edge.strokeWidth=.6f*d
                edge.color=Color.argb(92,100,116,132)
                c.drawRoundRect(RectF(r.left+2*d,r.top+2*d,r.right-2*d,r.bottom-2*d),maxOf(0f,rr-1.5f*d),maxOf(0f,rr-1.5f*d),edge)
            } else if(mode=="SATINATO_FULL"){
                // Niki UI Satin Full: satinato ma con superficie lucida, riflesso ampio
                // e profondita' ottica. Non deve sembrare una tessera opaca.
                fill.shader=LinearGradient(r.left,r.top,r.left,r.bottom,
                    intArrayOf(Color.argb(214,ar,ag,ab),Color.argb(180,ar,ag,ab),Color.argb(202,ar,ag,ab)),
                    floatArrayOf(0f,.50f,1f),Shader.TileMode.CLAMP)
                c.drawRoundRect(r,rr,rr,fill)
                val satinGloss=Paint(Paint.ANTI_ALIAS_FLAG)
                satinGloss.shader=LinearGradient(r.left,r.top,r.right,r.top,
                    intArrayOf(Color.argb(16,255,255,255),Color.argb(100,255,255,255),Color.argb(24,255,255,255)),floatArrayOf(0f,.50f,1f),Shader.TileMode.CLAMP)
                c.drawRoundRect(r,rr,rr,satinGloss)
                val sheen=Paint(Paint.ANTI_ALIAS_FLAG)
                sheen.shader=RadialGradient(r.left+r.width()*.48f,r.top+r.height()*.02f,r.width()*.72f,
                    intArrayOf(Color.argb(68,255,255,255),Color.argb(15,255,255,255),Color.TRANSPARENT),floatArrayOf(0f,.45f,1f),Shader.TileMode.CLAMP)
                c.drawRoundRect(r,rr,rr,sheen)
                edge.strokeWidth=1.25f*d
                edge.color=Color.argb(225,ar,ag,ab)
                c.drawRoundRect(r,rr,rr,edge)
                edge.strokeWidth=.72f*d
                edge.color=Color.argb(165,255,255,255)
                c.drawRoundRect(RectF(r.left+1.8f*d,r.top+1.8f*d,r.right-1.8f*d,r.bottom-1.8f*d),maxOf(0f,rr-1.2f*d),maxOf(0f,rr-1.2f*d),edge)
                val shine=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeWidth=.82f*d;strokeCap=Paint.Cap.ROUND;shader=LinearGradient(r.left,r.top,r.right,r.top,intArrayOf(Color.argb(18,255,255,255),Color.argb(150,255,255,255),Color.argb(38,255,255,255)),floatArrayOf(0f,.50f,1f),Shader.TileMode.CLAMP)}
                c.drawLine(r.left+rr*.68f,r.top+3.0f*d,r.right-rr*.68f,r.top+3.0f*d,shine)
            } else if(mode=="SCURO_ELEGANTE_14") {
                // Vetro scuro: superficie fumé elegante, trasparente ma con sufficiente
                // contrasto per far percepire profondità. Il colore del tipo resta nel bordo.
                fill.shader=LinearGradient(r.left,r.top,r.right,r.bottom,
                    intArrayOf(Color.argb(218,38,48,59),Color.argb(170,69,82,96),Color.argb(205,30,39,50)),
                    floatArrayOf(0f,.50f,1f),Shader.TileMode.CLAMP)
                c.drawRoundRect(r,rr,rr,fill)
                // Riflesso lucido: superficie scura ma fisicamente brillante, non opaca.
                val darkGloss=Paint(Paint.ANTI_ALIAS_FLAG)
                darkGloss.shader=RadialGradient(r.left+r.width()*.50f,r.top-r.height()*.06f,r.width()*.80f,
                    intArrayOf(Color.argb(95,255,255,255),Color.argb(22,255,255,255),Color.TRANSPARENT),floatArrayOf(0f,.36f,1f),Shader.TileMode.CLAMP)
                c.drawRoundRect(r,rr,rr,darkGloss)
                val darkSheen=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeWidth=1.0f*d;strokeCap=Paint.Cap.ROUND;shader=LinearGradient(r.left,r.top,r.right,r.top,intArrayOf(Color.argb(15,255,255,255),Color.argb(175,255,255,255),Color.argb(28,255,255,255)),floatArrayOf(0f,.50f,1f),Shader.TileMode.CLAMP)}
                c.drawLine(r.left+rr*.70f,r.top+3.1f*d,r.right-rr*.70f,r.top+3.1f*d,darkSheen)
                // Bordo cromatico piu' chiaro: deve staccarsi nettamente dalla superficie scura.
                edge.strokeWidth=1.55f*d
                edge.color=Color.argb(235,ar,ag,ab)
                c.drawRoundRect(r,rr,rr,edge)
                edge.strokeWidth=2.6f*d
                edge.color=Color.argb(58,ar,ag,ab)
                c.drawRoundRect(r,rr,rr,edge)
                // bordo interno chiaro molto tenue: simula vetro sotto luce
                edge.strokeWidth=.55f*d
                edge.color=Color.argb(105,205,224,240)
                c.drawRoundRect(RectF(r.left+1.8f*d,r.top+1.8f*d,r.right-1.8f*d,r.bottom-1.8f*d),maxOf(0f,rr-1.15f*d),maxOf(0f,rr-1.15f*d),edge)
                val shine=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeWidth=.75f*d;strokeCap=Paint.Cap.ROUND;shader=LinearGradient(r.left,r.top,r.right,r.top,intArrayOf(Color.argb(20,255,255,255),Color.argb(125,255,255,255),Color.argb(20,255,255,255)),floatArrayOf(0f,.5f,1f),Shader.TileMode.CLAMP)}
                c.drawLine(r.left+rr*.70f,r.top+2.8f*d,r.right-rr*.70f,r.top+2.8f*d,shine)
            }
        }
        override fun setAlpha(a:Int){};override fun setColorFilter(f:android.graphics.ColorFilter?){};override fun getOpacity()=android.graphics.PixelFormat.TRANSLUCENT
    }

    /**
     * Testo "immerso nel vetro": doppio micro-riflesso ottico, con highlight
     * sopra/sinistra e ombra interna sotto/destra. Non modifica il testo né il layout.
     */
    /**
     * Testo immerso nel vetro Liquid Glass.
     *
     * La scritta non viene spostata: l'effetto è ottico e costruito con una
     * rifrazione cromatica molto morbida, un micro-bordo di luce sulla parte alta
     * e un'ombra interna sfumata sulla parte bassa. L'obiettivo è far percepire
     * il testo come presente sotto la superficie lucida, non come elemento sopra.
     */
    /**
     * Testo Liquid Glass: la scritta resta nitida e pulita; la sensazione di
     * immersione viene affidata a una rifrazione luminosa molto tenue attorno
     * ai glifi, evitando il precedente effetto "ombra 3D".
     */
    private inner class SubmergedGlassTextView(
        context: Context,
        private val liquidAccent: Int
    ): TextView(context){
        override fun onDraw(canvas: Canvas){
            val l=layout ?: run { super.onDraw(canvas); return }
            val p=paint
            val originalColor=p.color
            val originalAlpha=p.alpha
            val originalStyle=p.style
            val originalTypeface=p.typeface
            val originalMask=p.maskFilter
            val d=resources.displayMetrics.density

            val ar=Color.red(liquidAccent)
            val ag=Color.green(liquidAccent)
            val ab=Color.blue(liquidAccent)

            // Effetto "testo immerso": prima costruiamo una piccola
            // deformazione ottica attorno ai glifi, poi una zona d'ombra
            // interna molto morbida. Non è una drop-shadow: deve sembrare
            // che la scritta sia sotto una pellicola trasparente.

            // 1) Rifrazione cromatica laterale, estremamente tenue.
            canvas.save()
            p.style=Paint.Style.FILL
            p.clearShadowLayer()
            p.color=Color.argb(7,ar,ag,ab)
            p.alpha=255
            p.setMaskFilter(android.graphics.BlurMaskFilter(0.72f*d, android.graphics.BlurMaskFilter.Blur.NORMAL))
            canvas.translate(0.34f*d,0.18f*d)
            l.draw(canvas)
            canvas.restore()

            canvas.save()
            p.clearShadowLayer()
            p.color=Color.argb(6,255,255,255)
            p.alpha=255
            p.setMaskFilter(android.graphics.BlurMaskFilter(0.58f*d, android.graphics.BlurMaskFilter.Blur.NORMAL))
            canvas.translate(-0.30f*d,-0.14f*d)
            l.draw(canvas)
            canvas.restore()

            // 2) Ombra di immersione: appena sotto il carattere, molto
            // morbida e corta. Serve a far leggere il glifo come incassato
            // nella superficie senza creare l'effetto testo rialzato.
            canvas.save()
            p.clearShadowLayer()
            p.color=Color.argb(10,ar,ag,ab)
            p.alpha=255
            p.setMaskFilter(android.graphics.BlurMaskFilter(0.82f*d, android.graphics.BlurMaskFilter.Blur.NORMAL))
            canvas.translate(0.12f*d,0.52f*d)
            l.draw(canvas)
            canvas.restore()

            // 3) Micro-highlight sul bordo superiore del glifo: la luce
            // sembra passare attraverso il liquido prima di raggiungere
            // la scritta.
            canvas.save()
            p.clearShadowLayer()
            p.color=Color.argb(18,255,255,255)
            p.alpha=255
            p.setMaskFilter(android.graphics.BlurMaskFilter(0.38f*d, android.graphics.BlurMaskFilter.Blur.NORMAL))
            canvas.translate(-0.10f*d,-0.30f*d)
            l.draw(canvas)
            canvas.restore()

            // 4) Corpo del testo: leggermente meno "stampato" rispetto a un
            // testo sopra il vetro, ma ancora completamente leggibile.
            canvas.save()
            p.clearShadowLayer()
            p.setMaskFilter(null)
            p.style=originalStyle
            p.typeface=originalTypeface
            p.color=originalColor
            p.alpha=originalAlpha
            l.draw(canvas)
            canvas.restore()

            p.clearShadowLayer()
            p.setMaskFilter(originalMask)
            p.style=originalStyle
            p.typeface=originalTypeface
            p.color=originalColor
            p.alpha=originalAlpha
        }
    }

    private fun appointmentSurfaceFor(a:Appointment, accent:Int):Drawable{
        val shape=when(appointmentStyleSet){
            "LIQUID_GLASS" -> liquidGlassAppointmentShape
            "VETRO_SOFT_14" -> vetroSoft14AppointmentShape
            "SATINATO_14" -> satinato14AppointmentShape
            "SCURO_ELEGANTE_14" -> scuroElegante14AppointmentShape
            else -> appointmentShape
        }
        val rr=dpf(if(shape=="RETTANGOLARE") 7f else 12f)
        return when(appointmentStyleSet){
            "LIQUID_GLASS" -> AppointmentGelBaseDrawable(rr,accent,calendarMaterialEffect,calendarMaterialIntensity)
            "VETRO_SOFT_14" -> LegacyAppointmentStyleDrawable(rr,accent,"VETRO_SOFT_14")
            "VETRO_SOFT_FULL" -> LegacyAppointmentStyleDrawable(rr,accent,"VETRO_SOFT_FULL")
            "SATINATO_14" -> LegacyAppointmentStyleDrawable(rr,accent,"SATINATO_14")
            "SATINATO_FULL" -> LegacyAppointmentStyleDrawable(rr,accent,"SATINATO_FULL")
            "SCURO_ELEGANTE_14" -> LegacyAppointmentStyleDrawable(rr,accent,"SCURO_ELEGANTE_14")
            else -> AppointmentGelBaseDrawable(rr,accent,calendarMaterialEffect,calendarMaterialIntensity)
        }
    }

    private fun appointmentChip(a:Appointment):View{
        val accent=typeColor(a.type)
        val chip=FrameLayout(this).apply{
            setPadding((dp(2)*calendarZoom).toInt(),(dp(1)*calendarZoom).toInt(),(dp(2)*calendarZoom).toInt(),(dp(1)*calendarZoom).toInt())
            background=appointmentSurfaceFor(a,accent)
            isClickable=true
        }
        // La riga di scadenza resta in alto, indipendente dal testo: il nome puo'
        // occupare esattamente il centro geometrico della scheda.
        if(calendarPackageExpired(a.name)){
            val stripe=SiliconeStripeDrawable(calendarZoom)
            chip.addView(TextView(this).apply{background=stripe;elevation=dpf(1.8f)},
                FrameLayout.LayoutParams(-1,(dp(6)*calendarZoom).toInt()).apply{
                    leftMargin=(dp(7)*calendarZoom).toInt();rightMargin=(dp(7)*calendarZoom).toInt();topMargin=(dp(3)*calendarZoom).toInt()
                })
        }
        val nameView=(if(appointmentStyleSet=="LIQUID_GLASS") SubmergedGlassTextView(this,accent) else TextView(this)).apply{
            text=displaySurnameFirst(a.name)
            textSize=9.5f*calendarZoom
            setTextColor(if(appointmentStyleSet=="SCURO_ELEGANTE_14") Color.rgb(242,246,250) else Color.rgb(25,30,35))
            gravity=Gravity.CENTER
            maxLines=2
            ellipsize=android.text.TextUtils.TruncateAt.END
            setTypeface(null,android.graphics.Typeface.BOLD)
            scaleX=1.004f;scaleY=.998f
        }
        chip.addView(nameView,FrameLayout.LayoutParams(-1,-1).apply{
            leftMargin=(dp(4)*calendarZoom).toInt();rightMargin=(dp(4)*calendarZoom).toInt()
            topMargin=(dp(2)*calendarZoom).toInt();bottomMargin=(dp(1)*calendarZoom).toInt()
        })
        // Un micro-riflesso comune lega tutte le card alla stessa grammatica Niki UI.
        if(appointmentStyleSet!="LIQUID_GLASS") chip.foreground=NikiAppointmentGlossDrawable(dpf(if(appointmentShape=="RETTANGOLARE") 7f else 12f))
        if(appointmentStyleSet=="LIQUID_GLASS"){
            chip.foreground=WaterSurfaceOverlayDrawable(dpf(12f),calendarMaterialIntensity.coerceIn(0,100)/100f,accent)
        }
        chip.elevation=if(appointmentStyleSet=="SCURO_ELEGANTE_14")dp(4).toFloat() else dp(2).toFloat()
        chip.translationZ=dp(1).toFloat()
        chip.setOnClickListener{appointmentActions(a)}
        return chip
    }

    private fun registerDeletedRegularAppointment(a:Appointment){
        if(!a.recovery){regularPackFor(a.name,a.date)?.let{it.missedSessions++}}
    }

    private fun appointmentActions(a:Appointment){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(6),dp(18),dp(10))}
        box.addView(TextView(this).apply{text=displaySurnameFirst(a.name);textSize=23f;setTextColor(Color.rgb(24,27,31));setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER;setPadding(0,dp(4),0,dp(2))},LinearLayout.LayoutParams(-1,dp(42)))
        box.addView(TextView(this).apply{text="${a.date.format(fmt)} • ${a.time} • ${typeDuration(a.type)} min";textSize=13.5f;setTextColor(Color.rgb(92,96,102));gravity=Gravity.CENTER;setPadding(0,0,0,dp(14))},LinearLayout.LayoutParams(-1,dp(30)))
        val edit=TextView(this).apply{text="Modifica / sposta";textSize=15f;gravity=Gravity.CENTER;setTextColor(Color.rgb(35,91,145));setTypeface(null,android.graphics.Typeface.BOLD);background=liquidInteractiveSurface(Color.rgb(232,243,255),20,Color.rgb(188,211,238),1);isClickable=true;applyLiquidControlDepth(this)}
        val del=TextView(this).apply{text="Elimina appuntamento";textSize=15f;gravity=Gravity.CENTER;setTextColor(Color.rgb(195,55,55));setTypeface(null,android.graphics.Typeface.BOLD);background=roundedSurface(Color.rgb(255,244,244),18,Color.rgb(244,215,215),1);isClickable=true}
        val cancel=TextView(this).apply{text="Annulla";textSize=14f;setTextColor(Color.rgb(0,125,110));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);background=roundedSurface(Color.rgb(248,250,253),18,Color.rgb(218,225,232),1);isClickable=true}
        box.addView(edit,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,0,0,dp(7))})
        box.addView(del,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,0,0,dp(7))})
        box.addView(cancel,LinearLayout.LayoutParams(-1,dp(46)))
        val dialog=AlertDialog.Builder(this).setView(box).create();styleModernCoachDialog(dialog)
        preparePopupBackdrop(dialog)
        dialog.setOnShowListener{popupBackdropCurrentDialog=dialog;dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28));applyPopupBackdropEffect(dialog);dialog.window?.setDimAmount(0.40f);dialog.window?.let{w->w.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT)};animateCalendarDialog(dialog,box);edit.setOnClickListener{dialog.dismiss();appointmentDialog(a)};del.setOnClickListener{
            dialog.dismiss()
            if(a.seriesId!=0L){
                val series=appointments.filter{it.seriesId==a.seriesId}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
                val seriesCount=series.size
                val selectedIndex=series.indexOfFirst{it.id==a.id}
                val laterCount=if(selectedIndex>=0) series.size-selectedIndex else 0
                val (seqDialog,outer,body)=packActionDialogBase("Elimina appuntamento","🗑",Color.rgb(205,45,55),Color.rgb(255,225,228),Color.WHITE)
                body.addView(dialogBodyText("Questo appuntamento fa parte di una programmazione di $seriesCount appuntamenti.\n\nScegli cosa vuoi eliminare."))
                fun seqButton(label:String, sub:String?=null, bg:Int=Color.rgb(246,248,250), fg:Int=Color.rgb(25,28,32)):Button=dialogButton(if(sub.isNullOrBlank())label else "$label\n$sub",fg,bg,if(bg==Color.rgb(246,248,250)) Color.rgb(220,225,232) else bg){}
                val one=seqButton("Solo questo appuntamento")
                val subsequent=seqButton("Questo e tutti i successivi","Elimina $laterCount appuntamenti da questo in poi")
                val all=seqButton("Tutta la sequenza","Elimina tutti i $seriesCount appuntamenti",Color.rgb(255,244,244),Color.rgb(195,55,55))
                body.addView(one,LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,0,0,dp(7))})
                body.addView(subsequent,LinearLayout.LayoutParams(-1,dp(58)).apply{setMargins(0,0,0,dp(7))})
                body.addView(all,LinearLayout.LayoutParams(-1,dp(58)).apply{setMargins(0,0,0,dp(5))})
                body.addView(dialogButton("Annulla",Color.rgb(0,125,110),Color.rgb(248,250,253),Color.rgb(218,225,232)){seqDialog.dismiss()},LinearLayout.LayoutParams(-1,dp(44)))
                one.setOnClickListener{registerDeletedRegularAppointment(a);addTrashItem("APPOINTMENT",appointmentTrashPayload(a));appointments.remove(a);saveData();seqDialog.dismiss();calendarScreen()}
                subsequent.setOnClickListener{
                    if(selectedIndex>=0){val toRemove=appointments.filter{it.seriesId==a.seriesId && (it.date.isAfter(a.date) || (it.date==a.date && it.time>=a.time))};toRemove.forEach{registerDeletedRegularAppointment(it);addTrashItem("APPOINTMENT",appointmentTrashPayload(it))};appointments.removeAll{it.id in toRemove.map{r->r.id}.toSet()}}
                    saveData();seqDialog.dismiss();calendarScreen()
                }
                all.setOnClickListener{val toRemove=appointments.filter{it.seriesId==a.seriesId};toRemove.forEach{registerDeletedRegularAppointment(it);addTrashItem("APPOINTMENT",appointmentTrashPayload(it))};appointments.removeAll{it.id in toRemove.map{r->r.id}.toSet()};saveData();seqDialog.dismiss();calendarScreen()}
                seqDialog.show()
            }else{
                val (confirmDialog,outer,body)=packActionDialogBase("Elimina appuntamento?","🗑",Color.rgb(205,45,55),Color.rgb(255,225,228),Color.WHITE)
                body.addView(dialogBodyText("Vuoi eliminare l'appuntamento di ${displaySurnameFirst(a.name)} del ${a.date.format(fmt)} alle ${a.time}?"))
                val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                buttons.addView(dialogButton("Annulla",Color.rgb(65,80,100),Color.WHITE,Color.rgb(215,223,232)){confirmDialog.dismiss()},LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(0,0,dp(4),0)})
                buttons.addView(dialogButton("🗑  Elimina",Color.WHITE,Color.rgb(205,45,55),Color.rgb(205,45,55)){registerDeletedRegularAppointment(a);addTrashItem("APPOINTMENT",appointmentTrashPayload(a));appointments.remove(a);saveData();confirmDialog.dismiss();calendarScreen()},LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(dp(4),0,0,0)})
                body.addView(buttons)
                confirmDialog.show()
            }
        };cancel.setOnClickListener{dialog.dismiss()}}
        dialog.show()
    }

    private fun animateCalendarDialog(dialog: AlertDialog, content: View){
        dialog.window?.apply{
            // Disattiva l'animazione di finestra Android: evitiamo di sommare due
            // animazioni (sistema + Niki UI) mentre il calendario continua a essere renderizzato sotto.
            attributes = attributes.apply{windowAnimations = 0}
        }
        content.alpha = 0f
        content.scaleX = 0.985f
        content.scaleY = 0.985f
        content.translationY = dp(8).toFloat()
        content.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .translationY(0f)
            .setDuration(170)
            .setInterpolator(android.view.animation.DecelerateInterpolator())
            .start()
    }

    private fun animateSettingsPageIn(dialog: AlertDialog, content: View){
        val shouldAnimate=settingsTransitionPending
        settingsTransitionPending=false
        dialog.window?.apply{
            attributes=attributes.apply{windowAnimations=0}
        }
        if(!shouldAnimate)return
        content.animate().cancel()
        content.alpha=0f
        content.translationX=dp(34).toFloat()
        content.scaleX=0.985f
        content.scaleY=0.985f
        content.animate().alpha(1f).translationX(0f).scaleX(1f).scaleY(1f)
            .setDuration(210)
            .setInterpolator(android.view.animation.DecelerateInterpolator(1.15f))
            .withLayer().start()
    }

    private fun styleFullPageCoachDialog(dialog:AlertDialog){
        preparePopupBackdrop(dialog)
        dialog.setOnShowListener{
            popupBackdropCurrentDialog=dialog
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28))
            applyPopupBackdropEffect(dialog)
            dialog.window?.setDimAmount(0.40f)
            dialog.window?.let{w->
                val metrics=resources.displayMetrics
                w.setLayout((metrics.widthPixels*0.92f).toInt(),(metrics.heightPixels*0.82f).toInt())
                w.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
                // La finestra resta ferma, mentre la pagina interna è realmente scrollabile
                // anche quando il contenuto, a tastiera chiusa, sarebbe più corto del viewport.
                fun prepareScroll(v:View){
                    if(v is ScrollView){
                        v.isFillViewport=true
                        v.clipToPadding=false
                        v.setPadding(0,dp(76),0,dp(76))
                        val child=v.getChildAt(0)
                        if(child!=null){
                            v.post{
                                val extra=dp(152)
                                child.minimumHeight=maxOf(child.measuredHeight,v.height+extra)
                            }
                        }
                    }
                    if(v is ViewGroup){
                        for(i in 0 until v.childCount) prepareScroll(v.getChildAt(i))
                    }
                }
                w.decorView.post{prepareScroll(w.decorView)}
            }
        }
    }

    private fun styleModernCoachDialog(dialog:AlertDialog){
        preparePopupBackdrop(dialog)
        dialog.setOnShowListener{
            popupBackdropCurrentDialog=dialog
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28))
            applyPopupBackdropEffect(dialog)
            dialog.window?.setDimAmount(0.40f)
            dialog.window?.let{w->
                val metrics=resources.displayMetrics
                w.setLayout((metrics.widthPixels*0.92f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT)
                w.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
            }
            dialog.findViewById<TextView>(resources.getIdentifier("alertTitle","id","android"))?.apply{
                textSize=22f
                gravity=Gravity.CENTER
                textAlignment=View.TEXT_ALIGNMENT_CENTER
                setTextColor(Color.rgb(28,30,33))
                setTypeface(null,android.graphics.Typeface.NORMAL)
                layoutParams = (layoutParams ?: ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT)).apply {
                    width = ViewGroup.LayoutParams.MATCH_PARENT
                    gravity = Gravity.CENTER
                }
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.apply{setTextColor(Color.rgb(0,125,110));setAllCaps(false);stateListAnimator=null}
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.apply{setTextColor(Color.rgb(0,125,110));setAllCaps(false);stateListAnimator=null}
        }
    }

    private fun styleSettingsPageWindow(dialog:AlertDialog){
        dialog.window?.apply{
            // Settings uses a full-screen window, but NOT edge-to-edge into
            // the status bar. The status bar stays opaque white with dark
            // icons so Android/Samsung system icons never collide with the
            // Settings title or become unreadable on the light background.
            setBackgroundDrawable(roundedSurface(Color.WHITE,0))
            setDimAmount(0f)
            if(android.os.Build.VERSION.SDK_INT >= 30){
                setDecorFitsSystemWindows(true)
            }
            clearFlags(android.view.WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            if(android.os.Build.VERSION.SDK_INT >= 21){
                clearFlags(android.view.WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION)
            }
            addFlags(android.view.WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            statusBarColor=Color.WHITE
            navigationBarColor=Color.WHITE
            if(android.os.Build.VERSION.SDK_INT >= 28){
                navigationBarDividerColor=Color.WHITE
            }
            val metrics=resources.displayMetrics
            setLayout(metrics.widthPixels,metrics.heightPixels)
        }
    }

    private fun styleSettingsPageDialog(dialog:AlertDialog, returnToSettings:Boolean){
        var backHandled=false
        dialog.setOnKeyListener{_,keyCode,event->
            if(keyCode==android.view.KeyEvent.KEYCODE_BACK && event.action==android.view.KeyEvent.ACTION_UP){
                if(backHandled)return@setOnKeyListener true
                backHandled=true
                val content=dialog.window?.decorView
                if(content!=null){
                    content.animate().cancel()
                    content.animate().translationX(dp(34).toFloat()).alpha(0f)
                        .setDuration(170)
                        .setInterpolator(android.view.animation.DecelerateInterpolator(1.15f))
                        .withLayer()
                        .withEndAction{dialog.dismiss();if(returnToSettings)window.decorView.post{settings()}}
                        .start()
                }else{
                    dialog.dismiss()
                    if(returnToSettings)window.decorView.post{settings()}
                }
                true
            }else false
        }
        dialog.setOnCancelListener{
            removePopupBackdropDialog(dialog)
            if(!backHandled && returnToSettings){
                backHandled=true
                window.decorView.post{settings()}
            }
        }
    }

    private fun styleOneUiDialog(dialog:AlertDialog){
        preparePopupBackdrop(dialog)
        dialog.setOnShowListener{
            popupBackdropCurrentDialog=dialog
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28))
            applyPopupBackdropEffect(dialog)
            dialog.window?.setDimAmount(0.38f)
            dialog.findViewById<TextView>(resources.getIdentifier("alertTitle","id","android"))?.apply{
                textSize=22f
                gravity=Gravity.CENTER
                textAlignment=View.TEXT_ALIGNMENT_CENTER
                setTextColor(Color.rgb(28,30,33))
                setTypeface(null,android.graphics.Typeface.NORMAL)
                setPadding(0,dp(2),0,dp(2))
                layoutParams = (layoutParams ?: ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT)).apply {
                    width = ViewGroup.LayoutParams.MATCH_PARENT
                    gravity = Gravity.CENTER
                }
            }
            dialog.findViewById<TextView>(android.R.id.message)?.apply{
                textSize=16f
                setTextColor(Color.rgb(55,58,63))
                setLineSpacing(0f,1.05f)
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.apply{setTextColor(Color.rgb(0,125,110));setAllCaps(false);stateListAnimator=null;minHeight=0;minimumHeight=0}
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.apply{setTextColor(Color.rgb(0,125,110));setAllCaps(false);stateListAnimator=null;minHeight=0;minimumHeight=0}
        }
    }

    private fun appointmentDialog(existing:Appointment?, forcedDay:LocalDate?=null, forcedTime:String?=null){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(4),dp(14),0)}
        val name=AutoCompleteTextView(this).apply{hint="Cognome e Nome";setText(existing?.name?:"");setSingleLine(true);setAdapter(clientNameAutoCompleteAdapter((packs.map{it.name}+sessionPacks.map{it.name}).distinct()))}
        val date=modernEditText().apply{hint="Data (gg/mm/aaaa)";inputType=2;setText((existing?.date?:forcedDay?:calendarWeekStart).format(fmt))};setupDateInput(date)
        val time=Spinner(this).also{installNikiTimeDropdown(it, true)}
        val type=Spinner(this);type.adapter=centeredSpinnerAdapter(appointmentTypes.map{it.name});type.setSelection(existing?.let{typeIndex(it.type)}?:0)
        var seriesEdit: Button? = null
        if(existing!=null && existing.seriesId!=0L){
            seriesEdit=Button(this).apply{
                text="↻  Modifica ripetizione";setAllCaps(false);textSize=15f;gravity=Gravity.CENTER_VERTICAL;setTextColor(Color.rgb(25,92,170))
                setTypeface(null,android.graphics.Typeface.BOLD)
                background=liquidInteractiveSurface(Color.rgb(232,242,255),20,Color.rgb(168,207,247),1);applyLiquidControlDepth(this);stateListAnimator=null
                setPadding(dp(14),0,dp(10),0)
            }
        }
        var recovery: CheckBox? = null

        // Mantieni aggiornata la fascia oraria disponibile anche nella nuova UI compatta.
        fun refreshTimeSlots(){
            val selectedType=typeIdAt(type.selectedItemPosition)
            val selectedDate=runCatching{parseDate(date.text.toString())}.getOrNull()?: (existing?.date?:forcedDay?:calendarWeekStart)
            val slots=availableTimeSlots(selectedDate,selectedType,existing)
            val values=if(slots.isEmpty()) listOf("NESSUNA FASCIA DISPONIBILE") else slots
            time.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,values)
            val wanted=existing?.time?:forcedTime
            if(wanted!=null){val idx=values.indexOf(wanted);if(idx>=0)time.setSelection(idx)}
        }

        fun refreshRecoveryOption(){
            if(existing!=null || recovery==null) return
            val selectedDate=runCatching{parseDate(date.text.toString())}.getOrNull() ?: LocalDate.now()
            val possiblePack=regularPackFor(name.text.toString(),selectedDate)
            val pending=possiblePack?.let{recoveriesForPack(it)} ?: 0
            recovery!!.isChecked=false
            recovery!!.isEnabled=pending>0
            recovery!!.visibility=if(pending>0)View.VISIBLE else View.GONE
            if(pending>0) recovery!!.text="↩ Recupero seduta persa ($pending disponibile/i)"
        }

        if(existing==null){
            // Creazione appuntamento: UI compatta e moderna. La logica di calendario/ripetizione resta invariata.
            val page=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(14),dp(18),dp(12))}
            val scroll=ScrollView(this).apply{isFillViewport=true;clipToPadding=false;setPadding(0,0,0,dp(24))}
            scroll.addView(page,ViewGroup.LayoutParams(-1,-2))

            val header=LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
                setPadding(dp(14),dp(10),dp(14),dp(10))
                background=roundedSurface(Color.rgb(238,246,255),22,Color.rgb(200,222,246),1)
            }
            val icon=TextView(this).apply{
                text="📅";textSize=23f;gravity=Gravity.CENTER
                background=roundedSurface(Color.WHITE,18)
                setPadding(dp(8),dp(7),dp(8),dp(7))
            }
            header.addView(icon,LinearLayout.LayoutParams(dp(50),dp(50)))
            val headerText=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),0,0,0)}
            headerText.addView(TextView(this).apply{
                text="Nuovo appuntamento";textSize=18f;setTextColor(Color.rgb(25,55,85));setTypeface(null,android.graphics.Typeface.BOLD)
            })
            headerText.addView(TextView(this).apply{
                text="Aggiungi un nuovo appuntamento al calendario";textSize=12.5f;setTextColor(Color.rgb(82,104,125));setPadding(0,dp(3),0,0)
            })
            header.addView(headerText,LinearLayout.LayoutParams(0,-2,1f))
            page.addView(header,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})

            fun modernSpinner(spinner:Spinner){
                spinner.background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(220,226,234),1)
                applyLiquidControlDepth(spinner)
                spinner.setPadding(dp(14),0,dp(10),0)
            }
            name.background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(220,226,234),1)
            applyLiquidControlDepth(name)
            name.setPadding(dp(14),0,dp(14),0)
            name.textSize=16f
            name.setTextColor(Color.rgb(35,38,42))
            name.setHintTextColor(Color.rgb(135,140,147))
            styleClientNameSuggestions(name)
            name.isFocusable=true;name.isFocusableInTouchMode=true
            modernSpinner(time);modernSpinner(type);installNikiTypeDropdown(type)
            val fields=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
            fields.addView(TextView(this).apply{text="Cognome e Nome";textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,74,80));setPadding(dp(2),0,0,dp(5))})
            fields.addView(name,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(10))})
            fields.addView(TextView(this).apply{text="Data";textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,74,80));setPadding(dp(2),0,0,dp(5))})
            fields.addView(date,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(10))})
            fields.addView(TextView(this).apply{text="Fascia oraria disponibile";textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,74,80));setPadding(dp(2),0,0,dp(5))})
            fields.addView(time,LinearLayout.LayoutParams(dp(110),dp(50)).apply{gravity=Gravity.CENTER;setMargins(0,0,0,dp(10))})
            fields.addView(TextView(this).apply{text="Tipo appuntamento";textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,74,80));setPadding(dp(2),0,0,dp(5))})
            fields.addView(type,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(10))})
            page.addView(fields)
            recovery=CheckBox(this).apply{
                text="↩ Recupero seduta persa";textSize=13.5f;setTextColor(Color.rgb(55,58,63));setPadding(0,0,0,0);visibility=View.GONE
            }
            page.addView(recovery,LinearLayout.LayoutParams(-1,dp(44)).apply{setMargins(dp(2),0,0,dp(2))})

            val repeat=CheckBox(this).apply{
                text="Ripeti ogni settimana";textSize=14f;setTextColor(Color.rgb(35,38,42));setPadding(0,0,0,0)
            }
            val repeatRow=LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
                setPadding(dp(12),dp(7),dp(10),dp(7))
                background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(220,226,234),1)
                applyLiquidControlDepth(this)
                addView(repeat,LinearLayout.LayoutParams(0,dp(48),1f))
            }
            page.addView(repeatRow,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})

            val repeatPanel=LinearLayout(this).apply{
                orientation=LinearLayout.VERTICAL;visibility=View.GONE
                setPadding(dp(12),dp(10),dp(12),dp(10))
                background=roundedSurface(Color.rgb(238,246,255),20,Color.rgb(205,225,247),1)
            }
            repeatPanel.addView(TextView(this).apply{
                text="Seleziona giorni e orari";textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(25,75,125));setPadding(0,0,0,dp(7))
            })
            val days=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
            val checks=(0..6).map{i->CheckBox(this).apply{text=dayShort(i);isChecked=i==((forcedDay?:calendarWeekStart).dayOfWeek.value-1);setPadding(0,0,0,0)}}
            val dayTimes=mutableMapOf<Int,Spinner>()
            val dayRows=mutableMapOf<Int,LinearLayout>()
            fun datesForWeekday(dayIndex:Int,start:LocalDate,end:LocalDate):List<LocalDate>{
                val out=mutableListOf<LocalDate>();var d=start
                while(!d.isAfter(end)){if(d.dayOfWeek.value-1==dayIndex)out.add(d);d=d.plusDays(1)}
                return out
            }
            fun slotsForWeekday(dayIndex:Int,start:LocalDate,end:LocalDate,selectedType:String):List<String>{
                val dates=datesForWeekday(dayIndex,start,end);if(dates.isEmpty())return emptyList()
                val first=availableTimeSlots(dates.first(),selectedType,existing)
                return first.filter{slot->dates.all{d->canAdd(d,slot,selectedType,if(existing?.date==d)existing else null)}}
            }
            val end=modernEditText().apply{hint="Fine ripetizione (gg/mm/aaaa)";inputType=2;setText(calendarWeekStart.plusWeeks(12).format(fmt));visibility=View.GONE};setupDateInput(end)
            repeatPanel.addView(days)
            repeatPanel.addView(end,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(8),0,0)})
            page.addView(repeatPanel,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})
            checks.forEachIndexed{idx,c->
                val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                row.addView(c,LinearLayout.LayoutParams(0,dp(48),1f))
                val spinner=Spinner(this).also{installNikiTimeDropdown(it, true)};modernSpinner(spinner);dayTimes[idx]=spinner
                row.addView(spinner,LinearLayout.LayoutParams(dp(110),dp(46)).apply{gravity=Gravity.CENTER_VERTICAL})
                dayRows[idx]=row;days.addView(row)
            }
            fun refreshDayTimeRows(){
                val startDate=runCatching{parseDate(date.text.toString())}.getOrNull()?:calendarWeekStart
                val endDate=runCatching{parseDate(end.text.toString())}.getOrNull()?:startDate
                val selectedType=typeIdAt(type.selectedItemPosition)
                checks.forEachIndexed{idx,c->
                    val row=dayRows[idx]?:return@forEachIndexed;val spinner=dayTimes[idx]?:return@forEachIndexed
                    // I sette giorni restano sempre visibili: solo l'orario viene mostrato
                    // quando il relativo giorno è selezionato.
                    row.visibility=View.VISIBLE
                    spinner.visibility=if(c.isChecked)View.VISIBLE else View.INVISIBLE
                    spinner.isEnabled=c.isChecked
                    if(!c.isChecked)return@forEachIndexed
                    val values=slotsForWeekday(idx,startDate,endDate,selectedType);val shown=if(values.isEmpty())listOf("NESSUNA FASCIA DISPONIBILE") else values
                    spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,shown)
                    val preferred=if(idx==((forcedDay?:calendarWeekStart).dayOfWeek.value-1))time.selectedItem?.toString()else null
                    if(preferred!=null){val pi=shown.indexOf(preferred);if(pi>=0)spinner.setSelection(pi)}
                    spinner.isEnabled=values.isNotEmpty()
                }
            }
            // Listener collegati dopo la dichiarazione della funzione locale: evita riferimenti non risolti in Kotlin.
            checks.forEach{c->c.setOnCheckedChangeListener{_,_->refreshDayTimeRows()}}
            type.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{
                override fun onNothingSelected(parent:AdapterView<*>?){ }
                override fun onItemSelected(parent:AdapterView<*>?,view:View?,position:Int,id:Long){
                    refreshTimeSlots()
                    if(repeat.isChecked) refreshDayTimeRows()
                }
            }
            var dialogRef:AlertDialog?=null
            repeat.setOnCheckedChangeListener{_,checked->
                repeatPanel.visibility=if(checked)View.VISIBLE else View.GONE
                end.visibility=if(checked)View.VISIBLE else View.GONE
                time.visibility=if(checked)View.GONE else View.VISIBLE
                recovery?.visibility=if(checked)View.GONE else if(recovery?.isEnabled==true)View.VISIBLE else View.GONE
                refreshDayTimeRows()
                dialogRef?.window?.let{w->
                    val target=if(checked)ViewGroup.LayoutParams.WRAP_CONTENT else ViewGroup.LayoutParams.WRAP_CONTENT
                    w.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),target)
                }
                if(checked){
                    repeatPanel.alpha=0f
                    repeatPanel.translationY=-dp(10).toFloat()
                    repeatPanel.animate().alpha(1f).translationY(0f).setDuration(180).start()
                    // Dopo l'espansione porta automaticamente la nuova sezione in vista,
                    // lasciando comunque lo ScrollView libero di muoversi in entrambe le direzioni.
                    scroll.postDelayed({
                        val target=(repeatPanel.top-dp(12)).coerceAtLeast(0)
                        scroll.smoothScrollTo(0,target)
                    },220)
                } else {
                    scroll.post{scroll.smoothScrollTo(0,0)}
                }
            }
            date.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){refreshTimeSlots();if(repeat.isChecked)refreshDayTimeRows();refreshRecoveryOption()};override fun afterTextChanged(s:Editable?){}})
            name.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){refreshRecoveryOption()};override fun afterTextChanged(s:Editable?){}})
            end.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){if(repeat.isChecked)refreshDayTimeRows()};override fun afterTextChanged(s:Editable?){}})

            val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            val cancel=TextView(this).apply{text="Annulla";textSize=14f;setTextColor(Color.rgb(20,91,165));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(220,226,234),1);isClickable=true;applyLiquidControlDepth(this)}
            val save=TextView(this).apply{text="✓ Salva";textSize=14f;setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);background=liquidInteractiveSurface(Color.rgb(232,243,255),20,Color.rgb(188,211,238),1);isClickable=true;applyLiquidControlDepth(this)}
            actions.addView(cancel,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(6),0)})
            actions.addView(save,LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(6),0,0,0)})
            page.addView(actions,LinearLayout.LayoutParams(-1,dp(48)))
            page.setPadding(dp(18),dp(14),dp(18),dp(24))

            listOf<View>(name,date,end).forEach{field->field.setOnFocusChangeListener{_,hasFocus->if(hasFocus)scroll.post{scroll.smoothScrollTo(0,(field.top-dp(24)).coerceAtLeast(0))}}}
            val dialog=AlertDialog.Builder(this).setView(scroll).create()
            preparePopupBackdrop(dialog)
            dialog.setOnShowListener{
                popupBackdropCurrentDialog=dialog
                dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28))
                applyPopupBackdropEffect(dialog);dialog.window?.setDimAmount(0.40f)
                dialog.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
                dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT)
                animateCalendarDialog(dialog,scroll)
                name.clearFocus();date.clearFocus();end.clearFocus()
            }
            cancel.setOnClickListener{dialog.dismiss()}
            save.setOnClickListener{
                val selectedDayTimes=dayTimes.filterKeys{checks[it].isChecked}.mapValues{it.value.selectedItem?.toString() ?: ""}
                createAppointments(name.text.toString().trim(),date.text.toString(),time.selectedItem?.toString() ?: "",typeIdAt(type.selectedItemPosition),repeat.isChecked,checks,end.text.toString(),recovery?.isChecked==true,dayTimes=selectedDayTimes)
                dialog.dismiss()
            }
            dialogRef=dialog
            dialog.show()
            refreshTimeSlots()
            refreshRecoveryOption()
            refreshDayTimeRows()
        }else{
            val page=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(14),dp(18),dp(18))}
            val scroll=ScrollView(this).apply{isFillViewport=true;clipToPadding=false;setPadding(0,0,0,dp(8));addView(page,ViewGroup.LayoutParams(-1,-2))}

            val top=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_HORIZONTAL}
            val icon=TextView(this).apply{
                text="✎";textSize=24f;gravity=Gravity.CENTER;setTextColor(Color.rgb(25,105,190))
                background=roundedSurface(Color.rgb(225,239,255),50);setPadding(dp(12),dp(10),dp(12),dp(10))
            }
            top.addView(icon,LinearLayout.LayoutParams(dp(64),dp(64)).apply{gravity=Gravity.CENTER})
            top.addView(TextView(this).apply{text="Modifica appuntamento";textSize=22f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(24,35,50));gravity=Gravity.CENTER;setPadding(0,dp(10),0,dp(2))},LinearLayout.LayoutParams(-1,dp(38)))
            top.addView(TextView(this).apply{text="Modifica i dati dell'appuntamento";textSize=13.5f;setTextColor(Color.rgb(88,98,110));gravity=Gravity.CENTER;setPadding(0,0,0,dp(12))},LinearLayout.LayoutParams(-1,dp(30)))
            page.addView(top)

            fun label(t:String)=TextView(this).apply{text=t;textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,78,88));setPadding(dp(2),0,0,dp(5))}
            fun modernAuto(v:AutoCompleteTextView){v.background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(220,226,234),1);applyLiquidControlDepth(v);v.setPadding(dp(14),0,dp(14),0);v.textSize=16f;v.setTextColor(Color.rgb(35,38,42));v.setHintTextColor(Color.rgb(135,140,147))}
            fun modernSpinner(v:Spinner){v.background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(220,226,234),1);applyLiquidControlDepth(v);v.setPadding(dp(12),0,dp(10),0)}
            modernAuto(name)
            styleClientNameSuggestions(name)
            // date è un EditText: manteniamo il campo moderno separato.
            date.background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(220,226,234),1);applyLiquidControlDepth(date);date.setPadding(dp(14),0,dp(14),0);date.textSize=16f
            modernSpinner(time);modernSpinner(type);installNikiTypeDropdown(type)
            val fields=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(2),0,dp(2),0)}
            fields.addView(label("Cognome e Nome"));fields.addView(name,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(10))})
            fields.addView(label("Data"));fields.addView(date,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(10))})
            fields.addView(label("Fascia oraria"));fields.addView(time,LinearLayout.LayoutParams(dp(110),dp(50)).apply{gravity=Gravity.CENTER;setMargins(0,0,0,dp(10))})
            fields.addView(label("Tipo appuntamento"));fields.addView(type,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(8))})
            page.addView(fields)
            if(seriesEdit!=null){
                page.addView(seriesEdit,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(6),0,dp(8))})
            }
            val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            val cancel=TextView(this).apply{text="Annulla";textSize=14f;setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);background=liquidInteractiveSurface(Color.rgb(248,249,251),20,Color.rgb(218,225,234),1);isClickable=true;applyLiquidControlDepth(this)}
            val save=TextView(this).apply{text="✓ Salva";textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;background=liquidInteractiveSurface(Color.rgb(232,243,255),20,Color.rgb(188,211,238),1);isClickable=true;applyLiquidControlDepth(this)}
            actions.addView(cancel,LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(0,0,dp(5),0)});actions.addView(save,LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(dp(5),0,0,0)})
            page.addView(actions,LinearLayout.LayoutParams(-1,dp(50)))
            listOf<View>(name,date).forEach{field->field.setOnFocusChangeListener{_,hasFocus->if(hasFocus)scroll.post{scroll.smoothScrollTo(0,(field.top-dp(20)).coerceAtLeast(0))}}}
            // La schermata di modifica usa esattamente la stessa struttura Glass
            // della schermata "Nuovo appuntamento": una sola superficie sulla finestra,
            // senza un secondo pannello Glass interno che crea una doppia fascia in basso.
            val dialog=AlertDialog.Builder(this).setView(scroll).create()
            preparePopupBackdrop(dialog)
            dialog.setOnShowListener{
                popupBackdropCurrentDialog=dialog
                dialog.window?.apply{
                    setBackgroundDrawable(roundedSurface(Color.WHITE,28))
                    setDimAmount(0.40f)
                    setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),ViewGroup.LayoutParams.WRAP_CONTENT)
                    setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN or android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
                }
                applyPopupBackdropEffect(dialog)
                animateCalendarDialog(dialog,scroll)
            }
            cancel.setOnClickListener{dialog.dismiss()}
            save.setOnClickListener{updateAppointment(existing,name.text.toString().trim(),date.text.toString(),time.selectedItem?.toString() ?: "",typeIdAt(type.selectedItemPosition));dialog.dismiss()}
            dialog.show();refreshTimeSlots();seriesEdit?.setOnClickListener{dialog.dismiss();editSeriesProgramming(existing!!)}
        }
    }

    private fun editSeriesProgramming(anchor:Appointment){
        val seriesId=anchor.seriesId
        if(seriesId==0L)return
        val series=appointments.filter{it.seriesId==seriesId}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
        if(series.isEmpty())return
        val future=series.filter{!it.date.isBefore(anchor.date)}
        if(future.isEmpty())return
        val endDate=series.maxOf{it.date}

        val page=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(18),dp(10),dp(18),dp(12))
        }
        val scroll=ScrollView(this).apply{
            isFillViewport=true
            clipToPadding=false
            setPadding(0,0,0,dp(18))
            addView(page,ViewGroup.LayoutParams(-1,-2))
        }

        // Header Niki UI: icona grafica + titolo + contesto, senza emoji.
        val header=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(12),dp(10),dp(12),dp(12))
            background=liquidInteractiveSurface(Color.rgb(238,246,255),22,Color.rgb(194,220,247),1)
        }
        val icon=TextView(this).apply{
            text="↻";textSize=30f;gravity=Gravity.CENTER
            setTextColor(Color.rgb(25,92,170))
            background=liquidInteractiveSurface(Color.rgb(222,237,255),20)
        }
        header.addView(icon,LinearLayout.LayoutParams(dp(56),dp(56)))
        val headerText=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0)}
        headerText.addView(TextView(this).apply{
            text="Modifica ripetizione";textSize=19f;setTextColor(Color.rgb(24,38,58));setTypeface(null,android.graphics.Typeface.BOLD)
        })
        headerText.addView(TextView(this).apply{
            text="Modifica da ${anchor.date.format(fmt)} in poi";textSize=13f;setTextColor(Color.rgb(82,104,125));setPadding(0,dp(3),0,0)
        })
        header.addView(headerText,LinearLayout.LayoutParams(0,-2,1f))
        page.addView(header,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(12))})

        page.addView(TextView(this).apply{
            text="Scegli i giorni e gli orari della nuova programmazione";textSize=14f;setTextColor(Color.rgb(55,64,76));setPadding(dp(2),0,dp(2),dp(10))
        })

        val type=Spinner(this).apply{adapter=centeredSpinnerAdapter(appointmentTypes.map{it.name});setSelection(typeIndex(anchor.type));installNikiTypeDropdown(this);background=liquidInteractiveSurface(Color.rgb(248,249,251),18,Color.rgb(220,226,234),1);setPadding(dp(14),0,dp(10),0)}
        page.addView(TextView(this).apply{text="Tipo appuntamento";textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,74,80));setPadding(dp(2),0,0,dp(5))})
        page.addView(type,LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,0,0,dp(12))})

        val days=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        page.addView(TextView(this).apply{text="Giorni";textSize=12.5f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(70,74,80));setPadding(dp(2),0,0,dp(6))})

        val checks=(0..6).map{i->CheckBox(this).apply{
            text=dayShort(i);textSize=15f;setTextColor(Color.rgb(35,38,42));setPadding(0,0,0,0);isChecked=future.any{it.date.dayOfWeek.value-1==i}
        }}
        val dayTimes=mutableMapOf<Int,Spinner>()
        val rows=mutableMapOf<Int,LinearLayout>()

        fun datesForDay(dayIndex:Int):List<LocalDate>{
            val out=mutableListOf<LocalDate>();var d=anchor.date
            while(!d.isAfter(endDate)){if(d.dayOfWeek.value-1==dayIndex)out.add(d);d=d.plusDays(1)}
            return out
        }
        fun availableSeriesSlots(dayIndex:Int,selectedType:String):List<String>{
            val dates=datesForDay(dayIndex)
            if(dates.isEmpty())return emptyList()
            val first=availableTimeSlotsAfterSeriesRemoval(dates.first(),selectedType,seriesId)
            return first.filter{slot->dates.all{d->canAddAfterSeriesRemoval(d,slot,selectedType,seriesId)}}
        }
        fun refresh(){
            val selectedType=typeIdAt(type.selectedItemPosition)
            checks.forEachIndexed{idx,c->
                val spinner=dayTimes[idx] ?: return@forEachIndexed
                val row=rows[idx] ?: return@forEachIndexed
                row.alpha=if(c.isChecked)1f else 0.72f
                spinner.visibility=if(c.isChecked)View.VISIBLE else View.INVISIBLE
                if(!c.isChecked)return@forEachIndexed
                val values=availableSeriesSlots(idx,selectedType)
                val shown=if(values.isEmpty())listOf("NESSUNA FASCIA DISPONIBILE") else values
                spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,shown)
                val preferred=future.firstOrNull{it.date.dayOfWeek.value-1==idx}?.time
                if(preferred!=null){val pi=shown.indexOf(preferred);if(pi>=0)spinner.setSelection(pi)}
                spinner.isEnabled=values.isNotEmpty()
            }
        }

        checks.forEachIndexed{idx,c->
            val row=LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
                setPadding(dp(12),dp(2),dp(8),dp(2))
                background=liquidInteractiveSurface(Color.rgb(248,249,251),18,Color.rgb(220,226,234),1)
            }
            row.addView(c,LinearLayout.LayoutParams(0,dp(50),1f))
            val spinner=Spinner(this).also{
                installNikiTimeDropdown(it, true)
                it.background=liquidInteractiveSurface(Color.rgb(248,249,251),16,Color.rgb(220,226,234),1)
                it.setPadding(dp(10),0,dp(6),0)
            }
            dayTimes[idx]=spinner
            row.addView(spinner,LinearLayout.LayoutParams(dp(110),dp(46)).apply{gravity=Gravity.CENTER_VERTICAL})
            rows[idx]=row
            days.addView(row,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,0,0,dp(6))})
            c.setOnCheckedChangeListener{_,_->refresh()}
        }
        page.addView(days,LinearLayout.LayoutParams(-1,-2))

        val endCard=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(12),dp(10),dp(12),dp(10))
            background=liquidInteractiveSurface(Color.rgb(232,243,255),18,Color.rgb(192,220,248),1)
        }
        endCard.addView(TextView(this).apply{text="▣";textSize=22f;setTextColor(Color.rgb(25,92,170));gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(38),dp(38)))
        endCard.addView(TextView(this).apply{
            text="Fine programmazione: ${endDate.format(fmt)}\nVerranno aggiornati gli appuntamenti futuri selezionati.";textSize=13f;setTextColor(Color.rgb(55,74,96));setLineSpacing(0f,1.05f);setPadding(dp(8),0,0,0)
        },LinearLayout.LayoutParams(0,-2,1f))
        page.addView(endCard,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(8),0,dp(12))})

        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val cancel=TextView(this).apply{
            text="Annulla";textSize=14f;setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;setTypeface(null,android.graphics.Typeface.BOLD);isClickable=true
            background=liquidInteractiveSurface(Color.rgb(248,249,251),18,Color.rgb(188,211,238),1)
        }
        val save=TextView(this).apply{
            text="✓ Salva";textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(35,91,145));gravity=Gravity.CENTER;isClickable=true
            background=liquidInteractiveSurface(Color.rgb(232,243,255),18,Color.rgb(188,211,238),1);applyLiquidControlDepth(this)
        }
        actions.addView(cancel,LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(0,0,dp(5),0)})
        actions.addView(save,LinearLayout.LayoutParams(0,dp(50),1f).apply{setMargins(dp(5),0,0,0)})
        page.addView(actions,LinearLayout.LayoutParams(-1,dp(50)))

        type.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent:AdapterView<*>?){ }
            override fun onItemSelected(parent:AdapterView<*>?,view:View?,position:Int,id:Long){refresh()}
        }
        val dialog=AlertDialog.Builder(this).setView(scroll).create()
        styleFullPageCoachDialog(dialog)
        cancel.setOnClickListener{dialog.dismiss()}
        save.setOnClickListener{
            val selected=checks.mapIndexedNotNull{idx,c->if(c.isChecked)idx else null}
            if(selected.isEmpty()){Toast.makeText(this,"Seleziona almeno un giorno.",Toast.LENGTH_LONG).show();return@setOnClickListener}
            val selectedType=typeIdAt(type.selectedItemPosition)
            val times=selected.associateWith{idx->dayTimes[idx]?.selectedItem?.toString()?.takeUnless{it=="NESSUNA FASCIA DISPONIBILE"}}
            if(times.values.any{it==null}){Toast.makeText(this,"Scegli un orario disponibile per ogni giorno selezionato.",Toast.LENGTH_LONG).show();return@setOnClickListener}
            applySeriesProgrammingFrom(anchor,selected,times.mapValues{it.value!!},selectedType,endDate)
            dialog.dismiss()
        }
        dialog.show()
        animateSeriesProgrammingIn(dialog,scroll)
        refresh()
    }

    private fun animateSeriesProgrammingIn(dialog: AlertDialog, content: View){
        dialog.window?.attributes = dialog.window?.attributes?.apply{windowAnimations=0}
        content.animate().cancel()
        content.alpha=0f
        content.translationX=dp(34).toFloat()
        content.scaleX=0.985f
        content.scaleY=0.985f
        content.animate().alpha(1f).translationX(0f).scaleX(1f).scaleY(1f)
            .setDuration(210)
            .setInterpolator(android.view.animation.DecelerateInterpolator(1.15f))
            .withLayer().start()
    }

    private fun availableTimeSlotsAfterSeriesRemoval(date:LocalDate,type:String,seriesId:Long):List<String>{
        return (0 until 20).map{slot -> val mins=7*60+slot*45; String.format("%02d:%02d",mins/60,mins%60)}.filter{slot->canAddAfterSeriesRemoval(date,slot,type,seriesId)}
    }

    private fun canAddAfterSeriesRemoval(date:LocalDate,time:String,type:String,seriesId:Long):Boolean{
        val r=calendarRoutines.getOrNull(activeRoutineIndex)?:CalendarRoutine("Personalizzata",3,MutableList(appointmentTypes.size){3})
        val items=appointments.filter{it.date==date&&it.time==time&&it.seriesId!=seriesId}
        if(items.size>=r.maxTotal)return false
        val idx=typeIndex(type);if(items.count{typeIndex(it.type)==idx}>=(r.maxByType.getOrNull(idx)?:r.maxTotal))return false
        return true
    }

    private fun applySeriesProgrammingFrom(anchor:Appointment,selectedDays:List<Int>,dayTimes:Map<Int,String>,type:String,endDate:LocalDate){
        val seriesId=anchor.seriesId
        val future=appointments.filter{it.seriesId==seriesId&&!it.date.isBefore(anchor.date)}
        if(future.isEmpty())return
        val sessionPackId=future.firstOrNull{it.sessionPackId!=0L}?.sessionPackId ?: anchor.sessionPackId
        val futureIds=future.map{it.id}.toSet()
        appointments.removeAll{it.id in futureIds}
        var d=anchor.date;var created=0;var skipped=0
        val linked=sessionPackId.takeIf{it!=0L}?.let{id->sessionPacks.firstOrNull{it.id==id}}
        val usedBefore=linked?.let{s->sessionBooked(s)}?:0
        while(!d.isAfter(endDate)){
            val idx=d.dayOfWeek.value-1
            if(idx in selectedDays){
                val t=dayTimes[idx]!!
                val capacityOk=canAdd(d,t,type)
                val packageOk=linked==null||usedBefore+created<linked.totalSessions
                if(capacityOk&&packageOk){appointments.add(Appointment(nextAppointmentId++,anchor.name,d,t,type,seriesId,sessionPackId,anchor.recovery));created++}else skipped++
            }
            d=d.plusDays(1)
        }
        saveData();calendarScreen()
        if(skipped>0)Toast.makeText(this,"$skipped appuntamenti non inseriti perché la fascia o il pacchetto non erano disponibili.",Toast.LENGTH_LONG).show()
    }

    private fun nikiConfirmDialog(title:String,message:String,positiveText:String,positiveColor:Int=Color.rgb(30,112,230),icon:String="⚠️",onPositive:()->Unit){
        val (dialog,outer,body)=packActionDialogBase(title,icon,positiveColor,if(positiveColor==Color.rgb(205,55,55))Color.rgb(255,235,235) else Color.rgb(232,242,255),Color.WHITE)
        body.addView(dialogBodyText(message))
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        row.addView(dialogButton("Annulla",Color.rgb(50,65,85),Color.rgb(246,248,251),Color.rgb(218,225,232)){dialog.dismiss()},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(0,0,dp(4),0)})
        row.addView(dialogButton(positiveText,Color.WHITE,positiveColor,positiveColor){dialog.dismiss();onPositive()},LinearLayout.LayoutParams(0,dp(48),1f).apply{setMargins(dp(4),0,0,0)})
        body.addView(row)
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels*0.92f).toInt(),WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun dayShort(i:Int)=arrayOf("Lunedì","Martedì","Mercoledì","Giovedì","Venerdì","Sabato","Domenica")[i]
    private fun createAppointments(name:String,dateText:String,timeText:String,type:String,repeat:Boolean,checks:List<CheckBox>,endText:String,recovery:Boolean=false,allowWarnings:Boolean=false,dayTimes:Map<Int,String>?=null){
        try{
            val cleanName=normalizeDisplayName(name);require(cleanName.isNotEmpty());val start=parseDate(dateText);val time=normalizeTime(timeText);val linked=if(recovery)null else activeSessionPackFor(cleanName)
            if(recovery){
                val rp=regularPackFor(cleanName,start) ?: throw IllegalArgumentException("Nessun recupero disponibile")
                if(repeat || recoveriesForPack(rp)<=0) throw IllegalArgumentException("Nessun recupero disponibile")
            }
            if(!allowWarnings){
                val duplicateDates=if(repeat){
                    val end=runCatching{parseDate(endText)}.getOrNull()?:start
                    val selected=checks.mapIndexedNotNull{idx,c->if(c.isChecked)idx+1 else null}.toSet()
                    appointments.filter{identityKey(it.name)==identityKey(cleanName)&&selected.contains(it.date.dayOfWeek.value)&&!it.date.isBefore(start)&&!it.date.isAfter(end)}.map{it.date}.distinct().sorted()
                }else appointments.filter{identityKey(it.name)==identityKey(cleanName)&&it.date==start}.map{it.date}
                if(duplicateDates.isNotEmpty()){
                    val first=appointments.filter{identityKey(it.name)==identityKey(cleanName)&&duplicateDates.contains(it.date)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time}).first()
                    nikiConfirmDialog("Appuntamento già presente",if(repeat)"$cleanName ha già appuntamenti in ${duplicateDates.size} giorno/i della ripetizione. Primo trovato: ${first.date.format(fmt)} alle ${first.time}. Vuoi comunque crearli?" else "$cleanName ha già un appuntamento il ${first.date.format(fmt)} alle ${first.time}. Vuoi comunque creare un altro appuntamento oggi?","Crea comunque"){createAppointments(cleanName,dateText,timeText,type,repeat,checks,endText,recovery,true,dayTimes)}
                    return
                }
                if(linked!=null){
                    val remaining=linked.totalSessions-sessionBooked(linked)
                    val potential=if(!repeat)1 else run {
                        val end=runCatching{parseDate(endText)}.getOrNull()?:start
                        val selected=checks.mapIndexedNotNull{idx,c->if(c.isChecked)idx+1 else null}.toSet()
                        var d=start;var count=0
                        while(!d.isAfter(end)){
                            if(selected.contains(d.dayOfWeek.value)){
                                val dayTime=dayTimes?.get(d.dayOfWeek.value-1)?.let{normalizeTime(it)} ?: time
                                if(canAdd(d,dayTime,type))count++
                            }
                            d=d.plusDays(1)
                        }
                        count
                    }
                    if(remaining>0&&potential>=remaining){
                        nikiConfirmDialog("Ultima seduta del pacchetto","Questa prenotazione utilizzerà l'ultima seduta disponibile di $cleanName. Dopo questa prenotazione il pacchetto risulterà scaduto. Vuoi continuare?","Continua"){createAppointments(cleanName,dateText,timeText,type,repeat,checks,endText,recovery,true,dayTimes)}
                        return
                    }
                }
            }
            if(!repeat){
                if(!canAdd(start,time,type))throw IllegalArgumentException("Fascia piena")
                if(linked!=null&&sessionBooked(linked)>=linked.totalSessions)throw IllegalArgumentException("Pacchetto sedute pieno")
                appointments.add(Appointment(nextAppointmentId++,cleanName,start,time,type,0L,linked?.id?:0L,recovery));saveData();calendarScreen();return
            }
            val end=parseDate(endText);require(!end.isBefore(start));val selected=checks.mapIndexedNotNull{idx,c->if(c.isChecked)idx+1 else null};require(selected.isNotEmpty())
            val series=nextAppointmentId;var d=start;var count=0;var sessionAdded=0
            while(!d.isAfter(end)){
                if(selected.contains(d.dayOfWeek.value)){
                    val dayTime=dayTimes?.get(d.dayOfWeek.value-1)?.let{normalizeTime(it)} ?: time
                    if(canAdd(d,dayTime,type)){appointments.add(Appointment(nextAppointmentId++,cleanName,d,dayTime,type,series,linked?.id?:0L,recovery));sessionAdded++}else count++
                }
                d=d.plusDays(1)
            }
            saveData();calendarScreen();if(count>0)Toast.makeText(this,"$count ripetizioni non inserite perché la fascia o il pacchetto sedute non erano disponibili.",Toast.LENGTH_LONG).show()
        }catch(e:Exception){Toast.makeText(this,if(e.message=="Fascia piena")"Fascia non disponibile: massimo 3 persone e massimo 2 allenamenti." else "Controlla cliente, data, ora e ripetizione.",Toast.LENGTH_LONG).show()}
    }

    private fun normalizeTime(value:String):String{val clean=value.trim();val parts=clean.split(":");require(parts.size==2);val h=parts[0].toInt();val m=parts[1].toInt();require(h in 7..21&&m in 0..59);require((h*60+m-7*60)%45==0);return String.format("%02d:%02d",h,m)}
    private fun updateAppointment(a:Appointment,name:String,dateText:String,timeText:String,type:String){
        try{
            val cleanName=normalizeDisplayName(name);require(cleanName.isNotEmpty());val date=parseDate(dateText);val time=normalizeTime(timeText)
            val duplicate=appointments.firstOrNull{it!==a&&it.date==date&&identityKey(it.name)==identityKey(cleanName)}
            if(duplicate!=null){
                nikiConfirmDialog("Appuntamento già presente","$cleanName ha già un appuntamento il ${date.format(fmt)} alle ${duplicate.time}. Vuoi comunque spostare/modificare questo appuntamento?","Continua"){updateAppointmentConfirmed(a,cleanName,date,time,type)};return
            }
            updateAppointmentConfirmed(a,cleanName,date,time,type)
        }catch(_:Exception){Toast.makeText(this,"Controlla i dati dell'appuntamento.",Toast.LENGTH_LONG).show()}
    }

    private fun updateAppointmentConfirmed(a:Appointment,name:String,date:LocalDate,time:String,type:String){
        if(!canAdd(date,time,type,a)){Toast.makeText(this,"Questa fascia non è disponibile.",Toast.LENGTH_LONG).show();return}
        var linked=if(a.sessionPackId!=0L)sessionPacks.firstOrNull{it.id==a.sessionPackId} else null
        if(linked==null)linked=activeSessionPackFor(name)
        if(linked!=null&&a.sessionPackId!=linked.id){
            val bookedWithoutThis=sessionBooked(linked)-if(a.sessionPackId==linked.id) 1 else 0
            if(bookedWithoutThis>=linked.totalSessions){Toast.makeText(this,"Il pacchetto sedute è già completo.",Toast.LENGTH_LONG).show();return}
            a.sessionPackId=linked.id
        }
        a.name=name;a.date=date;a.time=time;a.type=type;saveData();calendarScreen()
    }

    private fun appointmentDialogForSlot(day:LocalDate,time:String){appointmentDialog(null,day,time)}

    private fun availableTimeSlots(date:LocalDate,type:String,ignore:Appointment?=null):List<String>{
        return (0 until 20).map{slot->
            val mins=7*60+slot*45
            String.format("%02d:%02d",mins/60,mins%60)
        }.filter{slot->canAdd(date,slot,type,ignore)}
    }

    private fun canAdd(date:LocalDate,time:String,type:String,ignore:Appointment?=null):Boolean{
        val r=calendarRoutines.getOrNull(activeRoutineIndex)?:CalendarRoutine("Personalizzata",3,MutableList(appointmentTypes.size){3})
        val items=appointments.filter{it.date==date&&it.time==time&&it!==ignore}
        if(items.size>=r.maxTotal)return false
        val idx=typeIndex(type);if(items.count{typeIndex(it.type)==idx}>=(r.maxByType.getOrNull(idx)?:r.maxTotal))return false
        return true
    }

}
