package com.example.gestionescadenze

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.graphics.drawable.GradientDrawable
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import android.text.Editable
import android.text.TextWatcher
import java.io.BufferedReader
import java.io.InputStreamReader
import java.time.LocalDate
import java.time.format.DateTimeFormatter

private data class Pack(val name: String, val start: LocalDate, val total: Int, var paid: Int = 0)

class MainActivity : Activity() {
    private val fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy")
    private val packs = mutableListOf<Pack>()
    private var ferieStart: LocalDate? = null
    private var ferieEnd: LocalDate? = null
    private lateinit var list: LinearLayout

    companion object {
        private const val REQ_EXPORT = 1001
        private const val REQ_IMPORT = 1002
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        if (android.os.Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(true)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        loadData()
        build()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun buttonStyle(textValue: String): Button = Button(this).apply {
        text = textValue
        textSize = 14f
        setTextColor(Color.rgb(30, 30, 30))
        gravity = Gravity.CENTER
        minHeight = 0
        minimumHeight = 0
        background = GradientDrawable().apply {
            setColor(Color.rgb(235, 238, 242))
            cornerRadius = dp(8).toFloat()
        }
    }

    private fun build() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(12))
            setBackgroundColor(Color.WHITE)
        }

        root.addView(TextView(this).apply {
            text = "Gestione Pagamenti"
            textSize = 28f
            setTextColor(Color.rgb(25, 25, 25))
            gravity = Gravity.CENTER_VERTICAL
        }, LinearLayout.LayoutParams(-1, dp(56)))

        root.addView(TextView(this).apply {
            text = "Pacchetti clienti • 12 settimane • 3 rate"
            textSize = 15f
            setTextColor(Color.DKGRAY)
        }, LinearLayout.LayoutParams(-1, dp(32)))

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val add = buttonStyle("+ Nuovo pacchetto").apply { setOnClickListener { newPack() } }
        val ferie = buttonStyle("Chiusura ferie").apply { setOnClickListener { settings() } }
        buttons.addView(add, LinearLayout.LayoutParams(0, dp(64), 1f))
        buttons.addView(ferie, LinearLayout.LayoutParams(0, dp(64), 1f))
        root.addView(buttons, LinearLayout.LayoutParams(-1, dp(64)))

        root.addView(TextView(this).apply {
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(4), 0, dp(4))
            gravity = Gravity.CENTER_VERTICAL
            text = closureText()
        }, LinearLayout.LayoutParams(-1, dp(34)))

        val backup = buttonStyle("Backup dati: ESPORTA / IMPORTA").apply {
            setOnClickListener { backupMenu() }
        }
        root.addView(backup, LinearLayout.LayoutParams(-1, dp(50)))

        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(12), 0, 0)
        }
        val scroll = ScrollView(this).apply { addView(list, ViewGroup.LayoutParams(-1, -2)) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        render()
    }

    private fun newPack() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), 0)
        }
        val name = EditText(this).apply { hint = "Nome e Cognome" }
        val date = EditText(this).apply { hint = "Data inizio (gg/mm/aaaa)"; inputType = 2 }
        setupDateInput(date)
        val cost = EditText(this).apply { hint = "Costo totale (€)"; inputType = 2 }
        box.addView(name); box.addView(date); box.addView(cost)

        AlertDialog.Builder(this)
            .setTitle("Nuovo pacchetto")
            .setView(box)
            .setNegativeButton("Annulla", null)
            .setPositiveButton("Crea") { _, _ ->
                try {
                    val n = name.text.toString().trim()
                    val d = parseDate(date.text.toString())
                    val c = cost.text.toString().trim().toInt()
                    require(n.isNotEmpty() && c > 0)
                    packs.add(Pack(n, d, c))
                    saveData()
                    render()
                } catch (_: Exception) {
                    Toast.makeText(this, "Controlla nome, data e costo.", Toast.LENGTH_LONG).show()
                }
            }.show()
    }

    private fun setupDateInput(edit: EditText) {
        edit.addTextChangedListener(object : TextWatcher {
            private var editing = false
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (editing || s == null) return
                val digits = s.toString().filter { it.isDigit() }.take(8)
                val formatted = buildString {
                    digits.forEachIndexed { i, c ->
                        if (i == 2 || i == 4) append('/')
                        append(c)
                    }
                }
                if (formatted != s.toString()) {
                    editing = true
                    edit.setText(formatted)
                    edit.setSelection(formatted.length)
                    editing = false
                }
            }
        })
    }

    private fun parseDate(value: String): LocalDate {
        val clean = value.trim()
        return LocalDate.parse(clean, fmt)
    }

    private fun settings() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, dp(16), 0)
        }
        val s = EditText(this).apply {
            hint = "Inizio chiusura (gg/mm/aaaa)"
            inputType = 2
            ferieStart?.let { setText(it.format(fmt)) }
        }
        val e = EditText(this).apply {
            hint = "Fine chiusura (gg/mm/aaaa)"
            inputType = 2
            ferieEnd?.let { setText(it.format(fmt)) }
        }
        setupDateInput(s); setupDateInput(e)
        box.addView(s); box.addView(e)

        AlertDialog.Builder(this)
            .setTitle("Chiusura ferie")
            .setMessage("Inserisci le due date. Le scadenze che cadono nella chiusura vengono spostate al giorno successivo alla riapertura.")
            .setView(box)
            .setNegativeButton("Annulla", null)
            .setNeutralButton("Cancella ferie") { _, _ ->
                ferieStart = null
                ferieEnd = null
                saveData()
                build()
            }
            .setPositiveButton("SALVA") { _, _ ->
                try {
                    val start = parseDate(s.text.toString())
                    val end = parseDate(e.text.toString())
                    require(!end.isBefore(start))
                    ferieStart = start
                    ferieEnd = end
                    saveData()
                    build()
                    Toast.makeText(this, "Chiusura ferie salvata.", Toast.LENGTH_SHORT).show()
                } catch (_: Exception) {
                    Toast.makeText(this, "Inserisci date valide, ad esempio 27/07/2026 e 06/09/2026.", Toast.LENGTH_LONG).show()
                }
            }.show()
    }

    private fun backupMenu() {
        AlertDialog.Builder(this)
            .setTitle("Backup dati")
            .setItems(arrayOf("Esporta dati", "Importa dati")) { _, which ->
                if (which == 0) exportData() else importData()
            }
            .show()
    }

    private fun exportData() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, "GestionePagamenti_backup.json")
        }
        startActivityForResult(intent, REQ_EXPORT)
    }

    private fun importData() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
        }
        startActivityForResult(intent, REQ_IMPORT)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            REQ_EXPORT -> writeBackup(uri)
            REQ_IMPORT -> readBackup(uri)
        }
    }

    private fun backupJson(): JSONObject {
        val root = JSONObject()
        root.put("format", "GestionePagamenti")
        root.put("version", 1)
        root.put("exportedAt", java.time.LocalDateTime.now().toString())
        root.put("ferieStart", ferieStart?.toString() ?: JSONObject.NULL)
        root.put("ferieEnd", ferieEnd?.toString() ?: JSONObject.NULL)
        val array = JSONArray()
        packs.forEach { p ->
            val rates = ratesFor(p)
            val dates = dueDates(p)
            val o = JSONObject()
            o.put("name", p.name)
            o.put("start", p.start.toString())
            o.put("total", p.total)
            o.put("paid", p.paid)
            val due = JSONArray()
            dates.forEach { due.put(it.toString()) }
            o.put("dueDates", due)
            val amounts = JSONArray()
            rates.forEach { amounts.put(it) }
            o.put("rateAmounts", amounts)
            array.put(o)
        }
        root.put("packs", array)
        return root
    }

    private fun writeBackup(uri: Uri) {
        try {
            contentResolver.openOutputStream(uri)?.use { out ->
                out.write(backupJson().toString(2).toByteArray(Charsets.UTF_8))
            }
            Toast.makeText(this, "Backup esportato correttamente.", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Impossibile esportare il backup.", Toast.LENGTH_LONG).show()
        }
    }

    private fun readBackup(uri: Uri) {
        try {
            val text = contentResolver.openInputStream(uri)?.use { input ->
                BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
            } ?: throw Exception("file vuoto")
            val root = JSONObject(text)
            require(root.optString("format") == "GestionePagamenti")

            val newPacks = mutableListOf<Pack>()
            val array = root.getJSONArray("packs")
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                newPacks.add(
                    Pack(
                        o.getString("name"),
                        LocalDate.parse(o.getString("start")),
                        o.getInt("total"),
                        o.optInt("paid", 0)
                    )
                )
            }

            ferieStart = if (root.isNull("ferieStart")) null else LocalDate.parse(root.getString("ferieStart"))
            ferieEnd = if (root.isNull("ferieEnd")) null else LocalDate.parse(root.getString("ferieEnd"))
            packs.clear()
            packs.addAll(newPacks)
            saveData()
            build()
            Toast.makeText(this, "Backup importato: dati, ferie e pagamenti ripristinati.", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Backup non valido o non leggibile.", Toast.LENGTH_LONG).show()
        }
    }

    private fun saveData() {
        val prefs = getSharedPreferences("gestione_pagamenti", MODE_PRIVATE)
        val array = JSONArray()
        packs.forEach { p ->
            array.put(JSONObject().apply {
                put("name", p.name)
                put("start", p.start.toString())
                put("total", p.total)
                put("paid", p.paid)
            })
        }
        prefs.edit()
            .putString("packs", array.toString())
            .putString("ferieStart", ferieStart?.toString())
            .putString("ferieEnd", ferieEnd?.toString())
            .apply()
    }

    private fun loadData() {
        val prefs = getSharedPreferences("gestione_pagamenti", MODE_PRIVATE)
        packs.clear()
        val saved = prefs.getString("packs", null)
        if (!saved.isNullOrEmpty()) {
            try {
                val array = JSONArray(saved)
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)
                    packs.add(Pack(o.getString("name"), LocalDate.parse(o.getString("start")), o.getInt("total"), o.optInt("paid", 0)))
                }
            } catch (_: Exception) { packs.clear() }
        }
        ferieStart = prefs.getString("ferieStart", null)?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        ferieEnd = prefs.getString("ferieEnd", null)?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
    }

    private fun ratesFor(p: Pack): List<Int> {
        val r1 = p.total / 3
        return listOf(r1, r1, p.total - r1 * 2)
    }

    private fun dueDates(p: Pack): List<LocalDate> {
        val out = mutableListOf<LocalDate>()
        var d = p.start
        repeat(3) {
            out.add(d)
            d = advance(d, 28)
        }
        return out
    }

    private fun advance(d0: LocalDate, days: Int): LocalDate {
        var d = d0.plusDays(days.toLong())
        val fs = ferieStart
        val fe = ferieEnd
        if (fs != null && fe != null && !fe.isBefore(fs) && !d.isBefore(fs) && !d.isAfter(fe)) {
            d = fe.plusDays(1)
        }
        return d
    }

    private fun closureText(): String {
        val fs = ferieStart
        val fe = ferieEnd
        return if (fs != null && fe != null) "🏖 Chiusura ferie: ${fs.format(fmt)} → ${fe.format(fmt)}" else "Nessuna chiusura ferie impostata"
    }

    private fun render() {
        list.removeAllViews()
        if (packs.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "Nessun pacchetto inserito."
                textSize = 18f
                setTextColor(Color.DKGRAY)
                setPadding(0, dp(12), 0, dp(12))
            })
            return
        }
        packs.sortedWith(compareBy<Pack> {
            val rates = ratesFor(it)
            statusRank(statusFor(it, rates, dueDates(it)))
        }.thenBy { it.start }.thenBy { it.name.lowercase() }).forEach { card(it) }
    }

    private fun card(p: Pack) {
        val rates = ratesFor(p)
        val dates = dueDates(p)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setBackgroundColor(Color.rgb(245, 247, 250))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            isClickable = true
            isFocusable = true
            setPadding(0, dp(4), 0, dp(4))
        }
        val status = statusFor(p, rates, dates)
        val dot = TextView(this).apply { text = "●"; textSize = 18f; setTextColor(status.color); gravity = Gravity.CENTER; setPadding(0,0,dp(8),0) }
        val headerText = TextView(this).apply { text = p.name; textSize = 19f; setTextColor(Color.rgb(20,20,20)); gravity = Gravity.CENTER_VERTICAL }
        val statusText = TextView(this).apply { text = status.label; textSize = 13f; setTextColor(status.color); gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8),0,0,0) }
        val arrow = TextView(this).apply { text = "▾"; textSize = 20f; setTextColor(Color.DKGRAY); gravity = Gravity.CENTER; setPadding(dp(8),0,0,0) }
        header.addView(dot, LinearLayout.LayoutParams(dp(24), dp(44)))
        header.addView(headerText, LinearLayout.LayoutParams(0, dp(44), 1f))
        header.addView(statusText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)))
        header.addView(arrow, LinearLayout.LayoutParams(dp(36), dp(44)))
        card.addView(header)

        val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        details.addView(TextView(this).apply { text = "Partenza: ${p.start.format(fmt)}    Totale: €${p.total}"; textSize = 14f; setTextColor(Color.DKGRAY); setPadding(0,dp(2),0,dp(8)) })
        for (i in 0..2) {
            val isPaid = p.paid >= rates.take(i+1).sum()
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val text = TextView(this).apply { this.text = "Rata ${i+1}: €${rates[i]} • ${dates[i].format(fmt)}${if (isPaid) " ✓ pagata" else ""}"; textSize=15f; setTextColor(Color.rgb(30,30,30)); gravity=Gravity.CENTER_VERTICAL }
            row.addView(text, LinearLayout.LayoutParams(0,dp(48),1f))
            if (!isPaid) row.addView(Button(this).apply { this.text="PAGA"; setOnClickListener { p.paid=rates.take(i+1).sum(); saveData(); render() } })
            details.addView(row)
        }
        details.addView(Button(this).apply {
            text = "Gestisci"
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setTitle(p.name)
                    .setItems(arrayOf("Segna tutto pagato", "Elimina")) { _, which ->
                        if (which == 0) p.paid = p.total else packs.remove(p)
                        saveData(); render()
                    }.show()
            }
        })
        card.addView(details)
        header.setOnClickListener { val open = details.visibility != View.VISIBLE; details.visibility = if(open) View.VISIBLE else View.GONE; arrow.text = if(open) "▴" else "▾" }
        list.addView(card, LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,0,0,dp(10)) })
    }

    private data class PackStatus(val label: String, val color: Int)
    private fun statusRank(status: PackStatus): Int = when(status.label) { "SCADUTA" -> 0; "IN SCADENZA" -> 1; else -> 2 }
    private fun statusFor(p: Pack, rates: List<Int>, dates: List<LocalDate>): PackStatus {
        if (p.paid >= p.total) return PackStatus("IN REGOLA", Color.rgb(35,150,70))
        val nextIndex = (0..2).firstOrNull { p.paid < rates.take(it+1).sum() } ?: 2
        val due = dates[nextIndex]
        val today = LocalDate.now()
        return when {
            due.isBefore(today) -> PackStatus("SCADUTA", Color.rgb(210,45,45))
            !due.isAfter(today.plusDays(7)) -> PackStatus("IN SCADENZA", Color.rgb(220,160,20))
            else -> PackStatus("IN REGOLA", Color.rgb(35,150,70))
        }
    }
}
