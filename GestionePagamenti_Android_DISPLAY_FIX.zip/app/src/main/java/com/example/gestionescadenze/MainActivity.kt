package com.example.gestionescadenze

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.graphics.drawable.GradientDrawable
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import android.text.Editable
import android.text.TextWatcher
import java.io.BufferedReader
import java.io.InputStreamReader
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters

private data class Pack(val name: String, val start: LocalDate, val total: Int, var paid: Int = 0, var customRates: MutableList<Int>? = null)
private data class Appointment(
    val id: Long,
    var name: String,
    var date: LocalDate,
    var time: String,
    var type: String,
    var seriesId: Long = 0L
) {
    val duration: Int get() = if (type == "MEZZ'ORA") 30 else 45
}

class MainActivity : Activity() {
    private val fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy")
    private val timeFmt = DateTimeFormatter.ofPattern("HH:mm")
    private val packs = mutableListOf<Pack>()
    private val appointments = mutableListOf<Appointment>()
    private var ferieStart: LocalDate? = null
    private var ferieEnd: LocalDate? = null
    private lateinit var list: LinearLayout
    private var dashboardEnabled = false
    private lateinit var searchInput: EditText
    private var calendarWeekStart: LocalDate = LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    private var nextAppointmentId = 1L
    private var calendarZoom = 1.0f

    companion object {
        private const val REQ_EXPORT = 1001
        private const val REQ_IMPORT = 1002
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        if (android.os.Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(true)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        loadData()
        build()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun buttonStyle(textValue: String): Button = Button(this).apply {
        text = textValue; textSize = 14f; setTextColor(Color.rgb(30,30,30)); gravity = Gravity.CENTER
        minHeight = 0; minimumHeight = 0
        background = GradientDrawable().apply { setColor(Color.rgb(235,238,242)); cornerRadius = dp(8).toFloat() }
    }

    private fun build() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(16),dp(16),dp(12)); setBackgroundColor(Color.WHITE) }
        val titleRow = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        titleRow.addView(TextView(this).apply { text="Gestione Pagamenti"; textSize=28f; setTextColor(Color.rgb(25,25,25)); gravity=Gravity.CENTER_VERTICAL }, LinearLayout.LayoutParams(0,dp(56),1f))
        val dashButton = Button(this).apply {
            text=if(dashboardEnabled) "DASH ●" else "DASH ○"; textSize=12f; setTextColor(Color.rgb(80,85,92)); gravity=Gravity.CENTER; minHeight=0; minimumHeight=0; setPadding(dp(8),0,dp(8),0)
            background=GradientDrawable().apply { setColor(if(dashboardEnabled) Color.rgb(242,244,247) else Color.rgb(248,249,250)); cornerRadius=dp(10).toFloat(); setStroke(dp(1),Color.rgb(220,223,227)) }
            setOnClickListener { dashboardEnabled=!dashboardEnabled; saveData(); updateDashboardButton(this); render() }
        }
        titleRow.addView(dashButton,LinearLayout.LayoutParams(dp(78),dp(42))); root.addView(titleRow,LinearLayout.LayoutParams(-1,dp(56)))
        root.addView(TextView(this).apply { text="Pacchetti clienti • 12 settimane • 3 rate"; textSize=15f; setTextColor(Color.DKGRAY) },LinearLayout.LayoutParams(-1,dp(32)))
        val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val add=buttonStyle("+ Nuovo").apply{setOnClickListener{newPack()}}
        val ferie=buttonStyle("Chiusura ferie").apply{setOnClickListener{settings()}}
        val cal=buttonStyle("📅 Calendario").apply{setOnClickListener{calendarScreen()}}
        buttons.addView(add,LinearLayout.LayoutParams(0,dp(64),1f)); buttons.addView(ferie,LinearLayout.LayoutParams(0,dp(64),1f)); buttons.addView(cal,LinearLayout.LayoutParams(0,dp(64),1f)); root.addView(buttons,LinearLayout.LayoutParams(-1,dp(64)))
        root.addView(TextView(this).apply{textSize=13f;setTextColor(Color.DKGRAY);setPadding(0,dp(4),0,dp(4));gravity=Gravity.CENTER_VERTICAL;text=closureText()},LinearLayout.LayoutParams(-1,dp(34)))
        root.addView(buttonStyle("Backup dati: ESPORTA / IMPORTA").apply{setOnClickListener{backupMenu()}},LinearLayout.LayoutParams(-1,dp(50)))
        searchInput=EditText(this).apply{
            hint="🔎 Cerca cliente"; textSize=15f; setSingleLine(true); setPadding(dp(12),0,dp(12),0)
            background=GradientDrawable().apply{setColor(Color.rgb(247,248,250));cornerRadius=dp(10).toFloat();setStroke(dp(1),Color.rgb(225,228,232))}
            addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){render()};override fun afterTextChanged(s:Editable?){}})
        }
        root.addView(searchInput,LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(8),0,0)})
        list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,dp(12),0,0)}
        val scroll=ScrollView(this).apply{addView(list,ViewGroup.LayoutParams(-1,-2))}; root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root); render()
    }

    private fun updateDashboardButton(button:Button){button.text=if(dashboardEnabled)"DASH ●" else "DASH ○";button.background=GradientDrawable().apply{setColor(if(dashboardEnabled)Color.rgb(242,244,247)else Color.rgb(248,249,250));cornerRadius=dp(10).toFloat();setStroke(dp(1),Color.rgb(220,223,227))}}

    private fun newPack(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(8),dp(16),0)}
        val name=EditText(this).apply{hint="Nome e Cognome"}; val date=EditText(this).apply{hint="Data inizio (gg/mm/aaaa)";inputType=2}; setupDateInput(date); val cost=EditText(this).apply{hint="Costo totale (€)";inputType=2}; box.addView(name);box.addView(date);box.addView(cost)
        AlertDialog.Builder(this).setTitle("Nuovo pacchetto").setView(box).setNegativeButton("Annulla",null).setPositiveButton("Crea"){_,_->try{val n=name.text.toString().trim();val d=parseDate(date.text.toString());val c=cost.text.toString().trim().toInt();require(n.isNotEmpty()&&c>0);packs.add(Pack(n,d,c));saveData();render()}catch(_:Exception){Toast.makeText(this,"Controlla nome, data e costo.",Toast.LENGTH_LONG).show()}}.show()
    }

    private fun setupDateInput(edit:EditText){edit.addTextChangedListener(object:TextWatcher{private var editing=false;override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){};override fun afterTextChanged(s:Editable?){if(editing||s==null)return;val digits=s.toString().filter{it.isDigit()}.take(8);val formatted=buildString{digits.forEachIndexed{i,c->if(i==2||i==4)append('/');append(c)}};if(formatted!=s.toString()){editing=true;edit.setText(formatted);edit.setSelection(formatted.length);editing=false}}})}
    private fun parseDate(value:String):LocalDate=LocalDate.parse(value.trim(),fmt)

    private fun settings(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),0,dp(16),0)};val s=EditText(this).apply{hint="Inizio chiusura (gg/mm/aaaa)";inputType=2;ferieStart?.let{setText(it.format(fmt))}};val e=EditText(this).apply{hint="Fine chiusura (gg/mm/aaaa)";inputType=2;ferieEnd?.let{setText(it.format(fmt))}};setupDateInput(s);setupDateInput(e);box.addView(s);box.addView(e)
        AlertDialog.Builder(this).setTitle("Chiusura ferie").setMessage("Inserisci le due date. Le scadenze che cadono nella chiusura vengono spostate al giorno successivo alla riapertura.").setView(box).setNegativeButton("Annulla",null).setNeutralButton("Cancella ferie"){_,_->ferieStart=null;ferieEnd=null;saveData();build()}.setPositiveButton("SALVA"){_,_->try{val start=parseDate(s.text.toString());val end=parseDate(e.text.toString());require(!end.isBefore(start));ferieStart=start;ferieEnd=end;saveData();build();Toast.makeText(this,"Chiusura ferie salvata.",Toast.LENGTH_SHORT).show()}catch(_:Exception){Toast.makeText(this,"Inserisci date valide, ad esempio 27/07/2026 e 06/09/2026.",Toast.LENGTH_LONG).show()}}.show()
    }

    private fun backupMenu(){AlertDialog.Builder(this).setTitle("Backup dati").setItems(arrayOf("Esporta dati","Importa dati")){_,which->if(which==0)exportData()else importData()}.show()}
    private fun exportData(){startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/json";putExtra(Intent.EXTRA_TITLE,"GestionePagamenti_backup.json")},REQ_EXPORT)}
    private fun importData(){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/json"},REQ_IMPORT)}
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK)return;val uri=data?.data?:return;if(requestCode==REQ_EXPORT)writeBackup(uri)else if(requestCode==REQ_IMPORT)readBackup(uri)}

    private fun backupJson():JSONObject{
        val root=JSONObject();root.put("format","GestionePagamenti");root.put("version",3);root.put("exportedAt",LocalDateTime.now().toString());root.put("ferieStart",ferieStart?.toString()?:JSONObject.NULL);root.put("ferieEnd",ferieEnd?.toString()?:JSONObject.NULL);root.put("dashboardEnabled",dashboardEnabled)
        val array=JSONArray();packs.forEach{p->val rates=ratesFor(p);val dates=dueDates(p);array.put(JSONObject().apply{put("name",p.name);put("start",p.start.toString());put("total",p.total);put("paid",p.paid);put("dueDates",JSONArray().apply{dates.forEach{put(it.toString())}});put("rateAmounts",JSONArray().apply{rates.forEach{put(it)}})})};root.put("packs",array)
        root.put("appointments",JSONArray().apply{appointments.forEach{a->put(JSONObject().apply{put("id",a.id);put("name",a.name);put("date",a.date.toString());put("time",a.time);put("type",a.type);put("seriesId",a.seriesId)})}});return root
    }
    private fun writeBackup(uri:Uri){try{contentResolver.openOutputStream(uri)?.use{it.write(backupJson().toString(2).toByteArray(Charsets.UTF_8))};Toast.makeText(this,"Backup esportato correttamente.",Toast.LENGTH_LONG).show()}catch(_:Exception){Toast.makeText(this,"Impossibile esportare il backup.",Toast.LENGTH_LONG).show()}}
    private fun readBackup(uri:Uri){try{val text=contentResolver.openInputStream(uri)?.use{BufferedReader(InputStreamReader(it,Charsets.UTF_8)).readText()}?:throw Exception();val root=JSONObject(text);require(root.optString("format")=="GestionePagamenti");val newPacks=mutableListOf<Pack>();val array=root.getJSONArray("packs");for(i in 0 until array.length()){val o=array.getJSONObject(i);newPacks.add(Pack(o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("total"),o.optInt("paid",0), o.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}}))};ferieStart=if(root.isNull("ferieStart"))null else LocalDate.parse(root.getString("ferieStart"));ferieEnd=if(root.isNull("ferieEnd"))null else LocalDate.parse(root.getString("ferieEnd"));dashboardEnabled=root.optBoolean("dashboardEnabled",false);val newAppointments=mutableListOf<Appointment>();val ap=root.optJSONArray("appointments");if(ap!=null)for(i in 0 until ap.length()){val o=ap.getJSONObject(i);newAppointments.add(Appointment(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("date")),o.getString("time"),o.optString("type","ALLENAMENTO"),o.optLong("seriesId",0L)))};packs.clear();packs.addAll(newPacks);appointments.clear();appointments.addAll(newAppointments);nextAppointmentId=(appointments.maxOfOrNull{it.id}?:0L)+1;saveData();build();Toast.makeText(this,"Backup importato: dati, ferie, pagamenti e appuntamenti ripristinati.",Toast.LENGTH_LONG).show()}catch(_:Exception){Toast.makeText(this,"Backup non valido o non leggibile.",Toast.LENGTH_LONG).show()}}

    private fun saveData(){
        val prefs=getSharedPreferences("gestione_pagamenti",MODE_PRIVATE);val array=JSONArray();packs.forEach{p->array.put(JSONObject().apply{put("name",p.name);put("start",p.start.toString());put("total",p.total);put("paid",p.paid);put("rateAmounts",JSONArray().apply{ratesFor(p).forEach{put(it)}})})};val ap=JSONArray();appointments.forEach{a->ap.put(JSONObject().apply{put("id",a.id);put("name",a.name);put("date",a.date.toString());put("time",a.time);put("type",a.type);put("seriesId",a.seriesId)})};prefs.edit().putString("packs",array.toString()).putString("appointments",ap.toString()).putString("ferieStart",ferieStart?.toString()).putString("ferieEnd",ferieEnd?.toString()).putBoolean("dashboardEnabled",dashboardEnabled).putLong("nextAppointmentId",nextAppointmentId).apply()
    }
    private fun loadData(){
        val prefs=getSharedPreferences("gestione_pagamenti",MODE_PRIVATE);packs.clear();appointments.clear();val saved=prefs.getString("packs",null);if(!saved.isNullOrEmpty())try{val array=JSONArray(saved);for(i in 0 until array.length()){val o=array.getJSONObject(i);packs.add(Pack(o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("total"),o.optInt("paid",0), o.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}}))}}catch(_:Exception){packs.clear()};val ap=prefs.getString("appointments",null);if(!ap.isNullOrEmpty())try{val array=JSONArray(ap);for(i in 0 until array.length()){val o=array.getJSONObject(i);appointments.add(Appointment(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("date")),o.getString("time"),o.optString("type","ALLENAMENTO"),o.optLong("seriesId",0L)))}}catch(_:Exception){appointments.clear()};nextAppointmentId=maxOf(prefs.getLong("nextAppointmentId",1L),(appointments.maxOfOrNull{it.id}?:0L)+1);ferieStart=prefs.getString("ferieStart",null)?.let{runCatching{LocalDate.parse(it)}.getOrNull()};ferieEnd=prefs.getString("ferieEnd",null)?.let{runCatching{LocalDate.parse(it)}.getOrNull()};dashboardEnabled=prefs.getBoolean("dashboardEnabled",false)
    }

    private fun ratesFor(p:Pack):List<Int>{
        val c=p.customRates
        if(c!=null&&c.size==3&&c.all{it>=0}&&c.sum()==p.total)return c.toList()
        val r1=p.total/3;return listOf(r1,r1,p.total-r1*2)
    }

    private fun saveRates(p:Pack,rates:List<Int>){p.customRates=rates.toMutableList()}

    private fun paymentDialog(p:Pack,index:Int){
        val rates=ratesFor(p);val due=rates[index];val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(8),dp(16),0)}
        box.addView(TextView(this).apply{text="Rata ${index+1} • prevista €$due";textSize=15f;setTextColor(Color.DKGRAY);setPadding(0,0,0,dp(8))})
        val amount=EditText(this).apply{hint="Importo effettivamente pagato (€)";inputType=2;setSingleLine(true);setText(due.toString())};box.addView(amount)
        AlertDialog.Builder(this).setTitle("Registra pagamento").setView(box).setNegativeButton("Annulla",null).setPositiveButton("SALVA"){_,_->
            try{
                val paidNow=amount.text.toString().trim().toInt();require(paidNow>0&&p.paid+paidNow<=p.total)
                val alreadyOnRate=p.paid-rates.take(index).sum();val totalOnRate=alreadyOnRate+paidNow
                p.paid+=paidNow
                val remainingCount=3-(index+1)
                if(totalOnRate>due&&remainingCount>0){
                    val remaining=p.total-p.paid;val base=remaining/remainingCount;val extra=remaining%remainingCount
                    val newRates=rates.toMutableList();newRates[index]=totalOnRate
                    for(j in index+1 until 3)newRates[j]=base+if(j-index-1<extra)1 else 0
                    saveRates(p,newRates)
                }
                saveData();render()
            }catch(_:Exception){Toast.makeText(this,"Importo non valido o superiore al totale residuo.",Toast.LENGTH_LONG).show()}
        }.show()
    }

    private fun editRateDialog(p:Pack,index:Int){
        val rates=ratesFor(p);val firstUnpaid=p.paidRateIndex(rates);if(index<firstUnpaid){Toast.makeText(this,"Questa rata è già pagata.",Toast.LENGTH_SHORT).show();return}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(8),dp(16),0)}
        val amount=EditText(this).apply{hint="Nuovo importo rata";inputType=2;setSingleLine(true);setText(rates[index].toString())};box.addView(amount)
        val laterCount=2-index
        AlertDialog.Builder(this).setTitle("Modifica rata ${index+1}").setMessage(if(laterCount>0)"Modifica questa rata: le rate successive verranno ricalcolate automaticamente per mantenere invariato il totale di €${p.total}." else "Essendo l'ultima rata, l'importo viene calcolato sul residuo del pacchetto.").setView(box).setNegativeButton("Annulla",null).setPositiveButton("SALVA"){_,_->
            try{
                val newAmount=amount.text.toString().trim().toInt();require(newAmount>0)
                val paidBefore=rates.take(index).sum();val alreadyOnRate=p.paid-paidBefore;require(newAmount>=alreadyOnRate)
                val remainingAfter=p.total-paidBefore-newAmount;require(remainingAfter>=0)
                val newRates=rates.toMutableList();newRates[index]=newAmount
                if(laterCount>0){val base=remainingAfter/laterCount;val extra=remainingAfter%laterCount;for(j in index+1..2)newRates[j]=base+if(j-index-1<extra)1 else 0}else require(remainingAfter==0)
                require(newRates.sum()==p.total);saveRates(p,newRates);saveData();render()
            }catch(_:Exception){Toast.makeText(this,"Importo non valido: controlla il residuo del pacchetto.",Toast.LENGTH_LONG).show()}
        }.show()
    }
    private fun dueDates(p:Pack):List<LocalDate>{val out=mutableListOf<LocalDate>();var d=p.start;repeat(3){out.add(d);d=advance(d,28)};return out}
    private fun advance(d0:LocalDate,days:Int):LocalDate{var d=d0.plusDays(days.toLong());val fs=ferieStart;val fe=ferieEnd;if(fs!=null&&fe!=null&&!fe.isBefore(fs)&&!d.isBefore(fs)&&!d.isAfter(fe))d=fe.plusDays(1);return d}
    private fun closureText():String{val fs=ferieStart;val fe=ferieEnd;return if(fs!=null&&fe!=null)"🏖 Chiusura ferie: ${fs.format(fmt)} → ${fe.format(fmt)}" else "Nessuna chiusura ferie impostata"}

    private fun render(){list.removeAllViews();val query=if(::searchInput.isInitialized)searchInput.text.toString().trim().lowercase() else "";val filtered=packs.filter{query.isEmpty()||it.name.lowercase().contains(query)}.sortedWith(compareBy<Pack>{statusRank(statusFor(it,ratesFor(it),dueDates(it)))}.thenBy{it.start}.thenBy{it.name.lowercase()});if(filtered.isEmpty()){list.addView(TextView(this).apply{text=if(packs.isEmpty())"Nessun pacchetto inserito." else "Nessun cliente trovato.";textSize=18f;setTextColor(Color.DKGRAY);setPadding(0,dp(12),0,dp(12))});return};if(dashboardEnabled)renderDashboard(filtered)else filtered.forEach{card(it)}}
    private fun renderDashboard(items:List<Pack>){val groups=listOf(Triple("SCADUTI",Color.rgb(210,45,45),items.filter{statusFor(it,ratesFor(it),dueDates(it)).label=="SCADUTA"}),Triple("IN SCADENZA",Color.rgb(220,160,20),items.filter{statusFor(it,ratesFor(it),dueDates(it)).label=="IN SCADENZA"}),Triple("IN REGOLA",Color.rgb(35,150,70),items.filter{statusFor(it,ratesFor(it),dueDates(it)).label=="IN REGOLA"}));groups.forEach{(label,color,clients)->if(clients.isEmpty())return@forEach;val section=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.rgb(248,249,251))};val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;isClickable=true;isFocusable=true;setPadding(dp(12),dp(4),dp(12),dp(4))};header.addView(TextView(this).apply{text="●";textSize=18f;setTextColor(color);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(28),dp(48)));header.addView(TextView(this).apply{text="$label (${clients.size})";textSize=17f;setTextColor(Color.rgb(35,35,35));gravity=Gravity.CENTER_VERTICAL;setPadding(dp(8),0,0,0)},LinearLayout.LayoutParams(0,dp(48),1f));val arrow=TextView(this).apply{text="▾";textSize=20f;setTextColor(Color.DKGRAY);gravity=Gravity.CENTER};header.addView(arrow,LinearLayout.LayoutParams(dp(36),dp(48)));section.addView(header);val clientsBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE;setPadding(dp(8),0,dp(8),dp(4))};clients.forEach{card(it,clientsBox)};section.addView(clientsBox);header.setOnClickListener{val open=clientsBox.visibility!=View.VISIBLE;clientsBox.visibility=if(open)View.VISIBLE else View.GONE;arrow.text=if(open)"▴" else "▾"};list.addView(section,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})}}
    private fun card(p:Pack,parent:ViewGroup=list){
        val rates=ratesFor(p);val dates=dueDates(p);val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(10),dp(16),dp(10));setBackgroundColor(Color.rgb(245,247,250))}
        val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;isClickable=true;isFocusable=true;setPadding(0,dp(4),0,dp(4))}
        val status=statusFor(p,rates,dates)
        header.addView(TextView(this).apply{text="●";textSize=18f;setTextColor(status.color);gravity=Gravity.CENTER;setPadding(0,0,dp(8),0)},LinearLayout.LayoutParams(dp(24),dp(44)))
        header.addView(TextView(this).apply{text=p.name;textSize=19f;setTextColor(Color.rgb(20,20,20));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,dp(44),1f))
        header.addView(TextView(this).apply{text=status.label;textSize=13f;setTextColor(status.color);gravity=Gravity.CENTER_VERTICAL;setPadding(dp(8),0,0,0)},LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,dp(44)))
        val arrow=TextView(this).apply{text="▾";textSize=20f;setTextColor(Color.DKGRAY);gravity=Gravity.CENTER;setPadding(dp(8),0,0,0)};header.addView(arrow,LinearLayout.LayoutParams(dp(36),dp(44)));card.addView(header)
        val details=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE}
        details.addView(TextView(this).apply{text="Partenza: ${p.start.format(fmt)}    Totale: €${p.total}";textSize=14f;setTextColor(Color.DKGRAY);setPadding(0,dp(2),0,dp(8))})
        for(i in 0..2){
            val isPaid=p.paid>=rates.take(i+1).sum();val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
            val suffix = if(isPaid) " ✓ pagata" else if(i==p.paidRateIndex(rates)) " • parziale €${p.paid-rates.take(i).sum()}" else ""
            row.addView(TextView(this).apply{this.text="Rata ${i+1}: €${rates[i]} • ${dates[i].format(fmt)}$suffix";textSize=15f;setTextColor(Color.rgb(30,30,30));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,dp(48),1f))
            if(!isPaid){
                if(i==p.paidRateIndex(rates)) row.addView(Button(this).apply{this.text="PAGA";setOnClickListener{paymentDialog(p,i)}})
                row.addView(Button(this).apply{this.text="⋮";textSize=18f;setOnClickListener{editRateDialog(p,i)}})
            }
            details.addView(row)
        }
        details.addView(Button(this).apply{text="Gestisci";setOnClickListener{AlertDialog.Builder(this@MainActivity).setTitle(p.name).setItems(arrayOf("Segna tutto pagato","Elimina")){_,which->if(which==0){p.paid=p.total;saveData()}else packs.remove(p);saveData();render()}.show()}})
        card.addView(details)
        header.setOnClickListener{val open=details.visibility!=View.VISIBLE;details.visibility=if(open)View.VISIBLE else View.GONE;arrow.text=if(open)"▴" else "▾"}
        parent.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})
    }

    private fun Pack.paidRateIndex(rates:List<Int>):Int=(0..2).firstOrNull{paid<rates.take(it+1).sum()}?:3

    private data class PackStatus(val label:String,val color:Int)
    private fun statusRank(status:PackStatus):Int=when(status.label){"SCADUTA"->0;"IN SCADENZA"->1;else->2}
    private fun statusFor(p:Pack,rates:List<Int>,dates:List<LocalDate>):PackStatus{if(p.paid>=p.total)return PackStatus("IN REGOLA",Color.rgb(35,150,70));val nextIndex=(0..2).firstOrNull{p.paid<rates.take(it+1).sum()}?:2;val due=dates[nextIndex];val today=LocalDate.now();return when{due.isBefore(today)->PackStatus("SCADUTA",Color.rgb(210,45,45));!due.isAfter(today.plusDays(7))->PackStatus("IN SCADENZA",Color.rgb(220,160,20));else->PackStatus("IN REGOLA",Color.rgb(35,150,70))}}

    // ---------------- CALENDARIO ----------------
    private fun calendarScreen(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),dp(12),dp(10),dp(8));setBackgroundColor(Color.WHITE)}
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        top.addView(buttonStyle("‹").apply{setOnClickListener{calendarWeekStart=calendarWeekStart.minusWeeks(1);calendarScreen()}},LinearLayout.LayoutParams(dp(52),dp(48)))
        top.addView(TextView(this).apply{text="Settimana ${calendarWeekStart.format(fmt)}";textSize=17f;gravity=Gravity.CENTER;setTextColor(Color.rgb(30,30,30))},LinearLayout.LayoutParams(0,dp(48),1f))
        top.addView(buttonStyle("›").apply{setOnClickListener{calendarWeekStart=calendarWeekStart.plusWeeks(1);calendarScreen()}},LinearLayout.LayoutParams(dp(52),dp(48)))
        root.addView(top)
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL};actions.addView(buttonStyle("＋ Appuntamento").apply{setOnClickListener{appointmentDialog(null)}},LinearLayout.LayoutParams(0,dp(48),1f));actions.addView(buttonStyle("Oggi").apply{setOnClickListener{calendarWeekStart=LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));calendarScreen()}},LinearLayout.LayoutParams(dp(90),dp(48)));root.addView(actions,LinearLayout.LayoutParams(-1,dp(52)))
        val titleRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        titleRow.addView(TextView(this).apply{text="${calendarWeekStart.format(fmt)}  →  ${calendarWeekStart.plusDays(6).format(fmt)}";textSize=14f;setTextColor(Color.DKGRAY);gravity=Gravity.CENTER;setPadding(0,dp(4),0,dp(8))},LinearLayout.LayoutParams(0,dp(34),1f))
        val zoomLabel=TextView(this).apply{text="${(calendarZoom*100).toInt()}%";textSize=12f;setTextColor(Color.GRAY);gravity=Gravity.CENTER}
        titleRow.addView(buttonStyle("−").apply{setOnClickListener{calendarZoom=(calendarZoom-0.25f).coerceAtLeast(0.75f);calendarScreen()}},LinearLayout.LayoutParams(dp(44),dp(34)))
        titleRow.addView(zoomLabel,LinearLayout.LayoutParams(dp(44),dp(34)))
        titleRow.addView(buttonStyle("+").apply{setOnClickListener{calendarZoom=(calendarZoom+0.25f).coerceAtMost(1.75f);calendarScreen()}},LinearLayout.LayoutParams(dp(44),dp(34)))
        root.addView(titleRow,LinearLayout.LayoutParams(-1,dp(38)))
        val verticalScroll=ScrollView(this).apply{isFillViewport=false}
        val horizontalScroll=HorizontalScrollView(this).apply{isFillViewport=false;isHorizontalScrollBarEnabled=true}
        val week=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        for(i in 0..6)week.addView(dayColumn(calendarWeekStart.plusDays(i.toLong())),LinearLayout.LayoutParams((dp(178)*calendarZoom).toInt().coerceAtLeast(dp(132)),-2))
        horizontalScroll.addView(week,ViewGroup.LayoutParams(-2,-2))
        verticalScroll.addView(horizontalScroll,ViewGroup.LayoutParams(-2,-2))
        root.addView(verticalScroll,LinearLayout.LayoutParams(-1,0,1f))
        root.addView(buttonStyle("← Torna ai clienti").apply{setOnClickListener{build()}},LinearLayout.LayoutParams(-1,dp(48)))
        setContentView(root)
    }

    private fun dayColumn(day:LocalDate):View{
        val z=calendarZoom
        val col=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding((dp(4)*z).toInt(),0,(dp(4)*z).toInt(),(dp(4)*z).toInt())}
        val today=day==LocalDate.now()
        val headerBg=GradientDrawable().apply{cornerRadius=(dp(12)*z);setColor(if(today)Color.rgb(232,242,255)else Color.rgb(245,247,250));setStroke((dp(1)*z).toInt(),if(today)Color.rgb(150,195,235)else Color.rgb(230,233,238))}
        col.addView(TextView(this).apply{text="${dayShort(day.dayOfWeek.value-1)}\n${day.dayOfMonth.toString().padStart(2,'0')}/${day.monthValue.toString().padStart(2,'0')}";textSize=15f*z;gravity=Gravity.CENTER;setTextColor(if(today)Color.rgb(35,105,180)else Color.rgb(45,45,45));background=headerBg;setPadding(0,(dp(6)*z).toInt(),0,(dp(6)*z).toInt())},LinearLayout.LayoutParams(-1,(dp(58)*z).toInt()).apply{setMargins(0,0,0,(dp(4)*z).toInt())})
        for(slot in 0 until 20){val mins=7*60+slot*45;val hour=mins/60;val minute=mins%60;val time=String.format("%02d:%02d",hour,minute);val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding((dp(5)*z).toInt(),(dp(4)*z).toInt(),(dp(5)*z).toInt(),(dp(4)*z).toInt());background=GradientDrawable().apply{cornerRadius=(dp(9)*z);setColor(if(slot%2==0)Color.rgb(249,250,252)else Color.rgb(255,255,255));setStroke((dp(1)*z).toInt(),Color.rgb(235,237,241))};isClickable=true}
            val items=appointments.filter{it.date==day&&it.time==time}.sortedBy{it.type}
            val countColor=when{items.size>=3->Color.rgb(205,55,55);items.size==2->Color.rgb(210,145,25);else->Color.GRAY}
            val timeRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            timeRow.addView(TextView(this).apply{text=time;textSize=11f*z;setTextColor(Color.rgb(105,110,118));setTypeface(null,android.graphics.Typeface.BOLD)},LinearLayout.LayoutParams(0,(dp(22)*z).toInt(),1f))
            timeRow.addView(TextView(this).apply{text="${items.size}/3";textSize=9f*z;setTextColor(countColor);gravity=Gravity.CENTER},LinearLayout.LayoutParams((dp(30)*z).toInt(),(dp(22)*z).toInt()))
            box.addView(timeRow)
            if(items.isEmpty()){box.addView(TextView(this).apply{text="＋";textSize=18f*z;gravity=Gravity.CENTER;setTextColor(Color.LTGRAY)},LinearLayout.LayoutParams(-1,(dp(42)*z).toInt()));box.setOnClickListener{appointmentDialogForSlot(day,time)}}
            else{val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                items.forEachIndexed{index,a->row.addView(appointmentChip(a),LinearLayout.LayoutParams(0,(dp(46)*z).toInt(),1f).apply{if(index>0)setMargins((dp(3)*z).toInt(),0,0,0)})}
                box.addView(row,LinearLayout.LayoutParams(-1,(dp(46)*z).toInt()))
                box.addView(TextView(this).apply{text="${items.count{it.type=="ALLENAMENTO"}}/2 allenamenti";textSize=8.5f*z;setTextColor(Color.GRAY);gravity=Gravity.CENTER_VERTICAL;setPadding(0,(dp(2)*z).toInt(),0,0)},LinearLayout.LayoutParams(-1,(dp(16)*z).toInt()))
                box.setOnClickListener{appointmentDialogForSlot(day,time)}
            }
            col.addView(box,LinearLayout.LayoutParams(-1,(dp(84)*z).toInt()).apply{setMargins(0,(dp(2)*z).toInt(),0,0)})
        }
        return col
    }

    private fun appointmentChip(a:Appointment):View{
        val isHalf=a.type=="MEZZ'ORA"
        val accent=if(isHalf)Color.rgb(215,55,55)else Color.rgb(45,135,210)
        val bg=if(isHalf)Color.rgb(255,239,239)else Color.rgb(232,244,255)
        val chip=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding((dp(3)*calendarZoom).toInt(),(dp(2)*calendarZoom).toInt(),(dp(3)*calendarZoom).toInt(),(dp(2)*calendarZoom).toInt());background=GradientDrawable().apply{cornerRadius=(dp(8)*calendarZoom);setColor(bg);setStroke((dp(1)*calendarZoom).toInt(),accent)};isClickable=true}
        chip.addView(TextView(this).apply{text="●";textSize=11f*calendarZoom;setTextColor(accent);gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,(dp(13)*calendarZoom).toInt()))
        chip.addView(TextView(this).apply{text=a.name;textSize=9.5f*calendarZoom;setTextColor(Color.rgb(25,30,35));gravity=Gravity.CENTER;maxLines=2;ellipsize=android.text.TextUtils.TruncateAt.END;setTypeface(null,android.graphics.Typeface.BOLD)},LinearLayout.LayoutParams(-1,(dp(25)*calendarZoom).toInt()))
        chip.addView(TextView(this).apply{text=if(isHalf)"30 MIN"else"45 MIN";textSize=7.5f*calendarZoom;setTextColor(accent);gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,(dp(10)*calendarZoom).toInt()))
        chip.setOnClickListener{appointmentActions(a)}
        return chip}

    private fun appointmentActions(a:Appointment){AlertDialog.Builder(this).setTitle("${a.name} • ${a.time}").setItems(arrayOf("✏️ Modifica / sposta","🗑 Elimina")){_,which->if(which==0)appointmentDialog(a)else{appointments.remove(a);saveData();calendarScreen()}}.show()}

    private fun appointmentDialog(existing:Appointment?, forcedDay:LocalDate?=null, forcedTime:String?=null){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(4),dp(14),0)}
        val name=AutoCompleteTextView(this).apply{hint="Cliente";setText(existing?.name?:"");setSingleLine(true);setAdapter(ArrayAdapter(this@MainActivity,android.R.layout.simple_dropdown_item_1line,packs.map{it.name}.distinct().toTypedArray()))}
        val date=EditText(this).apply{hint="Data (gg/mm/aaaa)";inputType=2;setText((existing?.date?:forcedDay?:calendarWeekStart).format(fmt))};setupDateInput(date)
        val time=Spinner(this)
        val type=Spinner(this);type.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("ALLENAMENTO (45 min)","MEZZ'ORA (30 min)"));type.setSelection(if(existing?.type=="MEZZ'ORA")1 else 0)
        box.addView(name);box.addView(date)
        box.addView(TextView(this).apply{text="Fascia oraria disponibile";textSize=13f;setTextColor(Color.DKGRAY);setPadding(0,dp(8),0,dp(3))})
        box.addView(time)
        box.addView(type)

        fun refreshTimeSlots(){
            val selectedType=if(type.selectedItemPosition==1)"MEZZ'ORA" else "ALLENAMENTO"
            val selectedDate=runCatching{parseDate(date.text.toString())}.getOrNull()?: (existing?.date?:forcedDay?:calendarWeekStart)
            val slots=availableTimeSlots(selectedDate,selectedType,existing)
            val values=if(slots.isEmpty()) listOf("NESSUNA FASCIA DISPONIBILE") else slots
            time.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,values)
            val wanted=existing?.time?:forcedTime
            if(wanted!=null){val idx=values.indexOf(wanted);if(idx>=0)time.setSelection(idx)}
        }
        refreshTimeSlots()
        type.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(parent:AdapterView<*>?){ } override fun onItemSelected(parent:AdapterView<*>?,view:View?,position:Int,id:Long){refreshTimeSlots()}}
        date.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){refreshTimeSlots()};override fun afterTextChanged(s:Editable?){}})
        if(existing==null){
            box.addView(TextView(this).apply{text="Ripetizione (facoltativa)";textSize=14f;setTextColor(Color.DKGRAY);setPadding(0,dp(10),0,dp(4))})
            val repeat=CheckBox(this).apply{text="Ripeti ogni settimana"}
            val days=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE}
            val checks=(0..6).map{i->CheckBox(this).apply{text=dayShort(i);isChecked=i==((forcedDay?:calendarWeekStart).dayOfWeek.value-1);setPadding(0,0,0,0)}}
            checks.forEach{days.addView(it)}
            val end=EditText(this).apply{hint="Fine ripetizione (gg/mm/aaaa)";inputType=2;setText(calendarWeekStart.plusWeeks(12).format(fmt));visibility=View.GONE};setupDateInput(end)
            repeat.setOnCheckedChangeListener{_,checked->days.visibility=if(checked)View.VISIBLE else View.GONE;end.visibility=if(checked)View.VISIBLE else View.GONE}
            box.addView(repeat);box.addView(days);box.addView(end)
            AlertDialog.Builder(this).setTitle("Nuovo appuntamento").setView(box).setNegativeButton("Annulla",null).setPositiveButton("SALVA"){_,_->createAppointments(name.text.toString().trim(),date.text.toString(),time.selectedItem?.toString() ?: "",if(type.selectedItemPosition==1)"MEZZ'ORA" else "ALLENAMENTO",repeat.isChecked,checks,end.text.toString())}.show()
        }else{
            AlertDialog.Builder(this).setTitle("Modifica appuntamento").setView(box).setNegativeButton("Annulla",null).setPositiveButton("SALVA"){_,_->updateAppointment(existing,name.text.toString().trim(),date.text.toString(),time.selectedItem?.toString() ?: "",if(type.selectedItemPosition==1)"MEZZ'ORA" else "ALLENAMENTO")}.show()
        }
    }

    private fun dayShort(i:Int)=arrayOf("Lunedì","Martedì","Mercoledì","Giovedì","Venerdì","Sabato","Domenica")[i]
    private fun createAppointments(name:String,dateText:String,timeText:String,type:String,repeat:Boolean,checks:List<CheckBox>,endText:String){try{require(name.isNotEmpty());val start=parseDate(dateText);val time=normalizeTime(timeText);if(!repeat){if(!canAdd(start,time,type))throw IllegalArgumentException("Fascia piena");appointments.add(Appointment(nextAppointmentId++,name,start,time,type));saveData();calendarScreen();return};val end=parseDate(endText);require(!end.isBefore(start));val selected=checks.mapIndexedNotNull{idx,c->if(c.isChecked)idx+1 else null};require(selected.isNotEmpty());val series=nextAppointmentId;var d=start;var count=0;while(!d.isAfter(end)){if(selected.contains(d.dayOfWeek.value)){if(canAdd(d,time,type)){appointments.add(Appointment(nextAppointmentId++,name,d,time,type,series))}else count++};d=d.plusDays(1)};saveData();calendarScreen();if(count>0)Toast.makeText(this,"$count ripetizioni non inserite perché la fascia era incompatibile.",Toast.LENGTH_LONG).show()}catch(e:Exception){Toast.makeText(this,if(e.message=="Fascia piena")"Fascia non disponibile: massimo 3 persone e massimo 2 allenamenti." else "Controlla cliente, data, ora e ripetizione.",Toast.LENGTH_LONG).show()}}

    private fun normalizeTime(value:String):String{val clean=value.trim();val parts=clean.split(":");require(parts.size==2);val h=parts[0].toInt();val m=parts[1].toInt();require(h in 7..21&&m in 0..59);require((h*60+m-7*60)%45==0);return String.format("%02d:%02d",h,m)}
    private fun updateAppointment(a:Appointment,name:String,dateText:String,timeText:String,type:String){try{require(name.isNotEmpty());val date=parseDate(dateText);val time=normalizeTime(timeText);if(!canAdd(date,time,type,a)){Toast.makeText(this,"Questa fascia non è disponibile.",Toast.LENGTH_LONG).show();return};a.name=name;a.date=date;a.time=time;a.type=type;saveData();calendarScreen()}catch(_:Exception){Toast.makeText(this,"Controlla i dati dell'appuntamento.",Toast.LENGTH_LONG).show()}}
    private fun appointmentDialogForSlot(day:LocalDate,time:String){appointmentDialog(null,day,time)}

    private fun availableTimeSlots(date:LocalDate,type:String,ignore:Appointment?=null):List<String>{
        return (0 until 20).map{slot->
            val mins=7*60+slot*45
            String.format("%02d:%02d",mins/60,mins%60)
        }.filter{slot->canAdd(date,slot,type,ignore)}
    }

    private fun canAdd(date:LocalDate,time:String,type:String,ignore:Appointment?=null):Boolean{val items=appointments.filter{it.date==date&&it.time==time&&it!==ignore};if(items.size>=3)return false;if(type=="ALLENAMENTO"&&items.count{it.type=="ALLENAMENTO"}>=2)return false;return true}
}
