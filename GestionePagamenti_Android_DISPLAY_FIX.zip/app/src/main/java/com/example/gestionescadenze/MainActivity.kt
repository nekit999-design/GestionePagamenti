package com.example.gestionescadenze

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.view.View
import android.graphics.drawable.GradientDrawable
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import android.text.Editable
import android.text.TextWatcher
import java.time.LocalDate
import java.time.format.DateTimeFormatter

data class Pack(val name:String, val start:LocalDate, val total:Int, var paid:Int=0)

class MainActivity: Activity() {
    private val fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy")
    private val packs = mutableListOf<Pack>()
    private var ferieStart: LocalDate? = null
    private var ferieEnd: LocalDate? = null
    private lateinit var list: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(true)
        }
        window.decorView.systemUiVisibility =
            android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        loadData()
        build()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun build() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(12))
            setBackgroundColor(Color.WHITE)
        }

        val title = TextView(this).apply {
            text = "Gestione Pagamenti"
            textSize = 28f
            setTextColor(Color.rgb(25,25,25))
            gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(title, LinearLayout.LayoutParams(-1, dp(56)))

        val sub = TextView(this).apply {
            text = "Pacchetti clienti • 12 settimane • 3 rate"
            textSize = 15f
            setTextColor(Color.DKGRAY)
        }
        root.addView(sub, LinearLayout.LayoutParams(-1, dp(32)))

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val add = Button(this).apply {
            text = "+ Nuovo pacchetto"
            textSize = 14f
            setTextColor(Color.rgb(30,30,30))
            gravity = Gravity.CENTER
            minHeight = 0
            minimumHeight = 0
            background = GradientDrawable().apply {
                setColor(Color.rgb(235,238,242))
                cornerRadius = 12f
            }
            setOnClickListener { newPack() }
        }
        val ferie = Button(this).apply {
            text = "Chiusura ferie"
            textSize = 14f
            setTextColor(Color.rgb(30,30,30))
            gravity = Gravity.CENTER
            minHeight = 0
            minimumHeight = 0
            background = GradientDrawable().apply {
                setColor(Color.rgb(235,238,242))
                cornerRadius = 12f
            }
            setOnClickListener { settings() }
        }
        buttons.addView(add, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        buttons.addView(ferie, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(buttons, LinearLayout.LayoutParams(-1, dp(64)))

        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(12), 0, 0)
        }

        val scroll = ScrollView(this).apply {
            addView(list, ViewGroup.LayoutParams(-1, -2))
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        render()
    }

    private fun newPack() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), 0)
        }
        val name = EditText(this).apply { hint = "Nome e Cognome" }
        val date = EditText(this).apply { hint = "Data inizio (gg/mm/aaaa)"; inputType = 2 }
        setupDateInput(date)
        val cost = EditText(this).apply { hint = "Costo totale (€)"; inputType = 2 }
        box.addView(name); box.addView(date); box.addView(cost)

        AlertDialog.Builder(this)
            .setTitle("Nuovo pacchetto")
            .setView(box)
            .setNegativeButton("Annulla", null)
            .setPositiveButton("Crea") { _, _ ->
                try {
                    val n = name.text.toString().trim()
                    val d = LocalDate.parse(date.text.toString().trim(), fmt)
                    val c = cost.text.toString().trim().toInt()
                    require(n.isNotEmpty() && c > 0)
                    packs.add(Pack(n, d, c))
                    saveData()
                    render()
                } catch (_: Exception) {
                    Toast.makeText(this, "Controlla nome, data e costo.", Toast.LENGTH_LONG).show()
                }
            }.show()
    }

    private fun setupDateInput(edit: EditText) {
        edit.addTextChangedListener(object : TextWatcher {
            private var editing = false

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                if (editing || s == null) return
                val digits = s.toString().filter { it.isDigit() }.take(8)
                val formatted = buildString {
                    digits.forEachIndexed { i, c ->
                        if (i == 2 || i == 4) append('/')
                        append(c)
                    }
                }
                if (formatted != s.toString()) {
                    editing = true
                    edit.setText(formatted)
                    edit.setSelection(formatted.length)
                    editing = false
                }
            }
        })
    }

    private fun settings() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, dp(16), 0)
        }
        val s = EditText(this).apply { hint = "Inizio chiusura (gg/mm/aaaa)"; inputType = 2 }
        val e = EditText(this).apply { hint = "Fine chiusura (gg/mm/aaaa)"; inputType = 2 }
        setupDateInput(s)
        setupDateInput(e)
        box.addView(s); box.addView(e)
        AlertDialog.Builder(this)
            .setTitle("Chiusura feriale")
            .setView(box)
            .setNegativeButton("Annulla", null)
            .setPositiveButton("Salva") { _, _ ->
                try {
                    ferieStart = LocalDate.parse(s.text.toString().trim(), fmt)
                    ferieEnd = LocalDate.parse(e.text.toString().trim(), fmt)
                    saveData()
                    render()
                } catch (_: Exception) {
                    Toast.makeText(this, "Date non valide.", Toast.LENGTH_LONG).show()
                }
            }.show()
    }

    private fun saveData() {
        val prefs = getSharedPreferences("gestione_pagamenti", MODE_PRIVATE)
        val array = JSONArray()
        packs.forEach { p ->
            array.put(JSONObject().apply {
                put("name", p.name)
                put("start", p.start.toString())
                put("total", p.total)
                put("paid", p.paid)
            })
        }
        prefs.edit()
            .putString("packs", array.toString())
            .putString("ferieStart", ferieStart?.toString())
            .putString("ferieEnd", ferieEnd?.toString())
            .apply()
    }

    private fun loadData() {
        val prefs = getSharedPreferences("gestione_pagamenti", MODE_PRIVATE)
        packs.clear()
        val saved = prefs.getString("packs", null)
        if (!saved.isNullOrEmpty()) {
            try {
                val array = JSONArray(saved)
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)
                    packs.add(
                        Pack(
                            o.getString("name"),
                            LocalDate.parse(o.getString("start")),
                            o.getInt("total"),
                            o.optInt("paid", 0)
                        )
                    )
                }
            } catch (_: Exception) {
                packs.clear()
            }
        }
        ferieStart = prefs.getString("ferieStart", null)?.let {
            try { LocalDate.parse(it) } catch (_: Exception) { null }
        }
        ferieEnd = prefs.getString("ferieEnd", null)?.let {
            try { LocalDate.parse(it) } catch (_: Exception) { null }
        }
    }

    private fun dueDates(p: Pack): List<LocalDate> {
        val out = mutableListOf<LocalDate>()
        var d = p.start
        repeat(3) {
            out.add(d)
            d = advance(d, 28)
        }
        return out
    }

    private fun advance(d0: LocalDate, days: Int): LocalDate {
        var d = d0.plusDays(days.toLong())
        if (ferieStart != null && ferieEnd != null &&
            !d.isBefore(ferieStart) && !d.isAfter(ferieEnd)) {
            d = ferieEnd!!.plusDays(1)
        }
        return d
    }

    private fun render() {
        list.removeAllViews()
        if (packs.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "Nessun pacchetto inserito."
                textSize = 18f
                setTextColor(Color.DKGRAY)
                setPadding(0, dp(12), 0, dp(12))
            })
            return
        }

        packs.sortedWith(compareBy<Pack> { it.paid >= it.total }.thenBy { it.start })
            .forEach { card(it) }
    }

    private fun card(p: Pack) {
        val r1 = p.total / 3
        val rates = listOf(r1, r1, p.total - r1 * 2)
        val dates = dueDates(p)

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setBackgroundColor(Color.rgb(245,247,250))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            isClickable = true
            isFocusable = true
            setPadding(0, dp(4), 0, dp(4))
        }

        val status = statusFor(p, rates, dates)
        val dot = TextView(this).apply {
            text = "●"
            textSize = 18f
            setTextColor(status.color)
            gravity = Gravity.CENTER
            setPadding(0, 0, dp(8), 0)
        }

        val headerText = TextView(this).apply {
            text = p.name
            textSize = 19f
            setTextColor(Color.rgb(20,20,20))
            gravity = Gravity.CENTER_VERTICAL
        }

        val statusText = TextView(this).apply {
            text = status.label
            textSize = 13f
            setTextColor(status.color)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), 0, 0, 0)
        }

        val arrow = TextView(this).apply {
            text = "▾"
            textSize = 20f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(dp(8), 0, 0, 0)
        }

        header.addView(dot, LinearLayout.LayoutParams(dp(24), dp(44)))
        header.addView(headerText, LinearLayout.LayoutParams(0, dp(44), 1f))
        header.addView(statusText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)))
        header.addView(arrow, LinearLayout.LayoutParams(dp(36), dp(44)))
        card.addView(header)

        val details = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }

        details.addView(TextView(this).apply {
            text = "Partenza: ${p.start.format(fmt)}    Totale: €${p.total}"
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(2), 0, dp(8))
        })

        for (i in 0..2) {
            val isPaid = p.paid >= rates.take(i + 1).sum()
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val text = TextView(this).apply {
                text = "Rata ${i + 1}: €${rates[i]} • ${dates[i].format(fmt)}${if (isPaid) " ✓ pagata" else ""}"
                textSize = 15f
                setTextColor(Color.rgb(30,30,30))
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(text, LinearLayout.LayoutParams(0, dp(48), 1f))
            if (!isPaid) {
                row.addView(Button(this).apply {
                    this.text = "PAGA"
                    setOnClickListener {
                        p.paid = rates.take(i + 1).sum()
                        saveData()
                        render()
                    }
                })
            }
            details.addView(row)
        }

        details.addView(Button(this).apply {
            text = "Gestisci"
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle(p.name)
                    .setItems(arrayOf("Segna tutto pagato", "Elimina")) { _, which ->
                        if (which == 0) {
                            p.paid = p.total
                        } else {
                            packs.remove(p)
                        }
                        saveData()
                        render()
                    }.show()
            }
        })

        card.addView(details)

        header.setOnClickListener {
            val open = details.visibility != View.VISIBLE
            details.visibility = if (open) View.VISIBLE else View.GONE
            arrow.text = if (open) "▴" else "▾"
        }

        val lp = LinearLayout.LayoutParams(-1, -2).apply {
            setMargins(0, 0, 0, dp(10))
        }
        list.addView(card, lp)
    }

    private data class PackStatus(val label: String, val color: Int)

    private fun statusFor(p: Pack, rates: List<Int>, dates: List<LocalDate>): PackStatus {
        if (p.paid >= p.total) {
            return PackStatus("IN REGOLA", Color.rgb(35, 150, 70))
        }

        val nextIndex = (0..2).firstOrNull { p.paid < rates.take(it + 1).sum() } ?: 2
        val due = dates[nextIndex]
        val today = LocalDate.now()

        return when {
            due.isBefore(today) -> PackStatus("SCADUTA", Color.rgb(210, 45, 45))
            !due.isAfter(today.plusDays(7)) -> PackStatus("IN SCADENZA", Color.rgb(220, 160, 20))
            else -> PackStatus("IN REGOLA", Color.rgb(35, 150, 70))
        }
    }

}