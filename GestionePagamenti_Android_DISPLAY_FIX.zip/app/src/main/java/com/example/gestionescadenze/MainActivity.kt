package com.example.gestionescadenze

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter

data class Pack(val name:String, val start:LocalDate, val total:Int, var paid:Int=0)

class MainActivity: Activity() {
    private val fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy")
    private val packs = mutableListOf<Pack>()
    private var ferieStart: LocalDate? = null
    private var ferieEnd: LocalDate? = null
    private lateinit var list: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility =
            android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        build()
    }

    private fun build() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 16)
            setBackgroundColor(Color.WHITE)
        }

        val title = TextView(this).apply {
            text = "Gestione Pagamenti"
            textSize = 28f
            setTextColor(Color.rgb(25,25,25))
            gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 64))

        val sub = TextView(this).apply {
            text = "Pacchetti clienti • 12 settimane • 3 rate"
            textSize = 15f
            setTextColor(Color.DKGRAY)
        }
        root.addView(sub, LinearLayout.LayoutParams(-1, 48))

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val add = Button(this).apply {
            text = "+ Nuovo pacchetto"
            setOnClickListener { newPack() }
        }
        val ferie = Button(this).apply {
            text = "Chiusura ferie"
            setOnClickListener { settings() }
        }
        buttons.addView(add, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        buttons.addView(ferie, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(buttons, LinearLayout.LayoutParams(-1, 64))

        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 18, 0, 0)
        }

        val scroll = ScrollView(this).apply {
            addView(list, ViewGroup.LayoutParams(-1, -2))
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        render()
    }

    private fun newPack() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 8, 20, 0)
        }
        val name = EditText(this).apply { hint = "Nome e Cognome" }
        val date = EditText(this).apply { hint = "Data inizio (gg/mm/aaaa)"; inputType = 2 }
        val cost = EditText(this).apply { hint = "Costo totale (€)"; inputType = 2 }
        box.addView(name); box.addView(date); box.addView(cost)

        AlertDialog.Builder(this)
            .setTitle("Nuovo pacchetto")
            .setView(box)
            .setNegativeButton("Annulla", null)
            .setPositiveButton("Crea") { _, _ ->
                try {
                    val n = name.text.toString().trim()
                    val d = LocalDate.parse(date.text.toString().trim(), fmt)
                    val c = cost.text.toString().trim().toInt()
                    require(n.isNotEmpty() && c > 0)
                    packs.add(Pack(n, d, c))
                    render()
                } catch (_: Exception) {
                    Toast.makeText(this, "Controlla nome, data e costo.", Toast.LENGTH_LONG).show()
                }
            }.show()
    }

    private fun settings() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 0, 20, 0)
        }
        val s = EditText(this).apply { hint = "Inizio chiusura (gg/mm/aaaa)"; inputType = 2 }
        val e = EditText(this).apply { hint = "Fine chiusura (gg/mm/aaaa)"; inputType = 2 }
        box.addView(s); box.addView(e)
        AlertDialog.Builder(this)
            .setTitle("Chiusura feriale")
            .setView(box)
            .setNegativeButton("Annulla", null)
            .setPositiveButton("Salva") { _, _ ->
                try {
                    ferieStart = LocalDate.parse(s.text.toString().trim(), fmt)
                    ferieEnd = LocalDate.parse(e.text.toString().trim(), fmt)
                    render()
                } catch (_: Exception) {
                    Toast.makeText(this, "Date non valide.", Toast.LENGTH_LONG).show()
                }
            }.show()
    }

    private fun dueDates(p: Pack): List<LocalDate> {
        val out = mutableListOf<LocalDate>()
        var d = p.start
        repeat(3) {
            out.add(d)
            d = advance(d, 28)
        }
        return out
    }

    private fun advance(d0: LocalDate, days: Int): LocalDate {
        var d = d0.plusDays(days.toLong())
        if (ferieStart != null && ferieEnd != null &&
            !d.isBefore(ferieStart) && !d.isAfter(ferieEnd)) {
            d = ferieEnd!!.plusDays(1)
        }
        return d
    }

    private fun render() {
        list.removeAllViews()
        if (packs.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "Nessun pacchetto inserito."
                textSize = 18f
                setTextColor(Color.DKGRAY)
                setPadding(0, 12, 0, 12)
            })
            return
        }

        packs.sortedWith(compareBy<Pack> { it.paid >= it.total }.thenBy { it.start })
            .forEach { card(it) }
    }

    private fun card(p: Pack) {
        val r1 = p.total / 3
        val rates = listOf(r1, r1, p.total - r1 * 2)
        val dates = dueDates(p)

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            setBackgroundColor(Color.rgb(245,247,250))
        }

        card.addView(TextView(this).apply {
            text = "${p.name}   •   ${if (p.paid >= p.total) "IN REGOLA" else "DA PAGARE"}"
            textSize = 19f
            setTextColor(Color.rgb(20,20,20))
        })
        card.addView(TextView(this).apply {
            text = "Partenza: ${p.start.format(fmt)}    Totale: €${p.total}"
            textSize = 14f
            setTextColor(Color.DKGRAY)
        })

        for (i in 0..2) {
            val isPaid = p.paid >= rates.take(i+1).sum()
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val text = TextView(this).apply {
                text = "Rata ${i+1}: €${rates[i]} • ${dates[i].format(fmt)}${if (isPaid) " ✓ pagata" else ""}"
                textSize = 15f
                setTextColor(Color.rgb(30,30,30))
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(text, LinearLayout.LayoutParams(0, 54, 1f))
            if (!isPaid) {
                row.addView(Button(this).apply {
                    text = "PAGA"
                    setOnClickListener {
                        p.paid = rates.take(i+1).sum()
                        render()
                    }
                })
            }
            card.addView(row)
        }

        card.addView(Button(this).apply {
            text = "Gestisci"
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle(p.name)
                    .setItems(arrayOf("Segna tutto pagato", "Elimina")) { _, which ->
                        if (which == 0) {
                            p.paid = p.total
                        } else {
                            packs.remove(p)
                        }
                        render()
                    }.show()
            }
        })

        val lp = LinearLayout.LayoutParams(-1, -2).apply {
            setMargins(0, 0, 0, 12)
        }
        list.addView(card, lp)
    }
}