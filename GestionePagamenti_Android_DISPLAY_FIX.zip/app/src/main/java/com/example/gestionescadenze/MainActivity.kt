package com.example.gestionescadenze

import android.app.*
import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.graphics.drawable.GradientDrawable
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import android.text.Editable
import android.text.TextWatcher
import java.io.BufferedReader
import java.io.InputStreamReader
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters

private data class Pack(val name: String, val start: LocalDate, val total: Int, var paid: Int = 0, var customRates: MutableList<Int>? = null, var packageType: String = "PERSONALIZZATO", var active: Boolean = true)
private data class SessionPack(
    val id: Long,
    var name: String,
    val start: LocalDate,
    val totalSessions: Int,
    val cost: Int,
    var active: Boolean = true
)
private data class Appointment(
    val id: Long,
    var name: String,
    var date: LocalDate,
    var time: String,
    var type: String,
    var seriesId: Long = 0L,
    var sessionPackId: Long = 0L
) {
    val duration: Int get() = if (type == "MEZZ'ORA") 30 else 45
}

class MainActivity : Activity() {
    private val fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy")
    private val timeFmt = DateTimeFormatter.ofPattern("HH:mm")
    private val packs = mutableListOf<Pack>()
    private val sessionPacks = mutableListOf<SessionPack>()
    private val appointments = mutableListOf<Appointment>()
    private var ferieStart: LocalDate? = null
    private var ferieEnd: LocalDate? = null
    private lateinit var list: LinearLayout
    private var dashboardEnabled = false
    private lateinit var searchInput: EditText
    private var calendarWeekStart: LocalDate = LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    private var nextAppointmentId = 1L
    private var nextSessionPackId = 1L
    private var calendarZoom = 1.0f
    private var pendingSummaryText = ""
    private val expandedClients = mutableSetOf<String>()

    companion object {
        private const val REQ_EXPORT = 1001
        private const val REQ_IMPORT = 1002
        private const val REQ_SUMMARY = 1003
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        if (android.os.Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(true)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        loadData()
        build()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun roundedSurface(color:Int, radius:Int=16, strokeColor:Int=Color.TRANSPARENT, strokeWidth:Int=0): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius=dp(radius).toFloat(); if(strokeWidth>0) setStroke(dp(strokeWidth),strokeColor) }

    private fun buttonStyle(textValue: String): Button = Button(this).apply {
        text = textValue; textSize = 13.5f; setTextColor(Color.rgb(35,38,42)); gravity = Gravity.CENTER
        minHeight = 0; minimumHeight = 0; setAllCaps(false); stateListAnimator = null
        background = roundedSurface(Color.rgb(241,243,246),16,Color.rgb(226,229,234),1)
    }

    private fun build() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(14),dp(16),dp(10)); setBackgroundColor(Color.rgb(247,248,250)) }
        val titleRow = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        titleRow.addView(TextView(this).apply { text="Gestione Pagamenti"; textSize=30f; setTextColor(Color.rgb(20,20,22)); gravity=Gravity.CENTER_VERTICAL }, LinearLayout.LayoutParams(0,dp(56),1f))
        val dashButton = Button(this).apply {
            text=if(dashboardEnabled) "DASH  ●" else "DASH  ○"; textSize=12.5f; setTextColor(Color.rgb(70,74,80)); gravity=Gravity.CENTER; minHeight=0; minimumHeight=0; setPadding(dp(8),0,dp(8),0); setAllCaps(false); stateListAnimator=null
            background=roundedSurface(if(dashboardEnabled) Color.rgb(235,241,248) else Color.rgb(248,249,250),18,Color.rgb(220,223,227),1)
            setOnClickListener { dashboardEnabled=!dashboardEnabled; saveData(); updateDashboardButton(this); render() }
        }
        titleRow.addView(dashButton,LinearLayout.LayoutParams(dp(78),dp(42))); root.addView(titleRow,LinearLayout.LayoutParams(-1,dp(56)))
        root.addView(TextView(this).apply { text="Pacchetti clienti  •  12 settimane  •  rate e sedute"; textSize=15f; setTextColor(Color.rgb(92,95,101)); setPadding(dp(2),0,0,dp(5)) },LinearLayout.LayoutParams(-1,dp(34)))
        val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val add=buttonStyle("+ Nuovo").apply{setOnClickListener{newPackageMenu()}}
        val ferie=buttonStyle("Chiusura ferie").apply{setOnClickListener{settings()}}
        val cal=buttonStyle("📅 Calendario").apply{setOnClickListener{calendarScreen()}}
        buttons.addView(add,LinearLayout.LayoutParams(0,dp(58),1f).apply{setMargins(0,0,dp(4),0)}); buttons.addView(ferie,LinearLayout.LayoutParams(0,dp(58),1f).apply{setMargins(dp(2),0,dp(2),0)}); buttons.addView(cal,LinearLayout.LayoutParams(0,dp(58),1f).apply{setMargins(dp(4),0,0,0)}); root.addView(buttons,LinearLayout.LayoutParams(-1,dp(60)))
        root.addView(TextView(this).apply{textSize=13f;setTextColor(Color.DKGRAY);setPadding(0,dp(4),0,dp(4));gravity=Gravity.CENTER_VERTICAL;text=closureText()},LinearLayout.LayoutParams(-1,dp(34)))
        root.addView(buttonStyle("Backup dati  •  ESPORTA / IMPORTA").apply{setOnClickListener{backupMenu()}},LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(2),0,0)})
        searchInput=EditText(this).apply{
            hint="🔎 Cerca cliente"; textSize=15f; setSingleLine(true); setPadding(dp(12),0,dp(12),0)
            background=roundedSurface(Color.WHITE,18,Color.rgb(226,229,234),1)
            addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){render()};override fun afterTextChanged(s:Editable?){}})
        }
        root.addView(searchInput,LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(8),0,0)})
        list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,dp(12),0,0)}
        val scroll=ScrollView(this).apply{addView(list,ViewGroup.LayoutParams(-1,-2))}; root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root); render()
    }

    private fun updateDashboardButton(button:Button){button.text=if(dashboardEnabled)"DASH  ●" else "DASH  ○";button.background=roundedSurface(if(dashboardEnabled)Color.rgb(235,241,248)else Color.rgb(248,249,250),18,Color.rgb(220,223,227),1)}

    private fun newPackageMenu(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(4),dp(20),dp(10))}
        fun option(title:String,subtitle:String,action:()->Unit){
            val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(12),dp(16),dp(12));background=roundedSurface(Color.rgb(247,248,250),18,Color.rgb(226,229,234),1);isClickable=true;isFocusable=true;setOnClickListener{action()}}
            row.addView(TextView(this).apply{text=title;textSize=16f;setTextColor(Color.rgb(25,28,32));setTypeface(null,android.graphics.Typeface.BOLD)})
            row.addView(TextView(this).apply{text=subtitle;textSize=12.5f;setTextColor(Color.rgb(100,104,110));setPadding(0,dp(3),0,0)})
            box.addView(row,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))})
        }
        option("Pacchetto 12 settimane","3 rate • Bronze / Silver / Gold"){newPack()}
        option("Pacchetto sedute","Numero sedute e costo personalizzabili"){newSessionPack()}
        val dialog=AlertDialog.Builder(this).setTitle("Nuovo pacchetto").setView(box).setNegativeButton("CHIUDI",null).create()
        styleOneUiDialog(dialog)
        dialog.setOnShowListener{
            box.getChildAt(0)?.setOnClickListener{dialog.dismiss();newPack()}
            box.getChildAt(1)?.setOnClickListener{dialog.dismiss();newSessionPack()}
        }
        dialog.show()
    }

    private fun newSessionPack(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(8),dp(16),0)}
        val name=EditText(this).apply{hint="Nome e Cognome"}
        val sessions=EditText(this).apply{hint="Numero sedute";inputType=2;setSingleLine(true)}
        val cost=EditText(this).apply{hint="Costo totale (€)";inputType=2;setSingleLine(true)}
        box.addView(name);box.addView(sessions);box.addView(cost)
        AlertDialog.Builder(this).setTitle("Nuovo pacchetto sedute").setMessage("Il pacchetto viene saldato per intero e le sedute vengono conteggiate automaticamente dagli appuntamenti del calendario.").setView(box).setNegativeButton("Annulla",null).setPositiveButton("CREA"){_,_->
            try{
                val n=normalizeDisplayName(name.text.toString());val total=sessions.text.toString().trim().toInt();val c=cost.text.toString().trim().toInt()
                require(n.isNotEmpty()&&total>0&&c>0)
                sessionPacks.add(SessionPack(nextSessionPackId++,n,LocalDate.now(),total,c));saveData();render()
            }catch(_:Exception){Toast.makeText(this,"Controlla nome, numero sedute e costo.",Toast.LENGTH_LONG).show()}
        }.show()
    }

    private fun normalizeDisplayName(value:String):String{
        return value.trim().split(Regex("\\s+")).filter{it.isNotBlank()}.joinToString(" "){word->
            word.lowercase().replaceFirstChar{if(it.isLowerCase())it.titlecase() else it.toString()}
        }
    }

    private fun identityKey(value:String):String{
        return value.trim().lowercase().split(Regex("\\s+")).filter{it.isNotBlank()}.sorted().joinToString(" ")
    }

    private fun newPack(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(8),dp(16),0)}
        val name=EditText(this).apply{hint="Nome e Cognome"}
        val date=EditText(this).apply{hint="Data inizio (gg/mm/aaaa)";inputType=2}
        setupDateInput(date)
        val type=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("BRONZE • 12 sedute","SILVER • 24 sedute","GOLD • 36 sedute"))}
        val cost=EditText(this).apply{hint="Costo totale (€)";inputType=2}
        box.addView(name);box.addView(date)
        box.addView(TextView(this).apply{text="Tipo pacchetto";textSize=13f;setTextColor(Color.DKGRAY);setPadding(0,dp(8),0,dp(3))})
        box.addView(type);box.addView(cost)
        AlertDialog.Builder(this).setTitle("Nuovo pacchetto 12 settimane").setView(box).setNegativeButton("Annulla",null).setPositiveButton("Crea"){_,_->
            try{
                val n=normalizeDisplayName(name.text.toString());val d=parseDate(date.text.toString());val c=cost.text.toString().trim().toInt()
                require(n.isNotEmpty()&&c>0)
                val kind=when(type.selectedItemPosition){0->"BRONZE";1->"SILVER";else->"GOLD"}
                packs.add(Pack(n,d,c,0,null,kind,true));saveData();render()
            }catch(_:Exception){Toast.makeText(this,"Controlla nome, data, tipo e costo.",Toast.LENGTH_LONG).show()}
        }.show()
    }

    private fun setupDateInput(edit:EditText){edit.addTextChangedListener(object:TextWatcher{private var editing=false;override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){};override fun afterTextChanged(s:Editable?){if(editing||s==null)return;val digits=s.toString().filter{it.isDigit()}.take(8);val formatted=buildString{digits.forEachIndexed{i,c->if(i==2||i==4)append('/');append(c)}};if(formatted!=s.toString()){editing=true;edit.setText(formatted);edit.setSelection(formatted.length);editing=false}}})}
    private fun parseDate(value:String):LocalDate=LocalDate.parse(value.trim(),fmt)

    private fun settings(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),0,dp(16),0)};val s=EditText(this).apply{hint="Inizio chiusura (gg/mm/aaaa)";inputType=2;ferieStart?.let{setText(it.format(fmt))}};val e=EditText(this).apply{hint="Fine chiusura (gg/mm/aaaa)";inputType=2;ferieEnd?.let{setText(it.format(fmt))}};setupDateInput(s);setupDateInput(e);box.addView(s);box.addView(e)
        AlertDialog.Builder(this).setTitle("Chiusura ferie").setMessage("Inserisci le due date. Le scadenze che cadono nella chiusura vengono spostate al giorno successivo alla riapertura.").setView(box).setNegativeButton("Annulla",null).setNeutralButton("Cancella ferie"){_,_->ferieStart=null;ferieEnd=null;saveData();build()}.setPositiveButton("SALVA"){_,_->try{val start=parseDate(s.text.toString());val end=parseDate(e.text.toString());require(!end.isBefore(start));ferieStart=start;ferieEnd=end;saveData();build();Toast.makeText(this,"Chiusura ferie salvata.",Toast.LENGTH_SHORT).show()}catch(_:Exception){Toast.makeText(this,"Inserisci date valide, ad esempio 27/07/2026 e 06/09/2026.",Toast.LENGTH_LONG).show()}}.show()
    }

    private fun backupMenu(){AlertDialog.Builder(this).setTitle("Backup dati").setItems(arrayOf("Esporta dati","Importa dati")){_,which->if(which==0)exportData()else importData()}.show()}
    private fun exportData(){startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/json";putExtra(Intent.EXTRA_TITLE,"GestionePagamenti_backup.json")},REQ_EXPORT)}
    private fun importData(){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/json"},REQ_IMPORT)}
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK)return;val uri=data?.data?:return;if(requestCode==REQ_EXPORT)writeBackup(uri)else if(requestCode==REQ_IMPORT)readBackup(uri)else if(requestCode==REQ_SUMMARY)writeSummary(uri)}

    private fun backupJson():JSONObject{
        val root=JSONObject();root.put("format","GestionePagamenti");root.put("version",5);root.put("exportedAt",LocalDateTime.now().toString());root.put("ferieStart",ferieStart?.toString()?:JSONObject.NULL);root.put("ferieEnd",ferieEnd?.toString()?:JSONObject.NULL);root.put("dashboardEnabled",dashboardEnabled)
        val array=JSONArray();packs.forEach{p->val rates=ratesFor(p);val dates=dueDates(p);array.put(JSONObject().apply{put("name",p.name);put("start",p.start.toString());put("total",p.total);put("paid",p.paid);put("dueDates",JSONArray().apply{dates.forEach{put(it.toString())}});put("rateAmounts",JSONArray().apply{rates.forEach{put(it)}});put("packageType",p.packageType);put("active",p.active)})};root.put("packs",array)
        root.put("sessionPacks",JSONArray().apply{sessionPacks.forEach{s->put(JSONObject().apply{put("id",s.id);put("name",s.name);put("start",s.start.toString());put("totalSessions",s.totalSessions);put("cost",s.cost);put("active",s.active)})}})
        root.put("appointments",JSONArray().apply{appointments.forEach{a->put(JSONObject().apply{put("id",a.id);put("name",a.name);put("date",a.date.toString());put("time",a.time);put("type",a.type);put("seriesId",a.seriesId);put("sessionPackId",a.sessionPackId)})}});return root
    }
    private fun writeSummary(uri:Uri){try{contentResolver.openOutputStream(uri)?.use{it.write(pendingSummaryText.toByteArray(Charsets.UTF_8))};Toast.makeText(this,"Riepilogo esportato.",Toast.LENGTH_LONG).show()}catch(_:Exception){Toast.makeText(this,"Impossibile esportare il riepilogo.",Toast.LENGTH_LONG).show()}}

    private fun sessionsForPack(p:Pack,until:LocalDate=LocalDate.now()):List<Appointment>{
        val end=p.start.plusWeeks(12).minusDays(1)
        return appointments.filter{identityKey(it.name)==identityKey(p.name)&&!it.date.isBefore(p.start)&&!it.date.isAfter(until)&&!it.date.isAfter(end)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
    }

    private fun sessionsForSessionPack(s:SessionPack,until:LocalDate=LocalDate.now()):List<Appointment>{
        return appointments.filter{it.sessionPackId==s.id&&!it.date.isAfter(until)&&!it.date.isBefore(s.start)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time})
    }

    private fun summaryForPack(p: Pack): String {
        val today = LocalDate.now()
        val done = sessionsForPack(p, today)
        val expected = when (p.packageType) {
            "BRONZE" -> 12
            "SILVER" -> 24
            "GOLD" -> 36
            else -> 12
        }
        val packageEnd = p.start.plusWeeks(12).minusDays(1)
        val future = appointments.count {
            identityKey(it.name) == identityKey(p.name) &&
                it.date.isAfter(today) &&
                !it.date.isAfter(packageEnd)
        }
        return buildString {
            appendLine("RIEPILOGO SEDUTE")
            appendLine()
            appendLine("Cliente: ${p.name}")
            appendLine("Pacchetto: ${p.packageType}")
            appendLine("Periodo: ${p.start.format(fmt)} → ${packageEnd.format(fmt)}")
            appendLine("Sedute previste: $expected")
            appendLine("Sedute effettuate al ${today.format(fmt)}: ${done.size}")
            appendLine("Sedute future prenotate: $future")
            appendLine("Sedute teoriche rimanenti: ${(expected - done.size).coerceAtLeast(0)}")
            appendLine()
            appendLine("SEDUTE EFFETTUATE")
            done.forEachIndexed { index, appointment ->
                val timeText = if (appointment.time.isNotBlank()) " • ${appointment.time}" else ""
                val durationText = if (appointment.type == "MEZZ'ORA") "MEZZ'ORA" else "ALLENAMENTO"
                appendLine("${index + 1}. ${appointment.date.format(fmt)}$timeText • $durationText")
            }
        }
    }

    private fun summaryForSessionPack(s: SessionPack): String {
        val today = LocalDate.now()
        val done = sessionsForSessionPack(s, today)
        val future = appointments.count {
            it.sessionPackId == s.id && it.date.isAfter(today)
        }
        return buildString {
            appendLine("RIEPILOGO SEDUTE")
            appendLine()
            appendLine("Cliente: ${s.name}")
            appendLine("Pacchetto: ${s.totalSessions} sedute")
            appendLine("Costo: €${s.cost} (saldato per intero)")
            appendLine("Situazione al ${today.format(fmt)}")
            appendLine("Sedute effettuate: ${done.size}/${s.totalSessions}")
            appendLine("Sedute future prenotate: $future")
            appendLine("Sedute rimanenti: ${(s.totalSessions - done.size).coerceAtLeast(0)}")
            appendLine()
            appendLine("SEDUTE EFFETTUATE")
            done.forEachIndexed { index, appointment ->
                val timeText = if (appointment.time.isNotBlank()) " • ${appointment.time}" else ""
                val durationText = if (appointment.type == "MEZZ'ORA") "MEZZ'ORA" else "ALLENAMENTO"
                appendLine("${index + 1}. ${appointment.date.format(fmt)}$timeText • $durationText")
            }
        }
    }

    private fun copySummaryToClipboard(text:String,name:String){
        pendingSummaryText=text
        val clipboard=getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Riepilogo $name",text))
        val preview=TextView(this).apply{this.text=text;textSize=14f;setTextColor(Color.rgb(35,35,35));setPadding(dp(16),dp(8),dp(16),dp(8))}
        val dialog=AlertDialog.Builder(this).setTitle("📊 Riepilogo pronto per WhatsApp").setMessage("Il riepilogo è già stato copiato negli appunti. Puoi incollarlo direttamente su WhatsApp.").setView(ScrollView(this).apply{addView(preview)}).setPositiveButton("COPIA DI NUOVO"){_,_->
            clipboard.setPrimaryClip(ClipData.newPlainText("Riepilogo $name",text))
            Toast.makeText(this,"Riepilogo copiato negli appunti.",Toast.LENGTH_SHORT).show()
        }.setNegativeButton("CHIUDI",null).create()
        styleOneUiDialog(dialog)
        dialog.show()
    }

    private fun exportSummary(text:String,name:String){copySummaryToClipboard(text,name)}

    private fun writeBackup(uri:Uri){try{contentResolver.openOutputStream(uri)?.use{it.write(backupJson().toString(2).toByteArray(Charsets.UTF_8))};Toast.makeText(this,"Backup esportato correttamente.",Toast.LENGTH_LONG).show()}catch(_:Exception){Toast.makeText(this,"Impossibile esportare il backup.",Toast.LENGTH_LONG).show()}}
    private fun readBackup(uri:Uri){try{val text=contentResolver.openInputStream(uri)?.use{BufferedReader(InputStreamReader(it,Charsets.UTF_8)).readText()}?:throw Exception();val root=JSONObject(text);require(root.optString("format")=="GestionePagamenti");val newPacks=mutableListOf<Pack>();val array=root.getJSONArray("packs");for(i in 0 until array.length()){val o=array.getJSONObject(i);newPacks.add(Pack(o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("total"),o.optInt("paid",0), o.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}}, o.optString("packageType","PERSONALIZZATO"), o.optBoolean("active",true)))};ferieStart=if(root.isNull("ferieStart"))null else LocalDate.parse(root.getString("ferieStart"));ferieEnd=if(root.isNull("ferieEnd"))null else LocalDate.parse(root.getString("ferieEnd"));dashboardEnabled=root.optBoolean("dashboardEnabled",false);val newSessionPacks=mutableListOf<SessionPack>();val sp=root.optJSONArray("sessionPacks");if(sp!=null)for(i in 0 until sp.length()){val o=sp.getJSONObject(i);newSessionPacks.add(SessionPack(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("totalSessions"),o.getInt("cost"),o.optBoolean("active",true)))};val newAppointments=mutableListOf<Appointment>();val ap=root.optJSONArray("appointments");if(ap!=null)for(i in 0 until ap.length()){val o=ap.getJSONObject(i);newAppointments.add(Appointment(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("date")),o.getString("time"),o.optString("type","ALLENAMENTO"),o.optLong("seriesId",0L),o.optLong("sessionPackId",0L)))};packs.clear();packs.addAll(newPacks);sessionPacks.clear();sessionPacks.addAll(newSessionPacks);appointments.clear();appointments.addAll(newAppointments);nextAppointmentId=(appointments.maxOfOrNull{it.id}?:0L)+1;nextSessionPackId=(sessionPacks.maxOfOrNull{it.id}?:0L)+1;saveData();build();Toast.makeText(this,"Backup importato: dati, ferie, pagamenti e appuntamenti ripristinati.",Toast.LENGTH_LONG).show()}catch(_:Exception){Toast.makeText(this,"Backup non valido o non leggibile.",Toast.LENGTH_LONG).show()}}

    private fun saveData(){
        val prefs=getSharedPreferences("gestione_pagamenti",MODE_PRIVATE);val array=JSONArray();packs.forEach{p->array.put(JSONObject().apply{put("name",p.name);put("start",p.start.toString());put("total",p.total);put("paid",p.paid);put("rateAmounts",JSONArray().apply{ratesFor(p).forEach{put(it)}});put("packageType",p.packageType);put("active",p.active)})};val sp=JSONArray();sessionPacks.forEach{s->sp.put(JSONObject().apply{put("id",s.id);put("name",s.name);put("start",s.start.toString());put("totalSessions",s.totalSessions);put("cost",s.cost);put("active",s.active)})};val ap=JSONArray();appointments.forEach{a->ap.put(JSONObject().apply{put("id",a.id);put("name",a.name);put("date",a.date.toString());put("time",a.time);put("type",a.type);put("seriesId",a.seriesId);put("sessionPackId",a.sessionPackId)})};prefs.edit().putString("packs",array.toString()).putString("sessionPacks",sp.toString()).putString("appointments",ap.toString()).putString("ferieStart",ferieStart?.toString()).putString("ferieEnd",ferieEnd?.toString()).putBoolean("dashboardEnabled",dashboardEnabled).putLong("nextAppointmentId",nextAppointmentId).putLong("nextSessionPackId",nextSessionPackId).apply()
    }
    private fun loadData(){
        val prefs=getSharedPreferences("gestione_pagamenti",MODE_PRIVATE);packs.clear();sessionPacks.clear();appointments.clear();val saved=prefs.getString("packs",null);if(!saved.isNullOrEmpty())try{val array=JSONArray(saved);for(i in 0 until array.length()){val o=array.getJSONObject(i);packs.add(Pack(o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("total"),o.optInt("paid",0), o.optJSONArray("rateAmounts")?.let{ja->mutableListOf<Int>().apply{for(j in 0 until ja.length())add(ja.getInt(j))}}, o.optString("packageType","PERSONALIZZATO"), o.optBoolean("active",true)))}}catch(_:Exception){packs.clear()};val ap=prefs.getString("appointments",null);if(!ap.isNullOrEmpty())try{val array=JSONArray(ap);for(i in 0 until array.length()){val o=array.getJSONObject(i);appointments.add(Appointment(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("date")),o.getString("time"),o.optString("type","ALLENAMENTO"),o.optLong("seriesId",0L),o.optLong("sessionPackId",0L)))}}catch(_:Exception){appointments.clear()};val savedSp=prefs.getString("sessionPacks",null);if(!savedSp.isNullOrEmpty())try{val array=JSONArray(savedSp);for(i in 0 until array.length()){val o=array.getJSONObject(i);sessionPacks.add(SessionPack(o.getLong("id"),o.getString("name"),LocalDate.parse(o.getString("start")),o.getInt("totalSessions"),o.getInt("cost"),o.optBoolean("active",true)))}}catch(_:Exception){sessionPacks.clear()};nextAppointmentId=maxOf(prefs.getLong("nextAppointmentId",1L),(appointments.maxOfOrNull{it.id}?:0L)+1);nextSessionPackId=maxOf(prefs.getLong("nextSessionPackId",1L),(sessionPacks.maxOfOrNull{it.id}?:0L)+1)
        appointments.filter{it.sessionPackId==0L}.forEach{a->activeSessionPackFor(a.name)?.let{sp->a.sessionPackId=sp.id}}
        ferieStart=prefs.getString("ferieStart",null)?.let{runCatching{LocalDate.parse(it)}.getOrNull()};ferieEnd=prefs.getString("ferieEnd",null)?.let{runCatching{LocalDate.parse(it)}.getOrNull()};dashboardEnabled=prefs.getBoolean("dashboardEnabled",false)
    }

    private fun ratesFor(p:Pack):List<Int>{
        val c=p.customRates
        if(c!=null&&c.size==3&&c.all{it>=0}&&c.sum()==p.total)return c.toList()
        val r1=p.total/3;return listOf(r1,r1,p.total-r1*2)
    }

    private fun saveRates(p:Pack,rates:List<Int>){p.customRates=rates.toMutableList()}

    private fun registerPayment(p:Pack,index:Int,paidNow:Int){
        try{
            val rates=ratesFor(p)
            val due=rates[index]
            require(paidNow>0)
            require(p.paid+paidNow<=p.total)

            val paidBeforeCurrent=rates.take(index).sum()
            val alreadyPaidOnCurrent=(p.paid-paidBeforeCurrent).coerceAtLeast(0)
            val totalPaidOnCurrent=alreadyPaidOnCurrent+paidNow
            val newRates=rates.toMutableList()

            p.paid+=paidNow

            // Se il cliente paga più della rata prevista, la rata corrente
            // diventa pari a quanto effettivamente versato e il residuo viene
            // redistribuito sulle rate successive.
            if(totalPaidOnCurrent>due){
                newRates[index]=totalPaidOnCurrent
                val remainingCount=2-index
                if(remainingCount>0){
                    val remaining=p.total-rates.take(index).sum()-totalPaidOnCurrent
                    require(remaining>=0)
                    val base=remaining/remainingCount
                    val extra=remaining%remainingCount
                    for(j in index+1..2){
                        newRates[j]=base+if(j-index-1<extra)1 else 0
                    }
                } else require(totalPaidOnCurrent==p.total-rates.take(index).sum())
            }

            require(newRates.sum()==p.total)
            saveRates(p,newRates)
            expandedClients.add(identityKey(p.name))
            saveData()
            render()
            if(totalPaidOnCurrent>due) Toast.makeText(this,"Pagamento registrato: rate successive ricalcolate automaticamente.",Toast.LENGTH_LONG).show()
            else Toast.makeText(this,"Pagamento di €$paidNow registrato.",Toast.LENGTH_SHORT).show()
        }catch(_:Exception){
            Toast.makeText(this,"Importo non valido o superiore al totale residuo.",Toast.LENGTH_LONG).show()
        }
    }

    private fun paymentAmountDialog(p:Pack,index:Int){
        val rates=ratesFor(p)
        val due=rates[index]
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(8),dp(16),0)}
        box.addView(TextView(this).apply{this.text="Rata ${index+1} • prevista €$due";textSize=15f;setTextColor(Color.DKGRAY);setPadding(0,0,0,dp(8))})
        val amount=EditText(this).apply{hint="Importo effettivamente pagato (€)";inputType=2;setSingleLine(true);setText(due.toString());selectAll()}
        box.addView(amount)
        AlertDialog.Builder(this)
            .setTitle("Modifica importo pagamento")
            .setView(box)
            .setNegativeButton("ANNULLA",null)
            .setPositiveButton("CONFERMA PAGAMENTO"){_,_->
                val value=amount.text.toString().trim().toIntOrNull()
                if(value==null||value<=0||p.paid+value>p.total){
                    Toast.makeText(this,"Importo non valido o superiore al totale residuo.",Toast.LENGTH_LONG).show()
                }else{
                    registerPayment(p,index,value)
                }
            }.show()
    }

    private fun paymentOptionsDialog(p:Pack,index:Int){
        AlertDialog.Builder(this)
            .setTitle("Opzioni pagamento")
            .setItems(arrayOf("Modifica importo da pagare","Annulla")){_,which->
                if(which==0) paymentAmountDialog(p,index)
            }.show()
    }

    private fun editRateDialog(p:Pack,index:Int){
        val rates=ratesFor(p);val firstUnpaid=p.paidRateIndex(rates);if(index<firstUnpaid){Toast.makeText(this,"Questa rata è già pagata.",Toast.LENGTH_SHORT).show();return}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(8),dp(16),0)}
        val amount=EditText(this).apply{hint="Nuovo importo rata";inputType=2;setSingleLine(true);setText(rates[index].toString())};box.addView(amount)
        val laterCount=2-index
        AlertDialog.Builder(this).setTitle("Modifica rata ${index+1}").setMessage(if(laterCount>0)"Modifica questa rata: le rate successive verranno ricalcolate automaticamente per mantenere invariato il totale di €${p.total}." else "Essendo l'ultima rata, l'importo viene calcolato sul residuo del pacchetto.").setView(box).setNegativeButton("Annulla",null).setPositiveButton("SALVA"){_,_->
            try{
                val newAmount=amount.text.toString().trim().toInt();require(newAmount>0)
                val paidBefore=rates.take(index).sum();val alreadyOnRate=p.paid-paidBefore;require(newAmount>=alreadyOnRate)
                val remainingAfter=p.total-paidBefore-newAmount;require(remainingAfter>=0)
                val newRates=rates.toMutableList();newRates[index]=newAmount
                if(laterCount>0){val base=remainingAfter/laterCount;val extra=remainingAfter%laterCount;for(j in index+1..2)newRates[j]=base+if(j-index-1<extra)1 else 0}else require(remainingAfter==0)
                require(newRates.sum()==p.total);saveRates(p,newRates);saveData();render()
            }catch(_:Exception){Toast.makeText(this,"Importo non valido: controlla il residuo del pacchetto.",Toast.LENGTH_LONG).show()}
        }.show()
    }
    private fun dueDates(p:Pack):List<LocalDate>{val out=mutableListOf<LocalDate>();var d=p.start;repeat(3){out.add(d);d=advance(d,28)};return out}
    private fun advance(d0:LocalDate,days:Int):LocalDate{var d=d0.plusDays(days.toLong());val fs=ferieStart;val fe=ferieEnd;if(fs!=null&&fe!=null&&!fe.isBefore(fs)&&!d.isBefore(fs)&&!d.isAfter(fe))d=fe.plusDays(1);return d}
    private fun closureText():String{val fs=ferieStart;val fe=ferieEnd;return if(fs!=null&&fe!=null)"🏖 Chiusura ferie: ${fs.format(fmt)} → ${fe.format(fmt)}" else "Nessuna chiusura ferie impostata"}

    private fun displaySurnameFirst(name:String):String{
        val parts=name.trim().split(Regex("\\s+")).filter{it.isNotBlank()}
        return when{parts.size<=1->name.trim();else->parts.last()+" "+parts.dropLast(1).joinToString(" ")}
    }


    private fun render(){
        list.removeAllViews()
        val query=if(::searchInput.isInitialized)searchInput.text.toString().trim().lowercase() else ""
        val filtered=packs.filter{it.active&&(query.isEmpty()||it.name.lowercase().contains(query))}.sortedWith(compareBy<Pack>{statusRank(statusFor(it,ratesFor(it),dueDates(it)))}.thenBy{it.start}.thenBy{it.name.lowercase()})
        val filteredSessions=sessionPacks.filter{it.active&&(query.isEmpty()||it.name.lowercase().contains(query))}.sortedWith(compareBy<SessionPack>{statusRank(sessionStatus(it))}.thenBy{it.start}.thenBy{it.name.lowercase()})
        if(dashboardEnabled){renderDashboard(filtered,filteredSessions)}else{
            if(filtered.isEmpty()&&filteredSessions.isEmpty()){
                list.addView(TextView(this).apply{text=if(packs.isEmpty()&&sessionPacks.isEmpty())"Nessun pacchetto inserito." else "Nessun cliente trovato.";textSize=18f;setTextColor(Color.DKGRAY);setPadding(0,dp(12),0,dp(12))})
                return
            }
            val unified=mutableListOf<Pair<Int,Any>>()
            filtered.forEach{unified.add(statusRank(statusFor(it,ratesFor(it),dueDates(it))) to it)}
            filteredSessions.forEach{unified.add(statusRank(sessionStatus(it)) to it)}
            unified.sortedWith(compareBy<Pair<Int,Any>>{it.first}.thenBy{item->when(val value=item.second){is Pack->value.start;is SessionPack->value.start;else->LocalDate.MAX}}).forEach{item->when(val value=item.second){is Pack->card(value);is SessionPack->sessionCard(value)}}
        }
    }

    private fun renderDashboard(items:List<Pack>,sessionItems:List<SessionPack>){
        val today=LocalDate.now()
        val activeClients=(items.map{identityKey(it.name)}+sessionItems.map{identityKey(it.name)}).distinct().size
        val todayAppointments=appointments.count{it.date==today}
        val toCollect=packs.filter{it.active}.sumOf{(it.total-it.paid).coerceAtLeast(0)}
        val stats=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(0,0,0,dp(10))}
        fun stat(value:String,label:String):View=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(6),dp(8),dp(6),dp(8));background=roundedSurface(Color.WHITE,16,Color.rgb(230,232,236),1)
            addView(TextView(this@MainActivity).apply{text=value;textSize=19f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(28,31,35));gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,dp(28)))
            addView(TextView(this@MainActivity).apply{text=label;textSize=10.5f;setTextColor(Color.rgb(105,108,114));gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,dp(22))) }
        stats.addView(stat(activeClients.toString(),"CLIENTI ATTIVI"),LinearLayout.LayoutParams(0,dp(58),1f).apply{setMargins(0,0,dp(4),0)})
        stats.addView(stat(todayAppointments.toString(),"SEDUTE OGGI"),LinearLayout.LayoutParams(0,dp(58),1f).apply{setMargins(dp(2),0,dp(2),0)})
        stats.addView(stat("€$toCollect","DA INCASSARE"),LinearLayout.LayoutParams(0,dp(58),1f).apply{setMargins(dp(4),0,0,0)})
        list.addView(stats)
        val groups=listOf(
            Triple("SCADUTI",Color.rgb(210,45,45),items.filter{statusFor(it,ratesFor(it),dueDates(it)).label=="SCADUTA"}),
            Triple("IN SCADENZA",Color.rgb(220,160,20),items.filter{statusFor(it,ratesFor(it),dueDates(it)).label=="IN SCADENZA"}),
            Triple("IN REGOLA",Color.rgb(35,150,70),items.filter{statusFor(it,ratesFor(it),dueDates(it)).label=="IN REGOLA"})
        )
        val sessionGroups=listOf(
            Triple("SCADUTI",Color.rgb(210,45,45),sessionItems.filter{sessionStatus(it).label=="SCADUTA"}),
            Triple("IN SCADENZA",Color.rgb(220,160,20),sessionItems.filter{sessionStatus(it).label=="IN SCADENZA"}),
            Triple("IN REGOLA",Color.rgb(35,150,70),sessionItems.filter{sessionStatus(it).label=="IN REGOLA"})
        )
        groups.indices.forEach{idx->
            val clients=groups[idx].third
            val sessions=sessionGroups[idx].third
            if(clients.isEmpty()&&sessions.isEmpty())return@forEach
            val label=groups[idx].first;val color=groups[idx].second
            val section=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;background=roundedSurface(Color.WHITE,18,Color.rgb(232,234,238),1)}
            val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;isClickable=true;isFocusable=true;setPadding(dp(12),dp(4),dp(12),dp(4))}
            header.addView(TextView(this).apply{text="●";textSize=18f;setTextColor(color);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(28),dp(48)))
            val totalCount=clients.size+sessions.size
            header.addView(TextView(this).apply{text="$label ($totalCount)";textSize=17f;setTextColor(Color.rgb(35,35,35));gravity=Gravity.CENTER_VERTICAL;setPadding(dp(8),0,0,0)},LinearLayout.LayoutParams(0,dp(48),1f))
            val arrow=TextView(this).apply{text="▾";textSize=20f;setTextColor(Color.DKGRAY);gravity=Gravity.CENTER}
            header.addView(arrow,LinearLayout.LayoutParams(dp(36),dp(48)));section.addView(header)
            val sectionHasExpandedClient = clients.any{expandedClients.contains(identityKey(it.name))} || sessions.any{expandedClients.contains(identityKey(it.name))}
            val clientsBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=if(sectionHasExpandedClient)View.VISIBLE else View.GONE;setPadding(dp(8),0,dp(8),dp(4))}
            clients.forEach{card(it,clientsBox)};sessions.forEach{sessionCard(it,clientsBox)}
            section.addView(clientsBox)
            arrow.text=if(sectionHasExpandedClient)"▴" else "▾"
            header.setOnClickListener{val open=clientsBox.visibility!=View.VISIBLE;clientsBox.visibility=if(open)View.VISIBLE else View.GONE;arrow.text=if(open)"▴" else "▾"}
            list.addView(section,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})
        }
    }

    private fun card(p:Pack,parent:ViewGroup=list){
        val rates=ratesFor(p);val dates=dueDates(p);val status=statusFor(p,rates,dates)
        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(4),dp(10),dp(4));background=roundedSurface(Color.WHITE,18,Color.rgb(231,233,237),1)}
        val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;isClickable=true;isFocusable=true;setPadding(dp(2),0,0,0)}
        val nameView=TextView(this).apply{text=displaySurnameFirst(p.name);textSize=17.5f;setTextColor(Color.rgb(20,20,20));gravity=Gravity.CENTER_VERTICAL;maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END}
        header.addView(nameView,LinearLayout.LayoutParams(0,dp(48),1f))
        val menu=Button(this).apply{text="⋮";textSize=19f;minWidth=0;minimumWidth=0;setPadding(0,0,0,0);stateListAnimator=null;background=roundedSurface(Color.rgb(242,244,247),12,Color.rgb(228,231,235),1);setOnClickListener{packageInfoDialog(p)}}
        header.addView(menu,LinearLayout.LayoutParams(dp(38),dp(40)).apply{setMargins(dp(6),0,dp(6),0)})
        header.addView(TextView(this).apply{text="●";textSize=18f;setTextColor(status.color);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(26),dp(44)))
        card.addView(header)

        val isExpanded=expandedClients.contains(identityKey(p.name))
        val details=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=if(isExpanded)View.VISIBLE else View.GONE;setPadding(dp(2),dp(4),dp(2),dp(2))}
        details.addView(TextView(this).apply{text="${p.packageType} • ${when(p.packageType){"BRONZE"->12;"SILVER"->24;"GOLD"->36;else->"12+"}} sedute • Partenza: ${p.start.format(fmt)}    Totale: €${p.total}";textSize=14f;setTextColor(Color.DKGRAY);setPadding(0,dp(2),0,dp(8))})
        for(i in 0..2){
            val isPaid=p.paid>=rates.take(i+1).sum();val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
            val suffix = if(isPaid) " ✓ pagata" else if(i==p.paidRateIndex(rates)) " • parziale €${p.paid-rates.take(i).sum()}" else ""
            row.addView(TextView(this).apply{this.text="Rata ${i+1}: €${rates[i]} • ${dates[i].format(fmt)}$suffix";textSize=15f;setTextColor(Color.rgb(30,30,30));gravity=Gravity.CENTER_VERTICAL},LinearLayout.LayoutParams(0,dp(48),1f))
            if(!isPaid){
                if(i==p.paidRateIndex(rates)) row.addView(Button(this).apply{this.text="PAGA";setOnClickListener{
                    val alreadyPaidOnCurrent=(p.paid-rates.take(i).sum()).coerceAtLeast(0)
                    val remainingToPay=(rates[i]-alreadyPaidOnCurrent).coerceAtLeast(0)
                    if(remainingToPay>0) registerPayment(p,i,remainingToPay)
                }})
                row.addView(Button(this).apply{this.text="⋮";textSize=17f;minWidth=0;minimumWidth=0;setPadding(0,0,0,0);setOnClickListener{paymentOptionsDialog(p,i)}},LinearLayout.LayoutParams(dp(36),dp(44)))
            }
            details.addView(row)
        }
        card.addView(details)
        header.setOnClickListener{val open=details.visibility!=View.VISIBLE;details.visibility=if(open)View.VISIBLE else View.GONE;if(open)expandedClients.add(identityKey(p.name)) else expandedClients.remove(identityKey(p.name))}
        parent.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})
    }

    private fun packageInfoDialog(p:Pack){
        AlertDialog.Builder(this).setTitle(displaySurnameFirst(p.name)).setItems(arrayOf("📊 Riepilogo sedute","🗂 Storico cliente","⚙️ Gestisci pacchetto")){_,which->when(which){0->copySummaryToClipboard(summaryForPack(p),p.name);1->showClientHistory(p.name);else->AlertDialog.Builder(this).setTitle(p.name).setItems(arrayOf("Termina pacchetto","Segna tutto pagato","Elimina")){_,action->when(action){0->{p.active=false;saveData();render()};1->{p.paid=p.total;saveData();render()};else->{packs.remove(p);saveData();render()}}}.show()}}.setNegativeButton("Chiudi",null).show()
    }

    private fun sessionUsed(s:SessionPack):Int=appointments.count{it.sessionPackId==s.id}
    private fun sessionStatus(s:SessionPack):PackStatus{val used=sessionUsed(s);return when{used>=s.totalSessions->PackStatus("SCADUTA",Color.rgb(210,45,45));s.totalSessions-used<=2->PackStatus("IN SCADENZA",Color.rgb(220,160,20));else->PackStatus("IN REGOLA",Color.rgb(35,150,70))}}
    private fun activeSessionPackFor(name:String):SessionPack?=sessionPacks.filter{it.active&&identityKey(it.name)==identityKey(name)&&sessionUsed(it)<it.totalSessions}.maxByOrNull{it.start}

    private fun sessionCard(s:SessionPack,parent:ViewGroup=list){
        val used=sessionUsed(s);val remaining=(s.totalSessions-used).coerceAtLeast(0);val status=sessionStatus(s)
        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(4),dp(10),dp(4));background=roundedSurface(Color.WHITE,18,Color.rgb(231,233,237),1)}
        val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;isClickable=true;isFocusable=true;setPadding(dp(2),0,0,0)}
        val name=TextView(this).apply{text=displaySurnameFirst(s.name);textSize=17.5f;setTextColor(Color.rgb(20,20,20));gravity=Gravity.CENTER_VERTICAL;maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END}
        header.addView(name,LinearLayout.LayoutParams(0,dp(48),1f))
        header.addView(TextView(this).apply{text="$remaining rimaste";textSize=13f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(status.color);gravity=Gravity.CENTER_VERTICAL;maxLines=1},LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,dp(44)))
        val menu=Button(this).apply{text="⋮";textSize=19f;minWidth=0;minimumWidth=0;setPadding(0,0,0,0);stateListAnimator=null;background=roundedSurface(Color.rgb(242,244,247),12,Color.rgb(228,231,235),1);setOnClickListener{sessionPaymentInfo(s)}}
        header.addView(menu,LinearLayout.LayoutParams(dp(38),dp(40)).apply{setMargins(dp(6),0,dp(6),0)})
        header.addView(TextView(this).apply{text="●";textSize=18f;setTextColor(status.color);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(26),dp(44)))
        card.addView(header)

        val details=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE;setPadding(dp(4),dp(4),0,dp(2))}
        details.addView(TextView(this).apply{text="Pacchetto sedute • €${s.cost} • $used/${s.totalSessions} registrate";textSize=14f;setTextColor(Color.rgb(75,78,84));setPadding(0,0,0,dp(4))})
        val dates=appointments.filter{it.sessionPackId==s.id}.sortedBy{it.date}.joinToString(" • " ){it.date.format(fmt)}
        if(dates.isNotEmpty())details.addView(TextView(this).apply{text="Date: $dates";textSize=12.5f;setTextColor(Color.DKGRAY);setPadding(0,0,0,dp(5))})
        details.addView(Button(this).apply{text="⋮ ALTRE INFORMAZIONI";textSize=12.5f;setAllCaps(false);stateListAnimator=null;setOnClickListener{sessionOptionsDialog(s)}} ,LinearLayout.LayoutParams(-1,dp(40)))
        card.addView(details)
        header.setOnClickListener{val open=details.visibility!=View.VISIBLE;details.visibility=if(open)View.VISIBLE else View.GONE;if(open)expandedClients.add(identityKey(s.name)) else expandedClients.remove(identityKey(s.name))}
        parent.addView(card,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(8))})
    }

    private fun sessionPaymentInfo(s:SessionPack){
        val used=sessionUsed(s);val remaining=(s.totalSessions-used).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("⋮ ${displaySurnameFirst(s.name)}").setItems(arrayOf("📊 Riepilogo sedute","🗂 Storico cliente","⚙️ Gestisci pacchetto")){_,which->when(which){0->copySummaryToClipboard(summaryForSessionPack(s),s.name);1->showClientHistory(s.name);else->sessionOptionsDialog(s)}}.setNegativeButton("Chiudi",null).show()
    }

    private fun sessionOptionsDialog(s:SessionPack){
        val used=sessionUsed(s);val remaining=(s.totalSessions-used).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle(s.name).setMessage("Pacchetto da ${s.totalSessions} sedute • €${s.cost} saldato per intero\nSedute registrate: $used/${s.totalSessions}\nSedute rimanenti: $remaining").setItems(arrayOf("Termina pacchetto","Elimina pacchetto")){_,which->if(which==0){s.active=false;saveData();render()}else{sessionPacks.remove(s);appointments.filter{it.sessionPackId==s.id}.forEach{it.sessionPackId=0L};saveData();render()}}.setNegativeButton("Chiudi",null).show()
    }

    private fun showClientHistory(name:String){
        val oldPacks=packs.filter{!it.active&&identityKey(it.name)==identityKey(name)}
        val oldSessions=sessionPacks.filter{!it.active&&identityKey(it.name)==identityKey(name)}
        if(oldPacks.isEmpty()&&oldSessions.isEmpty()){Toast.makeText(this,"Nessun pacchetto terminato nello storico di $name.",Toast.LENGTH_SHORT).show();return}
        val items=mutableListOf<Pair<String,()->Unit>>()
        oldPacks.forEach{p->items.add("${p.packageType} • ${p.start.format(fmt)} • €${p.total}" to {exportSummary(summaryForPack(p),p.name)})}
        oldSessions.forEach{s->items.add("${s.totalSessions} sedute • ${s.start.format(fmt)} • €${s.cost}" to {exportSummary(summaryForSessionPack(s),s.name)})}
        AlertDialog.Builder(this).setTitle("🗂 Storico • $name").setItems(items.map{it.first}.toTypedArray()){_,which->items[which].second.invoke()}.setNegativeButton("Chiudi",null).show()
    }

    private fun Pack.paidRateIndex(rates:List<Int>):Int=(0..2).firstOrNull{paid<rates.take(it+1).sum()}?:3

    private data class PackStatus(val label:String,val color:Int)
    private fun statusRank(status:PackStatus):Int=when(status.label){"SCADUTA"->0;"IN SCADENZA"->1;else->2}
    private fun statusFor(p:Pack,rates:List<Int>,dates:List<LocalDate>):PackStatus{if(p.paid>=p.total)return PackStatus("IN REGOLA",Color.rgb(35,150,70));val nextIndex=(0..2).firstOrNull{p.paid<rates.take(it+1).sum()}?:2;val due=dates[nextIndex];val today=LocalDate.now();return when{due.isBefore(today)->PackStatus("SCADUTA",Color.rgb(210,45,45));!due.isAfter(today.plusDays(7))->PackStatus("IN SCADENZA",Color.rgb(220,160,20));else->PackStatus("IN REGOLA",Color.rgb(35,150,70))}}

    // ---------------- CALENDARIO ----------------
    private fun calendarScreen(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),dp(12),dp(10),dp(8));setBackgroundColor(Color.rgb(247,248,250))}
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        top.addView(buttonStyle("‹").apply{setOnClickListener{calendarWeekStart=calendarWeekStart.minusWeeks(1);calendarScreen()}},LinearLayout.LayoutParams(dp(52),dp(48)))
        top.addView(TextView(this).apply{text="Settimana ${calendarWeekStart.format(fmt)}";textSize=17f;gravity=Gravity.CENTER;setTextColor(Color.rgb(30,30,30))},LinearLayout.LayoutParams(0,dp(48),1f))
        top.addView(buttonStyle("›").apply{setOnClickListener{calendarWeekStart=calendarWeekStart.plusWeeks(1);calendarScreen()}},LinearLayout.LayoutParams(dp(52),dp(48)))
        root.addView(top)
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL};actions.addView(buttonStyle("＋ Appuntamento").apply{setOnClickListener{appointmentDialog(null)}},LinearLayout.LayoutParams(0,dp(48),1f));actions.addView(buttonStyle("Oggi").apply{setOnClickListener{calendarWeekStart=LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));calendarScreen()}},LinearLayout.LayoutParams(dp(90),dp(48)));root.addView(actions,LinearLayout.LayoutParams(-1,dp(52)))
        val titleRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        titleRow.addView(TextView(this).apply{text="${calendarWeekStart.format(fmt)}  →  ${calendarWeekStart.plusDays(6).format(fmt)}";textSize=14f;setTextColor(Color.DKGRAY);gravity=Gravity.CENTER;setPadding(0,dp(4),0,dp(8))},LinearLayout.LayoutParams(0,dp(34),1f))
        val zoomLabel=TextView(this).apply{text="${(calendarZoom*100).toInt()}%";textSize=12f;setTextColor(Color.GRAY);gravity=Gravity.CENTER}
        titleRow.addView(buttonStyle("−").apply{setOnClickListener{calendarZoom=(calendarZoom-0.25f).coerceAtLeast(0.75f);calendarScreen()}},LinearLayout.LayoutParams(dp(44),dp(34)))
        titleRow.addView(zoomLabel,LinearLayout.LayoutParams(dp(44),dp(34)))
        titleRow.addView(buttonStyle("+").apply{setOnClickListener{calendarZoom=(calendarZoom+0.25f).coerceAtMost(1.75f);calendarScreen()}},LinearLayout.LayoutParams(dp(44),dp(34)))
        root.addView(titleRow,LinearLayout.LayoutParams(-1,dp(38)))
        val verticalScroll=ScrollView(this).apply{isFillViewport=false}
        val horizontalScroll=HorizontalScrollView(this).apply{isFillViewport=false;isHorizontalScrollBarEnabled=true}
        val week=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        for(i in 0..6)week.addView(dayColumn(calendarWeekStart.plusDays(i.toLong())),LinearLayout.LayoutParams((dp(178)*calendarZoom).toInt().coerceAtLeast(dp(132)),-2))
        horizontalScroll.addView(week,ViewGroup.LayoutParams(-2,-2))
        verticalScroll.addView(horizontalScroll,ViewGroup.LayoutParams(-2,-2))
        root.addView(verticalScroll,LinearLayout.LayoutParams(-1,0,1f))
        root.addView(buttonStyle("← Torna ai clienti").apply{setOnClickListener{build()}},LinearLayout.LayoutParams(-1,dp(48)))
        setContentView(root)
    }

    private fun dayColumn(day:LocalDate):View{
        val z=calendarZoom
        val col=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding((dp(4)*z).toInt(),0,(dp(4)*z).toInt(),(dp(4)*z).toInt())}
        val today=day==LocalDate.now()
        val headerBg=GradientDrawable().apply{cornerRadius=(dp(12)*z);setColor(if(today)Color.rgb(232,242,255)else Color.WHITE);setStroke((dp(1)*z).toInt(),if(today)Color.rgb(145,190,232)else Color.rgb(226,229,234))}
        col.addView(TextView(this).apply{text="${dayShort(day.dayOfWeek.value-1)}\n${day.dayOfMonth.toString().padStart(2,'0')}/${day.monthValue.toString().padStart(2,'0')}";textSize=15f*z;gravity=Gravity.CENTER;setTextColor(if(today)Color.rgb(35,105,180)else Color.rgb(45,45,45));background=headerBg;setPadding(0,(dp(6)*z).toInt(),0,(dp(6)*z).toInt())},LinearLayout.LayoutParams(-1,(dp(58)*z).toInt()).apply{setMargins(0,0,0,(dp(4)*z).toInt())})
        for(slot in 0 until 20){val mins=7*60+slot*45;val hour=mins/60;val minute=mins%60;val time=String.format("%02d:%02d",hour,minute);val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding((dp(5)*z).toInt(),(dp(4)*z).toInt(),(dp(5)*z).toInt(),(dp(4)*z).toInt());background=GradientDrawable().apply{cornerRadius=(dp(9)*z);setColor(if(slot%2==0)Color.WHITE else Color.rgb(250,251,252));setStroke((dp(1)*z).toInt(),Color.rgb(232,234,238))};isClickable=true}
            val items=appointments.filter{it.date==day&&it.time==time}.sortedBy{it.type}
            val countColor=when{items.size>=3->Color.rgb(205,55,55);items.size==2->Color.rgb(210,145,25);else->Color.GRAY}
            val timeRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            timeRow.addView(TextView(this).apply{text=time;textSize=11f*z;setTextColor(Color.rgb(105,110,118));setTypeface(null,android.graphics.Typeface.BOLD)},LinearLayout.LayoutParams(0,(dp(22)*z).toInt(),1f))
            timeRow.addView(TextView(this).apply{text="${items.size}/3";textSize=9f*z;setTextColor(countColor);gravity=Gravity.CENTER},LinearLayout.LayoutParams((dp(30)*z).toInt(),(dp(22)*z).toInt()))
            box.addView(timeRow)
            if(items.isEmpty()){box.addView(TextView(this).apply{text="＋";textSize=18f*z;gravity=Gravity.CENTER;setTextColor(Color.LTGRAY)},LinearLayout.LayoutParams(-1,(dp(42)*z).toInt()));box.setOnClickListener{appointmentDialogForSlot(day,time)}}
            else{val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                items.forEachIndexed{index,a->row.addView(appointmentChip(a),LinearLayout.LayoutParams(0,(dp(46)*z).toInt(),1f).apply{if(index>0)setMargins((dp(3)*z).toInt(),0,0,0)})}
                box.addView(row,LinearLayout.LayoutParams(-1,(dp(46)*z).toInt()))
                box.addView(TextView(this).apply{text="${items.count{it.type=="ALLENAMENTO"}}/2 allenamenti";textSize=8.5f*z;setTextColor(Color.GRAY);gravity=Gravity.CENTER_VERTICAL;setPadding(0,(dp(2)*z).toInt(),0,0)},LinearLayout.LayoutParams(-1,(dp(16)*z).toInt()))
                box.setOnClickListener{appointmentDialogForSlot(day,time)}
            }
            col.addView(box,LinearLayout.LayoutParams(-1,(dp(84)*z).toInt()).apply{setMargins(0,(dp(2)*z).toInt(),0,0)})
        }
        return col
    }

    private fun appointmentChip(a:Appointment):View{
        val isHalf=a.type=="MEZZ'ORA"
        val accent=if(isHalf)Color.rgb(215,55,55)else Color.rgb(45,135,210)
        val bg=if(isHalf)Color.rgb(255,239,239)else Color.rgb(232,244,255)
        val chip=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding((dp(3)*calendarZoom).toInt(),(dp(2)*calendarZoom).toInt(),(dp(3)*calendarZoom).toInt(),(dp(2)*calendarZoom).toInt());background=GradientDrawable().apply{cornerRadius=(dp(11)*calendarZoom);setColor(bg);setStroke((dp(1)*calendarZoom).toInt(),accent)};isClickable=true}
        chip.addView(TextView(this).apply{text="●";textSize=11f*calendarZoom;setTextColor(accent);gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,(dp(13)*calendarZoom).toInt()))
        chip.addView(TextView(this).apply{text=a.name;textSize=9.5f*calendarZoom;setTextColor(Color.rgb(25,30,35));gravity=Gravity.CENTER;maxLines=2;ellipsize=android.text.TextUtils.TruncateAt.END;setTypeface(null,android.graphics.Typeface.BOLD)},LinearLayout.LayoutParams(-1,(dp(25)*calendarZoom).toInt()))
        chip.addView(TextView(this).apply{text=if(isHalf)"30 MIN"else"45 MIN";textSize=7.5f*calendarZoom;setTextColor(accent);gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,(dp(10)*calendarZoom).toInt()))
        chip.setOnClickListener{appointmentActions(a)}
        return chip}

    private fun appointmentActions(a:Appointment){AlertDialog.Builder(this).setTitle("${a.name} • ${a.time}").setItems(arrayOf("✏️ Modifica / sposta","🗑 Elimina")){_,which->if(which==0)appointmentDialog(a)else{appointments.remove(a);saveData();calendarScreen()}}.show()}

    private fun styleOneUiDialog(dialog:AlertDialog){
        dialog.setOnShowListener{
            dialog.window?.setBackgroundDrawable(roundedSurface(Color.WHITE,28))
            dialog.window?.setDimAmount(0.38f)
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.apply{setTextColor(Color.rgb(0,125,110));setAllCaps(false);stateListAnimator=null}
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.apply{setTextColor(Color.rgb(0,125,110));setAllCaps(false);stateListAnimator=null}
        }
    }

    private fun appointmentDialog(existing:Appointment?, forcedDay:LocalDate?=null, forcedTime:String?=null){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(4),dp(14),0)}
        val name=AutoCompleteTextView(this).apply{hint="Cliente";setText(existing?.name?:"");setSingleLine(true);setAdapter(ArrayAdapter(this@MainActivity,android.R.layout.simple_dropdown_item_1line,(packs.map{it.name}+sessionPacks.map{it.name}).distinct().toTypedArray()))}
        val date=EditText(this).apply{hint="Data (gg/mm/aaaa)";inputType=2;setText((existing?.date?:forcedDay?:calendarWeekStart).format(fmt))};setupDateInput(date)
        val time=Spinner(this)
        val type=Spinner(this);type.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("ALLENAMENTO (45 min)","MEZZ'ORA (30 min)"));type.setSelection(if(existing?.type=="MEZZ'ORA")1 else 0)
        box.addView(name);box.addView(date)
        box.addView(TextView(this).apply{text="Fascia oraria disponibile";textSize=13f;setTextColor(Color.DKGRAY);setPadding(0,dp(8),0,dp(3))})
        box.addView(time)
        box.addView(type)

        fun refreshTimeSlots(){
            val selectedType=if(type.selectedItemPosition==1)"MEZZ'ORA" else "ALLENAMENTO"
            val selectedDate=runCatching{parseDate(date.text.toString())}.getOrNull()?: (existing?.date?:forcedDay?:calendarWeekStart)
            val slots=availableTimeSlots(selectedDate,selectedType,existing)
            val values=if(slots.isEmpty()) listOf("NESSUNA FASCIA DISPONIBILE") else slots
            time.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,values)
            val wanted=existing?.time?:forcedTime
            if(wanted!=null){val idx=values.indexOf(wanted);if(idx>=0)time.setSelection(idx)}
        }
        refreshTimeSlots()
        type.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(parent:AdapterView<*>?){ } override fun onItemSelected(parent:AdapterView<*>?,view:View?,position:Int,id:Long){refreshTimeSlots()}}
        date.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){refreshTimeSlots()};override fun afterTextChanged(s:Editable?){}})
        if(existing==null){
            box.addView(TextView(this).apply{text="Ripetizione (facoltativa)";textSize=14f;setTextColor(Color.DKGRAY);setPadding(0,dp(10),0,dp(4))})
            val repeat=CheckBox(this).apply{text="Ripeti ogni settimana"}
            val days=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE}
            val checks=(0..6).map{i->CheckBox(this).apply{text=dayShort(i);isChecked=i==((forcedDay?:calendarWeekStart).dayOfWeek.value-1);setPadding(0,0,0,0)}}
            checks.forEach{days.addView(it)}
            val end=EditText(this).apply{hint="Fine ripetizione (gg/mm/aaaa)";inputType=2;setText(calendarWeekStart.plusWeeks(12).format(fmt));visibility=View.GONE};setupDateInput(end)
            repeat.setOnCheckedChangeListener{_,checked->days.visibility=if(checked)View.VISIBLE else View.GONE;end.visibility=if(checked)View.VISIBLE else View.GONE}
            box.addView(repeat);box.addView(days);box.addView(end)
            AlertDialog.Builder(this).setTitle("Nuovo appuntamento").setView(box).setNegativeButton("Annulla",null).setPositiveButton("SALVA"){_,_->createAppointments(name.text.toString().trim(),date.text.toString(),time.selectedItem?.toString() ?: "",if(type.selectedItemPosition==1)"MEZZ'ORA" else "ALLENAMENTO",repeat.isChecked,checks,end.text.toString())}.create().also{styleOneUiDialog(it);it.show()}
        }else{
            AlertDialog.Builder(this).setTitle("Modifica appuntamento").setView(box).setNegativeButton("Annulla",null).setPositiveButton("SALVA"){_,_->updateAppointment(existing,name.text.toString().trim(),date.text.toString(),time.selectedItem?.toString() ?: "",if(type.selectedItemPosition==1)"MEZZ'ORA" else "ALLENAMENTO")}.create().also{styleOneUiDialog(it);it.show()}
        }
    }

    private fun dayShort(i:Int)=arrayOf("Lunedì","Martedì","Mercoledì","Giovedì","Venerdì","Sabato","Domenica")[i]
    private fun createAppointments(name:String,dateText:String,timeText:String,type:String,repeat:Boolean,checks:List<CheckBox>,endText:String,allowWarnings:Boolean=false){
        try{
            val cleanName=normalizeDisplayName(name);require(cleanName.isNotEmpty());val start=parseDate(dateText);val time=normalizeTime(timeText);val linked=activeSessionPackFor(cleanName)
            if(!allowWarnings){
                val duplicateDates=if(repeat){
                    val end=runCatching{parseDate(endText)}.getOrNull()?:start
                    val selected=checks.mapIndexedNotNull{idx,c->if(c.isChecked)idx+1 else null}.toSet()
                    appointments.filter{identityKey(it.name)==identityKey(cleanName)&&selected.contains(it.date.dayOfWeek.value)&&!it.date.isBefore(start)&&!it.date.isAfter(end)}.map{it.date}.distinct().sorted()
                }else appointments.filter{identityKey(it.name)==identityKey(cleanName)&&it.date==start}.map{it.date}
                if(duplicateDates.isNotEmpty()){
                    val first=appointments.filter{identityKey(it.name)==identityKey(cleanName)&&duplicateDates.contains(it.date)}.sortedWith(compareBy<Appointment>{it.date}.thenBy{it.time}).first()
                    AlertDialog.Builder(this).setTitle("⚠️ Appuntamento già presente").setMessage(if(repeat)"$cleanName ha già appuntamenti in ${duplicateDates.size} giorno/i della ripetizione. Primo trovato: ${first.date.format(fmt)} alle ${first.time}. Vuoi comunque crearli?" else "$cleanName ha già un appuntamento il ${first.date.format(fmt)} alle ${first.time}. Vuoi comunque creare un altro appuntamento oggi?").setNegativeButton("ANNULLA",null).setPositiveButton("CREA COMUNQUE"){_,_->createAppointments(cleanName,dateText,timeText,type,repeat,checks,endText,true)}.show()
                    return
                }
                if(linked!=null){
                    val remaining=linked.totalSessions-sessionUsed(linked)
                    val potential=if(!repeat)1 else run {
                        val end=runCatching{parseDate(endText)}.getOrNull()?:start
                        val selected=checks.mapIndexedNotNull{idx,c->if(c.isChecked)idx+1 else null}.toSet()
                        var d=start;var count=0
                        while(!d.isAfter(end)){if(selected.contains(d.dayOfWeek.value)&&canAdd(d,time,type))count++;d=d.plusDays(1)}
                        count
                    }
                    if(remaining>0&&potential>=remaining){
                        AlertDialog.Builder(this).setTitle("⚠️ Ultima seduta del pacchetto").setMessage("Questa prenotazione utilizzerà l'ultima seduta disponibile di $cleanName. Dopo questa prenotazione il pacchetto risulterà scaduto. Vuoi continuare?").setNegativeButton("ANNULLA",null).setPositiveButton("CONTINUA"){_,_->createAppointments(cleanName,dateText,timeText,type,repeat,checks,endText,true)}.show()
                        return
                    }
                }
            }
            if(!repeat){
                if(!canAdd(start,time,type))throw IllegalArgumentException("Fascia piena")
                if(linked!=null&&sessionUsed(linked)>=linked.totalSessions)throw IllegalArgumentException("Pacchetto sedute pieno")
                appointments.add(Appointment(nextAppointmentId++,cleanName,start,time,type,0L,linked?.id?:0L));saveData();calendarScreen();return
            }
            val end=parseDate(endText);require(!end.isBefore(start));val selected=checks.mapIndexedNotNull{idx,c->if(c.isChecked)idx+1 else null};require(selected.isNotEmpty());val series=nextAppointmentId;var d=start;var count=0;var sessionAdded=0
            while(!d.isAfter(end)){
                if(selected.contains(d.dayOfWeek.value)){
                    if(linked!=null&&sessionUsed(linked)+sessionAdded>=linked.totalSessions){count++;d=d.plusDays(1);continue}
                    if(canAdd(d,time,type)){appointments.add(Appointment(nextAppointmentId++,cleanName,d,time,type,series,linked?.id?:0L));sessionAdded++}else count++
                }
                d=d.plusDays(1)
            }
            saveData();calendarScreen();if(count>0)Toast.makeText(this,"$count ripetizioni non inserite perché la fascia o il pacchetto sedute non erano disponibili.",Toast.LENGTH_LONG).show()
        }catch(e:Exception){Toast.makeText(this,if(e.message=="Fascia piena")"Fascia non disponibile: massimo 3 persone e massimo 2 allenamenti." else "Controlla cliente, data, ora e ripetizione.",Toast.LENGTH_LONG).show()}
    }

    private fun normalizeTime(value:String):String{val clean=value.trim();val parts=clean.split(":");require(parts.size==2);val h=parts[0].toInt();val m=parts[1].toInt();require(h in 7..21&&m in 0..59);require((h*60+m-7*60)%45==0);return String.format("%02d:%02d",h,m)}
    private fun updateAppointment(a:Appointment,name:String,dateText:String,timeText:String,type:String){
        try{
            val cleanName=normalizeDisplayName(name);require(cleanName.isNotEmpty());val date=parseDate(dateText);val time=normalizeTime(timeText)
            val duplicate=appointments.firstOrNull{it!==a&&it.date==date&&identityKey(it.name)==identityKey(cleanName)}
            if(duplicate!=null){
                AlertDialog.Builder(this).setTitle("⚠️ Appuntamento già presente").setMessage("$cleanName ha già un appuntamento il ${date.format(fmt)} alle ${duplicate.time}. Vuoi comunque spostare/modificare questo appuntamento?").setNegativeButton("ANNULLA",null).setPositiveButton("CONTINUA"){_,_->updateAppointmentConfirmed(a,cleanName,date,time,type)}.show();return
            }
            updateAppointmentConfirmed(a,cleanName,date,time,type)
        }catch(_:Exception){Toast.makeText(this,"Controlla i dati dell'appuntamento.",Toast.LENGTH_LONG).show()}
    }

    private fun updateAppointmentConfirmed(a:Appointment,name:String,date:LocalDate,time:String,type:String){
        if(!canAdd(date,time,type,a)){Toast.makeText(this,"Questa fascia non è disponibile.",Toast.LENGTH_LONG).show();return}
        var linked=if(a.sessionPackId!=0L)sessionPacks.firstOrNull{it.id==a.sessionPackId} else null
        if(linked==null)linked=activeSessionPackFor(name)
        if(linked!=null&&a.sessionPackId!=linked.id){
            val usedWithoutThis=sessionUsed(linked)
            if(usedWithoutThis>=linked.totalSessions){Toast.makeText(this,"Il pacchetto sedute è già completo.",Toast.LENGTH_LONG).show();return}
            a.sessionPackId=linked.id
        }
        a.name=name;a.date=date;a.time=time;a.type=type;saveData();calendarScreen()
    }

    private fun appointmentDialogForSlot(day:LocalDate,time:String){appointmentDialog(null,day,time)}

    private fun availableTimeSlots(date:LocalDate,type:String,ignore:Appointment?=null):List<String>{
        return (0 until 20).map{slot->
            val mins=7*60+slot*45
            String.format("%02d:%02d",mins/60,mins%60)
        }.filter{slot->canAdd(date,slot,type,ignore)}
    }

    private fun canAdd(date:LocalDate,time:String,type:String,ignore:Appointment?=null):Boolean{val items=appointments.filter{it.date==date&&it.time==time&&it!==ignore};if(items.size>=3)return false;if(type=="ALLENAMENTO"&&items.count{it.type=="ALLENAMENTO"}>=2)return false;return true}
}
