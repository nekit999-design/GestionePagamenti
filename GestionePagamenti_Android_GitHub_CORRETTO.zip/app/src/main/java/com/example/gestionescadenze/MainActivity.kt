package com.example.gestionescadenze

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.view.*
import android.widget.*
import java.time.*
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

data class Pack(val name:String, val start:LocalDate, val total:Int, var paid:Int=0)

class MainActivity: Activity() {
    val fmt=DateTimeFormatter.ofPattern("dd/MM/yyyy")
    val packs=mutableListOf<Pack>()
    var ferieStart:LocalDate?=null
    var ferieEnd:LocalDate?=null
    lateinit var list:LinearLayout
    lateinit var empty:TextView

    override fun onCreate(b:Bundle?) { super.onCreate(b); build() }

    fun build(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL; setPadding(24,24,24,16)}
        val title=TextView(this).apply{text="Gestione Pagamenti"; textSize=28f; setTextColor(Color.rgb(25,25,25))}
        root.addView(title, LinearLayout.LayoutParams(-1,70))
        val sub=TextView(this).apply{text="Pacchetti clienti • 12 settimane • 3 rate"; textSize=15f}
        root.addView(sub)
        val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val add=Button(this).apply{text="+ Nuovo pacchetto"; setOnClickListener{newPack()}}
        val ferie=Button(this).apply{text="⚙ Chiusura ferie"; setOnClickListener{settings()}}
        buttons.addView(add,LinearLayout.LayoutParams(0,60,1f)); buttons.addView(ferie,LinearLayout.LayoutParams(0,60,1f))
        root.addView(buttons)
        empty=TextView(this).apply{text="Nessun pacchetto inserito."; textSize=18f; setPadding(0,30,0,10)}
        list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val scroll=ScrollView(this); scroll.addView(list)
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root); render()
    }

    fun newPack(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL; setPadding(20,10,20,0)}
        val name=EditText(this).apply{hint="Nome e Cognome"}
        val date=EditText(this).apply{hint="Data inizio (gg/mm/aaaa)"; inputType=2}
        val cost=EditText(this).apply{hint="Costo totale (€)"; inputType=2}
        box.addView(name); box.addView(date); box.addView(cost)
        AlertDialog.Builder(this).setTitle("Nuovo pacchetto").setView(box)
          .setNegativeButton("Annulla",null).setPositiveButton("Crea"){_,_->
            try{
              val n=name.text.toString().trim(); val d=LocalDate.parse(date.text.toString(),fmt); val c=cost.text.toString().toInt()
              if(n.isNotEmpty()&&c>0){packs.add(Pack(n,d,c)); render()}
            }catch(_:Exception){Toast.makeText(this,"Controlla nome, data e costo.",Toast.LENGTH_LONG).show()}
          }.show()
    }

    fun settings(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,0,20,0)}
        val s=EditText(this).apply{hint="Inizio chiusura (gg/mm/aaaa)";inputType=2}
        val e=EditText(this).apply{hint="Fine chiusura (gg/mm/aaaa)";inputType=2}
        box.addView(s);box.addView(e)
        AlertDialog.Builder(this).setTitle("Chiusura feriale").setView(box)
          .setNegativeButton("Annulla",null).setPositiveButton("Salva"){_,_->
            try{ferieStart=LocalDate.parse(s.text.toString(),fmt);ferieEnd=LocalDate.parse(e.text.toString(),fmt);render()}
            catch(_:Exception){Toast.makeText(this,"Date non valide.",Toast.LENGTH_LONG).show()}
          }.show()
    }

    fun dueDates(p:Pack):List<LocalDate>{
        val out=mutableListOf<LocalDate>(); var d=p.start
        repeat(3){out.add(d); d=advance(d,28)}
        return out
    }
    fun advance(d0:LocalDate, days:Int):LocalDate{
        var d=d0.plusDays(days.toLong())
        if(ferieStart!=null&&ferieEnd!=null && !d.isBefore(ferieStart)&&!d.isAfter(ferieEnd)) d=ferieEnd!!.plusDays(1)
        return d
    }
    fun render(){
        list.removeAllViews()
        empty.visibility=if(packs.isEmpty())View.VISIBLE else View.GONE
        val sorted=packs.sortedWith(compareBy<Pack>{it.paid>=it.total}.thenBy{it.start})
        for(p in sorted) card(p)
    }
    fun card(p:Pack){
        val rate1=p.total/3; val rates=listOf(rate1,rate1,p.total-rate1*2)
        val dates=dueDates(p)
        val next=(0..2).firstOrNull{rates[it]>0 && (p.paid < rates.take(it+1).sum())}
        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,14,18,14);setBackgroundColor(Color.rgb(245,247,250))}
        val h=TextView(this).apply{text="${p.name}  •  ${if(p.paid>=p.total)"IN REGOLA" else "DA PAGARE"}";textSize=19f}
        card.addView(h)
        card.addView(TextView(this).apply{text="Partenza: ${p.start.format(fmt)}   Totale: €${p.total}";textSize=14f})
        for(i in 0..2){
            val paidSoFar=rates.take(i+1).sum()
            val isPaid=p.paid>=paidSoFar
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
            val t=TextView(this).apply{text="Rata ${i+1}: €${rates[i]}  •  ${dates[i].format(fmt)}${if(isPaid)"  ✓ pagata" else ""}";textSize=15f}
            row.addView(t,LinearLayout.LayoutParams(0,55,1f))
            if(!isPaid && (next==i)){
                row.addView(Button(this).apply{text="PAGA";setOnClickListener{p.paid=paidSoFar;render()}})
            }
            card.addView(row)
        }
        val edit=Button(this).apply{text="Modifica / elimina";setOnClickListener{manage(p)}}
        card.addView(edit)
        val lp=LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,10,0,10);list.addView(card,lp)
    }
    fun manage(p:Pack){
        AlertDialog.Builder(this).setTitle(p.name)
          .setItems(arrayOf("Segna tutto pagato","Elimina pacchetto")){_,which->
            if(which==0){p.paid=p.total;render()} else {packs.remove(p);render()}
          }.show()
    }
}